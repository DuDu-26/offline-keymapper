package a5;

import java.util.List;
import javax.net.ssl.SSLSocket;
import org.conscrypt.Conscrypt;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j f314a = new j();
    public static final boolean b;

    static {
        boolean z6 = false;
        try {
            Class.forName("org.conscrypt.Conscrypt$Version", false, k.class.getClassLoader());
            if (Conscrypt.isAvailable()) {
                if (k.a()) {
                    z6 = true;
                }
            }
        } catch (ClassNotFoundException | NoClassDefFoundError unused) {
        }
        b = z6;
    }

    @Override // a5.o
    public final String a(SSLSocket sSLSocket) {
        if (c(sSLSocket)) {
            return Conscrypt.getApplicationProtocol(sSLSocket);
        }
        return null;
    }

    @Override // a5.o
    public final boolean b() {
        return b;
    }

    @Override // a5.o
    public final boolean c(SSLSocket sSLSocket) {
        return Conscrypt.isConscrypt(sSLSocket);
    }

    @Override // a5.o
    public final void d(SSLSocket sSLSocket, String str, List list) {
        list.getClass();
        if (c(sSLSocket)) {
            Conscrypt.setUseSessionTickets(sSLSocket, true);
            z4.f fVar = z4.f.f9209a;
            Conscrypt.setApplicationProtocols(sSLSocket, (String[]) q.n.c(list).toArray(new String[0]));
        }
    }
}
