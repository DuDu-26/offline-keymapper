package a5;

import javax.net.ssl.SSLSocket;
import org.conscrypt.Conscrypt;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j implements m {
    @Override // a5.m
    public final boolean c(SSLSocket sSLSocket) {
        return l.b && Conscrypt.isConscrypt(sSLSocket);
    }

    @Override // a5.m
    public final o d(SSLSocket sSLSocket) {
        return new l();
    }
}
