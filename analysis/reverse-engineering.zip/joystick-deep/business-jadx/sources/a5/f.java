package a5;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class f implements o {
    public static final y1.e e = new y1.e(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f310a;
    public final Method b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Method f311c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Method f312d;

    public f(Class cls) throws NoSuchMethodException {
        this.f310a = cls;
        Method declaredMethod = cls.getDeclaredMethod(v.m.p.abcdstr(140), Boolean.TYPE);
        declaredMethod.getClass();
        this.b = declaredMethod;
        cls.getMethod(v.m.p.abcdstr(141), String.class);
        this.f311c = cls.getMethod(v.m.p.abcdstr(142), null);
        this.f312d = cls.getMethod(v.m.p.abcdstr(143), byte[].class);
    }

    @Override // a5.o
    public final String a(SSLSocket sSLSocket) {
        if (this.f310a.isInstance(sSLSocket)) {
            try {
                byte[] bArr = (byte[]) this.f311c.invoke(sSLSocket, null);
                if (bArr != null) {
                    return new String(bArr, w2.a.f8523a);
                }
            } catch (IllegalAccessException e3) {
                throw new AssertionError(e3);
            } catch (InvocationTargetException e7) {
                Throwable cause = e7.getCause();
                if (!(cause instanceof NullPointerException) || !q2.c.a(((NullPointerException) cause).getMessage(), v.m.p.abcdstr(144))) {
                    throw new AssertionError(e7);
                }
            }
        }
        return null;
    }

    @Override // a5.o
    public final boolean b() {
        boolean z6 = z4.c.e;
        return z4.c.e;
    }

    @Override // a5.o
    public final boolean c(SSLSocket sSLSocket) {
        return this.f310a.isInstance(sSLSocket);
    }

    @Override // a5.o
    public final void d(SSLSocket sSLSocket, String str, List list) {
        list.getClass();
        if (this.f310a.isInstance(sSLSocket)) {
            try {
                this.b.invoke(sSLSocket, Boolean.TRUE);
                Method method = this.f312d;
                z4.f fVar = z4.f.f9209a;
                method.invoke(sSLSocket, q.n.d(list));
            } catch (IllegalAccessException e3) {
                throw new AssertionError(e3);
            } catch (InvocationTargetException e7) {
                throw new AssertionError(e7);
            }
        }
    }
}
