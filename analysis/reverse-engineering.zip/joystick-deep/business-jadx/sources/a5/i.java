package a5;

import java.util.List;
import javax.net.ssl.SSLSocket;
import org.bouncycastle.jsse.BCSSLParameters;
import org.bouncycastle.jsse.BCSSLSocket;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f313a = new g();
    public static final boolean b;

    static {
        boolean z6 = false;
        try {
            Class.forName("org.bouncycastle.jsse.provider.BouncyCastleJsseProvider", false, h.class.getClassLoader());
            z6 = true;
        } catch (ClassNotFoundException unused) {
        }
        b = z6;
    }

    @Override // a5.o
    public final String a(SSLSocket sSLSocket) {
        String applicationProtocol = ((BCSSLSocket) sSLSocket).getApplicationProtocol();
        if (applicationProtocol == null || applicationProtocol.equals("")) {
            return null;
        }
        return applicationProtocol;
    }

    @Override // a5.o
    public final boolean b() {
        return b;
    }

    @Override // a5.o
    public final boolean c(SSLSocket sSLSocket) {
        return false;
    }

    @Override // a5.o
    public final void d(SSLSocket sSLSocket, String str, List list) {
        list.getClass();
        if (c(sSLSocket)) {
            BCSSLSocket bCSSLSocket = (BCSSLSocket) sSLSocket;
            BCSSLParameters parameters = bCSSLSocket.getParameters();
            z4.f fVar = z4.f.f9209a;
            parameters.setApplicationProtocols((String[]) q.n.c(list).toArray(new String[0]));
            bCSSLSocket.setParameters(parameters);
        }
    }
}
