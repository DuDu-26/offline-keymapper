package a5;

import a4.y0;
import android.app.AppOpsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EdgeEffect;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.f3;
import androidx.appcompat.widget.n2;
import androidx.emoji2.text.q;
import androidx.recyclerview.widget.i1;
import androidx.recyclerview.widget.u0;
import com.efs.sdk.base.Constants;
import com.google.android.material.datepicker.h0;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;
import com.umeng.analytics.pro.bc;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.UMErrorCode;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import f0.a0;
import f0.b0;
import f0.s0;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.WeakHashMap;
import moe.heroman.eventtest.adbhelper.AdbMessage;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.xmlpull.v1.XmlSerializer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class h {
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0047, code lost:
    
        if (r5.f8507c == r8.hashCode()) goto L21;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.content.res.ColorStateList A(android.content.Context r8, int r9) {
        /*
            android.content.res.Resources r0 = r8.getResources()
            android.content.res.Resources$Theme r8 = r8.getTheme()
            w.l r1 = new w.l
            r1.<init>(r0, r8)
            java.lang.Object r2 = w.n.f8510c
            monitor-enter(r2)
            java.util.WeakHashMap r3 = w.n.b     // Catch: java.lang.Throwable -> L3c
            java.lang.Object r3 = r3.get(r1)     // Catch: java.lang.Throwable -> L3c
            android.util.SparseArray r3 = (android.util.SparseArray) r3     // Catch: java.lang.Throwable -> L3c
            r4 = 0
            if (r3 == 0) goto L50
            int r5 = r3.size()     // Catch: java.lang.Throwable -> L3c
            if (r5 <= 0) goto L50
            java.lang.Object r5 = r3.get(r9)     // Catch: java.lang.Throwable -> L3c
            w.k r5 = (w.k) r5     // Catch: java.lang.Throwable -> L3c
            if (r5 == 0) goto L50
            android.content.res.Configuration r6 = r5.b     // Catch: java.lang.Throwable -> L3c
            android.content.res.Configuration r7 = r0.getConfiguration()     // Catch: java.lang.Throwable -> L3c
            boolean r6 = r6.equals(r7)     // Catch: java.lang.Throwable -> L3c
            if (r6 == 0) goto L4d
            if (r8 != 0) goto L3f
            int r6 = r5.f8507c     // Catch: java.lang.Throwable -> L3c
            if (r6 == 0) goto L49
            goto L3f
        L3c:
            r8 = move-exception
            goto Laf
        L3f:
            if (r8 == 0) goto L4d
            int r6 = r5.f8507c     // Catch: java.lang.Throwable -> L3c
            int r7 = r8.hashCode()     // Catch: java.lang.Throwable -> L3c
            if (r6 != r7) goto L4d
        L49:
            android.content.res.ColorStateList r3 = r5.f8506a     // Catch: java.lang.Throwable -> L3c
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L3c
            goto L52
        L4d:
            r3.remove(r9)     // Catch: java.lang.Throwable -> L3c
        L50:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L3c
            r3 = r4
        L52:
            if (r3 == 0) goto L55
            return r3
        L55:
            java.lang.ThreadLocal r2 = w.n.f8509a
            java.lang.Object r3 = r2.get()
            android.util.TypedValue r3 = (android.util.TypedValue) r3
            if (r3 != 0) goto L67
            android.util.TypedValue r3 = new android.util.TypedValue
            r3.<init>()
            r2.set(r3)
        L67:
            r2 = 1
            r0.getValue(r9, r3, r2)
            int r2 = r3.type
            r3 = 28
            if (r2 < r3) goto L76
            r3 = 31
            if (r2 > r3) goto L76
            goto L7e
        L76:
            android.content.res.XmlResourceParser r2 = r0.getXml(r9)
            android.content.res.ColorStateList r4 = w.c.a(r0, r2, r8)     // Catch: java.lang.Exception -> L7e
        L7e:
            if (r4 == 0) goto Laa
            java.lang.Object r2 = w.n.f8510c
            monitor-enter(r2)
            java.util.WeakHashMap r0 = w.n.b     // Catch: java.lang.Throwable -> L96
            java.lang.Object r3 = r0.get(r1)     // Catch: java.lang.Throwable -> L96
            android.util.SparseArray r3 = (android.util.SparseArray) r3     // Catch: java.lang.Throwable -> L96
            if (r3 != 0) goto L98
            android.util.SparseArray r3 = new android.util.SparseArray     // Catch: java.lang.Throwable -> L96
            r3.<init>()     // Catch: java.lang.Throwable -> L96
            r0.put(r1, r3)     // Catch: java.lang.Throwable -> L96
            goto L98
        L96:
            r8 = move-exception
            goto La8
        L98:
            w.k r0 = new w.k     // Catch: java.lang.Throwable -> L96
            android.content.res.Resources r1 = r1.f8508a     // Catch: java.lang.Throwable -> L96
            android.content.res.Configuration r1 = r1.getConfiguration()     // Catch: java.lang.Throwable -> L96
            r0.<init>(r4, r1, r8)     // Catch: java.lang.Throwable -> L96
            r3.append(r9, r0)     // Catch: java.lang.Throwable -> L96
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L96
            goto Lae
        La8:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L96
            throw r8
        Laa:
            android.content.res.ColorStateList r4 = w.j.b(r0, r9, r8)
        Lae:
            return r4
        Laf:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L3c
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.h.A(android.content.Context, int):android.content.res.ColorStateList");
    }

    public static e0.b B(Long l7, Long l8) {
        if (l7 == null && l8 == null) {
            return new e0.b(null, null);
        }
        if (l7 == null) {
            return new e0.b(null, C(l8.longValue()));
        }
        if (l8 == null) {
            return new e0.b(C(l7.longValue()), null);
        }
        Calendar calendarF = h0.f();
        Calendar calendarG = h0.g(null);
        calendarG.setTimeInMillis(l7.longValue());
        Calendar calendarG2 = h0.g(null);
        calendarG2.setTimeInMillis(l8.longValue());
        return calendarG.get(1) == calendarG2.get(1) ? calendarG.get(1) == calendarF.get(1) ? new e0.b(G(l7.longValue(), Locale.getDefault()), G(l8.longValue(), Locale.getDefault())) : new e0.b(G(l7.longValue(), Locale.getDefault()), L(l8.longValue(), Locale.getDefault())) : new e0.b(L(l7.longValue(), Locale.getDefault()), L(l8.longValue(), Locale.getDefault()));
    }

    public static String C(long j7) {
        Calendar calendarF = h0.f();
        Calendar calendarG = h0.g(null);
        calendarG.setTimeInMillis(j7);
        return calendarF.get(1) == calendarG.get(1) ? G(j7, Locale.getDefault()) : L(j7, Locale.getDefault());
    }

    public static float D(EdgeEffect edgeEffect) {
        if (Build.VERSION.SDK_INT >= 31) {
            return androidx.core.widget.e.b(edgeEffect);
        }
        return 0.0f;
    }

    public static Drawable E(Context context, int i7) {
        return n2.b().c(context, i7);
    }

    public static String F(Context context, int i7) {
        if (i7 == 87) {
            return v.m.p.abcdstr(224);
        }
        if (i7 == 88) {
            return v.m.p.abcdstr(223);
        }
        if (i7 == 119) {
            return context.getString(2131820761);
        }
        if (i7 == 512) {
            return context.getString(2131820772);
        }
        if (i7 == 513) {
            return context.getString(2131820771);
        }
        switch (i7) {
            case 1:
                return v.m.p.abcdstr(222);
            case 2:
                return v.m.p.abcdstr(221);
            case 3:
                return v.m.p.abcdstr(220);
            case 4:
                return v.m.p.abcdstr(219);
            case 5:
                return v.m.p.abcdstr(218);
            case 6:
                return v.m.p.abcdstr(217);
            case dd.f4082h /* 7 */:
                return v.m.p.abcdstr(216);
            case 8:
                return v.m.p.abcdstr(215);
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                return v.m.p.abcdstr(214);
            case 10:
                return v.m.p.abcdstr(213);
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                return v.m.p.abcdstr(212);
            case 12:
                return v.m.p.abcdstr(211);
            case 13:
                return v.m.p.abcdstr(210);
            case 14:
                return context.getString(2131820738);
            case 15:
                return context.getString(2131820769);
            case 16:
                return v.m.p.abcdstr(209);
            case 17:
                return v.m.p.abcdstr(208);
            case 18:
                return v.m.p.abcdstr(207);
            case 19:
                return v.m.p.abcdstr(206);
            case 20:
                return v.m.p.abcdstr(205);
            case 21:
                return v.m.p.abcdstr(204);
            case 22:
                return v.m.p.abcdstr(203);
            case 23:
                return v.m.p.abcdstr(202);
            case AdbMessage.HEADER_LENGTH /* 24 */:
                return v.m.p.abcdstr(201);
            case 25:
                return v.m.p.abcdstr(200);
            case 26:
                return v.m.p.abcdstr(199);
            case 27:
                return v.m.p.abcdstr(198);
            case 28:
                return context.getString(2131820742);
            case 29:
                return context.getString(2131820746);
            case 30:
                return v.m.p.abcdstr(197);
            case 31:
                return v.m.p.abcdstr(196);
            case com.umeng.analytics.a.f3643d /* 32 */:
                return v.m.p.abcdstr(195);
            case 33:
                return v.m.p.abcdstr(194);
            case 34:
                return v.m.p.abcdstr(193);
            case 35:
                return v.m.p.abcdstr(192);
            case 36:
                return v.m.p.abcdstr(191);
            case 37:
                return v.m.p.abcdstr(190);
            case 38:
                return v.m.p.abcdstr(189);
            case 39:
                return v.m.p.abcdstr(188);
            case 40:
                return v.m.p.abcdstr(187);
            case 41:
                return v.m.p.abcdstr(186);
            case 42:
                return context.getString(2131820747);
            case 43:
                return v.m.p.abcdstr(185);
            case 44:
                return v.m.p.abcdstr(184);
            case 45:
                return v.m.p.abcdstr(183);
            case 46:
                return v.m.p.abcdstr(182);
            case 47:
                return v.m.p.abcdstr(181);
            case 48:
                return v.m.p.abcdstr(180);
            case 49:
                return v.m.p.abcdstr(179);
            case 50:
                return v.m.p.abcdstr(178);
            case 51:
                return v.m.p.abcdstr(177);
            case 52:
                return v.m.p.abcdstr(176);
            case 53:
                return v.m.p.abcdstr(175);
            case 54:
                return context.getString(2131820765);
            case 55:
                return v.m.p.abcdstr(174);
            case 56:
                return context.getString(2131820745);
            case 57:
                return context.getString(2131820768);
            case 58:
                return context.getString(2131820739);
            case 59:
                return v.m.p.abcdstr(173);
            case 60:
                return v.m.p.abcdstr(172);
            case 61:
                return v.m.p.abcdstr(171);
            case 62:
                return v.m.p.abcdstr(170);
            case 63:
                return v.m.p.abcdstr(169);
            case 64:
                return v.m.p.abcdstr(168);
            case 65:
                return v.m.p.abcdstr(167);
            case 66:
                return v.m.p.abcdstr(166);
            case 67:
                return v.m.p.abcdstr(165);
            case 68:
                return v.m.p.abcdstr(164);
            case 69:
                return context.getString(2131820758);
            case 70:
                return context.getString(2131820767);
            case 71:
                return v.m.p.abcdstr(163);
            case 72:
                return v.m.p.abcdstr(162);
            case 73:
                return v.m.p.abcdstr(161);
            case 74:
                return v.m.p.abcdstr(160);
            case 75:
                return v.m.p.abcdstr(159);
            case 76:
                return v.m.p.abcdstr(158);
            case 77:
                return v.m.p.abcdstr(157);
            case 78:
                return v.m.p.abcdstr(156);
            case 79:
                return v.m.p.abcdstr(155);
            case 80:
                return v.m.p.abcdstr(154);
            case 81:
                return v.m.p.abcdstr(153);
            case 82:
                return v.m.p.abcdstr(152);
            case 83:
                return v.m.p.abcdstr(151);
            default:
                switch (i7) {
                    case 96:
                        return v.m.p.abcdstr(150);
                    case 97:
                        return context.getString(2131820764);
                    case 98:
                        return v.m.p.abcdstr(149);
                    case 99:
                        return context.getString(2131820762);
                    case bc.f3797f /* 100 */:
                        return context.getString(2131820763);
                    default:
                        switch (i7) {
                            case 102:
                                return context.getString(2131820743);
                            case 103:
                                return v.m.p.abcdstr(148);
                            case 104:
                                return context.getString(2131820760);
                            case 105:
                                return v.m.p.abcdstr(147);
                            case 106:
                                return v.m.p.abcdstr(146);
                            case 107:
                                return context.getString(2131820741);
                            case 108:
                                return v.m.p.abcdstr(145);
                            case 109:
                                return context.getString(2131820759);
                            case UMErrorCode.E_UM_BE_JSON_FAILED /* 110 */:
                                return context.getString(2131820744);
                            case UMErrorCode.E_UM_BE_CREATE_FAILED /* 111 */:
                                return context.getString(2131820740);
                            default:
                                switch (i7) {
                                    case 125:
                                        return context.getString(2131820748);
                                    case 126:
                                        return context.getString(2131820766);
                                    case 127:
                                        return context.getString(2131820749);
                                    default:
                                        switch (i7) {
                                            case 272:
                                                return context.getString(2131820751);
                                            case com.umeng.commonsdk.stateless.b.f4827a /* 273 */:
                                                return context.getString(2131820753);
                                            case 274:
                                                return context.getString(2131820752);
                                            case 275:
                                                return context.getString(2131820754);
                                            case 276:
                                                return context.getString(2131820750);
                                            case 277:
                                                return context.getString(2131820755);
                                            case 278:
                                                return context.getString(2131820756);
                                            case 279:
                                                return context.getString(2131820757);
                                            default:
                                                return context.getString(2131820770, Integer.valueOf(i7));
                                        }
                                }
                        }
                }
        }
    }

    public static String G(long j7, Locale locale) {
        return h0.b(v.m.p.abcdstr(225), locale).format(new Date(j7));
    }

    public static Intent H(androidx.appcompat.app.k kVar) {
        Intent intentA = androidx.core.app.e.a(kVar);
        if (intentA != null) {
            return intentA;
        }
        try {
            String strJ = J(kVar, kVar.getComponentName());
            if (strJ == null) {
                return null;
            }
            ComponentName componentName = new ComponentName(kVar, strJ);
            try {
                return J(kVar, componentName) == null ? Intent.makeMainActivity(componentName) : new Intent().setComponent(componentName);
            } catch (PackageManager.NameNotFoundException unused) {
                Log.e(v.m.p.abcdstr(228), v.m.p.abcdstr(226) + strJ + v.m.p.abcdstr(227));
                return null;
            }
        } catch (PackageManager.NameNotFoundException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static Intent I(androidx.appcompat.app.k kVar, ComponentName componentName) throws PackageManager.NameNotFoundException {
        String strJ = J(kVar, componentName);
        if (strJ == null) {
            return null;
        }
        ComponentName componentName2 = new ComponentName(componentName.getPackageName(), strJ);
        return J(kVar, componentName2) == null ? Intent.makeMainActivity(componentName2) : new Intent().setComponent(componentName2);
    }

    public static String J(Context context, ComponentName componentName) throws PackageManager.NameNotFoundException {
        String string;
        ActivityInfo activityInfo = context.getPackageManager().getActivityInfo(componentName, Build.VERSION.SDK_INT >= 29 ? 269222528 : 787072);
        String str = activityInfo.parentActivityName;
        if (str != null) {
            return str;
        }
        Bundle bundle = activityInfo.metaData;
        if (bundle == null || (string = bundle.getString("android.support.PARENT_ACTIVITY")) == null) {
            return null;
        }
        if (string.charAt(0) != '.') {
            return string;
        }
        return context.getPackageName() + string;
    }

    public static String L(long j7, Locale locale) {
        return h0.b(v.m.p.abcdstr(229), locale).format(new Date(j7));
    }

    public static boolean M() {
        int i7 = Build.VERSION.SDK_INT;
        if (i7 >= 33) {
            return true;
        }
        if (i7 < 32) {
            return false;
        }
        String str = Build.VERSION.CODENAME;
        if (v.m.p.abcdstr(230).equals(str)) {
            return false;
        }
        Locale locale = Locale.ROOT;
        return str.toUpperCase(locale).compareTo(v.m.p.abcdstr(231).toUpperCase(locale)) >= 0;
    }

    public static boolean N(int i7) {
        return (i7 <= 0 || O(i7) || i7 == 512 || i7 == 513) ? false : true;
    }

    public static boolean O(int i7) {
        return i7 >= 272 && i7 <= 279;
    }

    public static void P(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        if (inputConnection == null || editorInfo.hintText != null) {
            return;
        }
        for (ViewParent parent = textView.getParent(); parent instanceof View; parent = parent.getParent()) {
        }
    }

    public static float U(EdgeEffect edgeEffect, float f2, float f7) {
        if (Build.VERSION.SDK_INT >= 31) {
            return androidx.core.widget.e.c(edgeEffect, f2, f7);
        }
        androidx.core.widget.d.a(edgeEffect, f2, f7);
        return f2;
    }

    public static a3.j V(byte[] bArr) {
        if (bArr == null || bArr.length == 0) {
            return null;
        }
        try {
            a3.i iVar = new a3.i(bArr);
            a3.j jVarG = iVar.g(0);
            if (iVar.f25a) {
                return jVarG;
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        }
    }

    public static List W(byte[] bArr) {
        a3.j jVarV = V(bArr);
        return (jVarV == null || jVarV.f27a != 6) ? Collections.EMPTY_LIST : jVarV.f32h;
    }

    public static void Y(Context context, String str) throws IOException {
        String strAbcdstr = v.m.p.abcdstr(232);
        boolean zEquals = str.equals("");
        String strAbcdstr2 = v.m.p.abcdstr(233);
        if (zEquals) {
            context.deleteFile(strAbcdstr2);
            return;
        }
        try {
            FileOutputStream fileOutputStreamOpenFileOutput = context.openFileOutput(strAbcdstr2, 0);
            XmlSerializer xmlSerializerNewSerializer = Xml.newSerializer();
            try {
                xmlSerializerNewSerializer.setOutput(fileOutputStreamOpenFileOutput, null);
                xmlSerializerNewSerializer.startDocument("UTF-8", Boolean.TRUE);
                xmlSerializerNewSerializer.startTag(null, strAbcdstr);
                xmlSerializerNewSerializer.attribute(null, "application_locales", str);
                xmlSerializerNewSerializer.endTag(null, strAbcdstr);
                xmlSerializerNewSerializer.endDocument();
                if (fileOutputStreamOpenFileOutput != null) {
                    fileOutputStreamOpenFileOutput.close();
                }
            } catch (Exception unused) {
                if (fileOutputStreamOpenFileOutput != null) {
                    fileOutputStreamOpenFileOutput.close();
                }
            } catch (Throwable th) {
                if (fileOutputStreamOpenFileOutput != null) {
                    try {
                        fileOutputStreamOpenFileOutput.close();
                    } catch (IOException unused2) {
                    }
                }
                throw th;
            }
        } catch (FileNotFoundException | IOException unused3) {
        }
    }

    public static m0.b Z(MappedByteBuffer mappedByteBuffer) throws IOException {
        long j7;
        ByteBuffer byteBufferDuplicate = mappedByteBuffer.duplicate();
        byteBufferDuplicate.order(ByteOrder.BIG_ENDIAN);
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
        int i7 = byteBufferDuplicate.getShort() & 65535;
        String strAbcdstr = v.m.p.abcdstr(234);
        if (i7 > 100) {
            f3.v(strAbcdstr);
            return null;
        }
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 6);
        int i8 = 0;
        while (true) {
            if (i8 >= i7) {
                j7 = -1;
                break;
            }
            int i9 = byteBufferDuplicate.getInt();
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            j7 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            if (1835365473 == i9) {
                break;
            }
            i8++;
        }
        if (j7 != -1) {
            byteBufferDuplicate.position(byteBufferDuplicate.position() + ((int) (j7 - ((long) byteBufferDuplicate.position()))));
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 12);
            long j8 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            for (int i10 = 0; i10 < j8; i10++) {
                int i11 = byteBufferDuplicate.getInt();
                long j9 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
                byteBufferDuplicate.getInt();
                if (1164798569 == i11 || 1701669481 == i11) {
                    byteBufferDuplicate.position((int) (j9 + j7));
                    m0.b bVar = new m0.b();
                    byteBufferDuplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int iPosition = byteBufferDuplicate.position() + byteBufferDuplicate.getInt(byteBufferDuplicate.position());
                    bVar.f5600d = byteBufferDuplicate;
                    bVar.f5598a = iPosition;
                    int i12 = iPosition - byteBufferDuplicate.getInt(iPosition);
                    bVar.b = i12;
                    bVar.f5599c = ((ByteBuffer) bVar.f5600d).getShort(i12);
                    return bVar;
                }
            }
        }
        f3.v(strAbcdstr);
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x003f, code lost:
    
        r1 = r3.getAttributeValue(null, v.m.p.abcdstr("235"));
     */
    /* JADX WARN: Removed duplicated region for block: B:37:0x004c A[EXC_TOP_SPLITTER, PHI: r1
      0x004c: PHI (r1v3 java.lang.String) = (r1v0 java.lang.String), (r1v5 java.lang.String) binds: [B:27:0x0056, B:21:0x004a] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a0(android.content.Context r8) {
        /*
            r0 = 233(0xe9, float:3.27E-43)
            java.lang.String r0 = v.m.p.abcdstr(r0)
            java.lang.String r1 = ""
            java.io.FileInputStream r2 = r8.openFileInput(r0)     // Catch: java.io.FileNotFoundException -> L63
            org.xmlpull.v1.XmlPullParser r3 = android.util.Xml.newPullParser()     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            java.lang.String r4 = "UTF-8"
            r3.setInput(r2, r4)     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            int r4 = r3.getDepth()     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
        L1a:
            int r5 = r3.next()     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            r6 = 1
            if (r5 == r6) goto L4a
            r6 = 3
            if (r5 != r6) goto L2d
            int r7 = r3.getDepth()     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            if (r7 <= r4) goto L4a
            goto L2d
        L2b:
            r8 = move-exception
            goto L50
        L2d:
            if (r5 == r6) goto L1a
            r6 = 4
            if (r5 != r6) goto L33
            goto L1a
        L33:
            java.lang.String r5 = r3.getName()     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            java.lang.String r6 = "locales"
            boolean r5 = r5.equals(r6)     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            if (r5 == 0) goto L1a
            java.lang.String r4 = "235"
            java.lang.String r4 = v.m.p.abcdstr(r4)     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
            r5 = 0
            java.lang.String r1 = r3.getAttributeValue(r5, r4)     // Catch: java.lang.Throwable -> L2b java.lang.Throwable -> L56
        L4a:
            if (r2 == 0) goto L59
        L4c:
            r2.close()     // Catch: java.io.IOException -> L59
            goto L59
        L50:
            if (r2 == 0) goto L55
            r2.close()     // Catch: java.io.IOException -> L55
        L55:
            throw r8
        L56:
            if (r2 == 0) goto L59
            goto L4c
        L59:
            boolean r2 = r1.isEmpty()
            if (r2 != 0) goto L60
            goto L63
        L60:
            r8.deleteFile(r0)
        L63:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.h.a0(android.content.Context):java.lang.String");
    }

    public static void b0(TextInputLayout textInputLayout, CheckableImageButton checkableImageButton, ColorStateList colorStateList) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (checkableImageButton.getDrawable() == null || colorStateList == null || !colorStateList.isStateful()) {
            return;
        }
        int[] drawableState = textInputLayout.getDrawableState();
        int[] drawableState2 = checkableImageButton.getDrawableState();
        int length = drawableState.length;
        int[] iArrCopyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
        System.arraycopy(drawableState2, 0, iArrCopyOf, length, drawableState2.length);
        int colorForState = colorStateList.getColorForState(iArrCopyOf, colorStateList.getDefaultColor());
        Drawable drawableMutate = drawable.mutate();
        y.b.h(drawableMutate, ColorStateList.valueOf(colorForState));
        checkableImageButton.setImageDrawable(drawableMutate);
    }

    public static byte[] c0(LinkedList linkedList) {
        byte[] bArr = new byte[linkedList.size() * 3];
        Iterator it = linkedList.iterator();
        int i7 = 0;
        while (it.hasNext()) {
            c3.b bVar = (c3.b) it.next();
            int i8 = i7 * 3;
            byte bD = (byte) n.e.d(bVar.b);
            bArr[i8] = bD;
            bArr[i8] = (byte) (bD | ((byte) ((bVar.f2124c ? 1 : 0) << 1)));
            int i9 = bVar.f2125d;
            bArr[i8 + 1] = (byte) ((i9 >> 8) & 255);
            bArr[i8 + 2] = (byte) (i9 & 255);
            i7++;
        }
        return bArr;
    }

    public static void d0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        WeakHashMap weakHashMap = s0.f5582a;
        boolean zA = a0.a(checkableImageButton);
        boolean z6 = onLongClickListener != null;
        boolean z7 = zA || z6;
        checkableImageButton.setFocusable(z7);
        checkableImageButton.setClickable(zA);
        checkableImageButton.setPressable(zA);
        checkableImageButton.setLongClickable(z6);
        b0.s(checkableImageButton, z7 ? 1 : 2);
    }

    public static void e(TextInputLayout textInputLayout, CheckableImageButton checkableImageButton, ColorStateList colorStateList, PorterDuff.Mode mode) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (drawable != null) {
            drawable = drawable.mutate();
            if (colorStateList == null || !colorStateList.isStateful()) {
                y.b.h(drawable, colorStateList);
            } else {
                int[] drawableState = textInputLayout.getDrawableState();
                int[] drawableState2 = checkableImageButton.getDrawableState();
                int length = drawableState.length;
                int[] iArrCopyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
                System.arraycopy(drawableState2, 0, iArrCopyOf, length, drawableState2.length);
                y.b.h(drawable, ColorStateList.valueOf(colorStateList.getColorForState(iArrCopyOf, colorStateList.getDefaultColor())));
            }
            if (mode != null) {
                y.b.i(drawable, mode);
            }
        }
        if (checkableImageButton.getDrawable() != drawable) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public static void f(String str, boolean z6) {
        if (z6) {
            return;
        }
        f3.q(str);
    }

    public static void g(int i7) {
        if (i7 < 0) {
            throw new IllegalArgumentException();
        }
    }

    public static void h(Object obj, String str) {
        if (obj != null) {
            return;
        }
        f3.x(str);
    }

    public static int i(Context context, String str) {
        if (str != null) {
            return (M() || !TextUtils.equals(v.m.p.abcdstr(236), str)) ? context.checkPermission(str, Process.myPid(), Process.myUid()) : new androidx.core.app.g(context).f1038a.areNotificationsEnabled() ? 0 : -1;
        }
        f3.x(v.m.p.abcdstr(237));
        return 0;
    }

    public static int j(Context context, String str) {
        int iC;
        int iMyPid = Process.myPid();
        int iMyUid = Process.myUid();
        String packageName = context.getPackageName();
        if (context.checkPermission(str, iMyPid, iMyUid) != -1) {
            String strD = androidx.core.app.c.d(str);
            if (strD != null) {
                if (packageName == null) {
                    String[] packagesForUid = context.getPackageManager().getPackagesForUid(iMyUid);
                    if (packagesForUid != null && packagesForUid.length > 0) {
                        packageName = packagesForUid[0];
                    }
                }
                int iMyUid2 = Process.myUid();
                String packageName2 = context.getPackageName();
                if (iMyUid2 == iMyUid && e0.a.a(packageName2, packageName) && Build.VERSION.SDK_INT >= 29) {
                    AppOpsManager appOpsManagerC = androidx.core.app.d.c(context);
                    iC = androidx.core.app.d.a(appOpsManagerC, strD, Binder.getCallingUid(), packageName);
                    if (iC == 0) {
                        iC = androidx.core.app.d.a(appOpsManagerC, strD, iMyUid, androidx.core.app.d.b(context));
                    }
                } else {
                    iC = androidx.core.app.c.c((AppOpsManager) androidx.core.app.c.a(context, AppOpsManager.class), strD, packageName);
                }
                if (iC != 0) {
                    return -2;
                }
            }
            return 0;
        }
        return -1;
    }

    public static int k(int i7, int i8, int i9) {
        return i7 < i8 ? i8 : i7 > i9 ? i9 : i7;
    }

    public static int m(i1 i1Var, androidx.emoji2.text.f fVar, View view, View view2, u0 u0Var, boolean z6) {
        if (u0Var.v() == 0 || i1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z6) {
            return Math.abs(u0.J(view) - u0.J(view2)) + 1;
        }
        return Math.min(fVar.l(), fVar.b(view2) - fVar.e(view));
    }

    public static int n(i1 i1Var, androidx.emoji2.text.f fVar, View view, View view2, u0 u0Var, boolean z6, boolean z7) {
        if (u0Var.v() == 0 || i1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        int iMax = z7 ? Math.max(0, (i1Var.b() - Math.max(u0.J(view), u0.J(view2))) - 1) : Math.max(0, Math.min(u0.J(view), u0.J(view2)));
        if (z6) {
            return Math.round((iMax * (Math.abs(fVar.b(view2) - fVar.e(view)) / (Math.abs(u0.J(view) - u0.J(view2)) + 1))) + (fVar.k() - fVar.e(view)));
        }
        return iMax;
    }

    public static int o(i1 i1Var, androidx.emoji2.text.f fVar, View view, View view2, u0 u0Var, boolean z6) {
        if (u0Var.v() == 0 || i1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z6) {
            return i1Var.b();
        }
        return (int) (((fVar.b(view2) - fVar.e(view)) / (Math.abs(u0.J(view) - u0.J(view2)) + 1)) * i1Var.b());
    }

    public static ImageView.ScaleType p(int i7) {
        return i7 != 0 ? i7 != 1 ? i7 != 2 ? i7 != 3 ? i7 != 5 ? i7 != 6 ? ImageView.ScaleType.CENTER : ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_END : ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.FIT_START : ImageView.ScaleType.FIT_XY;
    }

    public static q q(Context context) {
        ProviderInfo providerInfo;
        c0.d dVar;
        ApplicationInfo applicationInfo;
        PackageManager packageManager = context.getPackageManager();
        h(packageManager, v.m.p.abcdstr(238));
        Iterator<ResolveInfo> it = packageManager.queryIntentContentProviders(new Intent(v.m.p.abcdstr(239)), 0).iterator();
        while (true) {
            if (!it.hasNext()) {
                providerInfo = null;
                break;
            }
            providerInfo = it.next().providerInfo;
            if (providerInfo != null && (applicationInfo = providerInfo.applicationInfo) != null && (applicationInfo.flags & 1) == 1) {
                break;
            }
        }
        if (providerInfo == null) {
            dVar = null;
        } else {
            try {
                String str = providerInfo.authority;
                String str2 = providerInfo.packageName;
                Signature[] signatureArr = packageManager.getPackageInfo(str2, 64).signatures;
                ArrayList arrayList = new ArrayList();
                for (Signature signature : signatureArr) {
                    arrayList.add(signature.toByteArray());
                }
                dVar = new c0.d(str, str2, "emojicompat-emoji-font", Collections.singletonList(arrayList));
            } catch (PackageManager.NameNotFoundException e) {
                Log.wtf(v.m.p.abcdstr(240), e);
                dVar = null;
            }
        }
        if (dVar == null) {
            return null;
        }
        return new q(new androidx.emoji2.text.p(context, dVar));
    }

    public static Mat r(int i7, int i8) {
        Mat matP = Mat.p(i8, i7, o6.a.f7243a);
        Imgproc.a(matP, new o6.b(i7 / 2, i8 / 2), Math.min(i7, i8) / 2, new o6.d(255.0d));
        return matP;
    }

    public static c3.a[] t(byte[] bArr) {
        if (bArr.length % 3 != 0) {
            f3.e(bArr.length, v.m.p.abcdstr(241));
            return null;
        }
        int length = bArr.length / 3;
        c3.a[] aVarArr = new c3.a[length];
        for (int i7 = 0; i7 < length; i7++) {
            int i8 = i7 * 3;
            int[] iArrE = n.e.e(2);
            byte b = bArr[i8];
            aVarArr[i7] = new c3.b(iArrE[b & 1], (2 & b) != 0, (bArr[i8 + 2] & 255) | ((bArr[i8 + 1] & 255) << 8));
        }
        return aVarArr;
    }

    public static c3.a[] u(byte[] bArr) {
        if (bArr.length % 8 != 0) {
            f3.e(bArr.length, v.m.p.abcdstr(242));
            return null;
        }
        int length = bArr.length / 8;
        c3.a[] aVarArr = new c3.a[length];
        for (int i7 = 0; i7 < length; i7++) {
            int i8 = i7 * 8;
            aVarArr[i7] = new c3.c(((bArr[i8] & 255) << 24) | ((bArr[i8 + 1] & 255) << 16) | ((bArr[i8 + 2] & 255) << 8) | (bArr[i8 + 3] & 255), (bArr[i8 + 7] & 255) | ((bArr[i8 + 4] & 255) << 24) | ((bArr[i8 + 5] & 255) << 16) | ((bArr[i8 + 6] & 255) << 8));
        }
        return aVarArr;
    }

    public static c3.a[] v(byte[] bArr) {
        if (bArr.length % 4 != 0) {
            f3.e(bArr.length, v.m.p.abcdstr(243));
            return null;
        }
        int length = bArr.length / 4;
        c3.a[] aVarArr = new c3.a[length];
        for (int i7 = 0; i7 < length; i7++) {
            int i8 = i7 * 4;
            aVarArr[i7] = new c3.d((bArr[i8 + 3] & 255) | ((bArr[i8] & 255) << 24) | ((bArr[i8 + 1] & 255) << 16) | ((bArr[i8 + 2] & 255) << 8));
        }
        return aVarArr;
    }

    public static c3.a[] w(byte[] bArr) {
        if (bArr.length % 18 != 0) {
            f3.e(bArr.length, v.m.p.abcdstr(244));
            return null;
        }
        int length = bArr.length / 18;
        c3.a[] aVarArr = new c3.a[length];
        for (int i7 = 0; i7 < length; i7++) {
            int i8 = i7 * 18;
            aVarArr[i7] = new c3.f(n.e.e(3)[bArr[i8]], bArr[i8 + 1], ((bArr[i8 + 2] & 255) << 24) | ((bArr[i8 + 3] & 255) << 16) | ((bArr[i8 + 4] & 255) << 8) | (bArr[i8 + 5] & 255), ((bArr[i8 + 6] & 255) << 24) | ((bArr[i8 + 7] & 255) << 16) | ((bArr[i8 + 8] & 255) << 8) | (bArr[i8 + 9] & 255), ((bArr[i8 + 10] & 255) << 24) | ((bArr[i8 + 11] & 255) << 16) | ((bArr[i8 + 12] & 255) << 8) | (bArr[i8 + 13] & 255), ((bArr[i8 + 14] & 255) << 24) | ((bArr[i8 + 15] & 255) << 16) | ((bArr[i8 + 16] & 255) << 8) | (bArr[i8 + 17] & 255));
        }
        return aVarArr;
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0134  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static c4.g x(android.graphics.Bitmap r21, double r22) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 428
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.h.x(android.graphics.Bitmap, double):c4.g");
    }

    public static c4.g y(Bitmap bitmap) {
        Mat mat = new Mat();
        Mat mat2 = new Mat();
        Mat mat3 = new Mat();
        Mat mat4 = new Mat();
        Mat mat5 = new Mat();
        Mat mat6 = new Mat();
        Mat mat7 = new Mat();
        Mat mat8 = new Mat();
        Mat matR = null;
        try {
            Utils.a(bitmap, mat);
            int iJ = mat.j();
            int iC = mat.c();
            double d3 = 0.0d;
            if (iJ <= 0 || iC <= 0) {
                mat.i();
                mat2.i();
                mat3.i();
            } else {
                matR = r(iC, iJ);
                int iD = Core.d(matR);
                if (iD != 0) {
                    Imgproc.c(mat, mat2, 1);
                    Imgproc.c(mat2, mat3, 41);
                    Core.e(mat3, mat4, 0);
                    Core.e(mat3, mat5, 1);
                    Core.e(mat3, mat6, 2);
                    Imgproc.n(mat6, mat7, 200.0d, 0);
                    Imgproc.n(mat5, mat8, 99.0d, 0);
                    Core.a(mat7, mat8, mat7);
                    Imgproc.n(mat4, mat8, 14.0d, 0);
                    Core.a(mat7, mat8, mat7);
                    Imgproc.n(mat4, mat8, 45.0d, 1);
                    Core.a(mat7, mat8, mat7);
                    Core.a(mat7, matR, mat7);
                    d3 = ((double) Core.d(mat7)) / ((double) iD);
                }
                mat.i();
                mat2.i();
                mat3.i();
                matR.i();
            }
            mat4.i();
            mat5.i();
            mat6.i();
            mat7.i();
            mat8.i();
            boolean z6 = d3 >= 0.04d;
            return new c4.g(z6, z6);
        } catch (Throwable th) {
            mat.i();
            mat2.i();
            mat3.i();
            if (matR != null) {
                matR.i();
            }
            mat4.i();
            mat5.i();
            mat6.i();
            mat7.i();
            mat8.i();
            throw th;
        }
    }

    public static View z(View view, int i7) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i8 = 0; i8 < childCount; i8++) {
            View viewFindViewById = viewGroup.getChildAt(i8).findViewById(i7);
            if (viewFindViewById != null) {
                return viewFindViewById;
            }
        }
        return null;
    }

    public w3.e K(androidx.appcompat.app.k kVar, Object obj) {
        return null;
    }

    public abstract void Q(Throwable th);

    public abstract View R(int i7);

    public abstract boolean S();

    public abstract void T(y0 y0Var);

    public abstract Object X(int i7, Intent intent);

    public abstract List l(String str, List list);

    public abstract Intent s(androidx.appcompat.app.k kVar, Object obj);
}
