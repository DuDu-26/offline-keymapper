package a5;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.net.ssl.SSLSockets;
import android.util.AttributeSet;
import android.view.SurfaceControl;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import androidx.lifecycle.f0;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract /* synthetic */ class a {
    public static /* bridge */ /* synthetic */ void A(WindowInsets.Builder builder, Insets insets) {
        builder.setSystemGestureInsets(insets);
    }

    public static /* bridge */ /* synthetic */ AccessibilityNodeInfo.AccessibilityAction B() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_RIGHT;
    }

    public static /* bridge */ /* synthetic */ void C(WindowInsets.Builder builder, Insets insets) {
        builder.setMandatorySystemGestureInsets(insets);
    }

    public static /* bridge */ /* synthetic */ void D(WindowInsets.Builder builder, Insets insets) {
        builder.setTappableElementInsets(insets);
    }

    public static /* bridge */ /* synthetic */ Insets a(WindowInsets windowInsets) {
        return windowInsets.getTappableElementInsets();
    }

    public static /* bridge */ /* synthetic */ Drawable b(EditText editText) {
        return editText.getTextCursorDrawable();
    }

    public static /* synthetic */ WindowInsets.Builder c() {
        return new WindowInsets.Builder();
    }

    public static /* synthetic */ WindowInsets.Builder d(WindowInsets windowInsets) {
        return new WindowInsets.Builder(windowInsets);
    }

    public static /* bridge */ /* synthetic */ WindowInsets e(WindowInsets.Builder builder) {
        return builder.build();
    }

    public static /* bridge */ /* synthetic */ WindowInsets f(WindowInsets windowInsets, int i7, int i8, int i9, int i10) {
        return windowInsets.inset(i7, i8, i9, i10);
    }

    public static /* bridge */ /* synthetic */ AccessibilityNodeInfo.AccessibilityAction g() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_UP;
    }

    public static /* bridge */ /* synthetic */ Class h() {
        return SurfaceControl.Transaction.class;
    }

    public static /* bridge */ /* synthetic */ String i(SSLSocket sSLSocket) {
        return sSLSocket.getApplicationProtocol();
    }

    public static /* bridge */ /* synthetic */ void j(Activity activity, f0.a aVar) {
        activity.registerActivityLifecycleCallbacks(aVar);
    }

    public static /* bridge */ /* synthetic */ void k(SurfaceControl.Transaction transaction) {
        transaction.close();
    }

    public static /* bridge */ /* synthetic */ void l(WindowInsets.Builder builder, Insets insets) {
        builder.setSystemWindowInsets(insets);
    }

    public static /* bridge */ /* synthetic */ void m(RecyclerView recyclerView, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i7) {
        recyclerView.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i7, 0);
    }

    public static /* bridge */ /* synthetic */ void n(ViewPager2 viewPager2, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray) {
        viewPager2.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, 0, 0);
    }

    public static /* bridge */ /* synthetic */ void o(SSLParameters sSLParameters, String[] strArr) {
        sSLParameters.setApplicationProtocols(strArr);
    }

    public static /* bridge */ /* synthetic */ void p(SSLSocket sSLSocket) {
        SSLSockets.setUseSessionTickets(sSLSocket, true);
    }

    public static /* bridge */ /* synthetic */ boolean q(SurfaceControl surfaceControl) {
        return surfaceControl.isValid();
    }

    public static /* bridge */ /* synthetic */ boolean r(Object obj) {
        return obj instanceof SurfaceControl;
    }

    public static /* bridge */ /* synthetic */ boolean s(SSLSocket sSLSocket) {
        return SSLSockets.isSupportedSocket(sSLSocket);
    }

    public static /* bridge */ /* synthetic */ Insets t(WindowInsets windowInsets) {
        return windowInsets.getMandatorySystemGestureInsets();
    }

    public static /* bridge */ /* synthetic */ AccessibilityNodeInfo.AccessibilityAction u() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_DOWN;
    }

    public static /* bridge */ /* synthetic */ Class v() {
        return SurfaceControl.class;
    }

    public static /* bridge */ /* synthetic */ void w(SurfaceControl.Transaction transaction) {
        transaction.apply();
    }

    public static /* bridge */ /* synthetic */ void x(WindowInsets.Builder builder, Insets insets) {
        builder.setStableInsets(insets);
    }

    public static /* bridge */ /* synthetic */ Insets y(WindowInsets windowInsets) {
        return windowInsets.getSystemGestureInsets();
    }

    public static /* bridge */ /* synthetic */ AccessibilityNodeInfo.AccessibilityAction z() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_LEFT;
    }
}
