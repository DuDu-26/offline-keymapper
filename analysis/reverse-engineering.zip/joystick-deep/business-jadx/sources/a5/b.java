package a5;

import android.os.Build;
import java.io.IOException;
import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b implements o {
    @Override // a5.o
    public final String a(SSLSocket sSLSocket) {
        try {
            String strI = a.i(sSLSocket);
            if (strI == null) {
                return null;
            }
            if (strI.equals("")) {
                return null;
            }
            return strI;
        } catch (UnsupportedOperationException unused) {
            return null;
        }
    }

    @Override // a5.o
    public final boolean b() {
        z4.f fVar = z4.f.f9209a;
        return Build.VERSION.SDK_INT >= 29;
    }

    @Override // a5.o
    public final boolean c(SSLSocket sSLSocket) {
        return a.s(sSLSocket);
    }

    @Override // a5.o
    public final void d(SSLSocket sSLSocket, String str, List list) throws IOException {
        list.getClass();
        try {
            a.p(sSLSocket);
            SSLParameters sSLParameters = sSLSocket.getSSLParameters();
            z4.f fVar = z4.f.f9209a;
            a.o(sSLParameters, (String[]) q.n.c(list).toArray(new String[0]));
            sSLSocket.setSSLParameters(sSLParameters);
        } catch (IllegalArgumentException e) {
            throw new IOException(v.m.p.abcdstr(138), e);
        }
    }
}
