package a5;

import java.util.List;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f315a;
    public o b;

    public n(m mVar) {
        this.f315a = mVar;
    }

    @Override // a5.o
    public final String a(SSLSocket sSLSocket) {
        o oVarE = e(sSLSocket);
        if (oVarE != null) {
            return oVarE.a(sSLSocket);
        }
        return null;
    }

    @Override // a5.o
    public final boolean b() {
        return true;
    }

    @Override // a5.o
    public final boolean c(SSLSocket sSLSocket) {
        return this.f315a.c(sSLSocket);
    }

    @Override // a5.o
    public final void d(SSLSocket sSLSocket, String str, List list) {
        list.getClass();
        o oVarE = e(sSLSocket);
        if (oVarE != null) {
            oVarE.d(sSLSocket, str, list);
        }
    }

    public final synchronized o e(SSLSocket sSLSocket) {
        try {
            if (this.b == null && this.f315a.c(sSLSocket)) {
                this.b = this.f315a.d(sSLSocket);
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.b;
    }
}
