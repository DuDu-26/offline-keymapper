package a5;

import android.util.Log;
import h2.q;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Level;
import java.util.logging.Logger;
import p4.z;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final CopyOnWriteArraySet f308a = new CopyOnWriteArraySet();
    public static final Map b;

    static {
        Map mapSingletonMap;
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Package r22 = z.class.getPackage();
        String name = r22 != null ? r22.getName() : null;
        if (name != null) {
            linkedHashMap.put(name, v.m.p.abcdstr(139));
        }
        linkedHashMap.put(z.class.getName(), "okhttp.OkHttpClient");
        linkedHashMap.put(w4.h.class.getName(), "okhttp.Http2");
        linkedHashMap.put(s4.d.class.getName(), "okhttp.TaskRunner");
        linkedHashMap.put("okhttp3.mockwebserver.MockWebServer", "okhttp.MockWebServer");
        int size = linkedHashMap.size();
        if (size == 0) {
            mapSingletonMap = q.f5908a;
        } else if (size != 1) {
            mapSingletonMap = new LinkedHashMap(linkedHashMap);
        } else {
            Map.Entry entry = (Map.Entry) linkedHashMap.entrySet().iterator().next();
            mapSingletonMap = Collections.singletonMap(entry.getKey(), entry.getValue());
            mapSingletonMap.getClass();
        }
        b = mapSingletonMap;
    }

    public static void a(int i7, String str, String str2, Throwable th) {
        int iMin;
        String strM0 = (String) b.get(str);
        if (strM0 == null) {
            strM0 = w2.g.m0(23, str);
        }
        if (Log.isLoggable(strM0, i7)) {
            if (th != null) {
                str2 = str2 + '\n' + Log.getStackTraceString(th);
            }
            int length = str2.length();
            int i8 = 0;
            while (i8 < length) {
                int iE0 = w2.g.e0(str2, '\n', i8, 4);
                if (iE0 == -1) {
                    iE0 = length;
                }
                while (true) {
                    iMin = Math.min(iE0, i8 + 4000);
                    Log.println(i7, strM0, str2.substring(i8, iMin));
                    if (iMin >= iE0) {
                        break;
                    } else {
                        i8 = iMin;
                    }
                }
                i8 = iMin + 1;
            }
        }
    }

    public static void b(String str, String str2) {
        Logger logger = Logger.getLogger(str);
        if (f308a.add(logger)) {
            logger.setUseParentHandlers(false);
            logger.setLevel(Log.isLoggable(str2, 3) ? Level.FINE : Log.isLoggable(str2, 4) ? Level.INFO : Level.WARNING);
            logger.addHandler(e.f309a);
        }
    }
}
