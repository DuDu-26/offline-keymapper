package a6;

import androidx.activity.g;
import h5.p;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public interface a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p f316a;
    public static final p b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p f317c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p f318d;
    public static final p e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final p f319f;

    static {
        p pVar = new p("1.2.840.10045");
        p pVarR = pVar.r("1");
        pVarR.r("1");
        p pVarR2 = pVarR.r("2");
        pVarR2.r("3.1");
        pVarR2.r("3.2");
        pVarR2.r("3.3");
        p pVarR3 = pVar.r("4");
        f316a = pVarR3.r("1");
        pVar.r("2").r("1");
        p pVarR4 = pVarR3.r("3");
        b = pVarR4.r("1");
        f317c = pVarR4.r("2");
        f318d = pVarR4.r("3");
        e = pVarR4.r("4");
        p pVarR5 = pVar.r("3");
        p pVarR6 = pVarR5.r("0");
        pVarR6.r("1");
        pVarR6.r("2");
        pVarR6.r("3");
        g.s(pVarR6, "4", "5", "6", "7");
        g.s(pVarR6, "8", "9", "10", "11");
        g.s(pVarR6, "12", "13", "14", "15");
        g.s(pVarR6, "16", "17", "18", "19");
        pVarR6.r("20");
        p pVarR7 = pVarR5.r("1");
        pVarR7.r("1");
        g.s(pVarR7, "2", "3", "4", "5");
        pVarR7.r("6");
        pVarR7.r("7");
        new p("1.2.840.10040.4.1");
        f319f = new p("1.2.840.10040.4.3");
        p pVar2 = new p("1.3.133.16.840.63.0");
        pVar2.r("2");
        pVar2.r("3");
        pVar2.r("16");
        p pVar3 = new p("1.2.840.10046");
        pVar3.r("2.1");
        p pVarR8 = pVar3.r("3");
        pVarR8.r("1");
        pVarR8.r("2");
        g.s(pVarR8, "3", "4", "5", "6");
        pVarR8.r("7");
        pVarR8.r("8");
        p pVarR9 = new p("1.3.133.16.840.9.44").r("1");
        pVarR9.r("1");
        pVarR9.r("2");
    }
}
