package androidx.core.app.unusedapprestrictions;

import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements IUnusedAppRestrictionsBackportCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IBinder f1039a;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f1039a;
    }

    @Override // androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback
    public final void onIsPermissionRevocationEnabledForAppResult(boolean z6, boolean z7) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(IUnusedAppRestrictionsBackportCallback.DESCRIPTOR);
            parcelObtain.writeInt(z6 ? 1 : 0);
            parcelObtain.writeInt(z7 ? 1 : 0);
            this.f1039a.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
