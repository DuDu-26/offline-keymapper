package androidx.core.app;

import android.app.NotificationManager;
import android.content.Context;
import java.util.HashSet;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final NotificationManager f1038a;

    static {
        new HashSet();
    }

    public g(Context context) {
        this.f1038a = (NotificationManager) context.getSystemService("notification");
    }
}
