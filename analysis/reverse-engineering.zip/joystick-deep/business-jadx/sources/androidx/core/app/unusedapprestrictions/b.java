package androidx.core.app.unusedapprestrictions;

import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b implements IUnusedAppRestrictionsBackportService {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IBinder f1040a;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f1040a;
    }

    @Override // androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService
    public final void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback iUnusedAppRestrictionsBackportCallback) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(IUnusedAppRestrictionsBackportService.DESCRIPTOR);
            parcelObtain.writeStrongInterface(iUnusedAppRestrictionsBackportCallback);
            this.f1040a.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
