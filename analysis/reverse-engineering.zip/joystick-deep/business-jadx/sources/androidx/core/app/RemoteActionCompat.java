package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class RemoteActionCompat implements z0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f1034a;
    public CharSequence b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f1035c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f1036d;
    public boolean e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f1037f;
}
