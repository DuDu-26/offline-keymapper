package androidx.core.app;

import android.app.Notification;
import android.os.Binder;
import android.support.v4.app.INotificationSideChannel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
class NotificationCompatSideChannelService$NotificationSideChannelStub extends INotificationSideChannel.Stub {
    final /* synthetic */ f this$0;

    public NotificationCompatSideChannelService$NotificationSideChannelStub(f fVar) {
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public void cancel(String str, int i7, String str2) {
        Binder.getCallingUid();
        throw null;
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public void cancelAll(String str) {
        Binder.getCallingUid();
        throw null;
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public void notify(String str, int i7, String str2, Notification notification) {
        Binder.getCallingUid();
        throw null;
    }
}
