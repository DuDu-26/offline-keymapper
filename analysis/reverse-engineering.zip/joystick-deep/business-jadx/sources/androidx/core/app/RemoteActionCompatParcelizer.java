package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(z0.a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        z0.c cVarG = remoteActionCompat.f1034a;
        boolean z6 = true;
        if (aVar.e(1)) {
            cVarG = aVar.g();
        }
        remoteActionCompat.f1034a = (IconCompat) cVarG;
        CharSequence charSequence = remoteActionCompat.b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((z0.b) aVar).e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f1035c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((z0.b) aVar).e);
        }
        remoteActionCompat.f1035c = charSequence2;
        remoteActionCompat.f1036d = (PendingIntent) aVar.f(remoteActionCompat.f1036d, 4);
        boolean z7 = remoteActionCompat.e;
        if (aVar.e(5)) {
            z7 = ((z0.b) aVar).e.readInt() != 0;
        }
        remoteActionCompat.e = z7;
        boolean z8 = remoteActionCompat.f1037f;
        if (!aVar.e(6)) {
            z6 = z8;
        } else if (((z0.b) aVar).e.readInt() == 0) {
            z6 = false;
        }
        remoteActionCompat.f1037f = z6;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, z0.a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f1034a;
        aVar.h(1);
        aVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        aVar.h(2);
        Parcel parcel = ((z0.b) aVar).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f1035c;
        aVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f1036d;
        aVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z6 = remoteActionCompat.e;
        aVar.h(5);
        parcel.writeInt(z6 ? 1 : 0);
        boolean z7 = remoteActionCompat.f1037f;
        aVar.h(6);
        parcel.writeInt(z7 ? 1 : 0);
    }
}
