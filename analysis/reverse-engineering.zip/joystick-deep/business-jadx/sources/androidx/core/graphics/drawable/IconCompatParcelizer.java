package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.appcompat.widget.f3;
import com.efs.sdk.base.http.HttpResponse;
import java.nio.charset.Charset;
import z0.a;
import z0.b;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i7 = iconCompat.f1042a;
        if (aVar.e(1)) {
            i7 = ((b) aVar).e.readInt();
        }
        iconCompat.f1042a = i7;
        byte[] bArr = iconCompat.f1043c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).e;
            int i8 = parcel.readInt();
            if (i8 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i8];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f1043c = bArr;
        iconCompat.f1044d = aVar.f(iconCompat.f1044d, 3);
        int i9 = iconCompat.e;
        if (aVar.e(4)) {
            i9 = ((b) aVar).e.readInt();
        }
        iconCompat.e = i9;
        int i10 = iconCompat.f1045f;
        if (aVar.e(5)) {
            i10 = ((b) aVar).e.readInt();
        }
        iconCompat.f1045f = i10;
        iconCompat.f1046g = (ColorStateList) aVar.f(iconCompat.f1046g, 6);
        String string = iconCompat.f1048i;
        if (aVar.e(7)) {
            string = ((b) aVar).e.readString();
        }
        iconCompat.f1048i = string;
        String string2 = iconCompat.f1049j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).e.readString();
        }
        iconCompat.f1049j = string2;
        iconCompat.f1047h = PorterDuff.Mode.valueOf(iconCompat.f1048i);
        switch (iconCompat.f1042a) {
            case HttpResponse.REQUEST_ERROR_DEFAULT /* -1 */:
                Parcelable parcelable = iconCompat.f1044d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                f3.q("Invalid icon");
                return null;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f1044d;
                if (parcelable2 != null) {
                    iconCompat.b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f1043c;
                iconCompat.b = bArr3;
                iconCompat.f1042a = 3;
                iconCompat.e = 0;
                iconCompat.f1045f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f1043c, Charset.forName("UTF-16"));
                iconCompat.b = str;
                if (iconCompat.f1042a == 2 && iconCompat.f1049j == null) {
                    iconCompat.f1049j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.b = iconCompat.f1043c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f1048i = iconCompat.f1047h.name();
        switch (iconCompat.f1042a) {
            case HttpResponse.REQUEST_ERROR_DEFAULT /* -1 */:
                iconCompat.f1044d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case 5:
                iconCompat.f1044d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.f1043c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f1043c = (byte[]) iconCompat.b;
                break;
            case 4:
            case 6:
                iconCompat.f1043c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i7 = iconCompat.f1042a;
        if (-1 != i7) {
            aVar.h(1);
            ((b) aVar).e.writeInt(i7);
        }
        byte[] bArr = iconCompat.f1043c;
        if (bArr != null) {
            aVar.h(2);
            Parcel parcel = ((b) aVar).e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1044d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).e.writeParcelable(parcelable, 0);
        }
        int i8 = iconCompat.e;
        if (i8 != 0) {
            aVar.h(4);
            ((b) aVar).e.writeInt(i8);
        }
        int i9 = iconCompat.f1045f;
        if (i9 != 0) {
            aVar.h(5);
            ((b) aVar).e.writeInt(i9);
        }
        ColorStateList colorStateList = iconCompat.f1046g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f1048i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).e.writeString(str);
        }
        String str2 = iconCompat.f1049j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).e.writeString(str2);
        }
    }
}
