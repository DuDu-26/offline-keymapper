package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.appcompat.widget.f3;
import androidx.versionedparcelable.CustomVersionedParcelable;
import y.d;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f1041k = PorterDuff.Mode.SRC_IN;
    public Object b;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f1049j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1042a = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f1043c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f1044d = null;
    public int e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1045f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f1046g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f1047h = f1041k;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f1048i = null;

    public final String toString() {
        String str;
        int iA;
        if (this.f1042a == -1) {
            return String.valueOf(this.b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f1042a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f1042a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f1049j);
                sb.append(" id=");
                int i7 = this.f1042a;
                if (i7 == -1) {
                    iA = d.a(this.b);
                } else {
                    if (i7 != 2) {
                        f3.p(this, "called getResId() on ");
                        return null;
                    }
                    iA = this.e;
                }
                sb.append(String.format("0x%08x", Integer.valueOf(iA)));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.e);
                if (this.f1045f != 0) {
                    sb.append(" off=");
                    sb.append(this.f1045f);
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.b);
                break;
        }
        if (this.f1046g != null) {
            sb.append(" tint=");
            sb.append(this.f1046g);
        }
        if (this.f1047h != f1041k) {
            sb.append(" mode=");
            sb.append(this.f1047h);
        }
        sb.append(")");
        return sb.toString();
    }
}
