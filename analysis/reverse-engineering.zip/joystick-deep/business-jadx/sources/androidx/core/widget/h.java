package androidx.core.widget;

import android.widget.ListView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class h {
    public static boolean a(ListView listView, int i7) {
        return listView.canScrollList(i7);
    }

    public static void b(ListView listView, int i7) {
        listView.scrollListBy(i7);
    }
}
