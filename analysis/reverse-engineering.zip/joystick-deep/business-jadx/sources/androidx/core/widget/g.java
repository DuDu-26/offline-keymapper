package androidx.core.widget;

import a4.w1;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import androidx.appcompat.widget.s1;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g implements View.OnTouchListener {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final int f1082r = ViewConfiguration.getTapTimeout();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f1083a;
    public final AccelerateInterpolator b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s1 f1084c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w1 f1085d;
    public final float[] e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final float[] f1086f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1087g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f1088h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final float[] f1089i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final float[] f1090j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final float[] f1091k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1092l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1093m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1094n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1095o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f1096p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final s1 f1097q;

    public g(s1 s1Var) {
        a aVar = new a();
        aVar.e = Long.MIN_VALUE;
        aVar.f1079g = -1L;
        aVar.f1078f = 0L;
        this.f1083a = aVar;
        this.b = new AccelerateInterpolator();
        float[] fArr = {0.0f, 0.0f};
        this.e = fArr;
        float[] fArr2 = {Float.MAX_VALUE, Float.MAX_VALUE};
        this.f1086f = fArr2;
        float[] fArr3 = {0.0f, 0.0f};
        this.f1089i = fArr3;
        float[] fArr4 = {0.0f, 0.0f};
        this.f1090j = fArr4;
        float[] fArr5 = {Float.MAX_VALUE, Float.MAX_VALUE};
        this.f1091k = fArr5;
        this.f1084c = s1Var;
        float f2 = Resources.getSystem().getDisplayMetrics().density;
        float f7 = ((int) ((1575.0f * f2) + 0.5f)) / 1000.0f;
        fArr5[0] = f7;
        fArr5[1] = f7;
        float f8 = ((int) ((f2 * 315.0f) + 0.5f)) / 1000.0f;
        fArr4[0] = f8;
        fArr4[1] = f8;
        this.f1087g = 1;
        fArr2[0] = Float.MAX_VALUE;
        fArr2[1] = Float.MAX_VALUE;
        fArr[0] = 0.2f;
        fArr[1] = 0.2f;
        fArr3[0] = 0.001f;
        fArr3[1] = 0.001f;
        this.f1088h = f1082r;
        aVar.f1075a = 500;
        aVar.b = 500;
        this.f1097q = s1Var;
    }

    public static float b(float f2, float f7, float f8) {
        return f2 > f8 ? f8 : f2 < f7 ? f7 : f2;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x003b A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x003c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final float a(float r4, float r5, float r6, int r7) {
        /*
            r3 = this;
            float[] r0 = r3.e
            r0 = r0[r7]
            float[] r1 = r3.f1086f
            r1 = r1[r7]
            float r0 = r0 * r5
            r2 = 0
            float r0 = b(r0, r2, r1)
            float r1 = r3.c(r4, r0)
            float r5 = r5 - r4
            float r4 = r3.c(r5, r0)
            float r4 = r4 - r1
            int r5 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            android.view.animation.AccelerateInterpolator r0 = r3.b
            if (r5 >= 0) goto L25
            float r4 = -r4
            float r4 = r0.getInterpolation(r4)
            float r4 = -r4
            goto L2d
        L25:
            int r5 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r5 <= 0) goto L36
            float r4 = r0.getInterpolation(r4)
        L2d:
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0 = 1065353216(0x3f800000, float:1.0)
            float r4 = b(r4, r5, r0)
            goto L37
        L36:
            r4 = r2
        L37:
            int r5 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r5 != 0) goto L3c
            return r2
        L3c:
            float[] r0 = r3.f1089i
            r0 = r0[r7]
            float[] r1 = r3.f1090j
            r1 = r1[r7]
            float[] r2 = r3.f1091k
            r7 = r2[r7]
            float r0 = r0 * r6
            if (r5 <= 0) goto L51
            float r4 = r4 * r0
            float r4 = b(r4, r1, r7)
            return r4
        L51:
            float r4 = -r4
            float r4 = r4 * r0
            float r4 = b(r4, r1, r7)
            float r4 = -r4
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.g.a(float, float, float, int):float");
    }

    public final float c(float f2, float f7) {
        if (f7 != 0.0f) {
            int i7 = this.f1087g;
            if (i7 == 0 || i7 == 1) {
                if (f2 < f7) {
                    if (f2 >= 0.0f) {
                        return 1.0f - (f2 / f7);
                    }
                    if (this.f1095o && i7 == 1) {
                        return 1.0f;
                    }
                }
            } else if (i7 == 2 && f2 < 0.0f) {
                return f2 / (-f7);
            }
        }
        return 0.0f;
    }

    public final void d() {
        int i7 = 0;
        if (this.f1093m) {
            this.f1095o = false;
            return;
        }
        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        a aVar = this.f1083a;
        int i8 = (int) (jCurrentAnimationTimeMillis - aVar.e);
        int i9 = aVar.b;
        if (i8 > i9) {
            i7 = i9;
        } else if (i8 >= 0) {
            i7 = i8;
        }
        aVar.f1081i = i7;
        aVar.f1080h = aVar.a(jCurrentAnimationTimeMillis);
        aVar.f1079g = jCurrentAnimationTimeMillis;
    }

    public final boolean e() {
        s1 s1Var;
        int count;
        a aVar = this.f1083a;
        float f2 = aVar.f1077d;
        int iAbs = (int) (f2 / Math.abs(f2));
        Math.abs(aVar.f1076c);
        if (iAbs != 0 && (count = (s1Var = this.f1097q).getCount()) != 0) {
            int childCount = s1Var.getChildCount();
            int firstVisiblePosition = s1Var.getFirstVisiblePosition();
            int i7 = firstVisiblePosition + childCount;
            if (iAbs <= 0 ? !(iAbs >= 0 || (firstVisiblePosition <= 0 && s1Var.getChildAt(0).getTop() >= 0)) : !(i7 >= count && s1Var.getChildAt(childCount - 1).getBottom() <= s1Var.getHeight())) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0014, code lost:
    
        if (r0 != 3) goto L30;
     */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouch(android.view.View r8, android.view.MotionEvent r9) {
        /*
            r7 = this;
            boolean r0 = r7.f1096p
            r1 = 0
            if (r0 != 0) goto L7
            goto L7d
        L7:
            int r0 = r9.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L1b
            if (r0 == r2) goto L17
            r3 = 2
            if (r0 == r3) goto L1f
            r8 = 3
            if (r0 == r8) goto L17
            goto L7d
        L17:
            r7.d()
            return r1
        L1b:
            r7.f1094n = r2
            r7.f1092l = r1
        L1f:
            float r0 = r9.getX()
            int r3 = r8.getWidth()
            float r3 = (float) r3
            androidx.appcompat.widget.s1 r4 = r7.f1084c
            int r5 = r4.getWidth()
            float r5 = (float) r5
            float r0 = r7.a(r0, r3, r5, r1)
            float r9 = r9.getY()
            int r8 = r8.getHeight()
            float r8 = (float) r8
            int r3 = r4.getHeight()
            float r3 = (float) r3
            float r8 = r7.a(r9, r8, r3, r2)
            androidx.core.widget.a r9 = r7.f1083a
            r9.f1076c = r0
            r9.f1077d = r8
            boolean r8 = r7.f1095o
            if (r8 != 0) goto L7d
            boolean r8 = r7.e()
            if (r8 == 0) goto L7d
            a4.w1 r8 = r7.f1085d
            if (r8 != 0) goto L61
            a4.w1 r8 = new a4.w1
            r9 = 4
            r8.<init>(r9, r7)
            r7.f1085d = r8
        L61:
            r7.f1095o = r2
            r7.f1093m = r2
            boolean r8 = r7.f1092l
            if (r8 != 0) goto L76
            int r8 = r7.f1088h
            if (r8 <= 0) goto L76
            a4.w1 r9 = r7.f1085d
            long r5 = (long) r8
            java.util.WeakHashMap r8 = f0.s0.f5582a
            f0.b0.n(r4, r9, r5)
            goto L7b
        L76:
            a4.w1 r8 = r7.f1085d
            r8.run()
        L7b:
            r7.f1092l = r2
        L7d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.g.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }
}
