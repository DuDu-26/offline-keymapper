package androidx.core.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1075a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f1076c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f1077d;
    public long e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f1078f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f1079g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f1080h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1081i;

    public final float a(long j7) {
        if (j7 < this.e) {
            return 0.0f;
        }
        long j8 = this.f1079g;
        if (j8 < 0 || j7 < j8) {
            return g.b((j7 - r0) / this.f1075a, 0.0f, 1.0f) * 0.5f;
        }
        float f2 = this.f1080h;
        return (g.b((j7 - j8) / this.f1081i, 0.0f, 1.0f) * f2) + (1.0f - f2);
    }
}
