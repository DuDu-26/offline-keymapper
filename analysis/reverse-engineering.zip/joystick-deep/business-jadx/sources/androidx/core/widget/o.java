package androidx.core.widget;

import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class o {
    public static boolean a(TextView textView) {
        return textView.getIncludeFontPadding();
    }

    public static int b(TextView textView) {
        return textView.getMaxLines();
    }

    public static int c(TextView textView) {
        return textView.getMinLines();
    }
}
