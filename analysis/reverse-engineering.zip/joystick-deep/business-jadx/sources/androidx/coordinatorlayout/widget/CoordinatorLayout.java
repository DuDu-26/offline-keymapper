package androidx.coordinatorlayout.widget;

import a4.y0;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import androidx.customview.view.AbsSavedState;
import androidx.recyclerview.widget.p0;
import com.umeng.commonsdk.statistics.UMErrorCode;
import e0.d;
import f0.b0;
import f0.c0;
import f0.f0;
import f0.h0;
import f0.p;
import f0.q;
import f0.s0;
import f0.w1;
import h3.m1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import l.k;
import s.h;
import u.b;
import u.c;
import u.e;
import u.f;
import u.g;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class CoordinatorLayout extends ViewGroup implements p, q {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final String f1011t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final Class[] f1012u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final ThreadLocal f1013v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final androidx.viewpager2.widget.a f1014w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final d f1015x;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f1016a;
    public final y0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f1017c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f1018d;
    public final int[] e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int[] f1019f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1020g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1021h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f1022i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public View f1023j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f1024k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public f f1025l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1026m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public w1 f1027n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1028o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Drawable f1029p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ViewGroup.OnHierarchyChangeListener f1030q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public g.d f1031r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final p0 f1032s;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public SparseArray f1033c;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int i7 = parcel.readInt();
            int[] iArr = new int[i7];
            parcel.readIntArray(iArr);
            Parcelable[] parcelableArray = parcel.readParcelableArray(classLoader);
            this.f1033c = new SparseArray(i7);
            for (int i8 = 0; i8 < i7; i8++) {
                this.f1033c.append(iArr[i8], parcelableArray[i8]);
            }
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            SparseArray sparseArray = this.f1033c;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i8 = 0; i8 < size; i8++) {
                iArr[i8] = this.f1033c.keyAt(i8);
                parcelableArr[i8] = (Parcelable) this.f1033c.valueAt(i8);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i7);
        }
    }

    static {
        Package r02 = CoordinatorLayout.class.getPackage();
        f1011t = r02 != null ? r02.getName() : null;
        f1014w = new androidx.viewpager2.widget.a(3);
        f1012u = new Class[]{Context.class, AttributeSet.class};
        f1013v = new ThreadLocal();
        f1015x = new d(12);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130968906);
        this.f1016a = new ArrayList();
        this.b = new y0(8);
        this.f1017c = new ArrayList();
        this.f1018d = new ArrayList();
        this.e = new int[2];
        this.f1019f = new int[2];
        this.f1032s = new p0();
        int[] iArr = t.a.f8237a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 2130968906, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            m1.l(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f1022i = intArray;
            float f2 = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i7 = 0; i7 < length; i7++) {
                this.f1022i[i7] = (int) (r1[i7] * f2);
            }
        }
        this.f1029p = typedArrayObtainStyledAttributes.getDrawable(1);
        typedArrayObtainStyledAttributes.recycle();
        w();
        super.setOnHierarchyChangeListener(new u.d(this));
        WeakHashMap weakHashMap = s0.f5582a;
        if (b0.c(this) == 0) {
            b0.s(this, 1);
        }
    }

    public static Rect g() {
        Rect rect = (Rect) f1015x.a();
        return rect == null ? new Rect() : rect;
    }

    public static void l(int i7, Rect rect, Rect rect2, e eVar, int i8, int i9) {
        int i10 = eVar.f8361c;
        if (i10 == 0) {
            i10 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, i7);
        int i11 = eVar.f8362d;
        if ((i11 & 7) == 0) {
            i11 |= 8388611;
        }
        if ((i11 & UMErrorCode.E_UM_BE_DEFLATE_FAILED) == 0) {
            i11 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i11, i7);
        int i12 = absoluteGravity & 7;
        int i13 = absoluteGravity & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        int i14 = absoluteGravity2 & 7;
        int i15 = absoluteGravity2 & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        int iWidth = i14 != 1 ? i14 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int iHeight = i15 != 16 ? i15 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i12 == 1) {
            iWidth -= i8 / 2;
        } else if (i12 != 5) {
            iWidth -= i8;
        }
        if (i13 == 16) {
            iHeight -= i9 / 2;
        } else if (i13 != 80) {
            iHeight -= i9;
        }
        rect2.set(iWidth, iHeight, i8 + iWidth, i9 + iHeight);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static e n(View view) {
        e eVar = (e) view.getLayoutParams();
        if (!eVar.b) {
            if (view instanceof u.a) {
                b behavior = ((u.a) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                b bVar = eVar.f8360a;
                if (bVar != behavior) {
                    if (bVar != null) {
                        bVar.e();
                    }
                    eVar.f8360a = behavior;
                    eVar.b = true;
                    if (behavior != null) {
                        behavior.c(eVar);
                    }
                }
                eVar.b = true;
                return eVar;
            }
            c cVar = null;
            for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                cVar = (c) superclass.getAnnotation(c.class);
                if (cVar != null) {
                    break;
                }
            }
            if (cVar != null) {
                try {
                    b bVar2 = (b) cVar.value().getDeclaredConstructor(null).newInstance(null);
                    b bVar3 = eVar.f8360a;
                    if (bVar3 != bVar2) {
                        if (bVar3 != null) {
                            bVar3.e();
                        }
                        eVar.f8360a = bVar2;
                        eVar.b = true;
                        if (bVar2 != null) {
                            bVar2.c(eVar);
                        }
                    }
                } catch (Exception e) {
                    Log.e("CoordinatorLayout", "Default behavior class " + cVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e);
                }
            }
            eVar.b = true;
        }
        return eVar;
    }

    public static void u(View view, int i7) {
        e eVar = (e) view.getLayoutParams();
        int i8 = eVar.f8366i;
        if (i8 != i7) {
            WeakHashMap weakHashMap = s0.f5582a;
            view.offsetLeftAndRight(i7 - i8);
            eVar.f8366i = i7;
        }
    }

    public static void v(View view, int i7) {
        e eVar = (e) view.getLayoutParams();
        int i8 = eVar.f8367j;
        if (i8 != i7) {
            WeakHashMap weakHashMap = s0.f5582a;
            view.offsetTopAndBottom(i7 - i8);
            eVar.f8367j = i7;
        }
    }

    @Override // f0.p
    public final void a(View view, View view2, int i7, int i8) {
        p0 p0Var = this.f1032s;
        if (i8 == 1) {
            p0Var.b = i7;
        } else {
            p0Var.f1623a = i7;
        }
        this.f1024k = view2;
        int childCount = getChildCount();
        for (int i9 = 0; i9 < childCount; i9++) {
            ((e) getChildAt(i9).getLayoutParams()).getClass();
        }
    }

    @Override // f0.p
    public final void b(View view, int i7) {
        p0 p0Var = this.f1032s;
        if (i7 == 1) {
            p0Var.b = 0;
        } else {
            p0Var.f1623a = 0;
        }
        int childCount = getChildCount();
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.a(i7)) {
                b bVar = eVar.f8360a;
                if (bVar != null) {
                    bVar.p(childAt, view, i7);
                }
                if (i7 == 0) {
                    eVar.f8370m = false;
                } else if (i7 == 1) {
                    eVar.f8371n = false;
                }
                eVar.f8372o = false;
            }
        }
        this.f1024k = null;
    }

    @Override // f0.p
    public final void c(View view, int i7, int i8, int[] iArr, int i9) {
        b bVar;
        int childCount = getChildCount();
        boolean z6 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(i9) && (bVar = eVar.f8360a) != null) {
                    int[] iArr2 = this.e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    bVar.j(this, childAt, view, i7, i8, iArr2, i9);
                    iMax = i7 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i8 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z6 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z6) {
            p(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof e) && super.checkLayoutParams(layoutParams);
    }

    @Override // f0.q
    public final void d(View view, int i7, int i8, int i9, int i10, int i11, int[] iArr) {
        b bVar;
        int childCount = getChildCount();
        int iMax = 0;
        int iMax2 = 0;
        boolean z6 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(i11) && (bVar = eVar.f8360a) != null) {
                    int[] iArr2 = this.e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    bVar.k(this, childAt, i8, i9, i10, iArr2);
                    iMax = i9 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i10 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z6 = true;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + iMax2;
        if (z6) {
            p(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j7) {
        b bVar = ((e) view.getLayoutParams()).f8360a;
        if (bVar != null) {
            bVar.getClass();
        }
        return super.drawChild(canvas, view, j7);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1029p;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // f0.p
    public final void e(View view, int i7, int i8, int i9, int i10, int i11) {
        d(view, i7, i8, i9, i10, 0, this.f1019f);
    }

    @Override // f0.p
    public final boolean f(View view, View view2, int i7, int i8) {
        int childCount = getChildCount();
        boolean z6 = false;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                b bVar = eVar.f8360a;
                if (bVar != null) {
                    boolean zO = bVar.o(childAt, i7, i8);
                    z6 |= zO;
                    if (i8 == 0) {
                        eVar.f8370m = zO;
                    } else if (i8 == 1) {
                        eVar.f8371n = zO;
                    }
                } else if (i8 == 0) {
                    eVar.f8370m = false;
                } else if (i8 == 1) {
                    eVar.f8371n = false;
                }
            }
        }
        return z6;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e ? new e((e) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    public final List<View> getDependencySortedChildren() {
        s();
        return Collections.unmodifiableList(this.f1016a);
    }

    public final w1 getLastWindowInsets() {
        return this.f1027n;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        p0 p0Var = this.f1032s;
        return p0Var.b | p0Var.f1623a;
    }

    public Drawable getStatusBarBackground() {
        return this.f1029p;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(e eVar, Rect rect, int i7, int i8) {
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
        int iA = h.a((width - getPaddingRight()) - i7, ((ViewGroup.MarginLayoutParams) eVar).rightMargin, rect.left, paddingLeft);
        int paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        int iA2 = h.a((height - getPaddingBottom()) - i8, ((ViewGroup.MarginLayoutParams) eVar).bottomMargin, rect.top, paddingTop);
        rect.set(iA, iA2, i7 + iA, i8 + iA2);
    }

    public final void i(View view, Rect rect, boolean z6) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z6) {
            k(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList j(View view) {
        k kVar = (k) this.b.f272c;
        int i7 = kVar.f6714c;
        ArrayList arrayList = null;
        for (int i8 = 0; i8 < i7; i8++) {
            ArrayList arrayList2 = (ArrayList) kVar.j(i8);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(kVar.h(i8));
            }
        }
        ArrayList arrayList3 = this.f1018d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void k(View view, Rect rect) {
        ThreadLocal threadLocal = g.f8375a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = g.f8375a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        g.a(this, view, matrix);
        ThreadLocal threadLocal3 = g.b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int m(int i7) {
        int[] iArr = this.f1022i;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i7);
            return 0;
        }
        if (i7 >= 0 && i7 < iArr.length) {
            return iArr[i7];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i7 + " out of range for " + this);
        return 0;
    }

    public final boolean o(View view, int i7, int i8) {
        d dVar = f1015x;
        Rect rectG = g();
        k(view, rectG);
        try {
            return rectG.contains(i7, i8);
        } finally {
            rectG.setEmpty();
            dVar.c(rectG);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        t(false);
        if (this.f1026m) {
            if (this.f1025l == null) {
                this.f1025l = new f(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f1025l);
        }
        if (this.f1027n == null) {
            WeakHashMap weakHashMap = s0.f5582a;
            if (b0.b(this)) {
                f0.c(this);
            }
        }
        this.f1021h = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        t(false);
        if (this.f1026m && this.f1025l != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f1025l);
        }
        View view = this.f1024k;
        if (view != null) {
            b(view, 0);
        }
        this.f1021h = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f1028o || this.f1029p == null) {
            return;
        }
        w1 w1Var = this.f1027n;
        int iD = w1Var != null ? w1Var.d() : 0;
        if (iD > 0) {
            this.f1029p.setBounds(0, 0, getWidth(), iD);
            this.f1029p.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            t(true);
        }
        boolean zR = r(motionEvent, 0);
        if (actionMasked != 1 && actionMasked != 3) {
            return zR;
        }
        t(true);
        return zR;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        b bVar;
        WeakHashMap weakHashMap = s0.f5582a;
        int iD = c0.d(this);
        ArrayList arrayList = this.f1016a;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            View view = (View) arrayList.get(i11);
            if (view.getVisibility() != 8 && ((bVar = ((e) view.getLayoutParams()).f8360a) == null || !bVar.g(this, view, iD))) {
                q(view, iD);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:72:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0167  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0189  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onMeasure(int r27, int r28) {
        /*
            Method dump skipped, instruction units count: 499
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f2, float f7, boolean z6) {
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(0)) {
                    b bVar = eVar.f8360a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f2, float f7) {
        b bVar;
        int childCount = getChildCount();
        boolean zI = false;
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(0) && (bVar = eVar.f8360a) != null) {
                    zI |= bVar.i(view);
                }
            }
        }
        return zI;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i7, int i8, int[] iArr) {
        c(view, i7, i8, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i7, int i8, int i9, int i10) {
        e(view, i7, i8, i9, i10, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i7) {
        a(view, view2, i7, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1099a);
        SparseArray sparseArray = savedState.f1033c;
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            int id = childAt.getId();
            b bVar = n(childAt).f8360a;
            if (id != -1 && bVar != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                bVar.m(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableN;
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            int id = childAt.getId();
            b bVar = ((e) childAt.getLayoutParams()).f8360a;
            if (id != -1 && bVar != null && (parcelableN = bVar.n(childAt)) != null) {
                sparseArray.append(id, parcelableN);
            }
        }
        savedState.f1033c = sparseArray;
        return savedState;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i7) {
        return f(view, view2, i7, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x002f  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015 A[PHI: r3
      0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:10:0x0022, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r1.getActionMasked()
            android.view.View r3 = r0.f1023j
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L17
            boolean r3 = r0.r(r1, r4)
            if (r3 == 0) goto L15
            goto L18
        L15:
            r6 = r5
            goto L2a
        L17:
            r3 = r5
        L18:
            android.view.View r6 = r0.f1023j
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            u.e r6 = (u.e) r6
            u.b r6 = r6.f8360a
            if (r6 == 0) goto L15
            android.view.View r7 = r0.f1023j
            boolean r6 = r6.q(r7, r1)
        L2a:
            android.view.View r7 = r0.f1023j
            r8 = 0
            if (r7 != 0) goto L35
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L48
        L35:
            if (r3 == 0) goto L48
            long r9 = android.os.SystemClock.uptimeMillis()
            r15 = 0
            r16 = 0
            r13 = 3
            r14 = 0
            r11 = r9
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L48:
            if (r8 == 0) goto L4d
            r8.recycle()
        L4d:
            if (r2 == r4) goto L54
            r1 = 3
            if (r2 != r1) goto L53
            goto L54
        L53:
            return r6
        L54:
            r0.t(r5)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x00de  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void p(int r23) {
        /*
            Method dump skipped, instruction units count: 752
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.p(int):void");
    }

    public final void q(View view, int i7) {
        Rect rectG;
        Rect rectG2;
        e eVar = (e) view.getLayoutParams();
        View view2 = eVar.f8368k;
        if (view2 == null && eVar.f8363f != -1) {
            f3.t("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
            return;
        }
        d dVar = f1015x;
        if (view2 != null) {
            rectG = g();
            rectG2 = g();
            try {
                k(view2, rectG);
                e eVar2 = (e) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                l(i7, rectG, rectG2, eVar2, measuredWidth, measuredHeight);
                h(eVar2, rectG2, measuredWidth, measuredHeight);
                view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
                return;
            } finally {
                rectG.setEmpty();
                dVar.c(rectG);
                rectG2.setEmpty();
                dVar.c(rectG2);
            }
        }
        int i8 = eVar.e;
        if (i8 < 0) {
            e eVar3 = (e) view.getLayoutParams();
            rectG = g();
            rectG.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar3).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar3).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) eVar3).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin);
            if (this.f1027n != null) {
                WeakHashMap weakHashMap = s0.f5582a;
                if (b0.b(this) && !b0.b(view)) {
                    rectG.left = this.f1027n.b() + rectG.left;
                    rectG.top = this.f1027n.d() + rectG.top;
                    rectG.right -= this.f1027n.c();
                    rectG.bottom -= this.f1027n.a();
                }
            }
            rectG2 = g();
            int i9 = eVar3.f8361c;
            if ((i9 & 7) == 0) {
                i9 |= 8388611;
            }
            if ((i9 & UMErrorCode.E_UM_BE_DEFLATE_FAILED) == 0) {
                i9 |= 48;
            }
            f0.k.b(i9, view.getMeasuredWidth(), view.getMeasuredHeight(), rectG, rectG2, i7);
            view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
            return;
        }
        e eVar4 = (e) view.getLayoutParams();
        int i10 = eVar4.f8361c;
        if (i10 == 0) {
            i10 = 8388661;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, i7);
        int i11 = absoluteGravity & 7;
        int i12 = absoluteGravity & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth2 = view.getMeasuredWidth();
        int measuredHeight2 = view.getMeasuredHeight();
        if (i7 == 1) {
            i8 = width - i8;
        }
        int iM = m(i8) - measuredWidth2;
        if (i11 == 1) {
            iM += measuredWidth2 / 2;
        } else if (i11 == 5) {
            iM += measuredWidth2;
        }
        int i13 = i12 != 16 ? i12 != 80 ? 0 : measuredHeight2 : measuredHeight2 / 2;
        int iA = h.a((width - getPaddingRight()) - measuredWidth2, ((ViewGroup.MarginLayoutParams) eVar4).rightMargin, iM, getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar4).leftMargin);
        int iA2 = h.a((height - getPaddingBottom()) - measuredHeight2, ((ViewGroup.MarginLayoutParams) eVar4).bottomMargin, i13, getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar4).topMargin);
        view.layout(iA, iA2, measuredWidth2 + iA, measuredHeight2 + iA2);
    }

    public final boolean r(MotionEvent motionEvent, int i7) {
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f1017c;
        arrayList.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i8 = childCount - 1; i8 >= 0; i8--) {
            arrayList.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i8) : i8));
        }
        androidx.viewpager2.widget.a aVar = f1014w;
        if (aVar != null) {
            Collections.sort(arrayList, aVar);
        }
        int size = arrayList.size();
        MotionEvent motionEventObtain = null;
        boolean zF = false;
        for (int i9 = 0; i9 < size; i9++) {
            View view = (View) arrayList.get(i9);
            b bVar = ((e) view.getLayoutParams()).f8360a;
            if (zF && actionMasked != 0) {
                if (bVar != null) {
                    if (motionEventObtain == null) {
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    }
                    if (i7 == 0) {
                        bVar.f(this, view, motionEventObtain);
                    } else if (i7 == 1) {
                        bVar.q(view, motionEventObtain);
                    }
                }
            } else if (!zF && bVar != null) {
                if (i7 == 0) {
                    zF = bVar.f(this, view, motionEvent);
                } else if (i7 == 1) {
                    zF = bVar.q(view, motionEvent);
                }
                if (zF) {
                    this.f1023j = view;
                }
            }
        }
        arrayList.clear();
        return zF;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z6) {
        b bVar = ((e) view.getLayoutParams()).f8360a;
        if (bVar != null) {
            bVar.l(this, view);
        }
        return super.requestChildRectangleOnScreen(view, rect, z6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z6) {
        super.requestDisallowInterceptTouchEvent(z6);
        if (!z6 || this.f1020g) {
            return;
        }
        t(false);
        this.f1020g = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b9  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0102  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void s() {
        /*
            Method dump skipped, instruction units count: 396
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.s():void");
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z6) {
        super.setFitsSystemWindows(z6);
        w();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f1030q = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f1029p;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f1029p = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f1029p.setState(getDrawableState());
                }
                Drawable drawable3 = this.f1029p;
                WeakHashMap weakHashMap = s0.f5582a;
                y.c.b(drawable3, c0.d(this));
                this.f1029p.setVisible(getVisibility() == 0, false);
                this.f1029p.setCallback(this);
            }
            WeakHashMap weakHashMap2 = s0.f5582a;
            b0.k(this);
        }
    }

    public void setStatusBarBackgroundColor(int i7) {
        setStatusBarBackground(new ColorDrawable(i7));
    }

    public void setStatusBarBackgroundResource(int i7) {
        setStatusBarBackground(i7 != 0 ? androidx.core.content.b.b(getContext(), i7) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i7) {
        super.setVisibility(i7);
        boolean z6 = i7 == 0;
        Drawable drawable = this.f1029p;
        if (drawable == null || drawable.isVisible() == z6) {
            return;
        }
        this.f1029p.setVisible(z6, false);
    }

    public final void t(boolean z6) {
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            b bVar = ((e) childAt.getLayoutParams()).f8360a;
            if (bVar != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z6) {
                    bVar.f(this, childAt, motionEventObtain);
                } else {
                    bVar.q(childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i8 = 0; i8 < childCount; i8++) {
            ((e) getChildAt(i8).getLayoutParams()).getClass();
        }
        this.f1023j = null;
        this.f1020g = false;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1029p;
    }

    public final void w() {
        WeakHashMap weakHashMap = s0.f5582a;
        if (!b0.b(this)) {
            h0.u(this, null);
            return;
        }
        if (this.f1031r == null) {
            this.f1031r = new g.d(28, this);
        }
        h0.u(this, this.f1031r);
        setSystemUiVisibility(1280);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }
}
