package androidx.lifecycle;

import java.util.HashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class CompositeGeneratedAdaptersObserver implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g[] f1330a;

    public CompositeGeneratedAdaptersObserver(g[] gVarArr) {
        this.f1330a = gVarArr;
    }

    @Override // androidx.lifecycle.p
    public final void a(r rVar, l lVar) {
        new HashMap();
        g[] gVarArr = this.f1330a;
        if (gVarArr.length > 0) {
            g gVar = gVarArr[0];
            throw null;
        }
        if (gVarArr.length <= 0) {
            return;
        }
        g gVar2 = gVarArr[0];
        throw null;
    }
}
