package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.e1;
import androidx.appcompat.widget.i;
import androidx.appcompat.widget.m;
import androidx.appcompat.widget.w3;
import d.a;
import g.b;
import g.k;
import g.l;
import g.n;
import g.z;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ActionMenuItemView extends e1 implements z, View.OnClickListener, m {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public n f561g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f562h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Drawable f563i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public k f564j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public i f565k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public b f566l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f567m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f568n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f569o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f570p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f571q;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f567m = d();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f5204c, 0, 0);
        this.f569o = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f571q = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f570p = -1;
        setSaveEnabled(false);
    }

    @Override // androidx.appcompat.widget.m
    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // g.z
    public final void b(n nVar) {
        this.f561g = nVar;
        setIcon(nVar.getIcon());
        setTitle(nVar.getTitleCondensed());
        setId(nVar.f5782a);
        setVisibility(nVar.isVisible() ? 0 : 8);
        setEnabled(nVar.isEnabled());
        if (nVar.hasSubMenu() && this.f565k == null) {
            this.f565k = new i(this);
        }
    }

    @Override // androidx.appcompat.widget.m
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f561g.getIcon() == null;
    }

    public final boolean d() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i7 = configuration.screenWidthDp;
        int i8 = configuration.screenHeightDp;
        if (i7 < 480) {
            return (i7 >= 640 && i8 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void e() {
        boolean z6 = true;
        boolean z7 = !TextUtils.isEmpty(this.f562h);
        if (this.f563i != null && ((this.f561g.f5804y & 4) != 4 || (!this.f567m && !this.f568n))) {
            z6 = false;
        }
        boolean z8 = z7 & z6;
        setText(z8 ? this.f562h : null);
        CharSequence charSequence = this.f561g.f5796q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z8 ? null : this.f561g.e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f561g.f5797r;
        if (TextUtils.isEmpty(charSequence2)) {
            w3.a(this, z8 ? null : this.f561g.e);
        } else {
            w3.a(this, charSequence2);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // g.z
    public n getItemData() {
        return this.f561g;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k kVar = this.f564j;
        if (kVar != null) {
            kVar.a(this.f561g);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f567m = d();
        e();
    }

    @Override // androidx.appcompat.widget.e1, android.widget.TextView, android.view.View
    public final void onMeasure(int i7, int i8) {
        int i9;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i9 = this.f570p) >= 0) {
            super.setPadding(i9, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i7, i8);
        int mode = View.MeasureSpec.getMode(i7);
        int size = View.MeasureSpec.getSize(i7);
        int measuredWidth = getMeasuredWidth();
        int i10 = this.f569o;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i10) : i10;
        if (mode != 1073741824 && i10 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i8);
        }
        if (!zIsEmpty || this.f563i == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f563i.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        i iVar;
        if (this.f561g.hasSubMenu() && (iVar = this.f565k) != null && iVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z6) {
    }

    public void setChecked(boolean z6) {
    }

    public void setExpandedFormat(boolean z6) {
        if (this.f568n != z6) {
            this.f568n = z6;
            n nVar = this.f561g;
            if (nVar != null) {
                l lVar = nVar.f5793n;
                lVar.f5766k = true;
                lVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f563i = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i7 = this.f571q;
            if (intrinsicWidth > i7) {
                intrinsicHeight = (int) (intrinsicHeight * (i7 / intrinsicWidth));
                intrinsicWidth = i7;
            }
            if (intrinsicHeight > i7) {
                intrinsicWidth = (int) (intrinsicWidth * (i7 / intrinsicHeight));
            } else {
                i7 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i7);
        }
        setCompoundDrawables(drawable, null, null, null);
        e();
    }

    public void setItemInvoker(k kVar) {
        this.f564j = kVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i7, int i8, int i9, int i10) {
        this.f570p = i7;
        super.setPadding(i7, i8, i9, i10);
    }

    public void setPopupCallback(b bVar) {
        this.f566l = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f562h = charSequence;
        e();
    }
}
