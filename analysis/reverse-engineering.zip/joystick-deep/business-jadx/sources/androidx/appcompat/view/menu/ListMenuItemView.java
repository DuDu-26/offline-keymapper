package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import d.a;
import f0.b0;
import f0.s0;
import g.l;
import g.n;
import g.z;
import java.util.WeakHashMap;
import y2.e;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ListMenuItemView extends LinearLayout implements z, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n f573a;
    public ImageView b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public RadioButton f574c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TextView f575d;
    public CheckBox e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TextView f576f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ImageView f577g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ImageView f578h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public LinearLayout f579i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Drawable f580j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f581k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Context f582l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f583m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Drawable f584n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f585o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public LayoutInflater f586p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f587q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        e eVarA = e.A(getContext(), attributeSet, a.f5218r, 2130969280);
        this.f580j = eVarA.o(5);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        this.f581k = typedArray.getResourceId(1, -1);
        this.f583m = typedArray.getBoolean(7, false);
        this.f582l = context;
        this.f584n = eVarA.o(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, 2130968981, 0);
        this.f585o = typedArrayObtainStyledAttributes.hasValue(0);
        eVarA.C();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f586p == null) {
            this.f586p = LayoutInflater.from(getContext());
        }
        return this.f586p;
    }

    private void setSubMenuArrowVisible(boolean z6) {
        ImageView imageView = this.f577g;
        if (imageView != null) {
            imageView.setVisibility(z6 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f578h;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f578h.getLayoutParams();
        rect.top = this.f578h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0058  */
    @Override // g.z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void b(g.n r11) {
        /*
            Method dump skipped, instruction units count: 315
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.b(g.n):void");
    }

    @Override // g.z
    public n getItemData() {
        return this.f573a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        WeakHashMap weakHashMap = s0.f5582a;
        b0.q(this, this.f580j);
        TextView textView = (TextView) findViewById(2131296778);
        this.f575d = textView;
        int i7 = this.f581k;
        if (i7 != -1) {
            textView.setTextAppearance(this.f582l, i7);
        }
        this.f576f = (TextView) findViewById(2131296702);
        ImageView imageView = (ImageView) findViewById(2131296740);
        this.f577g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f584n);
        }
        this.f578h = (ImageView) findViewById(2131296495);
        this.f579i = (LinearLayout) findViewById(2131296402);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i7, int i8) {
        if (this.b != null && this.f583m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.b.getLayoutParams();
            int i9 = layoutParams.height;
            if (i9 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i9;
            }
        }
        super.onMeasure(i7, i8);
    }

    public void setCheckable(boolean z6) {
        CompoundButton compoundButton;
        View view;
        if (!z6 && this.f574c == null && this.e == null) {
            return;
        }
        if ((this.f573a.f5803x & 4) != 0) {
            if (this.f574c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(2131492881, (ViewGroup) this, false);
                this.f574c = radioButton;
                LinearLayout linearLayout = this.f579i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f574c;
            view = this.e;
        } else {
            if (this.e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(2131492878, (ViewGroup) this, false);
                this.e = checkBox;
                LinearLayout linearLayout2 = this.f579i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.e;
            view = this.f574c;
        }
        if (z6) {
            compoundButton.setChecked(this.f573a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f574c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z6) {
        CompoundButton compoundButton;
        if ((this.f573a.f5803x & 4) != 0) {
            if (this.f574c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(2131492881, (ViewGroup) this, false);
                this.f574c = radioButton;
                LinearLayout linearLayout = this.f579i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f574c;
        } else {
            if (this.e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(2131492878, (ViewGroup) this, false);
                this.e = checkBox;
                LinearLayout linearLayout2 = this.f579i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.e;
        }
        compoundButton.setChecked(z6);
    }

    public void setForceShowIcon(boolean z6) {
        this.f587q = z6;
        this.f583m = z6;
    }

    public void setGroupDividerEnabled(boolean z6) {
        ImageView imageView = this.f578h;
        if (imageView != null) {
            imageView.setVisibility((this.f585o || !z6) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        l lVar = this.f573a.f5793n;
        boolean z6 = this.f587q;
        if (z6 || this.f583m) {
            ImageView imageView = this.b;
            if (imageView == null && drawable == null && !this.f583m) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(2131492879, (ViewGroup) this, false);
                this.b = imageView2;
                LinearLayout linearLayout = this.f579i;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f583m) {
                this.b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.b;
            if (!z6) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.b.getVisibility() != 0) {
                this.b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView = this.f575d;
        if (charSequence == null) {
            if (textView.getVisibility() != 8) {
                this.f575d.setVisibility(8);
            }
        } else {
            textView.setText(charSequence);
            if (this.f575d.getVisibility() != 0) {
                this.f575d.setVisibility(0);
            }
        }
    }
}
