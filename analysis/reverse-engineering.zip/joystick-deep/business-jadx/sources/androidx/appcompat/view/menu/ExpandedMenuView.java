package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import g.a0;
import g.k;
import g.l;
import g.n;
import y2.e;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class ExpandedMenuView extends ListView implements k, a0, AdapterView.OnItemClickListener {
    public static final int[] b = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l f572a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        e eVarA = e.A(context, attributeSet, b, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(eVarA.o(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(eVarA.o(1));
        }
        eVarA.C();
    }

    @Override // g.k
    public final boolean a(n nVar) {
        return this.f572a.q(nVar, null, 0);
    }

    @Override // g.a0
    public final void c(l lVar) {
        this.f572a = lVar;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i7, long j7) {
        a((n) getAdapter().getItem(i7));
    }
}
