package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j0 extends SeekBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k0 f816a;

    public j0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969514);
        i3.a(this, getContext());
        k0 k0Var = new k0(this);
        this.f816a = k0Var;
        k0Var.b(attributeSet, 2130969514);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        k0 k0Var = this.f816a;
        j0 j0Var = k0Var.e;
        Drawable drawable = k0Var.f821f;
        if (drawable != null && drawable.isStateful() && drawable.setState(j0Var.getDrawableState())) {
            j0Var.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f816a.f821f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f816a.g(canvas);
    }
}
