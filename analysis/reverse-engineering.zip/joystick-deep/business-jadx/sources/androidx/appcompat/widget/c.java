package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f717a;
    public final /* synthetic */ ActionBarOverlayLayout b;

    public /* synthetic */ c(ActionBarOverlayLayout actionBarOverlayLayout, int i7) {
        this.f717a = i7;
        this.b = actionBarOverlayLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f717a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.b;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f633w = actionBarOverlayLayout.f615d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f634x);
                break;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.b;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f633w = actionBarOverlayLayout2.f615d.animate().translationY(-actionBarOverlayLayout2.f615d.getHeight()).setListener(actionBarOverlayLayout2.f634x);
                break;
        }
    }
}
