package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k0 extends f0 {
    public final j0 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f821f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f822g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f823h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f824i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f825j;

    public k0(j0 j0Var) {
        super(j0Var);
        this.f822g = null;
        this.f823h = null;
        this.f824i = false;
        this.f825j = false;
        this.e = j0Var;
    }

    @Override // androidx.appcompat.widget.f0
    public final void b(AttributeSet attributeSet, int i7) {
        super.b(attributeSet, 2130969514);
        j0 j0Var = this.e;
        Context context = j0Var.getContext();
        int[] iArr = d.a.f5207g;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, 2130969514);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        f0.s0.i(j0Var, j0Var.getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, 2130969514);
        Drawable drawableP = eVarA.p(0);
        if (drawableP != null) {
            j0Var.setThumb(drawableP);
        }
        Drawable drawableO = eVarA.o(1);
        Drawable drawable = this.f821f;
        if (drawable != null) {
            drawable.setCallback(null);
        }
        this.f821f = drawableO;
        if (drawableO != null) {
            drawableO.setCallback(j0Var);
            y.c.b(drawableO, f0.c0.d(j0Var));
            if (drawableO.isStateful()) {
                drawableO.setState(j0Var.getDrawableState());
            }
            f();
        }
        j0Var.invalidate();
        if (typedArray.hasValue(3)) {
            this.f823h = m1.b(typedArray.getInt(3, -1), this.f823h);
            this.f825j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f822g = eVarA.n(2);
            this.f824i = true;
        }
        eVarA.C();
        f();
    }

    public final void f() {
        Drawable drawable = this.f821f;
        if (drawable != null) {
            if (this.f824i || this.f825j) {
                Drawable drawableMutate = drawable.mutate();
                this.f821f = drawableMutate;
                if (this.f824i) {
                    y.b.h(drawableMutate, this.f822g);
                }
                if (this.f825j) {
                    y.b.i(this.f821f, this.f823h);
                }
                if (this.f821f.isStateful()) {
                    this.f821f.setState(this.e.getDrawableState());
                }
            }
        }
    }

    public final void g(Canvas canvas) {
        if (this.f821f != null) {
            int max = this.e.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f821f.getIntrinsicWidth();
                int intrinsicHeight = this.f821f.getIntrinsicHeight();
                int i7 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i8 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f821f.setBounds(-i7, -i8, i7, i8);
                float width = ((r0.getWidth() - r0.getPaddingLeft()) - r0.getPaddingRight()) / max;
                int iSave = canvas.save();
                canvas.translate(r0.getPaddingLeft(), r0.getHeight() / 2);
                for (int i9 = 0; i9 <= max; i9++) {
                    this.f821f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(iSave);
            }
        }
    }
}
