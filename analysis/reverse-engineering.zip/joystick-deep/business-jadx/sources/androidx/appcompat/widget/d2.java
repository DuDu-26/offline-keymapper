package androidx.appcompat.widget;

import android.widget.AbsListView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d2 implements AbsListView.OnScrollListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f2 f735a;

    public d2(f2 f2Var) {
        this.f735a = f2Var;
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScroll(AbsListView absListView, int i7, int i8, int i9) {
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScrollStateChanged(AbsListView absListView, int i7) {
        f2 f2Var = this.f735a;
        b2 b2Var = f2Var.f766r;
        e0 e0Var = f2Var.f774z;
        if (i7 != 1 || e0Var.getInputMethodMode() == 2 || e0Var.getContentView() == null) {
            return;
        }
        f2Var.f770v.removeCallbacks(b2Var);
        b2Var.run();
    }
}
