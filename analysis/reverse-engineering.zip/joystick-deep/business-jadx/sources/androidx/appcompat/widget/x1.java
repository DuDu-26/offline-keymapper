package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import com.umeng.commonsdk.statistics.UMErrorCode;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class x1 extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f966a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f967c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f968d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f969f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f970g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f971h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int[] f972i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int[] f973j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Drawable f974k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f975l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f976m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f977n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f978o;

    public x1(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        this.f966a = true;
        this.b = -1;
        this.f967c = 0;
        this.e = 8388659;
        int[] iArr = d.a.f5214n;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, i7);
        f0.s0.i(this, context, iArr, attributeSet, (TypedArray) eVarA.f8965c, i7);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        int i8 = typedArray.getInt(1, -1);
        if (i8 >= 0) {
            setOrientation(i8);
        }
        int i9 = typedArray.getInt(0, -1);
        if (i9 >= 0) {
            setGravity(i9);
        }
        boolean z6 = typedArray.getBoolean(2, true);
        if (!z6) {
            setBaselineAligned(z6);
        }
        this.f970g = typedArray.getFloat(4, -1.0f);
        this.b = typedArray.getInt(3, -1);
        this.f971h = typedArray.getBoolean(7, false);
        setDividerDrawable(eVarA.o(5));
        this.f977n = typedArray.getInt(8, 0);
        this.f978o = typedArray.getDimensionPixelSize(6, 0);
        eVarA.C();
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof w1;
    }

    public final void d(Canvas canvas, int i7) {
        this.f974k.setBounds(getPaddingLeft() + this.f978o, i7, (getWidth() - getPaddingRight()) - this.f978o, this.f976m + i7);
        this.f974k.draw(canvas);
    }

    public final void e(Canvas canvas, int i7) {
        this.f974k.setBounds(i7, getPaddingTop() + this.f978o, this.f975l + i7, (getHeight() - getPaddingBottom()) - this.f978o);
        this.f974k.draw(canvas);
    }

    public w1 f() {
        int i7 = this.f968d;
        if (i7 == 0) {
            return new w1(-2, -2);
        }
        if (i7 == 1) {
            return new w1(-1, -2);
        }
        return null;
    }

    public w1 g(AttributeSet attributeSet) {
        return new w1(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return f();
    }

    @Override // android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return g(attributeSet);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i7;
        if (this.b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i8 = this.b;
        if (childCount <= i8) {
            f3.i("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
            return 0;
        }
        View childAt = getChildAt(i8);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.b == 0) {
                return -1;
            }
            f3.i("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            return 0;
        }
        int bottom = this.f967c;
        if (this.f968d == 1 && (i7 = this.e & UMErrorCode.E_UM_BE_DEFLATE_FAILED) != 48) {
            if (i7 == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f969f) / 2;
            } else if (i7 == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.f969f;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((w1) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.b;
    }

    public Drawable getDividerDrawable() {
        return this.f974k;
    }

    public int getDividerPadding() {
        return this.f978o;
    }

    public int getDividerWidth() {
        return this.f975l;
    }

    public int getGravity() {
        return this.e;
    }

    public int getOrientation() {
        return this.f968d;
    }

    public int getShowDividers() {
        return this.f977n;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f970g;
    }

    public w1 h(ViewGroup.LayoutParams layoutParams) {
        return new w1(layoutParams);
    }

    public final boolean i(int i7) {
        if (i7 == 0) {
            return (this.f977n & 1) != 0;
        }
        int childCount = getChildCount();
        int i8 = this.f977n;
        if (i7 == childCount) {
            return (i8 & 4) != 0;
        }
        if ((i8 & 2) != 0) {
            for (int i9 = i7 - 1; i9 >= 0; i9--) {
                if (getChildAt(i9).getVisibility() != 8) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int right;
        int left;
        int i7;
        if (this.f974k == null) {
            return;
        }
        int i8 = 0;
        if (this.f968d == 1) {
            int virtualChildCount = getVirtualChildCount();
            while (i8 < virtualChildCount) {
                View childAt = getChildAt(i8);
                if (childAt != null && childAt.getVisibility() != 8 && i(i8)) {
                    d(canvas, (childAt.getTop() - ((LinearLayout.LayoutParams) ((w1) childAt.getLayoutParams())).topMargin) - this.f976m);
                }
                i8++;
            }
            if (i(virtualChildCount)) {
                View childAt2 = getChildAt(virtualChildCount - 1);
                d(canvas, childAt2 == null ? (getHeight() - getPaddingBottom()) - this.f976m : childAt2.getBottom() + ((LinearLayout.LayoutParams) ((w1) childAt2.getLayoutParams())).bottomMargin);
                return;
            }
            return;
        }
        int virtualChildCount2 = getVirtualChildCount();
        boolean zA = z3.a(this);
        while (i8 < virtualChildCount2) {
            View childAt3 = getChildAt(i8);
            if (childAt3 != null && childAt3.getVisibility() != 8 && i(i8)) {
                w1 w1Var = (w1) childAt3.getLayoutParams();
                e(canvas, zA ? childAt3.getRight() + ((LinearLayout.LayoutParams) w1Var).rightMargin : (childAt3.getLeft() - ((LinearLayout.LayoutParams) w1Var).leftMargin) - this.f975l);
            }
            i8++;
        }
        if (i(virtualChildCount2)) {
            View childAt4 = getChildAt(virtualChildCount2 - 1);
            if (childAt4 != null) {
                w1 w1Var2 = (w1) childAt4.getLayoutParams();
                if (zA) {
                    left = childAt4.getLeft() - ((LinearLayout.LayoutParams) w1Var2).leftMargin;
                    i7 = this.f975l;
                    right = left - i7;
                } else {
                    right = childAt4.getRight() + ((LinearLayout.LayoutParams) w1Var2).rightMargin;
                }
            } else if (zA) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i7 = this.f975l;
                right = left - i7;
            }
            e(canvas, right);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0157  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0160  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x018e  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x01a1  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01a6  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onLayout(boolean r23, int r24, int r25, int r26, int r27) {
        /*
            Method dump skipped, instruction units count: 458
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.x1.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:229:0x04dc  */
    /* JADX WARN: Removed duplicated region for block: B:232:0x04f1  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x051f  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x052f  */
    /* JADX WARN: Removed duplicated region for block: B:247:0x0536  */
    /* JADX WARN: Removed duplicated region for block: B:251:0x0540  */
    /* JADX WARN: Removed duplicated region for block: B:368:0x0791  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x013d  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0146  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onMeasure(int r39, int r40) {
        /*
            Method dump skipped, instruction units count: 2139
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.x1.onMeasure(int, int):void");
    }

    public void setBaselineAligned(boolean z6) {
        this.f966a = z6;
    }

    public void setBaselineAlignedChildIndex(int i7) {
        if (i7 >= 0 && i7 < getChildCount()) {
            this.b = i7;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f974k) {
            return;
        }
        this.f974k = drawable;
        if (drawable != null) {
            this.f975l = drawable.getIntrinsicWidth();
            this.f976m = drawable.getIntrinsicHeight();
        } else {
            this.f975l = 0;
            this.f976m = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i7) {
        this.f978o = i7;
    }

    public void setGravity(int i7) {
        if (this.e != i7) {
            if ((8388615 & i7) == 0) {
                i7 |= 8388611;
            }
            if ((i7 & UMErrorCode.E_UM_BE_DEFLATE_FAILED) == 0) {
                i7 |= 48;
            }
            this.e = i7;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i7) {
        int i8 = i7 & 8388615;
        int i9 = this.e;
        if ((8388615 & i9) != i8) {
            this.e = i8 | ((-8388616) & i9);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z6) {
        this.f971h = z6;
    }

    public void setOrientation(int i7) {
        if (this.f968d != i7) {
            this.f968d = i7;
            requestLayout();
        }
    }

    public void setShowDividers(int i7) {
        if (i7 != this.f977n) {
            requestLayout();
        }
        this.f977n = i7;
    }

    public void setVerticalGravity(int i7) {
        int i8 = i7 & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        int i9 = this.e;
        if ((i9 & UMErrorCode.E_UM_BE_DEFLATE_FAILED) != i8) {
            this.e = i8 | (i9 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f2) {
        this.f970g = Math.max(0.0f, f2);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }
}
