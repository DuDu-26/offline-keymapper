package androidx.appcompat.widget;

import android.graphics.Typeface;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class b1 {
    public static Typeface a(Typeface typeface, int i7, boolean z6) {
        return Typeface.create(typeface, i7, z6);
    }
}
