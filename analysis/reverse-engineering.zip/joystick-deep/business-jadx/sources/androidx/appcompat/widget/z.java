package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f985a;
    public final g.d b;

    public z(TextView textView) {
        this.f985a = textView;
        this.b = new g.d(textView);
    }

    public final void a(AttributeSet attributeSet, int i7) {
        TypedArray typedArrayObtainStyledAttributes = this.f985a.getContext().obtainStyledAttributes(attributeSet, d.a.f5209i, i7, 0);
        try {
            boolean z6 = typedArrayObtainStyledAttributes.hasValue(14) ? typedArrayObtainStyledAttributes.getBoolean(14, true) : true;
            typedArrayObtainStyledAttributes.recycle();
            c(z6);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z6) {
        ((m4.f) this.b.b).L(z6);
    }

    public final void c(boolean z6) {
        ((m4.f) this.b.b).M(z6);
    }
}
