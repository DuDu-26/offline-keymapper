package androidx.appcompat.widget;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h3 extends j0.b implements View.OnClickListener {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final /* synthetic */ int f785x = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f786h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f787i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final LayoutInflater f788j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final SearchView f789k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final SearchableInfo f790l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Context f791m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final WeakHashMap f792n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f793o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f794p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ColorStateList f795q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f796r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f797s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f798t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f799u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f800v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f801w;

    public h3(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap weakHashMap) {
        int suggestionRowLayout = searchView.getSuggestionRowLayout();
        this.b = true;
        this.f6353c = null;
        this.f6352a = false;
        this.f6354d = -1;
        this.e = new j0.a(this);
        this.f6355f = new c2(1, this);
        this.f787i = suggestionRowLayout;
        this.f786h = suggestionRowLayout;
        this.f788j = (LayoutInflater) context.getSystemService("layout_inflater");
        this.f794p = 1;
        this.f796r = -1;
        this.f797s = -1;
        this.f798t = -1;
        this.f799u = -1;
        this.f800v = -1;
        this.f801w = -1;
        this.f789k = searchView;
        this.f790l = searchableInfo;
        this.f793o = searchView.getSuggestionCommitIconResId();
        this.f791m = context;
        this.f792n = weakHashMap;
    }

    public static String h(Cursor cursor, int i7) {
        if (i7 == -1) {
            return null;
        }
        try {
            return cursor.getString(i7);
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e);
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x0118  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x011a  */
    @Override // j0.b
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(android.view.View r21, android.database.Cursor r22) {
        /*
            Method dump skipped, instruction units count: 394
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.h3.a(android.view.View, android.database.Cursor):void");
    }

    @Override // j0.b
    public final void b(Cursor cursor) {
        try {
            super.b(cursor);
            if (cursor != null) {
                this.f796r = cursor.getColumnIndex("suggest_text_1");
                this.f797s = cursor.getColumnIndex("suggest_text_2");
                this.f798t = cursor.getColumnIndex("suggest_text_2_url");
                this.f799u = cursor.getColumnIndex("suggest_icon_1");
                this.f800v = cursor.getColumnIndex("suggest_icon_2");
                this.f801w = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e);
        }
    }

    @Override // j0.b
    public final String c(Cursor cursor) {
        String strH;
        String strH2;
        if (cursor == null) {
            return null;
        }
        String strH3 = h(cursor, cursor.getColumnIndex("suggest_intent_query"));
        if (strH3 != null) {
            return strH3;
        }
        SearchableInfo searchableInfo = this.f790l;
        if (searchableInfo.shouldRewriteQueryFromData() && (strH2 = h(cursor, cursor.getColumnIndex("suggest_intent_data"))) != null) {
            return strH2;
        }
        if (!searchableInfo.shouldRewriteQueryFromText() || (strH = h(cursor, cursor.getColumnIndex("suggest_text_1"))) == null) {
            return null;
        }
        return strH;
    }

    @Override // j0.b
    public final View d(ViewGroup viewGroup) {
        View viewInflate = this.f788j.inflate(this.f786h, viewGroup, false);
        viewInflate.setTag(new g3(viewInflate));
        ((ImageView) viewInflate.findViewById(2131296452)).setImageResource(this.f793o);
        return viewInflate;
    }

    public final Drawable e(Uri uri) throws FileNotFoundException {
        int identifier;
        String authority = uri.getAuthority();
        if (TextUtils.isEmpty(authority)) {
            f3.h(uri, "No authority: ");
            return null;
        }
        try {
            Resources resourcesForApplication = this.f791m.getPackageManager().getResourcesForApplication(authority);
            List<String> pathSegments = uri.getPathSegments();
            if (pathSegments == null) {
                f3.h(uri, "No path: ");
                return null;
            }
            int size = pathSegments.size();
            if (size == 1) {
                try {
                    identifier = Integer.parseInt(pathSegments.get(0));
                } catch (NumberFormatException unused) {
                    f3.h(uri, "Single path segment is not a resource ID: ");
                    return null;
                }
            } else {
                if (size != 2) {
                    f3.h(uri, "More than two path segments: ");
                    return null;
                }
                identifier = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
            }
            if (identifier != 0) {
                return resourcesForApplication.getDrawable(identifier);
            }
            f3.h(uri, "No resource found for: ");
            return null;
        } catch (PackageManager.NameNotFoundException unused2) {
            f3.h(uri, "No package found for authority: ");
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:52:0x00ea  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.graphics.drawable.Drawable f(java.lang.String r11) {
        /*
            Method dump skipped, instruction units count: 242
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.h3.f(java.lang.String):android.graphics.drawable.Drawable");
    }

    public final Cursor g(SearchableInfo searchableInfo, String str) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder builderFragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            builderFragment.appendEncodedPath(suggestPath);
        }
        builderFragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            builderFragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        builderFragment.appendQueryParameter("limit", String.valueOf(50));
        return this.f791m.getContentResolver().query(builderFragment.build(), null, suggestSelection, strArr2, null);
    }

    @Override // j0.b, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public final View getDropDownView(int i7, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i7, view, viewGroup);
        } catch (RuntimeException e) {
            View viewInflate = this.f788j.inflate(this.f787i, viewGroup, false);
            if (viewInflate != null) {
                ((g3) viewInflate.getTag()).f780a.setText(e.toString());
            }
            return viewInflate;
        }
    }

    @Override // j0.b, android.widget.Adapter
    public final View getView(int i7, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i7, view, viewGroup);
        } catch (RuntimeException e) {
            View viewD = d(viewGroup);
            ((g3) viewD.getTag()).f780a.setText(e.toString());
            return viewD;
        }
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public final boolean hasStableIds() {
        return false;
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        Cursor cursor = this.f6353c;
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null) {
            extras.getBoolean("in_progress");
        }
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        Cursor cursor = this.f6353c;
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null) {
            extras.getBoolean("in_progress");
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f789k.p((CharSequence) tag);
        }
    }
}
