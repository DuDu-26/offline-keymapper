package androidx.appcompat.widget;

import android.R;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f780a;
    public final TextView b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ImageView f781c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ImageView f782d;
    public final ImageView e;

    public g3(View view) {
        this.f780a = (TextView) view.findViewById(R.id.text1);
        this.b = (TextView) view.findViewById(R.id.text2);
        this.f781c = (ImageView) view.findViewById(R.id.icon1);
        this.f782d = (ImageView) view.findViewById(R.id.icon2);
        this.e = (ImageView) view.findViewById(2131296452);
    }
}
