package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g extends g.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ l f776a;

    public g(l lVar) {
        this.f776a = lVar;
    }
}
