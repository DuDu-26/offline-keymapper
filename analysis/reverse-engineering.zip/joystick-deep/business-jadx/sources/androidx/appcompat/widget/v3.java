package androidx.appcompat.widget;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class v3 implements l1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Toolbar f938a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f939c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f940d;
    public Drawable e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f941f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f942g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f943h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f944i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f945j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Window.Callback f946k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f947l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public l f948m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f949n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Drawable f950o;

    public final void a(int i7) {
        View view;
        Toolbar toolbar = this.f938a;
        int i8 = this.b ^ i7;
        this.b = i7;
        if (i8 != 0) {
            if ((i8 & 4) != 0) {
                if ((i7 & 4) != 0) {
                    b();
                }
                if ((this.b & 4) != 0) {
                    Drawable drawable = this.f941f;
                    if (drawable == null) {
                        drawable = this.f950o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i8 & 3) != 0) {
                c();
            }
            if ((i8 & 8) != 0) {
                if ((i7 & 8) != 0) {
                    toolbar.setTitle(this.f943h);
                    toolbar.setSubtitle(this.f944i);
                } else {
                    toolbar.setTitle((CharSequence) null);
                    toolbar.setSubtitle((CharSequence) null);
                }
            }
            if ((i8 & 16) == 0 || (view = this.f939c) == null) {
                return;
            }
            if ((i7 & 16) != 0) {
                toolbar.addView(view);
            } else {
                toolbar.removeView(view);
            }
        }
    }

    public final void b() {
        if ((this.b & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f945j);
            Toolbar toolbar = this.f938a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f949n);
            } else {
                toolbar.setNavigationContentDescription(this.f945j);
            }
        }
    }

    public final void c() {
        Drawable drawable;
        int i7 = this.b;
        if ((i7 & 2) == 0) {
            drawable = null;
        } else if ((i7 & 1) == 0 || (drawable = this.e) == null) {
            drawable = this.f940d;
        }
        this.f938a.setLogo(drawable);
    }
}
