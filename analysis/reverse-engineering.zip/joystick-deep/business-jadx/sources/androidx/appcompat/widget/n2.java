package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n2 {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static n2 f862g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakHashMap f864a;
    public final WeakHashMap b = new WeakHashMap(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f865c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f866d;
    public q6.c e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final PorterDuff.Mode f861f = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final m2 f863h = new m2(6);

    public static synchronized n2 b() {
        try {
            if (f862g == null) {
                f862g = new n2();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f862g;
    }

    public static synchronized PorterDuffColorFilter e(int i7, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        m2 m2Var = f863h;
        m2Var.getClass();
        int i8 = (31 + i7) * 31;
        porterDuffColorFilter = (PorterDuffColorFilter) m2Var.a(Integer.valueOf(mode.hashCode() + i8));
        if (porterDuffColorFilter == null) {
            porterDuffColorFilter = new PorterDuffColorFilter(i7, mode);
        }
        return porterDuffColorFilter;
    }

    public final Drawable a(Context context, int i7) {
        LayerDrawable layerDrawableK;
        WeakReference weakReference;
        Drawable drawableNewDrawable;
        if (this.f865c == null) {
            this.f865c = new TypedValue();
        }
        TypedValue typedValue = this.f865c;
        context.getResources().getValue(i7, typedValue, true);
        long j7 = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
        synchronized (this) {
            l.e eVar = (l.e) this.b.get(context);
            layerDrawableK = null;
            if (eVar != null && (weakReference = (WeakReference) eVar.c(j7)) != null) {
                Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
                if (constantState != null) {
                    drawableNewDrawable = constantState.newDrawable(context.getResources());
                } else {
                    eVar.f(j7);
                }
            }
            drawableNewDrawable = null;
        }
        if (drawableNewDrawable != null) {
            return drawableNewDrawable;
        }
        if (this.e != null) {
            if (i7 == 2131230776) {
                layerDrawableK = new LayerDrawable(new Drawable[]{c(context, 2131230775), c(context, 2131230777)});
            } else if (i7 == 2131230811) {
                layerDrawableK = q6.c.k(this, context, 2131165243);
            } else if (i7 == 2131230810) {
                layerDrawableK = q6.c.k(this, context, 2131165244);
            } else if (i7 == 2131230812) {
                layerDrawableK = q6.c.k(this, context, 2131165245);
            }
        }
        if (layerDrawableK == null) {
            return layerDrawableK;
        }
        layerDrawableK.setChangingConfigurations(typedValue.changingConfigurations);
        synchronized (this) {
            try {
                Drawable.ConstantState constantState2 = layerDrawableK.getConstantState();
                if (constantState2 == null) {
                    return layerDrawableK;
                }
                l.e eVar2 = (l.e) this.b.get(context);
                if (eVar2 == null) {
                    eVar2 = new l.e();
                    this.b.put(context, eVar2);
                }
                eVar2.e(j7, new WeakReference(constantState2));
                return layerDrawableK;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final synchronized Drawable c(Context context, int i7) {
        return d(context, i7, false);
    }

    public final synchronized Drawable d(Context context, int i7, boolean z6) {
        Drawable drawableA;
        try {
            if (!this.f866d) {
                this.f866d = true;
                Drawable drawableC = c(context, 2131230838);
                if (drawableC == null || (!(drawableC instanceof y0.o) && !"android.graphics.drawable.VectorDrawable".equals(drawableC.getClass().getName()))) {
                    this.f866d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            drawableA = a(context, i7);
            if (drawableA == null) {
                drawableA = androidx.core.content.b.b(context, i7);
            }
            if (drawableA != null) {
                drawableA = g(context, i7, z6, drawableA);
            }
            if (drawableA != null) {
                m1.a(drawableA);
            }
        } catch (Throwable th) {
            throw th;
        }
        return drawableA;
    }

    public final synchronized ColorStateList f(Context context, int i7) {
        ColorStateList colorStateList;
        l.l lVar;
        Object obj;
        WeakHashMap weakHashMap = this.f864a;
        ColorStateList colorStateListL = null;
        if (weakHashMap == null || (lVar = (l.l) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            int iA = l.d.a(lVar.f6717c, i7, lVar.f6716a);
            if (iA < 0 || (obj = lVar.b[iA]) == l.l.f6715d) {
                obj = null;
            }
            colorStateList = (ColorStateList) obj;
        }
        if (colorStateList == null) {
            q6.c cVar = this.e;
            if (cVar != null) {
                colorStateListL = cVar.l(context, i7);
            }
            if (colorStateListL != null) {
                if (this.f864a == null) {
                    this.f864a = new WeakHashMap();
                }
                l.l lVar2 = (l.l) this.f864a.get(context);
                if (lVar2 == null) {
                    lVar2 = new l.l();
                    this.f864a.put(context, lVar2);
                }
                lVar2.a(i7, colorStateListL);
            }
            colorStateList = colorStateListL;
        }
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:47:0x00e4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.graphics.drawable.Drawable g(android.content.Context r10, int r11, boolean r12, android.graphics.drawable.Drawable r13) {
        /*
            Method dump skipped, instruction units count: 257
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.n2.g(android.content.Context, int, boolean, android.graphics.drawable.Drawable):android.graphics.drawable.Drawable");
    }
}
