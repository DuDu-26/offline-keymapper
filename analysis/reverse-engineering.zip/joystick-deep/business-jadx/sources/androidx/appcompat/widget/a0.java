package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;
import android.widget.ImageView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class a0 extends ImageButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r f710a;
    public final b0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f711c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a0(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        j3.a(context);
        this.f711c = false;
        i3.a(this, getContext());
        r rVar = new r(this);
        this.f710a = rVar;
        rVar.l(attributeSet, i7);
        b0 b0Var = new b0(this);
        this.b = b0Var;
        b0Var.e(attributeSet, i7);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f710a;
        if (rVar != null) {
            rVar.a();
        }
        b0 b0Var = this.b;
        if (b0Var != null) {
            b0Var.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f710a;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f710a;
        if (rVar != null) {
            return rVar.j();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        k3 k3Var;
        b0 b0Var = this.b;
        if (b0Var == null || (k3Var = (k3) b0Var.f715d) == null) {
            return null;
        }
        return (ColorStateList) k3Var.f831c;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        k3 k3Var;
        b0 b0Var = this.b;
        if (b0Var == null || (k3Var = (k3) b0Var.f715d) == null) {
            return null;
        }
        return (PorterDuff.Mode) k3Var.f832d;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(((ImageView) this.b.f714c).getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f710a;
        if (rVar != null) {
            rVar.n();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i7) {
        super.setBackgroundResource(i7);
        r rVar = this.f710a;
        if (rVar != null) {
            rVar.o(i7);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        b0 b0Var = this.b;
        if (b0Var != null) {
            b0Var.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        b0 b0Var = this.b;
        if (b0Var != null && drawable != null && !this.f711c) {
            b0Var.b = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (b0Var != null) {
            b0Var.a();
            if (this.f711c) {
                return;
            }
            ImageView imageView = (ImageView) b0Var.f714c;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(b0Var.b);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i7) {
        super.setImageLevel(i7);
        this.f711c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i7) {
        this.b.h(i7);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        b0 b0Var = this.b;
        if (b0Var != null) {
            b0Var.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f710a;
        if (rVar != null) {
            rVar.t(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f710a;
        if (rVar != null) {
            rVar.u(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        b0 b0Var = this.b;
        if (b0Var != null) {
            if (((k3) b0Var.f715d) == null) {
                b0Var.f715d = new k3();
            }
            k3 k3Var = (k3) b0Var.f715d;
            k3Var.f831c = colorStateList;
            k3Var.b = true;
            b0Var.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        b0 b0Var = this.b;
        if (b0Var != null) {
            if (((k3) b0Var.f715d) == null) {
                b0Var.f715d = new k3();
            }
            k3 k3Var = (k3) b0Var.f715d;
            k3Var.f832d = mode;
            k3Var.f830a = true;
            b0Var.a();
        }
    }
}
