package androidx.appcompat.widget;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController$RecycleListView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q0 implements v0, DialogInterface.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.appcompat.app.h f886a;
    public r0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f887c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ w0 f888d;

    public q0(w0 w0Var) {
        this.f888d = w0Var;
    }

    @Override // androidx.appcompat.widget.v0
    public final boolean a() {
        androidx.appcompat.app.h hVar = this.f886a;
        if (hVar != null) {
            return hVar.isShowing();
        }
        return false;
    }

    @Override // androidx.appcompat.widget.v0
    public final int b() {
        return 0;
    }

    @Override // androidx.appcompat.widget.v0
    public final Drawable d() {
        return null;
    }

    @Override // androidx.appcompat.widget.v0
    public final void dismiss() {
        androidx.appcompat.app.h hVar = this.f886a;
        if (hVar != null) {
            hVar.dismiss();
            this.f886a = null;
        }
    }

    @Override // androidx.appcompat.widget.v0
    public final void e(CharSequence charSequence) {
        this.f887c = charSequence;
    }

    @Override // androidx.appcompat.widget.v0
    public final void i(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    @Override // androidx.appcompat.widget.v0
    public final void j(int i7) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    @Override // androidx.appcompat.widget.v0
    public final void k(int i7) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }

    @Override // androidx.appcompat.widget.v0
    public final void l(int i7) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    @Override // androidx.appcompat.widget.v0
    public final void m(int i7, int i8) {
        if (this.b == null) {
            return;
        }
        w0 w0Var = this.f888d;
        androidx.appcompat.app.g gVar = new androidx.appcompat.app.g(w0Var.getPopupContext());
        androidx.appcompat.app.c cVar = (androidx.appcompat.app.c) gVar.b;
        CharSequence charSequence = this.f887c;
        if (charSequence != null) {
            cVar.f418d = charSequence;
        }
        r0 r0Var = this.b;
        int selectedItemPosition = w0Var.getSelectedItemPosition();
        cVar.f426m = r0Var;
        cVar.f427n = this;
        cVar.f429p = selectedItemPosition;
        cVar.f428o = true;
        androidx.appcompat.app.h hVarD = gVar.d();
        this.f886a = hVarD;
        AlertController$RecycleListView alertController$RecycleListView = hVarD.f496f.f465f;
        o0.d(alertController$RecycleListView, i7);
        o0.c(alertController$RecycleListView, i8);
        this.f886a.show();
    }

    @Override // androidx.appcompat.widget.v0
    public final int n() {
        return 0;
    }

    @Override // androidx.appcompat.widget.v0
    public final CharSequence o() {
        return this.f887c;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i7) {
        w0 w0Var = this.f888d;
        w0Var.setSelection(i7);
        if (w0Var.getOnItemClickListener() != null) {
            w0Var.performItemClick(null, i7, this.b.getItemId(i7));
        }
        dismiss();
    }

    @Override // androidx.appcompat.widget.v0
    public final void p(ListAdapter listAdapter) {
        this.b = (r0) listAdapter;
    }
}
