package androidx.appcompat.widget;

import android.content.Context;
import android.view.View;
import android.view.Window;
import moe.heroman.eventtest.adbhelper.AdbProtocol;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class t3 implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g.a f917a;
    public final /* synthetic */ v3 b;

    public t3(v3 v3Var) {
        this.b = v3Var;
        Context context = v3Var.f938a.getContext();
        CharSequence charSequence = v3Var.f943h;
        g.a aVar = new g.a();
        aVar.e = AdbProtocol.A_MAXDATA;
        aVar.f5689g = AdbProtocol.A_MAXDATA;
        aVar.f5694l = null;
        aVar.f5695m = null;
        aVar.f5696n = false;
        aVar.f5697o = false;
        aVar.f5698p = 16;
        aVar.f5691i = context;
        aVar.f5685a = charSequence;
        this.f917a = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        v3 v3Var = this.b;
        Window.Callback callback = v3Var.f946k;
        if (callback == null || !v3Var.f947l) {
            return;
        }
        callback.onMenuItemSelected(0, this.f917a);
    }
}
