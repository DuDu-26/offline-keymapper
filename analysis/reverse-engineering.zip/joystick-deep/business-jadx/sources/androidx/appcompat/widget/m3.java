package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class m3 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f860a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ m3(Toolbar toolbar, int i7) {
        this.f860a = i7;
        this.b = toolbar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f860a) {
            case 0:
                p3 p3Var = this.b.L;
                g.n nVar = p3Var == null ? null : p3Var.b;
                if (nVar != null) {
                    nVar.collapseActionView();
                }
                break;
            default:
                this.b.n();
                break;
        }
    }
}
