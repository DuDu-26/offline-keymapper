package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l implements g.y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f833a;
    public Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public g.l f834c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LayoutInflater f835d;
    public g.x e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public g.a0 f838h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f839i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public j f840j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Drawable f841k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f842l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f843m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f844n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f845o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f846p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f847q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f848r;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public f f850t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public f f851u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public h f852v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public g f853w;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f855y;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f836f = 2131492867;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f837g = 2131492866;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final SparseBooleanArray f849s = new SparseBooleanArray();

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final w3.e f854x = new w3.e(7, this);

    public l(Context context) {
        this.f833a = context;
        this.f835d = LayoutInflater.from(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View a(g.n nVar, View view, ViewGroup viewGroup) {
        View actionView = nVar.getActionView();
        if (actionView == null || nVar.e()) {
            g.z zVar = view instanceof g.z ? (g.z) view : (g.z) this.f835d.inflate(this.f837g, viewGroup, false);
            zVar.b(nVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) zVar;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f838h);
            if (this.f853w == null) {
                this.f853w = new g(this);
            }
            actionMenuItemView.setPopupCallback(this.f853w);
            actionView = (View) zVar;
        }
        actionView.setVisibility(nVar.C ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof o)) {
            actionView.setLayoutParams(ActionMenuView.k(layoutParams));
        }
        return actionView;
    }

    @Override // g.y
    public final void b(g.x xVar) {
        throw null;
    }

    public final boolean c() {
        Object obj;
        h hVar = this.f852v;
        if (hVar != null && (obj = this.f838h) != null) {
            ((View) obj).removeCallbacks(hVar);
            this.f852v = null;
            return true;
        }
        f fVar = this.f850t;
        if (fVar == null) {
            return false;
        }
        if (fVar.b()) {
            fVar.f5820i.dismiss();
        }
        return true;
    }

    @Override // g.y
    public final void d(g.l lVar, boolean z6) {
        c();
        f fVar = this.f851u;
        if (fVar != null && fVar.b()) {
            fVar.f5820i.dismiss();
        }
        g.x xVar = this.e;
        if (xVar != null) {
            xVar.d(lVar, z6);
        }
    }

    @Override // g.y
    public final boolean e(g.n nVar) {
        return false;
    }

    @Override // g.y
    public final void f(Parcelable parcelable) {
        int i7;
        MenuItem menuItemFindItem;
        if ((parcelable instanceof ActionMenuPresenter$SavedState) && (i7 = ((ActionMenuPresenter$SavedState) parcelable).f637a) > 0 && (menuItemFindItem = this.f834c.findItem(i7)) != null) {
            j((g.e0) menuItemFindItem.getSubMenu());
        }
    }

    @Override // g.y
    public final boolean g(g.n nVar) {
        return false;
    }

    @Override // g.y
    public final int getId() {
        return this.f839i;
    }

    public final boolean h() {
        f fVar = this.f850t;
        return fVar != null && fVar.b();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // g.y
    public final void i(boolean z6) {
        int i7;
        ViewGroup viewGroup = (ViewGroup) this.f838h;
        ArrayList arrayList = null;
        boolean z7 = false;
        if (viewGroup != null) {
            g.l lVar = this.f834c;
            if (lVar != null) {
                lVar.i();
                ArrayList arrayListL = this.f834c.l();
                int size = arrayListL.size();
                i7 = 0;
                for (int i8 = 0; i8 < size; i8++) {
                    g.n nVar = (g.n) arrayListL.get(i8);
                    if ((nVar.f5803x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i7);
                        g.n itemData = childAt instanceof g.z ? ((g.z) childAt).getItemData() : null;
                        View viewA = a(nVar, childAt, viewGroup);
                        if (nVar != itemData) {
                            viewA.setPressed(false);
                            viewA.jumpDrawablesToCurrentState();
                        }
                        if (viewA != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewA.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewA);
                            }
                            ((ViewGroup) this.f838h).addView(viewA, i7);
                        }
                        i7++;
                    }
                }
            } else {
                i7 = 0;
            }
            while (i7 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i7) == this.f840j) {
                    i7++;
                } else {
                    viewGroup.removeViewAt(i7);
                }
            }
        }
        ((View) this.f838h).requestLayout();
        g.l lVar2 = this.f834c;
        if (lVar2 != null) {
            lVar2.i();
            ArrayList arrayList2 = lVar2.f5764i;
            int size2 = arrayList2.size();
            for (int i9 = 0; i9 < size2; i9++) {
                g.o oVar = ((g.n) arrayList2.get(i9)).A;
            }
        }
        g.l lVar3 = this.f834c;
        if (lVar3 != null) {
            lVar3.i();
            arrayList = lVar3.f5765j;
        }
        if (this.f843m && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z7 = !((g.n) arrayList.get(0)).C;
            } else if (size3 > 0) {
                z7 = true;
            }
        }
        j jVar = this.f840j;
        if (z7) {
            if (jVar == null) {
                this.f840j = new j(this, this.f833a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f840j.getParent();
            if (viewGroup3 != this.f838h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f840j);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f838h;
                j jVar2 = this.f840j;
                actionMenuView.getClass();
                o oVarJ = ActionMenuView.j();
                oVarJ.f868a = true;
                actionMenuView.addView(jVar2, oVarJ);
            }
        } else if (jVar != null) {
            Object parent = jVar.getParent();
            Object obj = this.f838h;
            if (parent == obj) {
                ((ViewGroup) obj).removeView(this.f840j);
            }
        }
        ((ActionMenuView) this.f838h).setOverflowReserved(this.f843m);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // g.y
    public final boolean j(g.e0 e0Var) {
        boolean z6;
        if (e0Var.hasVisibleItems()) {
            g.e0 e0Var2 = e0Var;
            while (true) {
                g.l lVar = e0Var2.f5724z;
                if (lVar == this.f834c) {
                    break;
                }
                e0Var2 = (g.e0) lVar;
            }
            g.n nVar = e0Var2.A;
            ViewGroup viewGroup = (ViewGroup) this.f838h;
            View view = null;
            view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i7 = 0;
                while (true) {
                    if (i7 >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i7);
                    if ((childAt instanceof g.z) && ((g.z) childAt).getItemData() == nVar) {
                        view = childAt;
                        break;
                    }
                    i7++;
                }
            }
            if (view != null) {
                this.f855y = e0Var.A.f5782a;
                int size = e0Var.f5761f.size();
                int i8 = 0;
                while (true) {
                    if (i8 >= size) {
                        z6 = false;
                        break;
                    }
                    MenuItem item = e0Var.getItem(i8);
                    if (item.isVisible() && item.getIcon() != null) {
                        z6 = true;
                        break;
                    }
                    i8++;
                }
                f fVar = new f(this, this.b, e0Var, view);
                this.f851u = fVar;
                fVar.f5818g = z6;
                g.t tVar = fVar.f5820i;
                if (tVar != null) {
                    tVar.q(z6);
                }
                f fVar2 = this.f851u;
                if (!fVar2.b()) {
                    if (fVar2.e == null) {
                        f3.t("MenuPopupHelper cannot be used without an anchor");
                        return false;
                    }
                    fVar2.d(0, 0, false, false);
                }
                g.x xVar = this.e;
                if (xVar != null) {
                    xVar.m(e0Var);
                }
                return true;
            }
        }
        return false;
    }

    @Override // g.y
    public final boolean k() {
        int size;
        ArrayList arrayListL;
        int i7;
        boolean z6;
        l lVar = this;
        g.l lVar2 = lVar.f834c;
        if (lVar2 != null) {
            arrayListL = lVar2.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i8 = lVar.f847q;
        int i9 = lVar.f846p;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) lVar.f838h;
        int i10 = 0;
        boolean z7 = false;
        int i11 = 0;
        int i12 = 0;
        while (true) {
            i7 = 2;
            z6 = true;
            if (i10 >= size) {
                break;
            }
            g.n nVar = (g.n) arrayListL.get(i10);
            int i13 = nVar.f5804y;
            if ((i13 & 2) == 2) {
                i11++;
            } else if ((i13 & 1) == 1) {
                i12++;
            } else {
                z7 = true;
            }
            if (lVar.f848r && nVar.C) {
                i8 = 0;
            }
            i10++;
        }
        if (lVar.f843m && (z7 || i12 + i11 > i8)) {
            i8--;
        }
        int i14 = i8 - i11;
        SparseBooleanArray sparseBooleanArray = lVar.f849s;
        sparseBooleanArray.clear();
        int i15 = 0;
        int i16 = 0;
        while (i15 < size) {
            g.n nVar2 = (g.n) arrayListL.get(i15);
            int i17 = nVar2.f5804y;
            boolean z8 = (i17 & 2) == i7 ? z6 : false;
            int i18 = nVar2.b;
            if (z8) {
                View viewA = lVar.a(nVar2, null, viewGroup);
                viewA.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewA.getMeasuredWidth();
                i9 -= measuredWidth;
                if (i16 == 0) {
                    i16 = measuredWidth;
                }
                if (i18 != 0) {
                    sparseBooleanArray.put(i18, z6);
                }
                nVar2.g(z6);
            } else if ((i17 & 1) == z6) {
                boolean z9 = sparseBooleanArray.get(i18);
                boolean z10 = ((i14 > 0 || z9) && i9 > 0) ? z6 : false;
                if (z10) {
                    View viewA2 = lVar.a(nVar2, null, viewGroup);
                    viewA2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    int measuredWidth2 = viewA2.getMeasuredWidth();
                    i9 -= measuredWidth2;
                    if (i16 == 0) {
                        i16 = measuredWidth2;
                    }
                    z10 &= i9 + i16 > 0;
                }
                if (z10 && i18 != 0) {
                    sparseBooleanArray.put(i18, true);
                } else if (z9) {
                    sparseBooleanArray.put(i18, false);
                    for (int i19 = 0; i19 < i15; i19++) {
                        g.n nVar3 = (g.n) arrayListL.get(i19);
                        if (nVar3.b == i18) {
                            if ((nVar3.f5803x & 32) == 32) {
                                i14++;
                            }
                            nVar3.g(false);
                        }
                    }
                }
                if (z10) {
                    i14--;
                }
                nVar2.g(z10);
            } else {
                nVar2.g(false);
                i15++;
                i7 = 2;
                lVar = this;
                z6 = true;
            }
            i15++;
            i7 = 2;
            lVar = this;
            z6 = true;
        }
        return z6;
    }

    @Override // g.y
    public final Parcelable l() {
        ActionMenuPresenter$SavedState actionMenuPresenter$SavedState = new ActionMenuPresenter$SavedState();
        actionMenuPresenter$SavedState.f637a = this.f855y;
        return actionMenuPresenter$SavedState;
    }

    @Override // g.y
    public final void m(Context context, g.l lVar) {
        this.b = context;
        LayoutInflater.from(context);
        this.f834c = lVar;
        Resources resources = context.getResources();
        if (!this.f844n) {
            this.f843m = true;
        }
        int i7 = 2;
        this.f845o = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i8 = configuration.screenWidthDp;
        int i9 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i8 > 600 || ((i8 > 960 && i9 > 720) || (i8 > 720 && i9 > 960))) {
            i7 = 5;
        } else if (i8 >= 500 || ((i8 > 640 && i9 > 480) || (i8 > 480 && i9 > 640))) {
            i7 = 4;
        } else if (i8 >= 360) {
            i7 = 3;
        }
        this.f847q = i7;
        int measuredWidth = this.f845o;
        if (this.f843m) {
            if (this.f840j == null) {
                j jVar = new j(this, this.f833a);
                this.f840j = jVar;
                if (this.f842l) {
                    jVar.setImageDrawable(this.f841k);
                    this.f841k = null;
                    this.f842l = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f840j.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f840j.getMeasuredWidth();
        } else {
            this.f840j = null;
        }
        this.f846p = measuredWidth;
        float f2 = resources.getDisplayMetrics().density;
    }

    public final boolean n() {
        g.l lVar;
        if (!this.f843m || h() || (lVar = this.f834c) == null || this.f838h == null || this.f852v != null) {
            return false;
        }
        lVar.i();
        if (lVar.f5765j.isEmpty()) {
            return false;
        }
        h hVar = new h(this, new f(this, this.b, this.f834c, this.f840j));
        this.f852v = hVar;
        ((View) this.f838h).post(hVar);
        return true;
    }
}
