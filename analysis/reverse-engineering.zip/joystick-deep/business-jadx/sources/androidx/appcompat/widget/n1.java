package androidx.appcompat.widget;

import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class n1 {
    public static void a(View view, float f2, float f7) {
        view.drawableHotspotChanged(f2, f7);
    }
}
