package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k2 extends s1 {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f826m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f827n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public g2 f828o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public g.n f829p;

    public k2(Context context, boolean z6) {
        super(context, z6);
        if (1 == j2.a(context.getResources().getConfiguration())) {
            this.f826m = 21;
            this.f827n = 22;
        } else {
            this.f826m = 22;
            this.f827n = 21;
        }
    }

    @Override // androidx.appcompat.widget.s1, android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        g.i iVar;
        int headersCount;
        int iPointToPosition;
        int i7;
        if (this.f828o != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                headersCount = headerViewListAdapter.getHeadersCount();
                iVar = (g.i) headerViewListAdapter.getWrappedAdapter();
            } else {
                iVar = (g.i) adapter;
                headersCount = 0;
            }
            g.n nVarB = (motionEvent.getAction() == 10 || (iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i7 = iPointToPosition - headersCount) < 0 || i7 >= iVar.getCount()) ? null : iVar.b(i7);
            g.n nVar = this.f829p;
            if (nVar != nVarB) {
                g.l lVar = iVar.f5753a;
                if (nVar != null) {
                    this.f828o.g(lVar, nVar);
                }
                this.f829p = nVarB;
                if (nVarB != null) {
                    this.f828o.f(lVar, nVarB);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i7, KeyEvent keyEvent) {
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i7 == this.f826m) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        }
        if (listMenuItemView == null || i7 != this.f827n) {
            return super.onKeyDown(i7, keyEvent);
        }
        setSelection(-1);
        ListAdapter adapter = getAdapter();
        (adapter instanceof HeaderViewListAdapter ? (g.i) ((HeaderViewListAdapter) adapter).getWrappedAdapter() : (g.i) adapter).f5753a.c(false);
        return true;
    }

    public void setHoverListener(g2 g2Var) {
        this.f828o = g2Var;
    }

    @Override // androidx.appcompat.widget.s1, android.widget.AbsListView
    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
