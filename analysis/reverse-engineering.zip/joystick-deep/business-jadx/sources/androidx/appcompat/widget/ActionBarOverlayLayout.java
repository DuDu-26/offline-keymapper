package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import com.umeng.analytics.pro.bc;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements f0.p, f0.q {
    public static final int[] B = {2130968581, R.attr.windowContentOverlay};
    public final androidx.recyclerview.widget.p0 A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f613a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f614c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f615d;
    public l1 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f616f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f617g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f618h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f619i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f620j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f621k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f622l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f623m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Rect f624n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Rect f625o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Rect f626p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public f0.w1 f627q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public f0.w1 f628r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public f0.w1 f629s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public f0.w1 f630t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public d f631u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public OverScroller f632v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ViewPropertyAnimator f633w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final b f634x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final c f635y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final c f636z;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 0;
        this.f624n = new Rect();
        this.f625o = new Rect();
        this.f626p = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        f0.w1 w1Var = f0.w1.b;
        this.f627q = w1Var;
        this.f628r = w1Var;
        this.f629s = w1Var;
        this.f630t = w1Var;
        this.f634x = new b(0, this);
        this.f635y = new c(this, 0);
        this.f636z = new c(this, 1);
        i(context);
        this.A = new androidx.recyclerview.widget.p0();
    }

    public static boolean g(View view, Rect rect, boolean z6) {
        boolean z7;
        e eVar = (e) view.getLayoutParams();
        int i7 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
        int i8 = rect.left;
        if (i7 != i8) {
            ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i8;
            z7 = true;
        } else {
            z7 = false;
        }
        int i9 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        int i10 = rect.top;
        if (i9 != i10) {
            ((ViewGroup.MarginLayoutParams) eVar).topMargin = i10;
            z7 = true;
        }
        int i11 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
        int i12 = rect.right;
        if (i11 != i12) {
            ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i12;
            z7 = true;
        }
        if (z6) {
            int i13 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            int i14 = rect.bottom;
            if (i13 != i14) {
                ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i14;
                return true;
            }
        }
        return z7;
    }

    @Override // f0.p
    public final void a(View view, View view2, int i7, int i8) {
        if (i8 == 0) {
            onNestedScrollAccepted(view, view2, i7);
        }
    }

    @Override // f0.p
    public final void b(View view, int i7) {
        if (i7 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // f0.p
    public final void c(View view, int i7, int i8, int[] iArr, int i9) {
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // f0.q
    public final void d(View view, int i7, int i8, int i9, int i10, int i11, int[] iArr) {
        e(view, i7, i8, i9, i10, i11);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f616f == null || this.f617g) {
            return;
        }
        if (this.f615d.getVisibility() == 0) {
            translationY = (int) (this.f615d.getTranslationY() + this.f615d.getBottom() + 0.5f);
        } else {
            translationY = 0;
        }
        this.f616f.setBounds(0, translationY, getWidth(), this.f616f.getIntrinsicHeight() + translationY);
        this.f616f.draw(canvas);
    }

    @Override // f0.p
    public final void e(View view, int i7, int i8, int i9, int i10, int i11) {
        if (i11 == 0) {
            onNestedScroll(view, i7, i8, i9, i10);
        }
    }

    @Override // f0.p
    public final boolean f(View view, View view2, int i7, int i8) {
        return i8 == 0 && onStartNestedScroll(view, view2, i7);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f615d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        androidx.recyclerview.widget.p0 p0Var = this.A;
        return p0Var.b | p0Var.f1623a;
    }

    public CharSequence getTitle() {
        k();
        return ((v3) this.e).f938a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f635y);
        removeCallbacks(this.f636z);
        ViewPropertyAnimator viewPropertyAnimator = this.f633w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(B);
        this.f613a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f616f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f617g = context.getApplicationInfo().targetSdkVersion < 19;
        this.f632v = new OverScroller(context);
    }

    public final void j(int i7) {
        k();
        if (i7 == 2) {
            this.e.getClass();
        } else if (i7 == 5) {
            this.e.getClass();
        } else {
            if (i7 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        l1 wrapper;
        if (this.f614c == null) {
            this.f614c = (ContentFrameLayout) findViewById(2131296309);
            this.f615d = (ActionBarContainer) findViewById(2131296310);
            KeyEvent.Callback callbackFindViewById = findViewById(2131296308);
            if (callbackFindViewById instanceof l1) {
                wrapper = (l1) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    f3.t("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                    return;
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.e = wrapper;
        }
    }

    public final void l(Menu menu, g.x xVar) {
        k();
        v3 v3Var = (v3) this.e;
        Toolbar toolbar = v3Var.f938a;
        if (v3Var.f948m == null) {
            l lVar = new l(toolbar.getContext());
            v3Var.f948m = lVar;
            lVar.f839i = 2131296320;
        }
        l lVar2 = v3Var.f948m;
        lVar2.e = xVar;
        g.l lVar3 = (g.l) menu;
        if (lVar3 == null && toolbar.f680a == null) {
            return;
        }
        toolbar.f();
        g.l lVar4 = toolbar.f680a.f638p;
        if (lVar4 == lVar3) {
            return;
        }
        if (lVar4 != null) {
            lVar4.r(toolbar.K);
            lVar4.r(toolbar.L);
        }
        if (toolbar.L == null) {
            toolbar.L = new p3(toolbar);
        }
        lVar2.f848r = true;
        Context context = toolbar.f687j;
        if (lVar3 != null) {
            lVar3.b(lVar2, context);
            lVar3.b(toolbar.L, toolbar.f687j);
        } else {
            lVar2.m(context, null);
            toolbar.L.m(toolbar.f687j, null);
            lVar2.i(true);
            toolbar.L.i(true);
        }
        toolbar.f680a.setPopupTheme(toolbar.f688k);
        toolbar.f680a.setPresenter(lVar2);
        toolbar.K = lVar2;
        toolbar.u();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        f0.w1 w1VarG = f0.w1.g(this, windowInsets);
        boolean zG = g(this.f615d, new Rect(w1VarG.b(), w1VarG.d(), w1VarG.c(), w1VarG.a()), false);
        WeakHashMap weakHashMap = f0.s0.f5582a;
        Rect rect = this.f624n;
        f0.h0.b(this, w1VarG, rect);
        int i7 = rect.left;
        int i8 = rect.top;
        int i9 = rect.right;
        int i10 = rect.bottom;
        f0.u1 u1Var = w1VarG.f5593a;
        f0.w1 w1VarL = u1Var.l(i7, i8, i9, i10);
        this.f627q = w1VarL;
        boolean z6 = true;
        if (!this.f628r.equals(w1VarL)) {
            this.f628r = this.f627q;
            zG = true;
        }
        Rect rect2 = this.f625o;
        if (rect2.equals(rect)) {
            z6 = zG;
        } else {
            rect2.set(rect);
        }
        if (z6) {
            requestLayout();
        }
        return u1Var.a().f5593a.c().f5593a.b().f();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = f0.s0.f5582a;
        f0.f0.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i12 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i13 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i12, i13, measuredWidth + i12, measuredHeight + i13);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i7, int i8) {
        int measuredHeight;
        k();
        measureChildWithMargins(this.f615d, i7, 0, i8, 0);
        e eVar = (e) this.f615d.getLayoutParams();
        int iMax = Math.max(0, this.f615d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int iMax2 = Math.max(0, this.f615d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f615d.getMeasuredState());
        WeakHashMap weakHashMap = f0.s0.f5582a;
        boolean z6 = (f0.b0.g(this) & bc.e) != 0;
        if (z6) {
            measuredHeight = this.f613a;
            if (this.f619i && this.f615d.getTabContainer() != null) {
                measuredHeight += this.f613a;
            }
        } else {
            measuredHeight = this.f615d.getVisibility() != 8 ? this.f615d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f624n;
        Rect rect2 = this.f626p;
        rect2.set(rect);
        f0.w1 w1Var = this.f627q;
        this.f629s = w1Var;
        if (this.f618h || z6) {
            x.c cVarB = x.c.b(w1Var.b(), this.f629s.d() + measuredHeight, this.f629s.c(), this.f629s.a());
            f0.w1 w1Var2 = this.f629s;
            int i9 = Build.VERSION.SDK_INT;
            f0.o1 n1Var = i9 >= 30 ? new f0.n1(w1Var2) : i9 >= 29 ? new f0.m1(w1Var2) : new f0.l1(w1Var2);
            n1Var.g(cVarB);
            this.f629s = n1Var.b();
        } else {
            rect2.top += measuredHeight;
            rect2.bottom = rect2.bottom;
            this.f629s = w1Var.f5593a.l(0, measuredHeight, 0, 0);
        }
        g(this.f614c, rect2, true);
        if (!this.f630t.equals(this.f629s)) {
            f0.w1 w1Var3 = this.f629s;
            this.f630t = w1Var3;
            ContentFrameLayout contentFrameLayout = this.f614c;
            WindowInsets windowInsetsF = w1Var3.f();
            if (windowInsetsF != null) {
                WindowInsets windowInsetsA = f0.f0.a(contentFrameLayout, windowInsetsF);
                if (!windowInsetsA.equals(windowInsetsF)) {
                    f0.w1.g(contentFrameLayout, windowInsetsA);
                }
            }
        }
        measureChildWithMargins(this.f614c, i7, 0, i8, 0);
        e eVar2 = (e) this.f614c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f614c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f614c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f614c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i7, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i8, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f2, float f7, boolean z6) {
        if (!this.f620j || !z6) {
            return false;
        }
        this.f632v.fling(0, 0, 0, (int) f7, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f632v.getFinalY() > this.f615d.getHeight()) {
            h();
            this.f636z.run();
        } else {
            h();
            this.f635y.run();
        }
        this.f621k = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f2, float f7) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i7, int i8, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i7, int i8, int i9, int i10) {
        int i11 = this.f622l + i8;
        this.f622l = i11;
        setActionBarHideOffset(i11);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i7) {
        androidx.appcompat.app.o0 o0Var;
        f.j jVar;
        this.A.f1623a = i7;
        this.f622l = getActionBarHideOffset();
        h();
        d dVar = this.f631u;
        if (dVar == null || (jVar = (o0Var = (androidx.appcompat.app.o0) dVar).f537s) == null) {
            return;
        }
        jVar.a();
        o0Var.f537s = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i7) {
        if ((i7 & 2) == 0 || this.f615d.getVisibility() != 0) {
            return false;
        }
        return this.f620j;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f620j || this.f621k) {
            return;
        }
        if (this.f622l <= this.f615d.getHeight()) {
            h();
            postDelayed(this.f635y, 600L);
        } else {
            h();
            postDelayed(this.f636z, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i7) {
        super.onWindowSystemUiVisibilityChanged(i7);
        k();
        int i8 = this.f623m ^ i7;
        this.f623m = i7;
        boolean z6 = (i7 & 4) == 0;
        boolean z7 = (i7 & bc.e) != 0;
        d dVar = this.f631u;
        if (dVar != null) {
            androidx.appcompat.app.o0 o0Var = (androidx.appcompat.app.o0) dVar;
            o0Var.f533o = !z7;
            if (z6 || !z7) {
                if (o0Var.f534p) {
                    o0Var.f534p = false;
                    o0Var.f(true);
                }
            } else if (!o0Var.f534p) {
                o0Var.f534p = true;
                o0Var.f(true);
            }
        }
        if ((i8 & bc.e) == 0 || this.f631u == null) {
            return;
        }
        WeakHashMap weakHashMap = f0.s0.f5582a;
        f0.f0.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i7) {
        super.onWindowVisibilityChanged(i7);
        this.b = i7;
        d dVar = this.f631u;
        if (dVar != null) {
            ((androidx.appcompat.app.o0) dVar).f532n = i7;
        }
    }

    public void setActionBarHideOffset(int i7) {
        h();
        this.f615d.setTranslationY(-Math.max(0, Math.min(i7, this.f615d.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.f631u = dVar;
        if (getWindowToken() != null) {
            ((androidx.appcompat.app.o0) this.f631u).f532n = this.b;
            int i7 = this.f623m;
            if (i7 != 0) {
                onWindowSystemUiVisibilityChanged(i7);
                WeakHashMap weakHashMap = f0.s0.f5582a;
                f0.f0.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z6) {
        this.f619i = z6;
    }

    public void setHideOnContentScrollEnabled(boolean z6) {
        if (z6 != this.f620j) {
            this.f620j = z6;
            if (z6) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i7) {
        k();
        v3 v3Var = (v3) this.e;
        v3Var.f940d = i7 != 0 ? a5.h.E(v3Var.f938a.getContext(), i7) : null;
        v3Var.c();
    }

    public void setLogo(int i7) {
        k();
        v3 v3Var = (v3) this.e;
        v3Var.e = i7 != 0 ? a5.h.E(v3Var.f938a.getContext(), i7) : null;
        v3Var.c();
    }

    public void setOverlayMode(boolean z6) {
        this.f618h = z6;
        this.f617g = z6 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z6) {
    }

    public void setUiOptions(int i7) {
    }

    public void setWindowCallback(Window.Callback callback) {
        k();
        ((v3) this.e).f946k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        k();
        v3 v3Var = (v3) this.e;
        if (v3Var.f942g) {
            return;
        }
        Toolbar toolbar = v3Var.f938a;
        v3Var.f943h = charSequence;
        if ((v3Var.b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (v3Var.f942g) {
                f0.s0.k(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        v3 v3Var = (v3) this.e;
        v3Var.f940d = drawable;
        v3Var.c();
    }
}
