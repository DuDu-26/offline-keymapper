package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.customview.view.AbsSavedState;
import com.umeng.commonsdk.statistics.UMErrorCode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList D;
    public final ArrayList E;
    public final int[] F;
    public final y2.o G;
    public ArrayList H;
    public final n3 I;
    public v3 J;
    public l K;
    public p3 L;
    public boolean M;
    public OnBackInvokedCallback N;
    public OnBackInvokedDispatcher O;
    public boolean P;
    public final a4.w1 Q;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ActionMenuView f680a;
    public e1 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public e1 f681c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public a0 f682d;
    public c0 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Drawable f683f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final CharSequence f684g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public a0 f685h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public View f686i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Context f687j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f688k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f689l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f690m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f691n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f692o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f693p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f694q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f695r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f696s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public p2 f697t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f698u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f699v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f700w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public CharSequence f701x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public CharSequence f702y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public ColorStateList f703z;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new s3();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f704c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f705d;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f704c = parcel.readInt();
            this.f705d = parcel.readInt() != 0;
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            parcel.writeInt(this.f704c);
            parcel.writeInt(this.f705d ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, 2130969752);
        this.f700w = 8388627;
        this.D = new ArrayList();
        this.E = new ArrayList();
        this.F = new int[2];
        this.G = new y2.o(new m3(this, 1));
        this.H = new ArrayList();
        this.I = new n3(this);
        this.Q = new a4.w1(3, this);
        Context context2 = getContext();
        int[] iArr = d.a.f5224x;
        y2.e eVarA = y2.e.A(context2, attributeSet, iArr, 2130969752);
        f0.s0.i(this, context, iArr, attributeSet, (TypedArray) eVarA.f8965c, 2130969752);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        this.f689l = typedArray.getResourceId(28, 0);
        this.f690m = typedArray.getResourceId(19, 0);
        this.f700w = typedArray.getInteger(0, 8388627);
        this.f691n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f696s = dimensionPixelOffset;
        this.f695r = dimensionPixelOffset;
        this.f694q = dimensionPixelOffset;
        this.f693p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f693p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f694q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f695r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f696s = dimensionPixelOffset5;
        }
        this.f692o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        p2 p2Var = this.f697t;
        p2Var.f880h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            p2Var.e = dimensionPixelSize;
            p2Var.f875a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            p2Var.f878f = dimensionPixelSize2;
            p2Var.b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            p2Var.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f698u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f699v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f683f = eVarA.o(4);
        this.f684g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f687j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableO = eVarA.o(16);
        if (drawableO != null) {
            setNavigationIcon(drawableO);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableO2 = eVarA.o(11);
        if (drawableO2 != null) {
            setLogo(drawableO2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(eVarA.n(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(eVarA.n(20));
        }
        if (typedArray.hasValue(14)) {
            m(typedArray.getResourceId(14, 0));
        }
        eVarA.C();
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i7 = 0; i7 < menu.size(); i7++) {
            arrayList.add(menu.getItem(i7));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new f.i(getContext());
    }

    public static q3 h() {
        q3 q3Var = new q3(-2, -2);
        q3Var.b = 0;
        q3Var.f890a = 8388627;
        return q3Var;
    }

    public static q3 i(ViewGroup.LayoutParams layoutParams) {
        boolean z6 = layoutParams instanceof q3;
        if (z6) {
            q3 q3Var = (q3) layoutParams;
            q3 q3Var2 = new q3(q3Var);
            q3Var2.b = 0;
            q3Var2.b = q3Var.b;
            return q3Var2;
        }
        if (z6) {
            q3 q3Var3 = new q3((q3) layoutParams);
            q3Var3.b = 0;
            return q3Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            q3 q3Var4 = new q3(layoutParams);
            q3Var4.b = 0;
            return q3Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        q3 q3Var5 = new q3(marginLayoutParams);
        q3Var5.b = 0;
        ((ViewGroup.MarginLayoutParams) q3Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) q3Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) q3Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) q3Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return q3Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return f0.m.b(marginLayoutParams) + f0.m.c(marginLayoutParams);
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i7) {
        WeakHashMap weakHashMap = f0.s0.f5582a;
        boolean z6 = f0.c0.d(this) == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i7, f0.c0.d(this));
        arrayList.clear();
        if (!z6) {
            for (int i8 = 0; i8 < childCount; i8++) {
                View childAt = getChildAt(i8);
                q3 q3Var = (q3) childAt.getLayoutParams();
                if (q3Var.b == 0 && t(childAt)) {
                    int i9 = q3Var.f890a;
                    WeakHashMap weakHashMap2 = f0.s0.f5582a;
                    int iD = f0.c0.d(this);
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i9, iD) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = iD == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i10 = childCount - 1; i10 >= 0; i10--) {
            View childAt2 = getChildAt(i10);
            q3 q3Var2 = (q3) childAt2.getLayoutParams();
            if (q3Var2.b == 0 && t(childAt2)) {
                int i11 = q3Var2.f890a;
                WeakHashMap weakHashMap3 = f0.s0.f5582a;
                int iD2 = f0.c0.d(this);
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i11, iD2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = iD2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z6) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        q3 q3VarH = layoutParams == null ? h() : !checkLayoutParams(layoutParams) ? i(layoutParams) : (q3) layoutParams;
        q3VarH.b = 1;
        if (!z6 || this.f686i == null) {
            addView(view, q3VarH);
        } else {
            view.setLayoutParams(q3VarH);
            this.E.add(view);
        }
    }

    public final void c() {
        if (this.f685h == null) {
            a0 a0Var = new a0(getContext(), null, 2130969751);
            this.f685h = a0Var;
            a0Var.setImageDrawable(this.f683f);
            this.f685h.setContentDescription(this.f684g);
            q3 q3VarH = h();
            q3VarH.f890a = (this.f691n & UMErrorCode.E_UM_BE_DEFLATE_FAILED) | 8388611;
            q3VarH.b = 2;
            this.f685h.setLayoutParams(q3VarH);
            this.f685h.setOnClickListener(new androidx.appcompat.app.a(2, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof q3);
    }

    public final void d() {
        if (this.f697t == null) {
            p2 p2Var = new p2();
            p2Var.f875a = 0;
            p2Var.b = 0;
            p2Var.f876c = Integer.MIN_VALUE;
            p2Var.f877d = Integer.MIN_VALUE;
            p2Var.e = 0;
            p2Var.f878f = 0;
            p2Var.f879g = false;
            p2Var.f880h = false;
            this.f697t = p2Var;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f680a;
        if (actionMenuView.f638p == null) {
            g.l lVar = (g.l) actionMenuView.getMenu();
            if (this.L == null) {
                this.L = new p3(this);
            }
            this.f680a.setExpandedActionViewsExclusive(true);
            lVar.b(this.L, this.f687j);
            u();
        }
    }

    public final void f() {
        if (this.f680a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f680a = actionMenuView;
            actionMenuView.setPopupTheme(this.f688k);
            this.f680a.setOnMenuItemClickListener(this.I);
            ActionMenuView actionMenuView2 = this.f680a;
            n3 n3Var = new n3(this);
            actionMenuView2.getClass();
            actionMenuView2.f643u = n3Var;
            q3 q3VarH = h();
            q3VarH.f890a = (this.f691n & UMErrorCode.E_UM_BE_DEFLATE_FAILED) | 8388613;
            this.f680a.setLayoutParams(q3VarH);
            b(this.f680a, false);
        }
    }

    public final void g() {
        if (this.f682d == null) {
            this.f682d = new a0(getContext(), null, 2130969751);
            q3 q3VarH = h();
            q3VarH.f890a = (this.f691n & UMErrorCode.E_UM_BE_DEFLATE_FAILED) | 8388611;
            this.f682d.setLayoutParams(q3VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        q3 q3Var = new q3(context, attributeSet);
        q3Var.f890a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, d.a.b);
        q3Var.f890a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        q3Var.b = 0;
        return q3Var;
    }

    public CharSequence getCollapseContentDescription() {
        a0 a0Var = this.f685h;
        if (a0Var != null) {
            return a0Var.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        a0 a0Var = this.f685h;
        if (a0Var != null) {
            return a0Var.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        p2 p2Var = this.f697t;
        if (p2Var != null) {
            return p2Var.f879g ? p2Var.f875a : p2Var.b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i7 = this.f699v;
        return i7 != Integer.MIN_VALUE ? i7 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        p2 p2Var = this.f697t;
        if (p2Var != null) {
            return p2Var.f875a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        p2 p2Var = this.f697t;
        if (p2Var != null) {
            return p2Var.b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        p2 p2Var = this.f697t;
        if (p2Var != null) {
            return p2Var.f879g ? p2Var.b : p2Var.f875a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i7 = this.f698u;
        return i7 != Integer.MIN_VALUE ? i7 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        g.l lVar;
        ActionMenuView actionMenuView = this.f680a;
        return (actionMenuView == null || (lVar = actionMenuView.f638p) == null || !lVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f699v, 0));
    }

    public int getCurrentContentInsetLeft() {
        WeakHashMap weakHashMap = f0.s0.f5582a;
        return f0.c0.d(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        WeakHashMap weakHashMap = f0.s0.f5582a;
        return f0.c0.d(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f698u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        c0 c0Var = this.e;
        if (c0Var != null) {
            return c0Var.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        c0 c0Var = this.e;
        if (c0Var != null) {
            return c0Var.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f680a.getMenu();
    }

    public View getNavButtonView() {
        return this.f682d;
    }

    public CharSequence getNavigationContentDescription() {
        a0 a0Var = this.f682d;
        if (a0Var != null) {
            return a0Var.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        a0 a0Var = this.f682d;
        if (a0Var != null) {
            return a0Var.getDrawable();
        }
        return null;
    }

    public l getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f680a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f687j;
    }

    public int getPopupTheme() {
        return this.f688k;
    }

    public CharSequence getSubtitle() {
        return this.f702y;
    }

    public final TextView getSubtitleTextView() {
        return this.f681c;
    }

    public CharSequence getTitle() {
        return this.f701x;
    }

    public int getTitleMarginBottom() {
        return this.f696s;
    }

    public int getTitleMarginEnd() {
        return this.f694q;
    }

    public int getTitleMarginStart() {
        return this.f693p;
    }

    public int getTitleMarginTop() {
        return this.f695r;
    }

    public final TextView getTitleTextView() {
        return this.b;
    }

    public l1 getWrapper() {
        Drawable drawable;
        if (this.J == null) {
            v3 v3Var = new v3();
            v3Var.f949n = 0;
            v3Var.f938a = this;
            v3Var.f943h = getTitle();
            v3Var.f944i = getSubtitle();
            v3Var.f942g = v3Var.f943h != null;
            v3Var.f941f = getNavigationIcon();
            y2.e eVarA = y2.e.A(getContext(), null, d.a.f5203a, 2130968583);
            TypedArray typedArray = (TypedArray) eVarA.f8965c;
            v3Var.f950o = eVarA.o(15);
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                v3Var.f942g = true;
                v3Var.f943h = text;
                if ((v3Var.b & 8) != 0) {
                    setTitle(text);
                    if (v3Var.f942g) {
                        f0.s0.k(getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                v3Var.f944i = text2;
                if ((v3Var.b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable drawableO = eVarA.o(20);
            if (drawableO != null) {
                v3Var.e = drawableO;
                v3Var.c();
            }
            Drawable drawableO2 = eVarA.o(17);
            if (drawableO2 != null) {
                v3Var.f940d = drawableO2;
                v3Var.c();
            }
            if (v3Var.f941f == null && (drawable = v3Var.f950o) != null) {
                v3Var.f941f = drawable;
                if ((v3Var.b & 4) != 0) {
                    setNavigationIcon(drawable);
                } else {
                    setNavigationIcon((Drawable) null);
                }
            }
            v3Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = v3Var.f939c;
                if (view != null && (v3Var.b & 16) != 0) {
                    removeView(view);
                }
                v3Var.f939c = viewInflate;
                if (viewInflate != null && (v3Var.b & 16) != 0) {
                    addView(viewInflate);
                }
                v3Var.a(v3Var.b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f697t.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f689l = resourceId2;
                e1 e1Var = this.b;
                if (e1Var != null) {
                    e1Var.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f690m = resourceId3;
                e1 e1Var2 = this.f681c;
                if (e1Var2 != null) {
                    e1Var2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            eVarA.C();
            if (2131820545 != v3Var.f949n) {
                v3Var.f949n = 2131820545;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i7 = v3Var.f949n;
                    v3Var.f945j = i7 != 0 ? getContext().getString(i7) : null;
                    v3Var.b();
                }
            }
            v3Var.f945j = getNavigationContentDescription();
            setNavigationOnClickListener(new t3(v3Var));
            this.J = v3Var;
        }
        return this.J;
    }

    public final int j(View view, int i7) {
        q3 q3Var = (q3) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i8 = i7 > 0 ? (measuredHeight - i7) / 2 : 0;
        int i9 = q3Var.f890a & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        if (i9 != 16 && i9 != 48 && i9 != 80) {
            i9 = this.f700w & UMErrorCode.E_UM_BE_DEFLATE_FAILED;
        }
        if (i9 == 48) {
            return getPaddingTop() - i8;
        }
        if (i9 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) q3Var).bottomMargin) - i8;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i10 = ((ViewGroup.MarginLayoutParams) q3Var).topMargin;
        if (iMax < i10) {
            iMax = i10;
        } else {
            int i11 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i12 = ((ViewGroup.MarginLayoutParams) q3Var).bottomMargin;
            if (i11 < i12) {
                iMax = Math.max(0, iMax - (i12 - i11));
            }
        }
        return paddingTop + iMax;
    }

    public void m(int i7) {
        getMenuInflater().inflate(i7, getMenu());
    }

    public final void n() {
        ArrayList arrayList = this.H;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.G.f8985c).iterator();
        if (it.hasNext()) {
            it.next().getClass();
            f3.b();
        } else {
            ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
            currentMenuItems2.removeAll(currentMenuItems);
            this.H = currentMenuItems2;
        }
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Q);
        u();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.C = false;
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:108:0x0285 A[LOOP:0: B:107:0x0283->B:108:0x0285, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:111:0x029d A[LOOP:1: B:110:0x029b->B:111:0x029d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:114:0x02bd A[LOOP:2: B:113:0x02bb->B:114:0x02bd, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0303  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0310 A[LOOP:3: B:122:0x030e->B:123:0x0310, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00c5  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00e0  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0115  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0124  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x0193  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01a0  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x020e  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            Method dump skipped, instruction units count: 801
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.view.View
    public final void onMeasure(int i7, int i8) {
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iL;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean zA = z3.a(this);
        int i9 = !zA ? 1 : 0;
        int i10 = 0;
        if (t(this.f682d)) {
            s(this.f682d, i7, 0, i8, this.f692o);
            iK = k(this.f682d) + this.f682d.getMeasuredWidth();
            iMax = Math.max(0, l(this.f682d) + this.f682d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f682d.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (t(this.f685h)) {
            s(this.f685h, i7, 0, i8, this.f692o);
            iK = k(this.f685h) + this.f685h.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f685h) + this.f685h.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f685h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        int[] iArr = this.F;
        iArr[zA ? 1 : 0] = iMax4;
        if (t(this.f680a)) {
            s(this.f680a, i7, iMax3, i8, this.f692o);
            iK2 = k(this.f680a) + this.f680a.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f680a) + this.f680a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f680a.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[i9] = Math.max(0, currentContentInsetEnd - iK2);
        if (t(this.f686i)) {
            iMax5 += r(this.f686i, i7, iMax5, i8, 0, iArr);
            iMax = Math.max(iMax, l(this.f686i) + this.f686i.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f686i.getMeasuredState());
        }
        if (t(this.e)) {
            iMax5 += r(this.e, i7, iMax5, i8, 0, iArr);
            iMax = Math.max(iMax, l(this.e) + this.e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((q3) childAt.getLayoutParams()).b == 0 && t(childAt)) {
                iMax5 += r(childAt, i7, iMax5, i8, 0, iArr);
                int iMax6 = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i12 = iMax5;
        int i13 = this.f695r + this.f696s;
        int i14 = this.f693p + this.f694q;
        if (t(this.b)) {
            r(this.b, i7, i12 + i14, i8, i13, iArr);
            int iK3 = k(this.b) + this.b.getMeasuredWidth();
            iL = l(this.b) + this.b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.b.getMeasuredState());
            iMax2 = iK3;
        } else {
            iL = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (t(this.f681c)) {
            iMax2 = Math.max(iMax2, r(this.f681c, i7, i12 + i14, i8, i13 + iL, iArr));
            iL += l(this.f681c) + this.f681c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f681c.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i12 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i7, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i8, iCombineMeasuredStates2 << 16);
        if (!this.M) {
            i10 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i15 = 0; i15 < childCount2; i15++) {
            View childAt2 = getChildAt(i15);
            if (t(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i10 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i10);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1099a);
        ActionMenuView actionMenuView = this.f680a;
        g.l lVar = actionMenuView != null ? actionMenuView.f638p : null;
        int i7 = savedState.f704c;
        if (i7 != 0 && this.L != null && lVar != null && (menuItemFindItem = lVar.findItem(i7)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (savedState.f705d) {
            a4.w1 w1Var = this.Q;
            removeCallbacks(w1Var);
            post(w1Var);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i7) {
        super.onRtlPropertiesChanged(i7);
        d();
        p2 p2Var = this.f697t;
        boolean z6 = i7 == 1;
        if (z6 == p2Var.f879g) {
            return;
        }
        p2Var.f879g = z6;
        if (!p2Var.f880h) {
            p2Var.f875a = p2Var.e;
            p2Var.b = p2Var.f878f;
            return;
        }
        if (z6) {
            int i8 = p2Var.f877d;
            if (i8 == Integer.MIN_VALUE) {
                i8 = p2Var.e;
            }
            p2Var.f875a = i8;
            int i9 = p2Var.f876c;
            if (i9 == Integer.MIN_VALUE) {
                i9 = p2Var.f878f;
            }
            p2Var.b = i9;
            return;
        }
        int i10 = p2Var.f876c;
        if (i10 == Integer.MIN_VALUE) {
            i10 = p2Var.e;
        }
        p2Var.f875a = i10;
        int i11 = p2Var.f877d;
        if (i11 == Integer.MIN_VALUE) {
            i11 = p2Var.f878f;
        }
        p2Var.b = i11;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        l lVar;
        g.n nVar;
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        p3 p3Var = this.L;
        if (p3Var != null && (nVar = p3Var.b) != null) {
            savedState.f704c = nVar.f5782a;
        }
        ActionMenuView actionMenuView = this.f680a;
        savedState.f705d = (actionMenuView == null || (lVar = actionMenuView.f642t) == null || !lVar.h()) ? false : true;
        return savedState;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.B = false;
        return true;
    }

    public final int p(View view, int i7, int i8, int[] iArr) {
        q3 q3Var = (q3) view.getLayoutParams();
        int i9 = ((ViewGroup.MarginLayoutParams) q3Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i9) + i7;
        iArr[0] = Math.max(0, -i9);
        int iJ = j(view, i8);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) q3Var).rightMargin + iMax;
    }

    public final int q(View view, int i7, int i8, int[] iArr) {
        q3 q3Var = (q3) view.getLayoutParams();
        int i9 = ((ViewGroup.MarginLayoutParams) q3Var).rightMargin - iArr[1];
        int iMax = i7 - Math.max(0, i9);
        iArr[1] = Math.max(0, -i9);
        int iJ = j(view, i8);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) q3Var).leftMargin);
    }

    public final int r(View view, int i7, int i8, int i9, int i10, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i11 = marginLayoutParams.leftMargin - iArr[0];
        int i12 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i12) + Math.max(0, i11);
        iArr[0] = Math.max(0, -i11);
        iArr[1] = Math.max(0, -i12);
        view.measure(ViewGroup.getChildMeasureSpec(i7, getPaddingRight() + getPaddingLeft() + iMax + i8, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i9, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i10, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public final void s(View view, int i7, int i8, int i9, int i10) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i7, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i8, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i9, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i10 >= 0) {
            if (mode != 0) {
                i10 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i10);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i10, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setBackInvokedCallbackEnabled(boolean z6) {
        if (this.P != z6) {
            this.P = z6;
            u();
        }
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        a0 a0Var = this.f685h;
        if (a0Var != null) {
            a0Var.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f685h.setImageDrawable(drawable);
        } else {
            a0 a0Var = this.f685h;
            if (a0Var != null) {
                a0Var.setImageDrawable(this.f683f);
            }
        }
    }

    public void setCollapsible(boolean z6) {
        this.M = z6;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i7) {
        if (i7 < 0) {
            i7 = Integer.MIN_VALUE;
        }
        if (i7 != this.f699v) {
            this.f699v = i7;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i7) {
        if (i7 < 0) {
            i7 = Integer.MIN_VALUE;
        }
        if (i7 != this.f698u) {
            this.f698u = i7;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(Drawable drawable) {
        c0 c0Var = this.e;
        if (drawable != null) {
            if (c0Var == null) {
                this.e = new c0(getContext());
            }
            if (!o(this.e)) {
                b(this.e, true);
            }
        } else if (c0Var != null && o(c0Var)) {
            removeView(this.e);
            this.E.remove(this.e);
        }
        c0 c0Var2 = this.e;
        if (c0Var2 != null) {
            c0Var2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.e == null) {
            this.e = new c0(getContext());
        }
        c0 c0Var = this.e;
        if (c0Var != null) {
            c0Var.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        a0 a0Var = this.f682d;
        if (a0Var != null) {
            a0Var.setContentDescription(charSequence);
            w3.a(this.f682d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.f682d)) {
                b(this.f682d, true);
            }
        } else {
            a0 a0Var = this.f682d;
            if (a0Var != null && o(a0Var)) {
                removeView(this.f682d);
                this.E.remove(this.f682d);
            }
        }
        a0 a0Var2 = this.f682d;
        if (a0Var2 != null) {
            a0Var2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f682d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(r3 r3Var) {
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f680a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i7) {
        if (this.f688k != i7) {
            this.f688k = i7;
            if (i7 == 0) {
                this.f687j = getContext();
            } else {
                this.f687j = new ContextThemeWrapper(getContext(), i7);
            }
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        boolean zIsEmpty = TextUtils.isEmpty(charSequence);
        e1 e1Var = this.f681c;
        if (!zIsEmpty) {
            if (e1Var == null) {
                Context context = getContext();
                e1 e1Var2 = new e1(context, null);
                this.f681c = e1Var2;
                e1Var2.setSingleLine();
                this.f681c.setEllipsize(TextUtils.TruncateAt.END);
                int i7 = this.f690m;
                if (i7 != 0) {
                    this.f681c.setTextAppearance(context, i7);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f681c.setTextColor(colorStateList);
                }
            }
            if (!o(this.f681c)) {
                b(this.f681c, true);
            }
        } else if (e1Var != null && o(e1Var)) {
            removeView(this.f681c);
            this.E.remove(this.f681c);
        }
        e1 e1Var3 = this.f681c;
        if (e1Var3 != null) {
            e1Var3.setText(charSequence);
        }
        this.f702y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        e1 e1Var = this.f681c;
        if (e1Var != null) {
            e1Var.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        boolean zIsEmpty = TextUtils.isEmpty(charSequence);
        e1 e1Var = this.b;
        if (!zIsEmpty) {
            if (e1Var == null) {
                Context context = getContext();
                e1 e1Var2 = new e1(context, null);
                this.b = e1Var2;
                e1Var2.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i7 = this.f689l;
                if (i7 != 0) {
                    this.b.setTextAppearance(context, i7);
                }
                ColorStateList colorStateList = this.f703z;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            if (!o(this.b)) {
                b(this.b, true);
            }
        } else if (e1Var != null && o(e1Var)) {
            removeView(this.b);
            this.E.remove(this.b);
        }
        e1 e1Var3 = this.b;
        if (e1Var3 != null) {
            e1Var3.setText(charSequence);
        }
        this.f701x = charSequence;
    }

    public void setTitleMarginBottom(int i7) {
        this.f696s = i7;
        requestLayout();
    }

    public void setTitleMarginEnd(int i7) {
        this.f694q = i7;
        requestLayout();
    }

    public void setTitleMarginStart(int i7) {
        this.f693p = i7;
        requestLayout();
    }

    public void setTitleMarginTop(int i7) {
        this.f695r = i7;
        requestLayout();
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f703z = colorStateList;
        e1 e1Var = this.b;
        if (e1Var != null) {
            e1Var.setTextColor(colorStateList);
        }
    }

    public final boolean t(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void u() {
        /*
            r4 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L4f
            android.window.OnBackInvokedDispatcher r0 = androidx.appcompat.widget.o3.a(r4)
            androidx.appcompat.widget.p3 r1 = r4.L
            r2 = 0
            if (r1 == 0) goto L23
            g.n r1 = r1.b
            if (r1 == 0) goto L23
            if (r0 == 0) goto L23
            java.util.WeakHashMap r1 = f0.s0.f5582a
            boolean r1 = f0.e0.b(r4)
            if (r1 == 0) goto L23
            boolean r1 = r4.P
            if (r1 == 0) goto L23
            r1 = 1
            goto L24
        L23:
            r1 = r2
        L24:
            if (r1 == 0) goto L41
            android.window.OnBackInvokedDispatcher r3 = r4.O
            if (r3 != 0) goto L41
            android.window.OnBackInvokedCallback r1 = r4.N
            if (r1 != 0) goto L39
            androidx.appcompat.widget.m3 r1 = new androidx.appcompat.widget.m3
            r1.<init>(r4, r2)
            android.window.OnBackInvokedCallback r1 = androidx.appcompat.widget.o3.b(r1)
            r4.N = r1
        L39:
            android.window.OnBackInvokedCallback r1 = r4.N
            androidx.appcompat.widget.o3.c(r0, r1)
            r4.O = r0
            return
        L41:
            if (r1 != 0) goto L4f
            android.window.OnBackInvokedDispatcher r0 = r4.O
            if (r0 == 0) goto L4f
            android.window.OnBackInvokedCallback r1 = r4.N
            androidx.appcompat.widget.o3.d(r0, r1)
            r0 = 0
            r4.O = r0
        L4f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.u():void");
    }

    public void setSubtitleTextColor(int i7) {
        setSubtitleTextColor(ColorStateList.valueOf(i7));
    }

    public void setTitleTextColor(int i7) {
        setTitleTextColor(ColorStateList.valueOf(i7));
    }

    public void setCollapseContentDescription(int i7) {
        setCollapseContentDescription(i7 != 0 ? getContext().getText(i7) : null);
    }

    public void setCollapseIcon(int i7) {
        setCollapseIcon(a5.h.E(getContext(), i7));
    }

    public void setNavigationContentDescription(int i7) {
        setNavigationContentDescription(i7 != 0 ? getContext().getText(i7) : null);
    }

    public void setLogoDescription(int i7) {
        setLogoDescription(getContext().getText(i7));
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public void setNavigationIcon(int i7) {
        setNavigationIcon(a5.h.E(getContext(), i7));
    }

    public void setLogo(int i7) {
        setLogo(a5.h.E(getContext(), i7));
    }

    public void setSubtitle(int i7) {
        setSubtitle(getContext().getText(i7));
    }

    public void setTitle(int i7) {
        setTitle(getContext().getText(i7));
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
