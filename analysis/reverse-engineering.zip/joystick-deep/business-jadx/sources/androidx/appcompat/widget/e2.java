package androidx.appcompat.widget;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e2 implements View.OnTouchListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f2 f741a;

    public e2(f2 f2Var) {
        this.f741a = f2Var;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        f2 f2Var = this.f741a;
        b2 b2Var = f2Var.f766r;
        Handler handler = f2Var.f770v;
        e0 e0Var = f2Var.f774z;
        int action = motionEvent.getAction();
        int x4 = (int) motionEvent.getX();
        int y6 = (int) motionEvent.getY();
        if (action == 0 && e0Var != null && e0Var.isShowing() && x4 >= 0 && x4 < e0Var.getWidth() && y6 >= 0 && y6 < e0Var.getHeight()) {
            handler.postDelayed(b2Var, 250L);
            return false;
        }
        if (action != 1) {
            return false;
        }
        handler.removeCallbacks(b2Var);
        return false;
    }
}
