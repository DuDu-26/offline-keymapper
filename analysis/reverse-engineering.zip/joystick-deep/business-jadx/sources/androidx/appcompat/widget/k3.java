package androidx.appcompat.widget;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f830a = true;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f831c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Serializable f832d;

    public p4.j a() {
        return new p4.j(this.f830a, this.b, (String[]) this.f831c, (String[]) this.f832d);
    }

    public void b(p4.h... hVarArr) {
        if (!this.f830a) {
            f3.q("no cipher suites for cleartext connections");
            return;
        }
        ArrayList arrayList = new ArrayList(hVarArr.length);
        for (p4.h hVar : hVarArr) {
            arrayList.add(hVar.f7588a);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        String[] strArr2 = (String[]) Arrays.copyOf(strArr, strArr.length);
        if (!this.f830a) {
            f3.q("no cipher suites for cleartext connections");
        } else if (strArr2.length != 0) {
            this.f831c = (String[]) Arrays.copyOf(strArr2, strArr2.length);
        } else {
            f3.q("At least one cipher suite is required");
        }
    }

    /* JADX WARN: Type inference failed for: r6v10, types: [java.io.Serializable, java.lang.String[]] */
    public void c(p4.k0... k0VarArr) {
        if (!this.f830a) {
            f3.q("no TLS versions for cleartext connections");
            return;
        }
        ArrayList arrayList = new ArrayList(k0VarArr.length);
        for (p4.k0 k0Var : k0VarArr) {
            arrayList.add(k0Var.f7612a);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        String[] strArr2 = (String[]) Arrays.copyOf(strArr, strArr.length);
        if (!this.f830a) {
            f3.q("no TLS versions for cleartext connections");
        } else if (strArr2.length != 0) {
            this.f832d = (String[]) Arrays.copyOf(strArr2, strArr2.length);
        } else {
            f3.q("At least one TLS version is required");
        }
    }
}
