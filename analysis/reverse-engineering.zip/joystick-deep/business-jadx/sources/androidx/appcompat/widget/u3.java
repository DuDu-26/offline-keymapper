package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u3 extends e4.r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f923a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f924c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f925d;

    public u3(v3 v3Var, int i7) {
        this.f923a = 0;
        this.f925d = v3Var;
        this.f924c = i7;
        this.b = false;
    }

    @Override // f0.y0
    public final void c() {
        switch (this.f923a) {
            case 0:
                if (!this.b) {
                    ((v3) this.f925d).f938a.setVisibility(this.f924c);
                }
                break;
            default:
                int i7 = this.f924c + 1;
                this.f924c = i7;
                f.j jVar = (f.j) this.f925d;
                if (i7 == jVar.f5530a.size()) {
                    f0.y0 y0Var = jVar.f5532d;
                    if (y0Var != null) {
                        y0Var.c();
                    }
                    this.f924c = 0;
                    this.b = false;
                    jVar.e = false;
                }
                break;
        }
    }

    @Override // e4.r0, f0.y0
    public void d() {
        switch (this.f923a) {
            case 0:
                this.b = true;
                break;
        }
    }

    @Override // e4.r0, f0.y0
    public final void e() {
        switch (this.f923a) {
            case 0:
                ((v3) this.f925d).f938a.setVisibility(0);
                break;
            default:
                if (!this.b) {
                    this.b = true;
                    f0.y0 y0Var = ((f.j) this.f925d).f5532d;
                    if (y0Var != null) {
                        y0Var.e();
                    }
                    break;
                }
                break;
        }
    }

    public u3(f.j jVar) {
        this.f923a = 1;
        this.f925d = jVar;
        this.b = false;
        this.f924c = 0;
    }
}
