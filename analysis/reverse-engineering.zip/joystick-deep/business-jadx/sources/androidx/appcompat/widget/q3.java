package androidx.appcompat.widget;

import android.view.ViewGroup;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q3 extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f890a;
    public int b;

    public q3(q3 q3Var) {
        super((ViewGroup.MarginLayoutParams) q3Var);
        this.f890a = 0;
        this.f890a = q3Var.f890a;
    }

    public q3(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f890a = 0;
    }
}
