package androidx.appcompat.widget;

import android.graphics.drawable.Drawable;
import android.widget.ListAdapter;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public interface v0 {
    boolean a();

    int b();

    Drawable d();

    void dismiss();

    void e(CharSequence charSequence);

    void i(Drawable drawable);

    void j(int i7);

    void k(int i7);

    void l(int i7);

    void m(int i7, int i8);

    int n();

    CharSequence o();

    void p(ListAdapter listAdapter);
}
