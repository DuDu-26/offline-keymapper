package androidx.appcompat.widget;

import android.view.MenuItem;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n3 implements p, g.j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Toolbar f867a;

    public /* synthetic */ n3(Toolbar toolbar) {
        this.f867a = toolbar;
    }

    @Override // g.j
    public boolean h(g.l lVar, MenuItem menuItem) {
        return false;
    }

    @Override // g.j
    public void l(g.l lVar) {
        Toolbar toolbar = this.f867a;
        l lVar2 = toolbar.f680a.f642t;
        if (lVar2 == null || !lVar2.h()) {
            Iterator it = ((CopyOnWriteArrayList) toolbar.G.f8985c).iterator();
            if (it.hasNext()) {
                it.next().getClass();
                f3.b();
            }
        }
    }
}
