package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import java.io.IOException;
import java.io.Serializable;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f713a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f714c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f715d;

    public b0() {
        this.f713a = 2;
        this.f714c = new Point();
        this.f715d = new Rect();
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x01f5, code lost:
    
        if (r11 == 1) goto L112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x01f8, code lost:
    
        if (r11 == 2) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x01fa, code lost:
    
        r16 = (int[]) r0.b;
        r17 = (float[]) r0.f124c;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x0208, code lost:
    
        if (r10 == 1) goto L109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x020a, code lost:
    
        if (r10 == 2) goto L108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x020c, code lost:
    
        r0 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:108:0x0219, code lost:
    
        r0 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:109:0x021c, code lost:
    
        r0 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x021f, code lost:
    
        r11 = new android.graphics.LinearGradient(r21, r22, r26, r27, r16, r17, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x0223, code lost:
    
        r11 = new android.graphics.SweepGradient(r8, r9, (int[]) r0.b, (float[]) r0.f124c);
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x0235, code lost:
    
        if (r25 <= 0.0f) goto L125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0237, code lost:
    
        r20 = (int[]) r0.b;
        r21 = (float[]) r0.f124c;
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0246, code lost:
    
        if (r10 == 1) goto L121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0249, code lost:
    
        if (r10 == 2) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x024b, code lost:
    
        r0 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x0256, code lost:
    
        r0 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x0259, code lost:
    
        r0 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x025c, code lost:
    
        r11 = new android.graphics.RadialGradient(r8, r9, r25, r20, r21, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:124:0x0268, code lost:
    
        return new androidx.appcompat.widget.b0(r11, null, 0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x0270, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x01da, code lost:
    
        if (r13.size() <= 0) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x01dc, code lost:
    
        r0 = new a4.i0(r13, r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x01e2, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x01e3, code lost:
    
        if (r0 == null) goto L97;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x01e7, code lost:
    
        if (r20 == false) goto L99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x01e9, code lost:
    
        r0 = new a4.i0(r6, r5, r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x01ef, code lost:
    
        r0 = new a4.i0(r6, r12);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static androidx.appcompat.widget.b0 b(android.content.res.Resources r30, int r31, android.content.res.Resources.Theme r32) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            Method dump skipped, instruction units count: 665
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.b0.b(android.content.res.Resources, int, android.content.res.Resources$Theme):androidx.appcompat.widget.b0");
    }

    public void a() {
        k3 k3Var;
        ImageView imageView = (ImageView) this.f714c;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            m1.a(drawable);
        }
        if (drawable == null || (k3Var = (k3) this.f715d) == null) {
            return;
        }
        w.e(drawable, k3Var, imageView.getDrawableState());
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [byte[][], java.io.Serializable] */
    public h5.f c(int i7) throws IOException {
        ?? r02 = (byte[][]) this.f715d;
        int i8 = this.b;
        h5.q1 q1Var = (h5.q1) this.f714c;
        if (q1Var instanceof h5.n1) {
            h5.n1 n1Var = (h5.n1) q1Var;
            n1Var.f6220f = false;
            n1Var.e();
        }
        int iT = h5.k.t(q1Var, i7);
        int iR = h5.k.r(q1Var, i8, iT == 3 || iT == 4 || iT == 16 || iT == 17 || iT == 8);
        if (iR < 0) {
            if ((i7 & 32) == 0) {
                f3.v("indefinite-length primitive encoding encountered");
                return null;
            }
            b0 b0Var = new b0(new h5.n1(q1Var, i8), i8, r02, 1);
            int i9 = i7 & 192;
            if (i9 != 0) {
                return new h5.k0(i9, iT, b0Var);
            }
            if (iT == 3) {
                return new h5.c0(b0Var);
            }
            if (iT == 4) {
                return new h5.f0(b0Var);
            }
            if (iT == 8) {
                return new h5.h0(b0Var);
            }
            if (iT == 16) {
                h5.h0 h0Var = new h5.h0(0);
                h0Var.b = b0Var;
                return h0Var;
            }
            if (iT != 17) {
                f3.y(Integer.toHexString(iT), "unknown BER object encountered: 0x");
                return null;
            }
            h5.h0 h0Var2 = new h5.h0(1);
            h0Var2.b = b0Var;
            return h0Var2;
        }
        h5.l1 l1Var = new h5.l1(q1Var, iR, i8);
        if ((i7 & 224) == 0) {
            if (iT == 3) {
                return new h5.h1(l1Var);
            }
            if (iT == 4) {
                h5.f0 f0Var = new h5.f0();
                f0Var.b = l1Var;
                return f0Var;
            }
            if (iT == 8) {
                throw new h5.i("externals must use constructed encoding (see X.690 8.18)");
            }
            if (iT == 16) {
                throw new h5.i("sets must use constructed encoding (see X.690 8.11.1/8.12.1)");
            }
            if (iT == 17) {
                throw new h5.i("sequences must use constructed encoding (see X.690 8.9.1/8.10.1)");
            }
            try {
                return h5.k.e(iT, l1Var, r02);
            } catch (IllegalArgumentException e) {
                throw new h5.i("corrupted stream detected", e);
            }
        }
        b0 b0Var2 = new b0(l1Var, l1Var.b, r02, 1);
        int i10 = i7 & 192;
        if (i10 != 0) {
            return new h5.k1(i10, iT, (i7 & 32) != 0, b0Var2);
        }
        if (iT == 3) {
            return new h5.c0(b0Var2);
        }
        if (iT == 4) {
            return new h5.f0(b0Var2);
        }
        if (iT == 8) {
            return new h5.h0(b0Var2);
        }
        if (iT == 16) {
            h5.h0 h0Var3 = new h5.h0(3);
            h0Var3.b = b0Var2;
            return h0Var3;
        }
        if (iT != 17) {
            f3.y(Integer.toHexString(iT), "unknown DL object encountered: 0x");
            return null;
        }
        h5.h0 h0Var4 = new h5.h0(4);
        h0Var4.b = b0Var2;
        return h0Var4;
    }

    public boolean d() {
        ColorStateList colorStateList;
        return ((Shader) this.f714c) == null && (colorStateList = (ColorStateList) this.f715d) != null && colorStateList.isStateful();
    }

    public void e(AttributeSet attributeSet, int i7) {
        int resourceId;
        ImageView imageView = (ImageView) this.f714c;
        Context context = imageView.getContext();
        int[] iArr = d.a.f5206f;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, i7);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        f0.s0.i(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, i7);
        try {
            Drawable drawable = imageView.getDrawable();
            if (drawable == null && (resourceId = typedArray.getResourceId(1, -1)) != -1 && (drawable = a5.h.E(imageView.getContext(), resourceId)) != null) {
                imageView.setImageDrawable(drawable);
            }
            if (drawable != null) {
                m1.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                androidx.core.widget.f.c(imageView, eVarA.n(2));
            }
            if (typedArray.hasValue(3)) {
                androidx.core.widget.f.d(imageView, m1.b(typedArray.getInt(3, -1), null));
            }
            eVarA.C();
        } catch (Throwable th) {
            eVarA.C();
            throw th;
        }
    }

    public h5.j0 f(int i7, int i8) throws IOException {
        h5.g gVarG = g();
        int i9 = gVarG.b;
        if (i9 == 1) {
            return new h5.j0(3, i7, i8, gVarG.c(0), 0);
        }
        h5.g0 g0Var = h5.d0.f6183a;
        return new h5.j0(4, i7, i8, i9 < 1 ? h5.d0.f6183a : new h5.g0(gVarG), 0);
    }

    public h5.g g() throws IOException {
        h5.q1 q1Var = (h5.q1) this.f714c;
        int i7 = q1Var.read();
        if (i7 < 0) {
            return new h5.g(0);
        }
        h5.g gVar = new h5.g();
        do {
            h5.f fVarC = c(i7);
            gVar.a(fVarC instanceof h5.m1 ? ((h5.m1) fVarC).e() : fVarC.b());
            i7 = q1Var.read();
        } while (i7 >= 0);
        return gVar;
    }

    public void h(int i7) {
        ImageView imageView = (ImageView) this.f714c;
        if (i7 != 0) {
            Drawable drawableE = a5.h.E(imageView.getContext(), i7);
            if (drawableE != null) {
                m1.a(drawableE);
            }
            imageView.setImageDrawable(drawableE);
        } else {
            imageView.setImageDrawable(null);
        }
        a();
    }

    public String toString() {
        switch (this.f713a) {
            case 3:
                StringBuilder sb = new StringBuilder();
                if (((p4.a0) this.f714c) == p4.a0.f7508c) {
                    sb.append("HTTP/1.0");
                } else {
                    sb.append("HTTP/1.1");
                }
                sb.append(' ');
                sb.append(this.b);
                sb.append(' ');
                sb.append((String) this.f715d);
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public /* synthetic */ b0(Object obj, int i7, Serializable serializable, int i8) {
        this.f713a = i8;
        this.f714c = obj;
        this.b = i7;
        this.f715d = serializable;
    }

    public b0(ImageView imageView) {
        this.f713a = 0;
        this.b = 0;
        this.f714c = imageView;
    }

    public b0(Shader shader, ColorStateList colorStateList, int i7) {
        this.f713a = 4;
        this.f714c = shader;
        this.f715d = colorStateList;
        this.b = i7;
    }
}
