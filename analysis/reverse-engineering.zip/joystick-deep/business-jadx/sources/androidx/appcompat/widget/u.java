package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u extends CheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v f918a;
    public final r b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c1 f919c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public z f920d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(Context context, AttributeSet attributeSet) {
        int resourceId;
        int resourceId2;
        super(context, attributeSet, 2130968765);
        j3.a(context);
        i3.a(this, getContext());
        c1 c1Var = new c1(this);
        this.f919c = c1Var;
        c1Var.f(attributeSet, 2130968765);
        c1Var.b();
        r rVar = new r(this);
        this.b = rVar;
        rVar.l(attributeSet, 2130968765);
        this.f918a = new v(this);
        Context context2 = getContext();
        int[] iArr = d.a.f5212l;
        y2.e eVarA = y2.e.A(context2, attributeSet, iArr, 2130968765);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        f0.s0.i(this, getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, 2130968765);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    setCheckMarkDrawable(a5.h.E(getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(0)) {
                        setCheckMarkDrawable(a5.h.E(getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                setCheckMarkDrawable(a5.h.E(getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                setCheckMarkTintList(eVarA.n(2));
            }
            if (typedArray.hasValue(3)) {
                setCheckMarkTintMode(m1.b(typedArray.getInt(3, -1), null));
            }
            eVarA.C();
            getEmojiTextViewHelper().a(attributeSet, 2130968765);
        } catch (Throwable th) {
            eVarA.C();
            throw th;
        }
    }

    private z getEmojiTextViewHelper() {
        if (this.f920d == null) {
            this.f920d = new z(this);
        }
        return this.f920d;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        c1 c1Var = this.f919c;
        if (c1Var != null) {
            c1Var.b();
        }
        r rVar = this.b;
        if (rVar != null) {
            rVar.a();
        }
        v vVar = this.f918a;
        if (vVar != null) {
            vVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return super.getCustomSelectionActionModeCallback();
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.b;
        if (rVar != null) {
            return rVar.j();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        v vVar = this.f918a;
        if (vVar != null) {
            return (ColorStateList) vVar.f926a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        v vVar = this.f918a;
        if (vVar != null) {
            return (PorterDuff.Mode) vVar.b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f919c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f919c.e();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        a5.h.P(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z6) {
        super.setAllCaps(z6);
        getEmojiTextViewHelper().b(z6);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.b;
        if (rVar != null) {
            rVar.n();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i7) {
        super.setBackgroundResource(i7);
        r rVar = this.b;
        if (rVar != null) {
            rVar.o(i7);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        v vVar = this.f918a;
        if (vVar != null) {
            if (vVar.e) {
                vVar.e = false;
            } else {
                vVar.e = true;
                vVar.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.f919c;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.f919c;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(callback);
    }

    public void setEmojiCompatEnabled(boolean z6) {
        getEmojiTextViewHelper().c(z6);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.b;
        if (rVar != null) {
            rVar.t(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.b;
        if (rVar != null) {
            rVar.u(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        v vVar = this.f918a;
        if (vVar != null) {
            vVar.f926a = colorStateList;
            vVar.f927c = true;
            vVar.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        v vVar = this.f918a;
        if (vVar != null) {
            vVar.b = mode;
            vVar.f928d = true;
            vVar.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        c1 c1Var = this.f919c;
        c1Var.i(colorStateList);
        c1Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        c1 c1Var = this.f919c;
        c1Var.j(mode);
        c1Var.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i7) {
        super.setTextAppearance(context, i7);
        c1 c1Var = this.f919c;
        if (c1Var != null) {
            c1Var.g(context, i7);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i7) {
        setCheckMarkDrawable(a5.h.E(getContext(), i7));
    }
}
