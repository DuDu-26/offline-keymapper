package androidx.appcompat.widget;

import android.database.DataSetObserver;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c2 extends DataSetObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f731a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c2(int i7, Object obj) {
        this.f731a = i7;
        this.b = obj;
    }

    @Override // android.database.DataSetObserver
    public final void onChanged() {
        switch (this.f731a) {
            case 0:
                f2 f2Var = (f2) this.b;
                if (f2Var.f774z.isShowing()) {
                    f2Var.c();
                }
                break;
            default:
                h3 h3Var = (h3) this.b;
                h3Var.f6352a = true;
                h3Var.notifyDataSetChanged();
                break;
        }
    }

    @Override // android.database.DataSetObserver
    public final void onInvalidated() {
        switch (this.f731a) {
            case 0:
                ((f2) this.b).dismiss();
                break;
            default:
                h3 h3Var = (h3) this.b;
                h3Var.f6352a = false;
                h3Var.notifyDataSetInvalidated();
                break;
        }
    }
}
