package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.res.ColorStateList;
import android.view.View;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.transformation.ExpandableTransformationBehavior;
import com.umeng.analytics.pro.dd;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f712a;
    public final /* synthetic */ Object b;

    public b(f0.y0 y0Var, View view) {
        this.f712a = 3;
        this.b = y0Var;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.f712a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.f633w = null;
                actionBarOverlayLayout.f621k = false;
                break;
            case 3:
                ((f0.y0) this.b).d();
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f712a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.f633w = null;
                actionBarOverlayLayout.f621k = false;
                break;
            case 1:
                com.google.android.material.textfield.j jVar = (com.google.android.material.textfield.j) this.b;
                jVar.p();
                jVar.f3511r.start();
                break;
            case 2:
                ((ExpandableTransformationBehavior) this.b).b = null;
                break;
            case 3:
                ((f0.y0) this.b).c();
                break;
            case 4:
                ((HideBottomViewOnScrollBehavior) this.b).f3034h = null;
                break;
            case 5:
                s1.i iVar = (s1.i) this.b;
                iVar.f8188q = 0;
                iVar.f8183l = null;
                break;
            case 6:
                ((x0.k) this.b).l();
                animator.removeListener(this);
                break;
            default:
                y0.e eVar = (y0.e) this.b;
                ArrayList arrayList = new ArrayList(eVar.e);
                int size = arrayList.size();
                for (int i7 = 0; i7 < size; i7++) {
                    ColorStateList colorStateList = ((com.google.android.material.checkbox.a) arrayList.get(i7)).b.f3136o;
                    if (colorStateList != null) {
                        y.b.h(eVar, colorStateList);
                    }
                }
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        switch (this.f712a) {
            case 3:
                ((f0.y0) this.b).e();
                break;
            case 4:
            case 6:
            default:
                super.onAnimationStart(animator);
                break;
            case 5:
                s1.i iVar = (s1.i) this.b;
                iVar.f8189r.a(0, false);
                iVar.f8188q = 2;
                iVar.f8183l = animator;
                break;
            case dd.f4082h /* 7 */:
                y0.e eVar = (y0.e) this.b;
                ArrayList arrayList = new ArrayList(eVar.e);
                int size = arrayList.size();
                for (int i7 = 0; i7 < size; i7++) {
                    com.google.android.material.checkbox.c cVar = ((com.google.android.material.checkbox.a) arrayList.get(i7)).b;
                    ColorStateList colorStateList = cVar.f3136o;
                    if (colorStateList != null) {
                        y.b.g(eVar, colorStateList.getColorForState(cVar.f3140s, colorStateList.getDefaultColor()));
                    }
                }
                break;
        }
    }

    public /* synthetic */ b(int i7, Object obj) {
        this.f712a = i7;
        this.b = obj;
    }
}
