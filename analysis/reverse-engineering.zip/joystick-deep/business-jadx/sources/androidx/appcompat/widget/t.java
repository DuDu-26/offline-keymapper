package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class t extends CheckBox implements androidx.core.widget.t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v f912a;
    public final r b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c1 f913c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public z f914d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        j3.a(context);
        i3.a(this, getContext());
        v vVar = new v(this);
        this.f912a = vVar;
        vVar.d(attributeSet, i7);
        r rVar = new r(this);
        this.b = rVar;
        rVar.l(attributeSet, i7);
        c1 c1Var = new c1(this);
        this.f913c = c1Var;
        c1Var.f(attributeSet, i7);
        getEmojiTextViewHelper().a(attributeSet, i7);
    }

    private z getEmojiTextViewHelper() {
        if (this.f914d == null) {
            this.f914d = new z(this);
        }
        return this.f914d;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.b;
        if (rVar != null) {
            rVar.a();
        }
        c1 c1Var = this.f913c;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        v vVar = this.f912a;
        if (vVar != null) {
            vVar.getClass();
        }
        return compoundPaddingLeft;
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.b;
        if (rVar != null) {
            return rVar.j();
        }
        return null;
    }

    @Override // androidx.core.widget.t
    public ColorStateList getSupportButtonTintList() {
        v vVar = this.f912a;
        if (vVar != null) {
            return (ColorStateList) vVar.f926a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        v vVar = this.f912a;
        if (vVar != null) {
            return (PorterDuff.Mode) vVar.b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f913c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f913c.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z6) {
        super.setAllCaps(z6);
        getEmojiTextViewHelper().b(z6);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.b;
        if (rVar != null) {
            rVar.n();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i7) {
        super.setBackgroundResource(i7);
        r rVar = this.b;
        if (rVar != null) {
            rVar.o(i7);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        v vVar = this.f912a;
        if (vVar != null) {
            if (vVar.e) {
                vVar.e = false;
            } else {
                vVar.e = true;
                vVar.a();
            }
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.f913c;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.f913c;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z6) {
        getEmojiTextViewHelper().c(z6);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((m4.f) getEmojiTextViewHelper().b.b).q(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.b;
        if (rVar != null) {
            rVar.t(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.b;
        if (rVar != null) {
            rVar.u(mode);
        }
    }

    @Override // androidx.core.widget.t
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        v vVar = this.f912a;
        if (vVar != null) {
            vVar.f926a = colorStateList;
            vVar.f927c = true;
            vVar.a();
        }
    }

    @Override // androidx.core.widget.t
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        v vVar = this.f912a;
        if (vVar != null) {
            vVar.b = mode;
            vVar.f928d = true;
            vVar.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        c1 c1Var = this.f913c;
        c1Var.i(colorStateList);
        c1Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        c1 c1Var = this.f913c;
        c1Var.j(mode);
        c1Var.b();
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i7) {
        setButtonDrawable(a5.h.E(getContext(), i7));
    }
}
