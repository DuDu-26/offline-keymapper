package androidx.appcompat.widget;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class m0 implements ViewTreeObserver.OnGlobalLayoutListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f858a;
    public final /* synthetic */ Object b;

    public /* synthetic */ m0(int i7, Object obj) {
        this.f858a = i7;
        this.b = obj;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        int i7 = this.f858a;
        Object obj = this.b;
        switch (i7) {
            case 0:
                w0 w0Var = (w0) obj;
                if (!w0Var.getInternalPopup().a()) {
                    w0Var.f957f.m(o0.b(w0Var), o0.a(w0Var));
                }
                ViewTreeObserver viewTreeObserver = w0Var.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    n0.a(viewTreeObserver, this);
                }
                break;
            case 1:
                u0 u0Var = (u0) obj;
                w0 w0Var2 = u0Var.G;
                WeakHashMap weakHashMap = f0.s0.f5582a;
                if (f0.e0.b(w0Var2) && w0Var2.getGlobalVisibleRect(u0Var.E)) {
                    u0Var.s();
                    u0Var.c();
                } else {
                    u0Var.dismiss();
                }
                break;
            case 2:
                g.f fVar = (g.f) obj;
                ArrayList arrayList = fVar.f5729h;
                if (fVar.a() && arrayList.size() > 0) {
                    int i8 = 0;
                    if (!((g.e) arrayList.get(0)).f5722a.f773y) {
                        View view = fVar.f5736o;
                        if (view != null && view.isShown()) {
                            int size = arrayList.size();
                            while (i8 < size) {
                                Object obj2 = arrayList.get(i8);
                                i8++;
                                ((g.e) obj2).f5722a.c();
                            }
                        } else {
                            fVar.dismiss();
                        }
                    }
                    break;
                }
                break;
            default:
                g.d0 d0Var = (g.d0) obj;
                l2 l2Var = d0Var.f5709h;
                if (d0Var.a() && !l2Var.f773y) {
                    View view2 = d0Var.f5714m;
                    if (view2 != null && view2.isShown()) {
                        l2Var.c();
                    } else {
                        d0Var.dismiss();
                    }
                    break;
                }
                break;
        }
    }
}
