package androidx.appcompat.widget;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.ViewGroup;
import com.google.android.material.textfield.TextInputLayout;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class r2 implements TextWatcher {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f897a;
    public final /* synthetic */ ViewGroup b;

    public /* synthetic */ r2(ViewGroup viewGroup, int i7) {
        this.f897a = i7;
        this.b = viewGroup;
    }

    private final void a(Editable editable) {
    }

    private final void b(int i7, int i8, int i9, CharSequence charSequence) {
    }

    private final void c(int i7, int i8, int i9, CharSequence charSequence) {
    }

    private final void d(int i7, int i8, int i9, CharSequence charSequence) {
    }

    @Override // android.text.TextWatcher
    public final void afterTextChanged(Editable editable) {
        switch (this.f897a) {
            case 0:
                break;
            default:
                TextInputLayout textInputLayout = (TextInputLayout) this.b;
                textInputLayout.u(!textInputLayout.f3480z0, false);
                if (textInputLayout.f3451k) {
                    textInputLayout.n(editable);
                }
                if (textInputLayout.f3466s) {
                    textInputLayout.v(editable);
                }
                break;
        }
    }

    @Override // android.text.TextWatcher
    public final void beforeTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
        int i10 = this.f897a;
    }

    @Override // android.text.TextWatcher
    public final void onTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
        switch (this.f897a) {
            case 0:
                SearchView searchView = (SearchView) this.b;
                Editable text = searchView.f665p.getText();
                searchView.V = text;
                boolean zIsEmpty = TextUtils.isEmpty(text);
                searchView.v(!zIsEmpty);
                int i10 = 8;
                if (searchView.U && !searchView.N && zIsEmpty) {
                    searchView.f670u.setVisibility(8);
                    i10 = 0;
                }
                searchView.f672w.setVisibility(i10);
                searchView.r();
                searchView.u();
                charSequence.toString();
                break;
        }
    }
}
