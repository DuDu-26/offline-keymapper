package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.view.MenuItem;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l2 extends f2 implements g2 {
    public static final Method D;
    public g.d C;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                D = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
        }
    }

    @Override // androidx.appcompat.widget.g2
    public final void f(g.l lVar, g.n nVar) {
        g.d dVar = this.C;
        if (dVar != null) {
            dVar.f(lVar, nVar);
        }
    }

    @Override // androidx.appcompat.widget.g2
    public final void g(g.l lVar, MenuItem menuItem) {
        g.d dVar = this.C;
        if (dVar != null) {
            dVar.g(lVar, menuItem);
        }
    }

    @Override // androidx.appcompat.widget.f2
    public final s1 q(Context context, boolean z6) {
        k2 k2Var = new k2(context, z6);
        k2Var.setHoverListener(this);
        return k2Var;
    }
}
