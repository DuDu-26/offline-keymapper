package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f720a;
    public k3 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public k3 f721c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public k3 f722d;
    public k3 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public k3 f723f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public k3 f724g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public k3 f725h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final i1 f726i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f727j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f728k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Typeface f729l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f730m;

    public c1(TextView textView) {
        this.f720a = textView;
        this.f726i = new i1(textView);
    }

    public static k3 c(Context context, w wVar, int i7) {
        ColorStateList colorStateListF;
        synchronized (wVar) {
            colorStateListF = wVar.f952a.f(context, i7);
        }
        if (colorStateListF == null) {
            return null;
        }
        k3 k3Var = new k3();
        k3Var.b = true;
        k3Var.f831c = colorStateListF;
        return k3Var;
    }

    public static void h(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        int i7 = Build.VERSION.SDK_INT;
        if (i7 >= 30 || inputConnection == null) {
            return;
        }
        CharSequence text = textView.getText();
        if (i7 >= 30) {
            i0.a.a(editorInfo, text);
            return;
        }
        text.getClass();
        if (i7 >= 30) {
            i0.a.a(editorInfo, text);
            return;
        }
        int i8 = editorInfo.initialSelStart;
        int i9 = editorInfo.initialSelEnd;
        int i10 = i8 > i9 ? i9 : i8;
        if (i8 <= i9) {
            i8 = i9;
        }
        int length = text.length();
        if (i10 < 0 || i8 > length) {
            e4.r0.e0(editorInfo, null, 0, 0);
            return;
        }
        int i11 = editorInfo.inputType & 4095;
        if (i11 == 129 || i11 == 225 || i11 == 18) {
            e4.r0.e0(editorInfo, null, 0, 0);
            return;
        }
        if (length <= 2048) {
            e4.r0.e0(editorInfo, text, i10, i8);
            return;
        }
        int i12 = i8 - i10;
        int i13 = i12 > 1024 ? 0 : i12;
        int i14 = 2048 - i13;
        int iMin = Math.min(text.length() - i8, i14 - Math.min(i10, (int) (((double) i14) * 0.8d)));
        int iMin2 = Math.min(i10, i14 - iMin);
        int i15 = i10 - iMin2;
        if (Character.isLowSurrogate(text.charAt(i15))) {
            i15++;
            iMin2--;
        }
        if (Character.isHighSurrogate(text.charAt((i8 + iMin) - 1))) {
            iMin--;
        }
        int i16 = iMin2 + i13;
        e4.r0.e0(editorInfo, i13 != i12 ? TextUtils.concat(text.subSequence(i15, i15 + iMin2), text.subSequence(i8, iMin + i8)) : text.subSequence(i15, i16 + iMin + i15), iMin2, i16);
    }

    public final void a(Drawable drawable, k3 k3Var) {
        if (drawable == null || k3Var == null) {
            return;
        }
        w.e(drawable, k3Var, this.f720a.getDrawableState());
    }

    public final void b() {
        k3 k3Var = this.b;
        TextView textView = this.f720a;
        if (k3Var != null || this.f721c != null || this.f722d != null || this.e != null) {
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            a(compoundDrawables[0], this.b);
            a(compoundDrawables[1], this.f721c);
            a(compoundDrawables[2], this.f722d);
            a(compoundDrawables[3], this.e);
        }
        if (this.f723f == null && this.f724g == null) {
            return;
        }
        Drawable[] drawableArrA = y0.a(textView);
        a(drawableArrA[0], this.f723f);
        a(drawableArrA[2], this.f724g);
    }

    public final ColorStateList d() {
        k3 k3Var = this.f725h;
        if (k3Var != null) {
            return (ColorStateList) k3Var.f831c;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        k3 k3Var = this.f725h;
        if (k3Var != null) {
            return (PorterDuff.Mode) k3Var.f832d;
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void f(AttributeSet attributeSet, int i7) {
        boolean z6;
        boolean z7;
        String string;
        String string2;
        int i8;
        ColorStateList colorStateList;
        int resourceId;
        int i9;
        int resourceId2;
        TextView textView = this.f720a;
        Context context = textView.getContext();
        w wVarA = w.a();
        int[] iArr = d.a.f5208h;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, i7);
        f0.s0.i(textView, textView.getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, i7);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        int resourceId3 = typedArray.getResourceId(0, -1);
        if (typedArray.hasValue(3)) {
            this.b = c(context, wVarA, typedArray.getResourceId(3, 0));
        }
        if (typedArray.hasValue(1)) {
            this.f721c = c(context, wVarA, typedArray.getResourceId(1, 0));
        }
        if (typedArray.hasValue(4)) {
            this.f722d = c(context, wVarA, typedArray.getResourceId(4, 0));
        }
        if (typedArray.hasValue(2)) {
            this.e = c(context, wVarA, typedArray.getResourceId(2, 0));
        }
        if (typedArray.hasValue(5)) {
            this.f723f = c(context, wVarA, typedArray.getResourceId(5, 0));
        }
        if (typedArray.hasValue(6)) {
            this.f724g = c(context, wVarA, typedArray.getResourceId(6, 0));
        }
        eVarA.C();
        boolean z8 = textView.getTransformationMethod() instanceof PasswordTransformationMethod;
        int[] iArr2 = d.a.f5223w;
        if (resourceId3 != -1) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(resourceId3, iArr2);
            y2.e eVar = new y2.e(context, typedArrayObtainStyledAttributes);
            if (z8 || !typedArrayObtainStyledAttributes.hasValue(14)) {
                z6 = false;
                z7 = false;
            } else {
                z7 = typedArrayObtainStyledAttributes.getBoolean(14, false);
                z6 = true;
            }
            k(context, eVar);
            string2 = typedArrayObtainStyledAttributes.hasValue(15) ? typedArrayObtainStyledAttributes.getString(15) : null;
            string = typedArrayObtainStyledAttributes.hasValue(13) ? typedArrayObtainStyledAttributes.getString(13) : null;
            eVar.C();
        } else {
            z6 = false;
            z7 = false;
            string = null;
            string2 = null;
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i7, 0);
        y2.e eVar2 = new y2.e(context, typedArrayObtainStyledAttributes2);
        if (!z8 && typedArrayObtainStyledAttributes2.hasValue(14)) {
            z7 = typedArrayObtainStyledAttributes2.getBoolean(14, false);
            z6 = true;
        }
        boolean z9 = z7;
        if (typedArrayObtainStyledAttributes2.hasValue(15)) {
            string2 = typedArrayObtainStyledAttributes2.getString(15);
        }
        if (typedArrayObtainStyledAttributes2.hasValue(13)) {
            string = typedArrayObtainStyledAttributes2.getString(13);
        }
        if (typedArrayObtainStyledAttributes2.hasValue(0) && typedArrayObtainStyledAttributes2.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        k(context, eVar2);
        eVar2.C();
        if (!z8 && z6) {
            textView.setAllCaps(z9);
        }
        Typeface typeface = this.f729l;
        if (typeface != null) {
            if (this.f728k == -1) {
                textView.setTypeface(typeface, this.f727j);
            } else {
                textView.setTypeface(typeface);
            }
        }
        if (string != null) {
            a1.d(textView, string);
        }
        if (string2 != null) {
            z0.b(textView, z0.a(string2));
        }
        i1 i1Var = this.f726i;
        Context context2 = i1Var.f809h;
        int[] iArr3 = d.a.f5209i;
        TypedArray typedArrayObtainStyledAttributes3 = context2.obtainStyledAttributes(attributeSet, iArr3, i7, 0);
        TextView textView2 = i1Var.f808g;
        f0.s0.i(textView2, textView2.getContext(), iArr3, attributeSet, typedArrayObtainStyledAttributes3, i7);
        if (typedArrayObtainStyledAttributes3.hasValue(5)) {
            i1Var.f804a = typedArrayObtainStyledAttributes3.getInt(5, 0);
        }
        float dimension = typedArrayObtainStyledAttributes3.hasValue(4) ? typedArrayObtainStyledAttributes3.getDimension(4, -1.0f) : -1.0f;
        float dimension2 = typedArrayObtainStyledAttributes3.hasValue(2) ? typedArrayObtainStyledAttributes3.getDimension(2, -1.0f) : -1.0f;
        float dimension3 = typedArrayObtainStyledAttributes3.hasValue(1) ? typedArrayObtainStyledAttributes3.getDimension(1, -1.0f) : -1.0f;
        if (!typedArrayObtainStyledAttributes3.hasValue(3) || (resourceId2 = typedArrayObtainStyledAttributes3.getResourceId(3, 0)) <= 0) {
            i8 = 0;
        } else {
            TypedArray typedArrayObtainTypedArray = typedArrayObtainStyledAttributes3.getResources().obtainTypedArray(resourceId2);
            int length = typedArrayObtainTypedArray.length();
            i8 = 0;
            int[] iArr4 = new int[length];
            if (length > 0) {
                for (int i10 = 0; i10 < length; i10++) {
                    iArr4[i10] = typedArrayObtainTypedArray.getDimensionPixelSize(i10, -1);
                }
                int[] iArrA = i1.a(iArr4);
                i1Var.e = iArrA;
                boolean z10 = iArrA.length > 0;
                i1Var.f807f = z10;
                if (z10) {
                    i1Var.f804a = 1;
                    i1Var.f805c = iArrA[0];
                    i1Var.f806d = iArrA[r14 - 1];
                    i1Var.b = -1.0f;
                }
            }
            typedArrayObtainTypedArray.recycle();
        }
        typedArrayObtainStyledAttributes3.recycle();
        if (!i1Var.b()) {
            i1Var.f804a = i8;
        } else if (i1Var.f804a == 1) {
            if (!i1Var.f807f) {
                DisplayMetrics displayMetrics = context2.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    i9 = 2;
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                } else {
                    i9 = 2;
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(i9, 112.0f, displayMetrics);
                }
                float f2 = dimension3;
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                if (dimension2 <= 0.0f) {
                    throw new IllegalArgumentException("Minimum auto-size text size (" + dimension2 + "px) is less or equal to (0px)");
                }
                if (f2 <= dimension2) {
                    throw new IllegalArgumentException("Maximum auto-size text size (" + f2 + "px) is less or equal to minimum auto-size text size (" + dimension2 + "px)");
                }
                if (dimension <= 0.0f) {
                    throw new IllegalArgumentException("The auto-size step granularity (" + dimension + "px) is less or equal to (0px)");
                }
                i1Var.f804a = 1;
                i1Var.f805c = dimension2;
                i1Var.f806d = f2;
                i1Var.b = dimension;
                i1Var.f807f = i8;
            }
            if (i1Var.b() && i1Var.f804a == 1 && (!i1Var.f807f || i1Var.e.length == 0)) {
                int iFloor = ((int) Math.floor((i1Var.f806d - i1Var.f805c) / i1Var.b)) + 1;
                int[] iArr5 = new int[iFloor];
                for (int i11 = 0; i11 < iFloor; i11++) {
                    iArr5[i11] = Math.round((i11 * i1Var.b) + i1Var.f805c);
                }
                i1Var.e = i1.a(iArr5);
            }
        }
        Method method = z3.f986a;
        if (i1Var.f804a != 0) {
            int[] iArr6 = i1Var.e;
            if (iArr6.length > 0) {
                if (a1.a(textView) != -1.0f) {
                    a1.b(textView, Math.round(i1Var.f805c), Math.round(i1Var.f806d), Math.round(i1Var.b), 0);
                } else {
                    a1.c(textView, iArr6, 0);
                }
            }
        }
        TypedArray typedArrayObtainStyledAttributes4 = context.obtainStyledAttributes(attributeSet, iArr3);
        int resourceId4 = typedArrayObtainStyledAttributes4.getResourceId(8, -1);
        Drawable drawableB = resourceId4 != -1 ? wVarA.b(context, resourceId4) : null;
        int resourceId5 = typedArrayObtainStyledAttributes4.getResourceId(13, -1);
        Drawable drawableB2 = resourceId5 != -1 ? wVarA.b(context, resourceId5) : null;
        int resourceId6 = typedArrayObtainStyledAttributes4.getResourceId(9, -1);
        Drawable drawableB3 = resourceId6 != -1 ? wVarA.b(context, resourceId6) : null;
        int resourceId7 = typedArrayObtainStyledAttributes4.getResourceId(6, -1);
        Drawable drawableB4 = resourceId7 != -1 ? wVarA.b(context, resourceId7) : null;
        int resourceId8 = typedArrayObtainStyledAttributes4.getResourceId(10, -1);
        Drawable drawableB5 = resourceId8 != -1 ? wVarA.b(context, resourceId8) : null;
        int resourceId9 = typedArrayObtainStyledAttributes4.getResourceId(7, -1);
        Drawable drawableB6 = resourceId9 != -1 ? wVarA.b(context, resourceId9) : null;
        if (drawableB5 != null || drawableB6 != null) {
            Drawable[] drawableArrA = y0.a(textView);
            if (drawableB5 == null) {
                drawableB5 = drawableArrA[0];
            }
            if (drawableB2 == null) {
                drawableB2 = drawableArrA[1];
            }
            if (drawableB6 == null) {
                drawableB6 = drawableArrA[2];
            }
            if (drawableB4 == null) {
                drawableB4 = drawableArrA[3];
            }
            y0.b(textView, drawableB5, drawableB2, drawableB6, drawableB4);
        } else if (drawableB != null || drawableB2 != null || drawableB3 != null || drawableB4 != null) {
            Drawable[] drawableArrA2 = y0.a(textView);
            Drawable drawable = drawableArrA2[0];
            if (drawable == null && drawableArrA2[2] == null) {
                Drawable[] compoundDrawables = textView.getCompoundDrawables();
                if (drawableB == null) {
                    drawableB = compoundDrawables[0];
                }
                if (drawableB2 == null) {
                    drawableB2 = compoundDrawables[1];
                }
                if (drawableB3 == null) {
                    drawableB3 = compoundDrawables[2];
                }
                if (drawableB4 == null) {
                    drawableB4 = compoundDrawables[3];
                }
                textView.setCompoundDrawablesWithIntrinsicBounds(drawableB, drawableB2, drawableB3, drawableB4);
            } else {
                if (drawableB2 == null) {
                    drawableB2 = drawableArrA2[1];
                }
                Drawable drawable2 = drawableArrA2[2];
                if (drawableB4 == null) {
                    drawableB4 = drawableArrA2[3];
                }
                y0.b(textView, drawable, drawableB2, drawable2, drawableB4);
            }
        }
        if (typedArrayObtainStyledAttributes4.hasValue(11)) {
            if (!typedArrayObtainStyledAttributes4.hasValue(11) || (resourceId = typedArrayObtainStyledAttributes4.getResourceId(11, 0)) == 0 || (colorStateList = a5.h.A(context, resourceId)) == null) {
                colorStateList = typedArrayObtainStyledAttributes4.getColorStateList(11);
            }
            androidx.core.widget.q.f(textView, colorStateList);
        }
        if (typedArrayObtainStyledAttributes4.hasValue(12)) {
            androidx.core.widget.q.g(textView, m1.b(typedArrayObtainStyledAttributes4.getInt(12, -1), null));
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes4.getDimensionPixelSize(15, -1);
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes4.getDimensionPixelSize(18, -1);
        int dimensionPixelSize3 = typedArrayObtainStyledAttributes4.getDimensionPixelSize(19, -1);
        typedArrayObtainStyledAttributes4.recycle();
        if (dimensionPixelSize != -1) {
            a5.h.g(dimensionPixelSize);
            androidx.core.widget.r.c(textView, dimensionPixelSize);
        }
        if (dimensionPixelSize2 != -1) {
            a5.h.g(dimensionPixelSize2);
            Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
            int i12 = androidx.core.widget.o.a(textView) ? fontMetricsInt.bottom : fontMetricsInt.descent;
            if (dimensionPixelSize2 > Math.abs(i12)) {
                textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), dimensionPixelSize2 - i12);
            }
        }
        if (dimensionPixelSize3 != -1) {
            a5.h.g(dimensionPixelSize3);
            if (dimensionPixelSize3 != textView.getPaint().getFontMetricsInt(null)) {
                textView.setLineSpacing(dimensionPixelSize3 - r1, 1.0f);
            }
        }
    }

    public final void g(Context context, int i7) {
        String string;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i7, d.a.f5223w);
        y2.e eVar = new y2.e(context, typedArrayObtainStyledAttributes);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(14);
        TextView textView = this.f720a;
        if (zHasValue) {
            textView.setAllCaps(typedArrayObtainStyledAttributes.getBoolean(14, false));
        }
        if (typedArrayObtainStyledAttributes.hasValue(0) && typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        k(context, eVar);
        if (typedArrayObtainStyledAttributes.hasValue(13) && (string = typedArrayObtainStyledAttributes.getString(13)) != null) {
            a1.d(textView, string);
        }
        eVar.C();
        Typeface typeface = this.f729l;
        if (typeface != null) {
            textView.setTypeface(typeface, this.f727j);
        }
    }

    public final void i(ColorStateList colorStateList) {
        if (this.f725h == null) {
            this.f725h = new k3();
        }
        k3 k3Var = this.f725h;
        k3Var.f831c = colorStateList;
        k3Var.b = colorStateList != null;
        this.b = k3Var;
        this.f721c = k3Var;
        this.f722d = k3Var;
        this.e = k3Var;
        this.f723f = k3Var;
        this.f724g = k3Var;
    }

    public final void j(PorterDuff.Mode mode) {
        if (this.f725h == null) {
            this.f725h = new k3();
        }
        k3 k3Var = this.f725h;
        k3Var.f832d = mode;
        k3Var.f830a = mode != null;
        this.b = k3Var;
        this.f721c = k3Var;
        this.f722d = k3Var;
        this.e = k3Var;
        this.f723f = k3Var;
        this.f724g = k3Var;
    }

    public final void k(Context context, y2.e eVar) {
        String string;
        int i7 = this.f727j;
        TypedArray typedArray = (TypedArray) eVar.f8965c;
        this.f727j = typedArray.getInt(2, i7);
        int i8 = typedArray.getInt(11, -1);
        this.f728k = i8;
        if (i8 != -1) {
            this.f727j &= 2;
        }
        if (!typedArray.hasValue(10) && !typedArray.hasValue(12)) {
            if (typedArray.hasValue(1)) {
                this.f730m = false;
                int i9 = typedArray.getInt(1, 1);
                if (i9 == 1) {
                    this.f729l = Typeface.SANS_SERIF;
                    return;
                } else if (i9 == 2) {
                    this.f729l = Typeface.SERIF;
                    return;
                } else {
                    if (i9 != 3) {
                        return;
                    }
                    this.f729l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.f729l = null;
        int i10 = typedArray.hasValue(12) ? 12 : 10;
        int i11 = this.f728k;
        int i12 = this.f727j;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceQ = eVar.q(i10, this.f727j, new x0(this, i11, i12, new WeakReference(this.f720a)));
                if (typefaceQ != null) {
                    if (this.f728k != -1) {
                        this.f729l = b1.a(Typeface.create(typefaceQ, 0), this.f728k, (this.f727j & 2) != 0);
                    } else {
                        this.f729l = typefaceQ;
                    }
                }
                this.f730m = this.f729l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f729l != null || (string = typedArray.getString(i10)) == null) {
            return;
        }
        if (this.f728k != -1) {
            this.f729l = b1.a(Typeface.create(string, 0), this.f728k, (this.f727j & 2) != 0);
        } else {
            this.f729l = Typeface.create(string, this.f727j);
        }
    }
}
