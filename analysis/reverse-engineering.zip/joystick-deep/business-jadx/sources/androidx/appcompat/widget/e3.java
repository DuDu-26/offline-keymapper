package androidx.appcompat.widget;

import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e3 extends TouchDelegate {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f742a;
    public final Rect b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f743c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Rect f744d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f745f;

    public e3(Rect rect, Rect rect2, View view) {
        super(rect, view);
        int scaledTouchSlop = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        this.e = scaledTouchSlop;
        Rect rect3 = new Rect();
        this.b = rect3;
        Rect rect4 = new Rect();
        this.f744d = rect4;
        Rect rect5 = new Rect();
        this.f743c = rect5;
        rect3.set(rect);
        rect4.set(rect);
        int i7 = -scaledTouchSlop;
        rect4.inset(i7, i7);
        rect5.set(rect2);
        this.f742a = view;
    }

    @Override // android.view.TouchDelegate
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z6;
        boolean z7;
        int x4 = (int) motionEvent.getX();
        int y6 = (int) motionEvent.getY();
        int action = motionEvent.getAction();
        boolean z8 = true;
        if (action != 0) {
            if (action == 1 || action == 2) {
                z7 = this.f745f;
                if (z7 && !this.f744d.contains(x4, y6)) {
                    z8 = z7;
                    z6 = false;
                }
            } else {
                if (action == 3) {
                    z7 = this.f745f;
                    this.f745f = false;
                }
                z6 = true;
                z8 = false;
            }
            z8 = z7;
            z6 = true;
        } else if (this.b.contains(x4, y6)) {
            this.f745f = true;
            z6 = true;
        } else {
            z6 = true;
            z8 = false;
        }
        if (!z8) {
            return false;
        }
        Rect rect = this.f743c;
        View view = this.f742a;
        if (!z6 || rect.contains(x4, y6)) {
            motionEvent.setLocation(x4 - rect.left, y6 - rect.top);
        } else {
            motionEvent.setLocation(view.getWidth() / 2, view.getHeight() / 2);
        }
        return view.dispatchTouchEvent(motionEvent);
    }
}
