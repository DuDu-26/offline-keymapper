package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class w {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static w f951c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2 f952a;

    public static synchronized w a() {
        try {
            if (f951c == null) {
                d();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f951c;
    }

    public static synchronized PorterDuffColorFilter c(int i7, PorterDuff.Mode mode) {
        return n2.e(i7, mode);
    }

    public static synchronized void d() {
        if (f951c == null) {
            w wVar = new w();
            f951c = wVar;
            wVar.f952a = n2.b();
            n2 n2Var = f951c.f952a;
            q6.c cVar = new q6.c(2);
            synchronized (n2Var) {
                n2Var.e = cVar;
            }
        }
    }

    public static void e(Drawable drawable, k3 k3Var, int[] iArr) {
        PorterDuff.Mode mode = n2.f861f;
        int[] state = drawable.getState();
        int[] iArr2 = m1.f859a;
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z6 = k3Var.b;
            if (!z6 && !k3Var.f830a) {
                drawable.clearColorFilter();
                return;
            }
            PorterDuffColorFilter porterDuffColorFilterE = null;
            ColorStateList colorStateList = z6 ? (ColorStateList) k3Var.f831c : null;
            PorterDuff.Mode mode2 = k3Var.f830a ? (PorterDuff.Mode) k3Var.f832d : n2.f861f;
            if (colorStateList != null && mode2 != null) {
                porterDuffColorFilterE = n2.e(colorStateList.getColorForState(iArr, 0), mode2);
            }
            drawable.setColorFilter(porterDuffColorFilterE);
        }
    }

    public final synchronized Drawable b(Context context, int i7) {
        return this.f952a.c(context, i7);
    }
}
