package androidx.appcompat.widget;

import android.content.Context;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class f extends g.w {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f746l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ l f747m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(l lVar, Context context, g.e0 e0Var, View view) {
        super(context, e0Var, view, false, 2130968610, 0);
        this.f747m = lVar;
        if ((e0Var.A.f5803x & 32) != 32) {
            View view2 = lVar.f840j;
            this.e = view2 == null ? (View) lVar.f838h : view2;
        }
        w3.e eVar = lVar.f854x;
        this.f5819h = eVar;
        g.t tVar = this.f5820i;
        if (tVar != null) {
            tVar.b(eVar);
        }
    }

    @Override // g.w
    public final void c() {
        switch (this.f746l) {
            case 0:
                l lVar = this.f747m;
                lVar.f851u = null;
                lVar.f855y = 0;
                super.c();
                break;
            default:
                l lVar2 = this.f747m;
                g.l lVar3 = lVar2.f834c;
                if (lVar3 != null) {
                    lVar3.c(true);
                }
                lVar2.f850t = null;
                super.c();
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(l lVar, Context context, g.l lVar2, View view) {
        super(context, lVar2, view, true, 2130968610, 0);
        this.f747m = lVar;
        this.f5817f = 8388613;
        w3.e eVar = lVar.f854x;
        this.f5819h = eVar;
        g.t tVar = this.f5820i;
        if (tVar != null) {
            tVar.b(eVar);
        }
    }
}
