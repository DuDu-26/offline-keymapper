package androidx.appcompat.widget;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u2 implements View.OnLayoutChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f922a;
    public final /* synthetic */ Object b;

    public /* synthetic */ u2(int i7, Object obj) {
        this.f922a = i7;
        this.b = obj;
    }

    @Override // android.view.View.OnLayoutChangeListener
    public final void onLayoutChange(View view, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14) {
        h1.a aVar;
        switch (this.f922a) {
            case 0:
                SearchView searchView = (SearchView) this.b;
                SearchView.SearchAutoComplete searchAutoComplete = searchView.f665p;
                View view2 = searchView.f673x;
                if (view2.getWidth() > 1) {
                    Resources resources = searchView.getContext().getResources();
                    int paddingLeft = searchView.f667r.getPaddingLeft();
                    Rect rect = new Rect();
                    boolean zA = z3.a(searchView);
                    int dimensionPixelSize = searchView.M ? resources.getDimensionPixelSize(2131165226) + resources.getDimensionPixelSize(2131165225) : 0;
                    searchAutoComplete.getDropDownBackground().getPadding(rect);
                    int i15 = rect.left;
                    searchAutoComplete.setDropDownHorizontalOffset(zA ? -i15 : paddingLeft - (i15 + dimensionPixelSize));
                    searchAutoComplete.setDropDownWidth((((view2.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
                    return;
                }
                return;
            case 1:
                throw null;
            default:
                j1.a aVar2 = (j1.a) this.b;
                ImageView imageView = aVar2.f3354n;
                if (imageView.getVisibility() != 0 || (aVar = aVar2.F) == null) {
                    return;
                }
                Rect rect2 = new Rect();
                imageView.getDrawingRect(rect2);
                aVar.setBounds(rect2);
                aVar.h(imageView, null);
                return;
        }
    }
}
