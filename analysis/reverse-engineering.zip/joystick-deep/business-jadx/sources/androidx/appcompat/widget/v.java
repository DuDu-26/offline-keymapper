package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Parcelable f926a;
    public Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f927c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f928d;
    public boolean e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Object f929f;

    public /* synthetic */ v(TextView textView) {
        this.f926a = null;
        this.b = null;
        this.f927c = false;
        this.f928d = false;
        this.f929f = textView;
    }

    public void a() {
        CompoundButton compoundButton = (CompoundButton) this.f929f;
        Drawable drawableA = androidx.core.widget.c.a(compoundButton);
        if (drawableA != null) {
            if (this.f927c || this.f928d) {
                Drawable drawableMutate = drawableA.mutate();
                if (this.f927c) {
                    y.b.h(drawableMutate, (ColorStateList) this.f926a);
                }
                if (this.f928d) {
                    y.b.i(drawableMutate, (PorterDuff.Mode) this.b);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(compoundButton.getDrawableState());
                }
                compoundButton.setButtonDrawable(drawableMutate);
            }
        }
    }

    public void b() {
        u uVar = (u) this.f929f;
        Drawable checkMarkDrawable = uVar.getCheckMarkDrawable();
        if (checkMarkDrawable != null) {
            if (this.f927c || this.f928d) {
                Drawable drawableMutate = checkMarkDrawable.mutate();
                if (this.f927c) {
                    y.b.h(drawableMutate, (ColorStateList) this.f926a);
                }
                if (this.f928d) {
                    y.b.i(drawableMutate, (PorterDuff.Mode) this.b);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(uVar.getDrawableState());
                }
                uVar.setCheckMarkDrawable(drawableMutate);
            }
        }
    }

    public Bundle c(String str) {
        if (!this.f928d) {
            f3.t("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
            return null;
        }
        Bundle bundle = (Bundle) this.f926a;
        if (bundle == null) {
            return null;
        }
        Bundle bundle2 = bundle.getBundle(str);
        Bundle bundle3 = (Bundle) this.f926a;
        if (bundle3 != null) {
            bundle3.remove(str);
        }
        Bundle bundle4 = (Bundle) this.f926a;
        if (bundle4 != null && !bundle4.isEmpty()) {
            return bundle2;
        }
        this.f926a = null;
        return bundle2;
    }

    public void d(AttributeSet attributeSet, int i7) {
        int resourceId;
        int resourceId2;
        CompoundButton compoundButton = (CompoundButton) this.f929f;
        Context context = compoundButton.getContext();
        int[] iArr = d.a.f5213m;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, i7);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        f0.s0.i(compoundButton, compoundButton.getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, i7);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    compoundButton.setButtonDrawable(a5.h.E(compoundButton.getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(0)) {
                        compoundButton.setButtonDrawable(a5.h.E(compoundButton.getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                compoundButton.setButtonDrawable(a5.h.E(compoundButton.getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                androidx.core.widget.b.c(compoundButton, eVarA.n(2));
            }
            if (typedArray.hasValue(3)) {
                androidx.core.widget.b.d(compoundButton, m1.b(typedArray.getInt(3, -1), null));
            }
            eVarA.C();
        } catch (Throwable th) {
            eVarA.C();
            throw th;
        }
    }

    public void e(String str, u0.c cVar) {
        Object obj;
        i.f fVar = (i.f) this.f929f;
        i.c cVarA = fVar.a(str);
        if (cVarA != null) {
            obj = cVarA.b;
        } else {
            i.c cVar2 = new i.c(str, cVar);
            fVar.f6260d++;
            i.c cVar3 = fVar.b;
            if (cVar3 == null) {
                fVar.f6258a = cVar2;
                fVar.b = cVar2;
            } else {
                cVar3.f6254c = cVar2;
                cVar2.f6255d = cVar3;
                fVar.b = cVar2;
            }
            obj = null;
        }
        if (((u0.c) obj) == null) {
            return;
        }
        f3.q("SavedStateProvider with the given key is already registered");
    }

    public v() {
        this.f929f = new i.f();
        this.e = true;
    }
}
