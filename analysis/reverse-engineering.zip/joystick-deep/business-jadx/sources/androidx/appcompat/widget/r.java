package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class r implements y3.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f891a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f892c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f893d;
    public Object e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f894f;

    public r(androidx.recyclerview.widget.j0 j0Var) {
        this.b = new e0.c(30);
        this.f892c = new ArrayList();
        this.f893d = new ArrayList();
        this.f891a = 0;
        this.e = j0Var;
        this.f894f = new w3.e(10, this);
    }

    public static r e(Context context, int i7) {
        a5.h.f("Cannot create a CalendarItemStyle with a styleResId of 0", i7 != 0);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i7, e1.a.f5312p);
        Rect rect = new Rect(typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(2, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(3, 0));
        ColorStateList colorStateListN = m4.f.n(context, typedArrayObtainStyledAttributes, 4);
        ColorStateList colorStateListN2 = m4.f.n(context, typedArrayObtainStyledAttributes, 9);
        ColorStateList colorStateListN3 = m4.f.n(context, typedArrayObtainStyledAttributes, 7);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        y1.k kVarA = y1.k.a(context, typedArrayObtainStyledAttributes.getResourceId(5, 0), typedArrayObtainStyledAttributes.getResourceId(6, 0), new y1.a(0)).a();
        typedArrayObtainStyledAttributes.recycle();
        return new r(colorStateListN, colorStateListN2, colorStateListN3, dimensionPixelSize, kVarA, rect);
    }

    public void a() {
        View view = (View) this.b;
        Drawable background = view.getBackground();
        if (background != null) {
            if (((k3) this.f893d) != null) {
                if (((k3) this.f894f) == null) {
                    this.f894f = new k3();
                }
                k3 k3Var = (k3) this.f894f;
                k3Var.f831c = null;
                k3Var.b = false;
                k3Var.f832d = null;
                k3Var.f830a = false;
                WeakHashMap weakHashMap = f0.s0.f5582a;
                ColorStateList colorStateListG = f0.h0.g(view);
                if (colorStateListG != null) {
                    k3Var.b = true;
                    k3Var.f831c = colorStateListG;
                }
                PorterDuff.Mode modeH = f0.h0.h(view);
                if (modeH != null) {
                    k3Var.f830a = true;
                    k3Var.f832d = modeH;
                }
                if (k3Var.b || k3Var.f830a) {
                    w.e(background, k3Var, view.getDrawableState());
                    return;
                }
            }
            k3 k3Var2 = (k3) this.e;
            if (k3Var2 != null) {
                w.e(background, k3Var2, view.getDrawableState());
                return;
            }
            k3 k3Var3 = (k3) this.f893d;
            if (k3Var3 != null) {
                w.e(background, k3Var3, view.getDrawableState());
            }
        }
    }

    public boolean b(int i7) {
        ArrayList arrayList = (ArrayList) this.f893d;
        int size = arrayList.size();
        for (int i8 = 0; i8 < size; i8++) {
            androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) arrayList.get(i8);
            int i9 = aVar.f1463a;
            if (i9 != 8) {
                if (i9 == 1) {
                    int i10 = aVar.b;
                    int i11 = aVar.f1464c + i10;
                    while (i10 < i11) {
                        if (h(i10, i8 + 1) == i7) {
                            return true;
                        }
                        i10++;
                    }
                } else {
                    continue;
                }
            } else {
                if (h(aVar.f1464c, i8 + 1) == i7) {
                    return true;
                }
            }
        }
        return false;
    }

    public void c() {
        ArrayList arrayList = (ArrayList) this.f893d;
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            ((androidx.recyclerview.widget.j0) this.e).a((androidx.recyclerview.widget.a) arrayList.get(i7));
        }
        r(arrayList);
        this.f891a = 0;
    }

    public void d() {
        androidx.recyclerview.widget.j0 j0Var = (androidx.recyclerview.widget.j0) this.e;
        c();
        ArrayList arrayList = (ArrayList) this.f892c;
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) arrayList.get(i7);
            int i8 = aVar.f1463a;
            if (i8 == 1) {
                j0Var.a(aVar);
                j0Var.d(aVar.b, aVar.f1464c);
            } else if (i8 == 2) {
                j0Var.a(aVar);
                int i9 = aVar.b;
                int i10 = aVar.f1464c;
                RecyclerView recyclerView = j0Var.f1563a;
                recyclerView.P(i9, i10, true);
                recyclerView.f1411i0 = true;
                recyclerView.f1405f0.f1551c += i10;
            } else if (i8 == 4) {
                j0Var.a(aVar);
                j0Var.c(aVar.b, aVar.f1464c);
            } else if (i8 == 8) {
                j0Var.a(aVar);
                j0Var.e(aVar.b, aVar.f1464c);
            }
        }
        r(arrayList);
        this.f891a = 0;
    }

    public void f(androidx.recyclerview.widget.a aVar) {
        int i7;
        e0.c cVar = (e0.c) this.b;
        int i8 = aVar.f1463a;
        if (i8 == 1 || i8 == 8) {
            f3.q("should not dispatch add or move for pre layout");
            return;
        }
        int iW = w(aVar.b, i8);
        int i9 = aVar.b;
        int i10 = aVar.f1463a;
        if (i10 == 2) {
            i7 = 0;
        } else {
            if (i10 != 4) {
                k3.g.h(aVar, "op should be remove or update.");
                return;
            }
            i7 = 1;
        }
        int i11 = 1;
        for (int i12 = 1; i12 < aVar.f1464c; i12++) {
            int iW2 = w((i7 * i12) + aVar.b, aVar.f1463a);
            int i13 = aVar.f1463a;
            if (i13 == 2 ? iW2 != iW : !(i13 == 4 && iW2 == iW + 1)) {
                androidx.recyclerview.widget.a aVarM = m(i13, iW, i11);
                g(aVarM, i9);
                cVar.c(aVarM);
                if (aVar.f1463a == 4) {
                    i9 += i11;
                }
                i11 = 1;
                iW = iW2;
            } else {
                i11++;
            }
        }
        cVar.c(aVar);
        if (i11 > 0) {
            androidx.recyclerview.widget.a aVarM2 = m(aVar.f1463a, iW, i11);
            g(aVarM2, i9);
            cVar.c(aVarM2);
        }
    }

    public void g(androidx.recyclerview.widget.a aVar, int i7) {
        androidx.recyclerview.widget.j0 j0Var = (androidx.recyclerview.widget.j0) this.e;
        j0Var.a(aVar);
        int i8 = aVar.f1463a;
        if (i8 != 2) {
            if (i8 == 4) {
                j0Var.c(i7, aVar.f1464c);
                return;
            } else {
                f3.q("only remove and update ops can be dispatched in first pass");
                return;
            }
        }
        int i9 = aVar.f1464c;
        RecyclerView recyclerView = j0Var.f1563a;
        recyclerView.P(i7, i9, true);
        recyclerView.f1411i0 = true;
        recyclerView.f1405f0.f1551c += i9;
    }

    public int h(int i7, int i8) {
        ArrayList arrayList = (ArrayList) this.f893d;
        int size = arrayList.size();
        while (i8 < size) {
            androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) arrayList.get(i8);
            int i9 = aVar.f1463a;
            int i10 = aVar.b;
            if (i9 == 8) {
                if (i10 == i7) {
                    i7 = aVar.f1464c;
                } else {
                    if (i10 < i7) {
                        i7--;
                    }
                    if (aVar.f1464c <= i7) {
                        i7++;
                    }
                }
            } else if (i10 > i7) {
                continue;
            } else if (i9 == 2) {
                int i11 = aVar.f1464c;
                if (i7 < i10 + i11) {
                    return -1;
                }
                i7 -= i11;
            } else if (i9 == 1) {
                i7 += aVar.f1464c;
            }
            i8++;
        }
        return i7;
    }

    public ColorStateList i() {
        k3 k3Var = (k3) this.e;
        if (k3Var != null) {
            return (ColorStateList) k3Var.f831c;
        }
        return null;
    }

    public PorterDuff.Mode j() {
        k3 k3Var = (k3) this.e;
        if (k3Var != null) {
            return (PorterDuff.Mode) k3Var.f832d;
        }
        return null;
    }

    public boolean k() {
        return ((ArrayList) this.f892c).size() > 0;
    }

    public void l(AttributeSet attributeSet, int i7) {
        ColorStateList colorStateListF;
        View view = (View) this.b;
        Context context = view.getContext();
        int[] iArr = d.a.f5226z;
        y2.e eVarA = y2.e.A(context, attributeSet, iArr, i7);
        TypedArray typedArray = (TypedArray) eVarA.f8965c;
        View view2 = (View) this.b;
        f0.s0.i(view2, view2.getContext(), iArr, attributeSet, (TypedArray) eVarA.f8965c, i7);
        try {
            if (typedArray.hasValue(0)) {
                this.f891a = typedArray.getResourceId(0, -1);
                w wVar = (w) this.f892c;
                Context context2 = view.getContext();
                int i8 = this.f891a;
                synchronized (wVar) {
                    colorStateListF = wVar.f952a.f(context2, i8);
                }
                if (colorStateListF != null) {
                    s(colorStateListF);
                }
            }
            if (typedArray.hasValue(1)) {
                f0.h0.q(view, eVarA.n(1));
            }
            if (typedArray.hasValue(2)) {
                f0.h0.r(view, m1.b(typedArray.getInt(2, -1), null));
            }
            eVarA.C();
        } catch (Throwable th) {
            eVarA.C();
            throw th;
        }
    }

    public androidx.recyclerview.widget.a m(int i7, int i8, int i9) {
        androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) ((e0.c) this.b).a();
        if (aVar != null) {
            aVar.f1463a = i7;
            aVar.b = i8;
            aVar.f1464c = i9;
            return aVar;
        }
        androidx.recyclerview.widget.a aVar2 = new androidx.recyclerview.widget.a();
        aVar2.f1463a = i7;
        aVar2.b = i8;
        aVar2.f1464c = i9;
        return aVar2;
    }

    public void n() {
        this.f891a = -1;
        s(null);
        a();
    }

    public void o(int i7) {
        ColorStateList colorStateListF;
        this.f891a = i7;
        w wVar = (w) this.f892c;
        if (wVar != null) {
            Context context = ((View) this.b).getContext();
            synchronized (wVar) {
                colorStateListF = wVar.f952a.f(context, i7);
            }
        } else {
            colorStateListF = null;
        }
        s(colorStateListF);
        a();
    }

    public void p(androidx.recyclerview.widget.a aVar) {
        androidx.recyclerview.widget.j0 j0Var = (androidx.recyclerview.widget.j0) this.e;
        ((ArrayList) this.f893d).add(aVar);
        int i7 = aVar.f1463a;
        if (i7 == 1) {
            j0Var.d(aVar.b, aVar.f1464c);
            return;
        }
        if (i7 == 2) {
            int i8 = aVar.b;
            int i9 = aVar.f1464c;
            RecyclerView recyclerView = j0Var.f1563a;
            recyclerView.P(i8, i9, false);
            recyclerView.f1411i0 = true;
            return;
        }
        if (i7 == 4) {
            j0Var.c(aVar.b, aVar.f1464c);
        } else if (i7 == 8) {
            j0Var.e(aVar.b, aVar.f1464c);
        } else {
            k3.g.h(aVar, "Unknown update op type for ");
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:185:0x00a8 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:186:0x0120 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:189:0x0115 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:203:0x0015 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x007d  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00a3  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void q() {
        /*
            Method dump skipped, instruction units count: 667
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.r.q():void");
    }

    public void r(ArrayList arrayList) {
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) arrayList.get(i7);
            aVar.getClass();
            ((e0.c) this.b).c(aVar);
        }
        arrayList.clear();
    }

    public void s(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (((k3) this.f893d) == null) {
                this.f893d = new k3();
            }
            k3 k3Var = (k3) this.f893d;
            k3Var.f831c = colorStateList;
            k3Var.b = true;
        } else {
            this.f893d = null;
        }
        a();
    }

    public void t(ColorStateList colorStateList) {
        if (((k3) this.e) == null) {
            this.e = new k3();
        }
        k3 k3Var = (k3) this.e;
        k3Var.f831c = colorStateList;
        k3Var.b = true;
        a();
    }

    public void u(PorterDuff.Mode mode) {
        if (((k3) this.e) == null) {
            this.e = new k3();
        }
        k3 k3Var = (k3) this.e;
        k3Var.f832d = mode;
        k3Var.f830a = true;
        a();
    }

    public void v(TextView textView) {
        ColorStateList colorStateList = (ColorStateList) this.f892c;
        y1.g gVar = new y1.g();
        y1.g gVar2 = new y1.g();
        y1.k kVar = (y1.k) this.f894f;
        gVar.setShapeAppearanceModel(kVar);
        gVar2.setShapeAppearanceModel(kVar);
        gVar.k((ColorStateList) this.f893d);
        float f2 = this.f891a;
        ColorStateList colorStateList2 = (ColorStateList) this.e;
        gVar.f8878a.f8870j = f2;
        gVar.invalidateSelf();
        y1.f fVar = gVar.f8878a;
        if (fVar.f8865d != colorStateList2) {
            fVar.f8865d = colorStateList2;
            gVar.onStateChange(gVar.getState());
        }
        textView.setTextColor(colorStateList);
        RippleDrawable rippleDrawable = new RippleDrawable(colorStateList.withAlpha(30), gVar, gVar2);
        Rect rect = (Rect) this.b;
        InsetDrawable insetDrawable = new InsetDrawable((Drawable) rippleDrawable, rect.left, rect.top, rect.right, rect.bottom);
        WeakHashMap weakHashMap = f0.s0.f5582a;
        f0.b0.q(textView, insetDrawable);
    }

    public int w(int i7, int i8) {
        int i9;
        int i10;
        e0.c cVar = (e0.c) this.b;
        ArrayList arrayList = (ArrayList) this.f893d;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) arrayList.get(size);
            int i11 = aVar.f1463a;
            int i12 = aVar.b;
            if (i11 == 8) {
                int i13 = aVar.f1464c;
                if (i12 < i13) {
                    i10 = i13;
                    i9 = i12;
                } else {
                    i9 = i13;
                    i10 = i12;
                }
                if (i7 < i9 || i7 > i10) {
                    if (i7 < i12) {
                        if (i8 == 1) {
                            aVar.b = i12 + 1;
                            aVar.f1464c = i13 + 1;
                        } else if (i8 == 2) {
                            aVar.b = i12 - 1;
                            aVar.f1464c = i13 - 1;
                        }
                    }
                } else if (i9 == i12) {
                    if (i8 == 1) {
                        aVar.f1464c = i13 + 1;
                    } else if (i8 == 2) {
                        aVar.f1464c = i13 - 1;
                    }
                    i7++;
                } else {
                    if (i8 == 1) {
                        aVar.b = i12 + 1;
                    } else if (i8 == 2) {
                        aVar.b = i12 - 1;
                    }
                    i7--;
                }
            } else if (i12 <= i7) {
                if (i11 == 1) {
                    i7 -= aVar.f1464c;
                } else if (i11 == 2) {
                    i7 += aVar.f1464c;
                }
            } else if (i8 == 1) {
                aVar.b = i12 + 1;
            } else if (i8 == 2) {
                aVar.b = i12 - 1;
            }
        }
        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
            androidx.recyclerview.widget.a aVar2 = (androidx.recyclerview.widget.a) arrayList.get(size2);
            int i14 = aVar2.f1463a;
            int i15 = aVar2.f1464c;
            if (i14 == 8) {
                if (i15 == aVar2.b || i15 < 0) {
                    arrayList.remove(size2);
                    cVar.c(aVar2);
                }
            } else if (i15 <= 0) {
                arrayList.remove(size2);
                cVar.c(aVar2);
            }
        }
        return i7;
    }

    public r(ColorStateList colorStateList, ColorStateList colorStateList2, ColorStateList colorStateList3, int i7, y1.k kVar, Rect rect) {
        a5.h.g(rect.left);
        a5.h.g(rect.top);
        a5.h.g(rect.right);
        a5.h.g(rect.bottom);
        this.b = rect;
        this.f892c = colorStateList2;
        this.f893d = colorStateList;
        this.e = colorStateList3;
        this.f891a = i7;
        this.f894f = kVar;
    }

    public r(View view) {
        this.f891a = -1;
        this.b = view;
        this.f892c = w.a();
    }

    public r(y3.p pVar, y3.b bVar, z3.a aVar, String str, int i7, String str2) {
        this.f894f = pVar;
        this.b = bVar;
        this.f892c = aVar;
        this.f893d = str;
        this.f891a = i7;
        this.e = str2;
    }
}
