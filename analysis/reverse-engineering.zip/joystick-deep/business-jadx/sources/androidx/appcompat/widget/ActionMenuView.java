package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ActionMenuView extends x1 implements g.k, g.a0 {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public g.l f638p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Context f639q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f640r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f641s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public l f642t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public n3 f643u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f644v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f645w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f646x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f647y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public p f648z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setBaselineAligned(false);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.f646x = (int) (56.0f * f2);
        this.f647y = (int) (f2 * 4.0f);
        this.f639q = context;
        this.f640r = 0;
    }

    public static o j() {
        o oVar = new o(-2, -2);
        oVar.f868a = false;
        ((LinearLayout.LayoutParams) oVar).gravity = 16;
        return oVar;
    }

    public static o k(ViewGroup.LayoutParams layoutParams) {
        o oVar;
        if (layoutParams == null) {
            return j();
        }
        if (layoutParams instanceof o) {
            o oVar2 = (o) layoutParams;
            oVar = new o(oVar2);
            oVar.f868a = oVar2.f868a;
        } else {
            oVar = new o(layoutParams);
        }
        if (((LinearLayout.LayoutParams) oVar).gravity <= 0) {
            ((LinearLayout.LayoutParams) oVar).gravity = 16;
        }
        return oVar;
    }

    @Override // g.k
    public final boolean a(g.n nVar) {
        return this.f638p.q(nVar, null, 0);
    }

    @Override // g.a0
    public final void c(g.l lVar) {
        this.f638p = lVar;
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof o;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // androidx.appcompat.widget.x1
    public final /* bridge */ /* synthetic */ w1 f() {
        return j();
    }

    @Override // androidx.appcompat.widget.x1
    public final w1 g(AttributeSet attributeSet) {
        return new o(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return j();
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new o(getContext(), attributeSet);
    }

    public Menu getMenu() {
        if (this.f638p == null) {
            Context context = getContext();
            g.l lVar = new g.l(context);
            this.f638p = lVar;
            lVar.e = new w3.e(8, this);
            l lVar2 = new l(context);
            this.f642t = lVar2;
            lVar2.f843m = true;
            lVar2.f844n = true;
            lVar2.e = new n();
            this.f638p.b(lVar2, this.f639q);
            l lVar3 = this.f642t;
            lVar3.f838h = this;
            this.f638p = lVar3.f834c;
        }
        return this.f638p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        l lVar = this.f642t;
        j jVar = lVar.f840j;
        if (jVar != null) {
            return jVar.getDrawable();
        }
        if (lVar.f842l) {
            return lVar.f841k;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f640r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // androidx.appcompat.widget.x1
    public final /* bridge */ /* synthetic */ w1 h(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public final boolean l(int i7) {
        boolean zA = false;
        if (i7 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i7 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i7);
        if (i7 < getChildCount() && (childAt instanceof m)) {
            zA = ((m) childAt).a();
        }
        return (i7 <= 0 || !(childAt2 instanceof m)) ? zA : ((m) childAt2).c() | zA;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        l lVar = this.f642t;
        if (lVar != null) {
            lVar.i(false);
            if (this.f642t.h()) {
                this.f642t.c();
                this.f642t.n();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l lVar = this.f642t;
        if (lVar != null) {
            lVar.c();
            f fVar = lVar.f851u;
            if (fVar == null || !fVar.b()) {
                return;
            }
            fVar.f5820i.dismiss();
        }
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        int width;
        int paddingLeft;
        if (!this.f644v) {
            super.onLayout(z6, i7, i8, i9, i10);
            return;
        }
        int childCount = getChildCount();
        int i11 = (i10 - i8) / 2;
        int dividerWidth = getDividerWidth();
        int i12 = i9 - i7;
        int paddingRight = (i12 - getPaddingRight()) - getPaddingLeft();
        boolean zA = z3.a(this);
        int i13 = 0;
        int i14 = 0;
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt = getChildAt(i15);
            if (childAt.getVisibility() != 8) {
                o oVar = (o) childAt.getLayoutParams();
                if (oVar.f868a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (l(i15)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (zA) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) oVar).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) oVar).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i16 = i11 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i16, width, measuredHeight + i16);
                    paddingRight -= measuredWidth;
                    i13 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) oVar).leftMargin) + ((LinearLayout.LayoutParams) oVar).rightMargin;
                    l(i15);
                    i14++;
                }
            }
        }
        if (childCount == 1 && i13 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i17 = (i12 / 2) - (measuredWidth2 / 2);
            int i18 = i11 - (measuredHeight2 / 2);
            childAt2.layout(i17, i18, measuredWidth2 + i17, measuredHeight2 + i18);
            return;
        }
        int i19 = i14 - (i13 ^ 1);
        int iMax = Math.max(0, i19 > 0 ? paddingRight / i19 : 0);
        if (zA) {
            int width2 = getWidth() - getPaddingRight();
            for (int i20 = 0; i20 < childCount; i20++) {
                View childAt3 = getChildAt(i20);
                o oVar2 = (o) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !oVar2.f868a) {
                    int i21 = width2 - ((LinearLayout.LayoutParams) oVar2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i22 = i11 - (measuredHeight3 / 2);
                    childAt3.layout(i21 - measuredWidth3, i22, i21, measuredHeight3 + i22);
                    width2 = i21 - ((measuredWidth3 + ((LinearLayout.LayoutParams) oVar2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i23 = 0; i23 < childCount; i23++) {
            View childAt4 = getChildAt(i23);
            o oVar3 = (o) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !oVar3.f868a) {
                int i24 = paddingLeft2 + ((LinearLayout.LayoutParams) oVar3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i25 = i11 - (measuredHeight4 / 2);
                childAt4.layout(i24, i25, i24 + measuredWidth4, measuredHeight4 + i25);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) oVar3).rightMargin + iMax + i24;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v41 */
    @Override // androidx.appcompat.widget.x1, android.view.View
    public final void onMeasure(int i7, int i8) {
        int i9;
        int i10;
        ?? r11;
        int i11;
        int i12;
        g.l lVar;
        boolean z6 = this.f644v;
        boolean z7 = View.MeasureSpec.getMode(i7) == 1073741824;
        this.f644v = z7;
        if (z6 != z7) {
            this.f645w = 0;
        }
        int size = View.MeasureSpec.getSize(i7);
        if (this.f644v && (lVar = this.f638p) != null && size != this.f645w) {
            this.f645w = size;
            lVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f644v || childCount <= 0) {
            for (int i13 = 0; i13 < childCount; i13++) {
                o oVar = (o) getChildAt(i13).getLayoutParams();
                ((LinearLayout.LayoutParams) oVar).rightMargin = 0;
                ((LinearLayout.LayoutParams) oVar).leftMargin = 0;
            }
            super.onMeasure(i7, i8);
            return;
        }
        int mode = View.MeasureSpec.getMode(i8);
        int size2 = View.MeasureSpec.getSize(i7);
        int size3 = View.MeasureSpec.getSize(i8);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i8, paddingBottom, -2);
        int i14 = size2 - paddingRight;
        int i15 = this.f646x;
        int i16 = i14 / i15;
        int i17 = i14 % i15;
        if (i16 == 0) {
            setMeasuredDimension(i14, 0);
            return;
        }
        int i18 = (i17 / i16) + i15;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i19 = 0;
        int iMax2 = 0;
        int i20 = 0;
        boolean z8 = false;
        int i21 = 0;
        long j7 = 0;
        while (true) {
            i9 = this.f647y;
            if (i20 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i20);
            int i22 = size3;
            int i23 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i11 = i18;
            } else {
                boolean z9 = childAt instanceof ActionMenuItemView;
                i19++;
                if (z9) {
                    childAt.setPadding(i9, 0, i9, 0);
                }
                o oVar2 = (o) childAt.getLayoutParams();
                oVar2.f871f = false;
                oVar2.f869c = 0;
                oVar2.b = 0;
                oVar2.f870d = false;
                ((LinearLayout.LayoutParams) oVar2).leftMargin = 0;
                ((LinearLayout.LayoutParams) oVar2).rightMargin = 0;
                oVar2.e = z9 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i24 = oVar2.f868a ? 1 : i16;
                o oVar3 = (o) childAt.getLayoutParams();
                int i25 = i16;
                i11 = i18;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i23, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z9 ? (ActionMenuItemView) childAt : null;
                boolean z10 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z11 = z10;
                if (i24 <= 0 || (z10 && i24 < 2)) {
                    i12 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i11 * i24, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i12 = measuredWidth / i11;
                    if (measuredWidth % i11 != 0) {
                        i12++;
                    }
                    if (z11 && i12 < 2) {
                        i12 = 2;
                    }
                }
                oVar3.f870d = !oVar3.f868a && z11;
                oVar3.b = i12;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i12 * i11, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i12);
                if (oVar2.f870d) {
                    i21++;
                }
                if (oVar2.f868a) {
                    z8 = true;
                }
                i16 = i25 - i12;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i12 == 1) {
                    j7 |= (long) (1 << i20);
                }
            }
            i20++;
            size3 = i22;
            paddingBottom = i23;
            i18 = i11;
        }
        int i26 = size3;
        int i27 = i16;
        int i28 = i18;
        boolean z12 = z8 && i19 == 2;
        int i29 = i27;
        boolean z13 = false;
        while (i21 > 0 && i29 > 0) {
            int i30 = Integer.MAX_VALUE;
            long j8 = 0;
            int i31 = 0;
            int i32 = 0;
            while (i32 < childCount2) {
                int i33 = iMax;
                o oVar4 = (o) getChildAt(i32).getLayoutParams();
                boolean z14 = z12;
                if (oVar4.f870d) {
                    int i34 = oVar4.b;
                    if (i34 < i30) {
                        j8 = 1 << i32;
                        i30 = i34;
                        i31 = 1;
                    } else if (i34 == i30) {
                        j8 |= 1 << i32;
                        i31++;
                    }
                }
                i32++;
                z12 = z14;
                iMax = i33;
            }
            i10 = iMax;
            boolean z15 = z12;
            j7 |= j8;
            if (i31 > i29) {
                break;
            }
            int i35 = i30 + 1;
            int i36 = 0;
            while (i36 < childCount2) {
                View childAt2 = getChildAt(i36);
                o oVar5 = (o) childAt2.getLayoutParams();
                boolean z16 = z8;
                long j9 = 1 << i36;
                if ((j8 & j9) != 0) {
                    if (z15 && oVar5.e) {
                        r11 = 1;
                        r11 = 1;
                        if (i29 == 1) {
                            childAt2.setPadding(i9 + i28, 0, i9, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    oVar5.b += r11;
                    oVar5.f871f = r11;
                    i29--;
                } else if (oVar5.b == i35) {
                    j7 |= j9;
                }
                i36++;
                z8 = z16;
            }
            z12 = z15;
            iMax = i10;
            z13 = true;
        }
        i10 = iMax;
        boolean z17 = !z8 && i19 == 1;
        if (i29 > 0 && j7 != 0 && (i29 < i19 - 1 || z17 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j7);
            if (!z17) {
                if ((j7 & 1) != 0 && !((o) getChildAt(0).getLayoutParams()).e) {
                    fBitCount -= 0.5f;
                }
                int i37 = childCount2 - 1;
                if ((j7 & ((long) (1 << i37))) != 0 && !((o) getChildAt(i37).getLayoutParams()).e) {
                    fBitCount -= 0.5f;
                }
            }
            int i38 = fBitCount > 0.0f ? (int) ((i29 * i28) / fBitCount) : 0;
            boolean z18 = z13;
            for (int i39 = 0; i39 < childCount2; i39++) {
                if ((j7 & ((long) (1 << i39))) != 0) {
                    View childAt3 = getChildAt(i39);
                    o oVar6 = (o) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        oVar6.f869c = i38;
                        oVar6.f871f = true;
                        if (i39 == 0 && !oVar6.e) {
                            ((LinearLayout.LayoutParams) oVar6).leftMargin = (-i38) / 2;
                        }
                        z18 = true;
                    } else if (oVar6.f868a) {
                        oVar6.f869c = i38;
                        oVar6.f871f = true;
                        ((LinearLayout.LayoutParams) oVar6).rightMargin = (-i38) / 2;
                        z18 = true;
                    } else {
                        if (i39 != 0) {
                            ((LinearLayout.LayoutParams) oVar6).leftMargin = i38 / 2;
                        }
                        if (i39 != childCount2 - 1) {
                            ((LinearLayout.LayoutParams) oVar6).rightMargin = i38 / 2;
                        }
                    }
                }
            }
            z13 = z18;
        }
        if (z13) {
            for (int i40 = 0; i40 < childCount2; i40++) {
                View childAt4 = getChildAt(i40);
                o oVar7 = (o) childAt4.getLayoutParams();
                if (oVar7.f871f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((oVar7.b * i28) + oVar7.f869c, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i14, mode != 1073741824 ? i10 : i26);
    }

    public void setExpandedActionViewsExclusive(boolean z6) {
        this.f642t.f848r = z6;
    }

    public void setOnMenuItemClickListener(p pVar) {
        this.f648z = pVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        l lVar = this.f642t;
        j jVar = lVar.f840j;
        if (jVar != null) {
            jVar.setImageDrawable(drawable);
        } else {
            lVar.f842l = true;
            lVar.f841k = drawable;
        }
    }

    public void setOverflowReserved(boolean z6) {
        this.f641s = z6;
    }

    public void setPopupTheme(int i7) {
        if (this.f640r != i7) {
            this.f640r = i7;
            if (i7 == 0) {
                this.f639q = getContext();
            } else {
                this.f639q = new ContextThemeWrapper(getContext(), i7);
            }
        }
    }

    public void setPresenter(l lVar) {
        this.f642t = lVar;
        lVar.f838h = this;
        this.f638p = lVar.f834c;
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }
}
