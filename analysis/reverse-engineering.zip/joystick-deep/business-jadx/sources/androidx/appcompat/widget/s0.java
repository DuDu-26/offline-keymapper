package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class s0 implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f900a;
    public final /* synthetic */ Object b;

    public /* synthetic */ s0(int i7, Object obj) {
        this.f900a = i7;
        this.b = obj;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i7, long j7) {
        switch (this.f900a) {
            case 0:
                u0 u0Var = (u0) this.b;
                w0 w0Var = u0Var.G;
                w0Var.setSelection(i7);
                if (w0Var.getOnItemClickListener() != null) {
                    w0Var.performItemClick(view, i7, u0Var.D.getItemId(i7));
                }
                u0Var.dismiss();
                break;
            case 1:
                ((SearchView) this.b).n(i7);
                break;
            default:
                com.google.android.material.textfield.u uVar = (com.google.android.material.textfield.u) this.b;
                f2 f2Var = uVar.e;
                com.google.android.material.textfield.u.a(uVar, i7 < 0 ? !f2Var.f774z.isShowing() ? null : f2Var.f752c.getSelectedItem() : uVar.getAdapter().getItem(i7));
                AdapterView.OnItemClickListener onItemClickListener = uVar.getOnItemClickListener();
                if (onItemClickListener != null) {
                    if (view == null || i7 < 0) {
                        view = !f2Var.f774z.isShowing() ? null : f2Var.f752c.getSelectedView();
                        i7 = !f2Var.f774z.isShowing() ? -1 : f2Var.f752c.getSelectedItemPosition();
                        j7 = !f2Var.f774z.isShowing() ? Long.MIN_VALUE : f2Var.f752c.getSelectedItemId();
                    }
                    onItemClickListener.onItemClick(f2Var.f752c, view, i7, j7);
                }
                f2Var.dismiss();
                break;
        }
    }
}
