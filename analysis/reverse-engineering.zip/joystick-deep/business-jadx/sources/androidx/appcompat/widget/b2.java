package androidx.appcompat.widget;

import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b2 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f716a;
    public final /* synthetic */ f2 b;

    public /* synthetic */ b2(f2 f2Var, int i7) {
        this.f716a = i7;
        this.b = f2Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i7 = this.f716a;
        f2 f2Var = this.b;
        switch (i7) {
            case 0:
                s1 s1Var = f2Var.f752c;
                if (s1Var != null) {
                    s1Var.setListSelectionHidden(true);
                    s1Var.requestLayout();
                }
                break;
            default:
                s1 s1Var2 = f2Var.f752c;
                if (s1Var2 != null) {
                    WeakHashMap weakHashMap = f0.s0.f5582a;
                    if (f0.e0.b(s1Var2) && f2Var.f752c.getCount() > f2Var.f752c.getChildCount() && f2Var.f752c.getChildCount() <= f2Var.f761m) {
                        f2Var.f774z.setInputMethodMode(2);
                        f2Var.c();
                        break;
                    }
                }
                break;
        }
    }
}
