package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import androidx.customview.view.AbsSavedState;
import com.umeng.analytics.pro.bc;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class SearchView extends x1 implements f.b {

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public static final y2.e f659g0;
    public final Rect A;
    public final int[] B;
    public final int[] C;
    public final ImageView D;
    public final Drawable E;
    public final int F;
    public final int G;
    public final Intent H;
    public final Intent I;
    public final CharSequence J;
    public View.OnFocusChangeListener K;
    public View.OnClickListener L;
    public boolean M;
    public boolean N;
    public j0.b O;
    public boolean P;
    public CharSequence Q;
    public boolean R;
    public boolean S;
    public int T;
    public boolean U;
    public CharSequence V;
    public boolean W;
    public int a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public SearchableInfo f660b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public Bundle f661c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final s2 f662d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final s2 f663e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final WeakHashMap f664f0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final SearchAutoComplete f665p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final View f666q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final View f667r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final View f668s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final ImageView f669t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final ImageView f670u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final ImageView f671v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final ImageView f672w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final View f673x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public e3 f674y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final Rect f675z;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new c3();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f676c;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f676c = ((Boolean) parcel.readValue(null)).booleanValue();
        }

        public final String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.f676c + "}";
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i7) {
            super.writeToParcel(parcel, i7);
            parcel.writeValue(Boolean.valueOf(this.f676c));
        }
    }

    public static class SearchAutoComplete extends q {
        public int e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public SearchView f677f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public boolean f678g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public final d3 f679h;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f679h = new d3(this);
            this.e = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i7 = configuration.screenWidthDp;
            int i8 = configuration.screenHeightDp;
            if (i7 >= 960 && i8 >= 720 && configuration.orientation == 2) {
                return bc.e;
            }
            if (i7 < 600) {
                return (i7 < 640 || i8 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                y2.b(this, 1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            y2.e eVar = SearchView.f659g0;
            eVar.getClass();
            y2.e.B();
            Method method = (Method) eVar.f8966d;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.e <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.q, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f678g) {
                d3 d3Var = this.f679h;
                removeCallbacks(d3Var);
                post(d3Var);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z6, int i7, Rect rect) {
            super.onFocusChanged(z6, i7, rect);
            SearchView searchView = this.f677f;
            searchView.w(searchView.N);
            searchView.post(searchView.f662d0);
            if (searchView.f665p.hasFocus()) {
                searchView.l();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i7, KeyEvent keyEvent) {
            if (i7 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f677f.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i7, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z6) {
            super.onWindowFocusChanged(z6);
            if (z6 && this.f677f.hasFocus() && getVisibility() == 0) {
                this.f678g = true;
                Context context = getContext();
                y2.e eVar = SearchView.f659g0;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z6) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            d3 d3Var = this.f679h;
            if (!z6) {
                this.f678g = false;
                removeCallbacks(d3Var);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f678g = true;
                    return;
                }
                this.f678g = false;
                removeCallbacks(d3Var);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f677f = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i7) {
            super.setThreshold(i7);
            this.e = i7;
        }
    }

    static {
        y2.e eVar = null;
        if (Build.VERSION.SDK_INT < 29) {
            y2.e eVar2 = new y2.e(4, false);
            eVar2.b = null;
            eVar2.f8965c = null;
            eVar2.f8966d = null;
            y2.e.B();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                eVar2.b = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                eVar2.f8965c = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                eVar2.f8966d = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            eVar = eVar2;
        }
        f659g0 = eVar;
    }

    public SearchView(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        this.f675z = new Rect();
        this.A = new Rect();
        this.B = new int[2];
        this.C = new int[2];
        this.f662d0 = new s2(this, 0);
        this.f663e0 = new s2(this, 1);
        this.f664f0 = new WeakHashMap();
        v2 v2Var = new v2(this);
        w2 w2Var = new w2(this);
        x2 x2Var = new x2(this);
        s0 s0Var = new s0(1, this);
        y1 y1Var = new y1(1, this);
        r2 r2Var = new r2(this, 0);
        int[] iArr = d.a.f5221u;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i7, 0);
        y2.e eVar = new y2.e(context, typedArrayObtainStyledAttributes);
        f0.s0.i(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i7);
        LayoutInflater.from(context).inflate(typedArrayObtainStyledAttributes.getResourceId(19, 2131492889), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(2131296695);
        this.f665p = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f666q = findViewById(2131296691);
        View viewFindViewById = findViewById(2131296694);
        this.f667r = viewFindViewById;
        View viewFindViewById2 = findViewById(2131296741);
        this.f668s = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(2131296689);
        this.f669t = imageView;
        ImageView imageView2 = (ImageView) findViewById(2131296692);
        this.f670u = imageView2;
        ImageView imageView3 = (ImageView) findViewById(2131296690);
        this.f671v = imageView3;
        ImageView imageView4 = (ImageView) findViewById(2131296696);
        this.f672w = imageView4;
        ImageView imageView5 = (ImageView) findViewById(2131296693);
        this.D = imageView5;
        f0.b0.q(viewFindViewById, eVar.o(20));
        f0.b0.q(viewFindViewById2, eVar.o(25));
        imageView.setImageDrawable(eVar.o(23));
        imageView2.setImageDrawable(eVar.o(15));
        imageView3.setImageDrawable(eVar.o(12));
        imageView4.setImageDrawable(eVar.o(28));
        imageView5.setImageDrawable(eVar.o(23));
        this.E = eVar.o(22);
        w3.a(imageView, getResources().getString(2131820565));
        this.F = typedArrayObtainStyledAttributes.getResourceId(26, 2131492888);
        this.G = typedArrayObtainStyledAttributes.getResourceId(13, 0);
        imageView.setOnClickListener(v2Var);
        imageView3.setOnClickListener(v2Var);
        imageView2.setOnClickListener(v2Var);
        imageView4.setOnClickListener(v2Var);
        searchAutoComplete.setOnClickListener(v2Var);
        searchAutoComplete.addTextChangedListener(r2Var);
        searchAutoComplete.setOnEditorActionListener(x2Var);
        searchAutoComplete.setOnItemClickListener(s0Var);
        searchAutoComplete.setOnItemSelectedListener(y1Var);
        searchAutoComplete.setOnKeyListener(w2Var);
        searchAutoComplete.setOnFocusChangeListener(new t2(this));
        setIconifiedByDefault(typedArrayObtainStyledAttributes.getBoolean(18, true));
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(2, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.J = typedArrayObtainStyledAttributes.getText(14);
        this.Q = typedArrayObtainStyledAttributes.getText(21);
        int i8 = typedArrayObtainStyledAttributes.getInt(6, -1);
        if (i8 != -1) {
            setImeOptions(i8);
        }
        int i9 = typedArrayObtainStyledAttributes.getInt(5, -1);
        if (i9 != -1) {
            setInputType(i9);
        }
        setFocusable(typedArrayObtainStyledAttributes.getBoolean(1, true));
        eVar.C();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.H = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.I = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f673x = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new u2(0, this));
        }
        w(this.M);
        t();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(2131165238);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(2131165239);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f665p;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.S = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f665p;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.S = false;
    }

    public int getImeOptions() {
        return this.f665p.getImeOptions();
    }

    public int getInputType() {
        return this.f665p.getInputType();
    }

    public int getMaxWidth() {
        return this.T;
    }

    public CharSequence getQuery() {
        return this.f665p.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.Q;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f660b0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.J : getContext().getText(this.f660b0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.G;
    }

    public int getSuggestionRowLayout() {
        return this.F;
    }

    public j0.b getSuggestionsAdapter() {
        return this.O;
    }

    public final Intent j(String str, Uri uri, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.V);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f661c0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f660b0.getSearchActivity());
        return intent;
    }

    public final Intent k(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f661c0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void l() {
        int i7 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f665p;
        if (i7 >= 29) {
            y2.a(searchAutoComplete);
            return;
        }
        y2.e eVar = f659g0;
        eVar.getClass();
        y2.e.B();
        Method method = (Method) eVar.b;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        eVar.getClass();
        y2.e.B();
        Method method2 = (Method) eVar.f8965c;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void m() {
        SearchAutoComplete searchAutoComplete = this.f665p;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText("");
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.M) {
            clearFocus();
            w(true);
        }
    }

    public final void n(int i7) {
        String strH;
        Cursor cursor = this.O.f6353c;
        if (cursor != null && cursor.moveToPosition(i7)) {
            Intent intentJ = null;
            try {
                try {
                    int i8 = h3.f785x;
                    String strH2 = h3.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                    if (strH2 == null) {
                        strH2 = this.f660b0.getSuggestIntentAction();
                    }
                    if (strH2 == null) {
                        strH2 = "android.intent.action.SEARCH";
                    }
                    String strH3 = h3.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                    if (strH3 == null) {
                        strH3 = this.f660b0.getSuggestIntentData();
                    }
                    if (strH3 != null && (strH = h3.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                        strH3 = strH3 + "/" + Uri.encode(strH);
                    }
                    intentJ = j(strH2, strH3 == null ? null : Uri.parse(strH3), h3.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), h3.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
                } catch (RuntimeException unused) {
                }
            } catch (RuntimeException unused2) {
                cursor.getPosition();
            }
            if (intentJ != null) {
                try {
                    getContext().startActivity(intentJ);
                } catch (RuntimeException e) {
                    Log.e("SearchView", "Failed launch activity: " + intentJ, e);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f665p;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void o(int i7) {
        Editable text = this.f665p.getText();
        Cursor cursor = this.O.f6353c;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i7)) {
            setQuery(text);
            return;
        }
        String strC = this.O.c(cursor);
        if (strC != null) {
            setQuery(strC);
        } else {
            setQuery(text);
        }
    }

    @Override // f.b
    public final void onActionViewCollapsed() {
        SearchAutoComplete searchAutoComplete = this.f665p;
        searchAutoComplete.setText("");
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.V = "";
        clearFocus();
        w(true);
        searchAutoComplete.setImeOptions(this.a0);
        this.W = false;
    }

    @Override // f.b
    public final void onActionViewExpanded() {
        if (this.W) {
            return;
        }
        this.W = true;
        SearchAutoComplete searchAutoComplete = this.f665p;
        int imeOptions = searchAutoComplete.getImeOptions();
        this.a0 = imeOptions;
        searchAutoComplete.setImeOptions(imeOptions | 33554432);
        searchAutoComplete.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.f662d0);
        post(this.f663e0);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.x1, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        super.onLayout(z6, i7, i8, i9, i10);
        if (z6) {
            SearchAutoComplete searchAutoComplete = this.f665p;
            int[] iArr = this.B;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.C;
            getLocationInWindow(iArr2);
            int i11 = iArr[1] - iArr2[1];
            int i12 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i12;
            int height = searchAutoComplete.getHeight() + i11;
            Rect rect = this.f675z;
            rect.set(i12, i11, width, height);
            int i13 = rect.left;
            int i14 = rect.right;
            int i15 = i10 - i8;
            Rect rect2 = this.A;
            rect2.set(i13, 0, i14, i15);
            e3 e3Var = this.f674y;
            if (e3Var == null) {
                e3 e3Var2 = new e3(rect2, rect, searchAutoComplete);
                this.f674y = e3Var2;
                setTouchDelegate(e3Var2);
            } else {
                e3Var.b.set(rect2);
                Rect rect3 = e3Var.f744d;
                rect3.set(rect2);
                int i16 = -e3Var.e;
                rect3.inset(i16, i16);
                e3Var.f743c.set(rect);
            }
        }
    }

    @Override // androidx.appcompat.widget.x1, android.view.View
    public final void onMeasure(int i7, int i8) {
        int i9;
        if (this.N) {
            super.onMeasure(i7, i8);
            return;
        }
        int mode = View.MeasureSpec.getMode(i7);
        int size = View.MeasureSpec.getSize(i7);
        if (mode == Integer.MIN_VALUE) {
            int i10 = this.T;
            size = i10 > 0 ? Math.min(i10, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.T;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i9 = this.T) > 0) {
            size = Math.min(i9, size);
        }
        int mode2 = View.MeasureSpec.getMode(i8);
        int size2 = View.MeasureSpec.getSize(i8);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1099a);
        w(savedState.f676c);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f676c = this.N;
        return savedState;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z6) {
        super.onWindowFocusChanged(z6);
        post(this.f662d0);
    }

    public final void p(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public final void q() {
        SearchAutoComplete searchAutoComplete = this.f665p;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f660b0 != null) {
            getContext().startActivity(j("android.intent.action.SEARCH", null, null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void r() {
        boolean zIsEmpty = TextUtils.isEmpty(this.f665p.getText());
        int i7 = (!zIsEmpty || (this.M && !this.W)) ? 0 : 8;
        ImageView imageView = this.f671v;
        imageView.setVisibility(i7);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(!zIsEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i7, Rect rect) {
        if (this.S || !isFocusable()) {
            return false;
        }
        if (this.N) {
            return super.requestFocus(i7, rect);
        }
        boolean zRequestFocus = this.f665p.requestFocus(i7, rect);
        if (zRequestFocus) {
            w(false);
        }
        return zRequestFocus;
    }

    public final void s() {
        int[] iArr = this.f665p.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f667r.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f668s.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public void setAppSearchData(Bundle bundle) {
        this.f661c0 = bundle;
    }

    public void setIconified(boolean z6) {
        if (z6) {
            m();
            return;
        }
        w(false);
        SearchAutoComplete searchAutoComplete = this.f665p;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.L;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z6) {
        if (this.M == z6) {
            return;
        }
        this.M = z6;
        w(z6);
        t();
    }

    public void setImeOptions(int i7) {
        this.f665p.setImeOptions(i7);
    }

    public void setInputType(int i7) {
        this.f665p.setInputType(i7);
    }

    public void setMaxWidth(int i7) {
        this.T = i7;
        requestLayout();
    }

    public void setOnCloseListener(z2 z2Var) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.K = onFocusChangeListener;
    }

    public void setOnQueryTextListener(a3 a3Var) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.L = onClickListener;
    }

    public void setOnSuggestionListener(b3 b3Var) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.Q = charSequence;
        t();
    }

    public void setQueryRefinementEnabled(boolean z6) {
        this.R = z6;
        j0.b bVar = this.O;
        if (bVar instanceof h3) {
            ((h3) bVar).f794p = z6 ? 2 : 1;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0098  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.f660b0 = r7
            r0 = 0
            r1 = 1
            androidx.appcompat.widget.SearchView$SearchAutoComplete r2 = r6.f665p
            if (r7 == 0) goto L65
            int r7 = r7.getSuggestThreshold()
            r2.setThreshold(r7)
            android.app.SearchableInfo r7 = r6.f660b0
            int r7 = r7.getImeOptions()
            r2.setImeOptions(r7)
            android.app.SearchableInfo r7 = r6.f660b0
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r1) goto L31
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.f660b0
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L31
            r3 = 589824(0x90000, float:8.2652E-40)
            r7 = r7 | r3
        L31:
            r2.setInputType(r7)
            j0.b r7 = r6.O
            if (r7 == 0) goto L3b
            r7.b(r0)
        L3b:
            android.app.SearchableInfo r7 = r6.f660b0
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L62
            androidx.appcompat.widget.h3 r7 = new androidx.appcompat.widget.h3
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.f660b0
            java.util.WeakHashMap r5 = r6.f664f0
            r7.<init>(r3, r6, r4, r5)
            r6.O = r7
            r2.setAdapter(r7)
            j0.b r7 = r6.O
            androidx.appcompat.widget.h3 r7 = (androidx.appcompat.widget.h3) r7
            boolean r3 = r6.R
            if (r3 == 0) goto L5f
            r3 = 2
            goto L60
        L5f:
            r3 = r1
        L60:
            r7.f794p = r3
        L62:
            r6.t()
        L65:
            android.app.SearchableInfo r7 = r6.f660b0
            r3 = 0
            if (r7 == 0) goto L98
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L98
            android.app.SearchableInfo r7 = r6.f660b0
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L7b
            android.content.Intent r0 = r6.H
            goto L85
        L7b:
            android.app.SearchableInfo r7 = r6.f660b0
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L85
            android.content.Intent r0 = r6.I
        L85:
            if (r0 == 0) goto L98
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            r4 = 65536(0x10000, float:9.18355E-41)
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r0, r4)
            if (r7 == 0) goto L98
            goto L99
        L98:
            r1 = r3
        L99:
            r6.U = r1
            if (r1 == 0) goto La2
            java.lang.String r7 = "nm"
            r2.setPrivateImeOptions(r7)
        La2:
            boolean r7 = r6.N
            r6.w(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z6) {
        this.P = z6;
        w(this.N);
    }

    public void setSuggestionsAdapter(j0.b bVar) {
        this.O = bVar;
        this.f665p.setAdapter(bVar);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void t() {
        CharSequence queryHint = getQueryHint();
        CharSequence charSequence = queryHint;
        if (queryHint == null) {
            charSequence = "";
        }
        boolean z6 = this.M;
        SearchAutoComplete searchAutoComplete = this.f665p;
        CharSequence charSequence2 = charSequence;
        if (z6) {
            Drawable drawable = this.E;
            charSequence2 = charSequence;
            if (drawable != null) {
                int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
                drawable.setBounds(0, 0, textSize, textSize);
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
                spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
                spannableStringBuilder.append(charSequence);
                charSequence2 = spannableStringBuilder;
            }
        }
        searchAutoComplete.setHint(charSequence2);
    }

    public final void u() {
        this.f668s.setVisibility(((this.P || this.U) && !this.N && (this.f670u.getVisibility() == 0 || this.f672w.getVisibility() == 0)) ? 0 : 8);
    }

    public final void v(boolean z6) {
        boolean z7 = this.P;
        this.f670u.setVisibility((!z7 || !(z7 || this.U) || this.N || !hasFocus() || (!z6 && this.U)) ? 8 : 0);
    }

    public final void w(boolean z6) {
        this.N = z6;
        int i7 = 8;
        int i8 = z6 ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.f665p.getText());
        this.f669t.setVisibility(i8);
        v(!zIsEmpty);
        this.f666q.setVisibility(z6 ? 8 : 0);
        ImageView imageView = this.D;
        imageView.setVisibility((imageView.getDrawable() == null || this.M) ? 8 : 0);
        r();
        if (this.U && !this.N && zIsEmpty) {
            this.f670u.setVisibility(8);
            i7 = 0;
        }
        this.f672w.setVisibility(i7);
        u();
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130969513);
    }

    public SearchView(Context context) {
        this(context, null);
    }
}
