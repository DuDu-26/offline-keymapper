package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n implements g.x {
    @Override // g.x
    public final void d(g.l lVar, boolean z6) {
    }

    @Override // g.x
    public final boolean m(g.l lVar) {
        return false;
    }
}
