package androidx.appcompat.widget;

import android.view.MenuItem;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public interface g2 {
    void f(g.l lVar, g.n nVar);

    void g(g.l lVar, MenuItem menuItem);
}
