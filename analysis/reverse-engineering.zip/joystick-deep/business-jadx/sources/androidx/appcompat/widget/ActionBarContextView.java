package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a3.i f595a;
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionMenuView f596c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public l f597d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public f0.x0 f598f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f599g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f600h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f601i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f602j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f603k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f604l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f605m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public LinearLayout f606n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public TextView f607o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public TextView f608p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f609q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f610r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f611s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f612t;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, 2130968606);
        this.f595a = new a3.i(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(2130968580, typedValue, true) || typedValue.resourceId == 0) {
            this.b = context;
        } else {
            this.b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, d.a.f5205d, 2130968606, 0);
        Drawable drawable = (!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : a5.h.E(context, resourceId);
        WeakHashMap weakHashMap = f0.s0.f5582a;
        f0.b0.q(this, drawable);
        this.f609q = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f610r = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f612t = typedArrayObtainStyledAttributes.getResourceId(2, 2131492869);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static /* synthetic */ void a(ActionBarContextView actionBarContextView) {
        super.setVisibility(0);
    }

    public static /* synthetic */ void b(ActionBarContextView actionBarContextView, int i7) {
        super.setVisibility(i7);
    }

    public static int f(View view, int i7, int i8) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i7, Integer.MIN_VALUE), i8);
        return Math.max(0, i7 - view.getMeasuredWidth());
    }

    public static int g(View view, int i7, int i8, int i9, boolean z6) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i10 = ((i9 - measuredHeight) / 2) + i8;
        if (z6) {
            view.layout(i7 - measuredWidth, i10, i7, measuredHeight + i10);
        } else {
            view.layout(i7, i10, i7 + measuredWidth, measuredHeight + i10);
        }
        return z6 ? -measuredWidth : measuredWidth;
    }

    public final void c(f.a aVar) {
        View view = this.f603k;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f612t, (ViewGroup) this, false);
            this.f603k = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f603k);
        }
        View viewFindViewById = this.f603k.findViewById(2131296323);
        this.f604l = viewFindViewById;
        viewFindViewById.setOnClickListener(new androidx.appcompat.app.a(1, aVar));
        g.l lVarC = aVar.c();
        l lVar = this.f597d;
        if (lVar != null) {
            lVar.c();
            f fVar = lVar.f851u;
            if (fVar != null && fVar.b()) {
                fVar.f5820i.dismiss();
            }
        }
        l lVar2 = new l(getContext());
        this.f597d = lVar2;
        lVar2.f843m = true;
        lVar2.f844n = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        lVarC.b(this.f597d, this.b);
        l lVar3 = this.f597d;
        g.a0 a0Var = lVar3.f838h;
        if (a0Var == null) {
            g.a0 a0Var2 = (g.a0) lVar3.f835d.inflate(lVar3.f836f, (ViewGroup) this, false);
            lVar3.f838h = a0Var2;
            a0Var2.c(lVar3.f834c);
            lVar3.i(true);
        }
        g.a0 a0Var3 = lVar3.f838h;
        if (a0Var != a0Var3) {
            ((ActionMenuView) a0Var3).setPresenter(lVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) a0Var3;
        this.f596c = actionMenuView;
        WeakHashMap weakHashMap = f0.s0.f5582a;
        f0.b0.q(actionMenuView, null);
        addView(this.f596c, layoutParams);
    }

    public final void d() {
        if (this.f606n == null) {
            LayoutInflater.from(getContext()).inflate(2131492864, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f606n = linearLayout;
            this.f607o = (TextView) linearLayout.findViewById(2131296314);
            this.f608p = (TextView) this.f606n.findViewById(2131296313);
            int i7 = this.f609q;
            if (i7 != 0) {
                this.f607o.setTextAppearance(getContext(), i7);
            }
            int i8 = this.f610r;
            if (i8 != 0) {
                this.f608p.setTextAppearance(getContext(), i8);
            }
        }
        this.f607o.setText(this.f601i);
        this.f608p.setText(this.f602j);
        boolean zIsEmpty = TextUtils.isEmpty(this.f601i);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f602j);
        this.f608p.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f606n.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f606n.getParent() == null) {
            addView(this.f606n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f605m = null;
        this.f596c = null;
        this.f597d = null;
        View view = this.f604l;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f598f != null ? this.f595a.b : getVisibility();
    }

    public int getContentHeight() {
        return this.e;
    }

    public CharSequence getSubtitle() {
        return this.f602j;
    }

    public CharSequence getTitle() {
        return this.f601i;
    }

    public final void h(int i7) {
        if (i7 != getVisibility()) {
            f0.x0 x0Var = this.f598f;
            if (x0Var != null) {
                x0Var.b();
            }
            super.setVisibility(i7);
        }
    }

    public final f0.x0 i(int i7, long j7) {
        f0.x0 x0Var = this.f598f;
        if (x0Var != null) {
            x0Var.b();
        }
        a3.i iVar = this.f595a;
        if (i7 != 0) {
            f0.x0 x0VarA = f0.s0.a(this);
            x0VarA.a(0.0f);
            x0VarA.c(j7);
            ((ActionBarContextView) iVar.f26c).f598f = x0VarA;
            iVar.b = i7;
            x0VarA.d(iVar);
            return x0VarA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        f0.x0 x0VarA2 = f0.s0.a(this);
        x0VarA2.a(1.0f);
        x0VarA2.c(j7);
        ((ActionBarContextView) iVar.f26c).f598f = x0VarA2;
        iVar.b = i7;
        x0VarA2.d(iVar);
        return x0VarA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, d.a.f5203a, 2130968583, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        l lVar = this.f597d;
        if (lVar != null) {
            Configuration configuration2 = lVar.b.getResources().getConfiguration();
            int i7 = configuration2.screenWidthDp;
            int i8 = configuration2.screenHeightDp;
            lVar.f847q = (configuration2.smallestScreenWidthDp > 600 || i7 > 600 || (i7 > 960 && i8 > 720) || (i7 > 720 && i8 > 960)) ? 5 : (i7 >= 500 || (i7 > 640 && i8 > 480) || (i7 > 480 && i8 > 640)) ? 4 : i7 >= 360 ? 3 : 2;
            g.l lVar2 = lVar.f834c;
            if (lVar2 != null) {
                lVar2.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l lVar = this.f597d;
        if (lVar != null) {
            lVar.c();
            f fVar = this.f597d.f851u;
            if (fVar == null || !fVar.b()) {
                return;
            }
            fVar.f5820i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f600h = false;
        }
        if (!this.f600h) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f600h = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f600h = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        boolean zA = z3.a(this);
        int paddingRight = zA ? (i9 - i7) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i10 - i8) - getPaddingTop()) - getPaddingBottom();
        View view = this.f603k;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f603k.getLayoutParams();
            int i11 = zA ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i12 = zA ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i13 = zA ? paddingRight - i11 : paddingRight + i11;
            int iG = g(this.f603k, i13, paddingTop, paddingTop2, zA) + i13;
            paddingRight = zA ? iG - i12 : iG + i12;
        }
        LinearLayout linearLayout = this.f606n;
        if (linearLayout != null && this.f605m == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(this.f606n, paddingRight, paddingTop, paddingTop2, zA);
        }
        View view2 = this.f605m;
        if (view2 != null) {
            g(view2, paddingRight, paddingTop, paddingTop2, zA);
        }
        int paddingLeft = zA ? getPaddingLeft() : (i9 - i7) - getPaddingRight();
        ActionMenuView actionMenuView = this.f596c;
        if (actionMenuView != null) {
            g(actionMenuView, paddingLeft, paddingTop, paddingTop2, !zA);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i7, int i8) {
        if (View.MeasureSpec.getMode(i7) != 1073741824) {
            f3.t(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
            return;
        }
        if (View.MeasureSpec.getMode(i8) == 0) {
            f3.t(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
            return;
        }
        int size = View.MeasureSpec.getSize(i7);
        int size2 = this.e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i8);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f603k;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f603k.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f596c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f596c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f606n;
        if (linearLayout != null && this.f605m == null) {
            if (this.f611s) {
                this.f606n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f606n.getMeasuredWidth();
                boolean z6 = measuredWidth <= paddingLeft;
                if (z6) {
                    paddingLeft -= measuredWidth;
                }
                this.f606n.setVisibility(z6 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f605m;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i9 = layoutParams.width;
            int i10 = i9 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i9 >= 0) {
                paddingLeft = Math.min(i9, paddingLeft);
            }
            int i11 = layoutParams.height;
            int i12 = i11 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i11 >= 0) {
                iMin = Math.min(i11, iMin);
            }
            this.f605m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i10), View.MeasureSpec.makeMeasureSpec(iMin, i12));
        }
        if (this.e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i13 = 0;
        for (int i14 = 0; i14 < childCount; i14++) {
            int measuredHeight = getChildAt(i14).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i13) {
                i13 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i13);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f599g = false;
        }
        if (!this.f599g) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f599g = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f599g = false;
        return true;
    }

    public void setContentHeight(int i7) {
        this.e = i7;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f605m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f605m = view;
        if (view != null && (linearLayout = this.f606n) != null) {
            removeView(linearLayout);
            this.f606n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f602j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f601i = charSequence;
        d();
        f0.s0.k(this, charSequence);
    }

    public void setTitleOptional(boolean z6) {
        if (z6 != this.f611s) {
            requestLayout();
        }
        this.f611s = z6;
    }

    @Override // android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i7) {
        h(i7);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
