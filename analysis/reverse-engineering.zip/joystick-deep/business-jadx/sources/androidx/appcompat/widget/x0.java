package androidx.appcompat.widget;

import android.graphics.Typeface;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class x0 extends w.b {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f962h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f963i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ WeakReference f964j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ c1 f965k;

    public x0(c1 c1Var, int i7, int i8, WeakReference weakReference) {
        this.f965k = c1Var;
        this.f962h = i7;
        this.f963i = i8;
        this.f964j = weakReference;
    }

    @Override // w.b
    public final void g(int i7) {
    }

    @Override // w.b
    public final void h(Typeface typeface) {
        int i7 = this.f962h;
        if (i7 != -1) {
            typeface = b1.a(typeface, i7, (this.f963i & 2) != 0);
        }
        c1 c1Var = this.f965k;
        if (c1Var.f730m) {
            c1Var.f729l = typeface;
            TextView textView = (TextView) this.f964j.get();
            if (textView != null) {
                WeakHashMap weakHashMap = f0.s0.f5582a;
                boolean zB = f0.e0.b(textView);
                int i8 = c1Var.f727j;
                if (zB) {
                    textView.post(new androidx.activity.h(textView, typeface, i8));
                } else {
                    textView.setTypeface(typeface, i8);
                }
            }
        }
    }
}
