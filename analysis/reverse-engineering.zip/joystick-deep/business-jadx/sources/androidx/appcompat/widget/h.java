package androidx.appcompat.widget;

import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f f783a;
    public final /* synthetic */ l b;

    public h(l lVar, f fVar) {
        this.b = lVar;
        this.f783a = fVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        g.j jVar;
        l lVar = this.b;
        g.l lVar2 = lVar.f834c;
        if (lVar2 != null && (jVar = lVar2.e) != null) {
            jVar.l(lVar2);
        }
        View view = (View) lVar.f838h;
        if (view != null && view.getWindowToken() != null) {
            f fVar = this.f783a;
            if (fVar.b()) {
                lVar.f850t = fVar;
            } else if (fVar.e != null) {
                fVar.d(0, 0, false, false);
                lVar.f850t = fVar;
            }
        }
        lVar.f852v = null;
    }
}
