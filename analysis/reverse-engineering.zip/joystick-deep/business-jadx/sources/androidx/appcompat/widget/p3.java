package androidx.appcompat.widget;

import android.content.Context;
import android.os.Parcelable;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.umeng.commonsdk.statistics.UMErrorCode;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p3 implements g.y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public g.l f881a;
    public g.n b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Toolbar f882c;

    public p3(Toolbar toolbar) {
        this.f882c = toolbar;
    }

    @Override // g.y
    public final void d(g.l lVar, boolean z6) {
    }

    @Override // g.y
    public final boolean e(g.n nVar) {
        Toolbar toolbar = this.f882c;
        toolbar.c();
        ViewParent parent = toolbar.f685h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f685h);
            }
            toolbar.addView(toolbar.f685h);
        }
        View actionView = nVar.getActionView();
        toolbar.f686i = actionView;
        this.b = nVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f686i);
            }
            q3 q3VarH = Toolbar.h();
            q3VarH.f890a = (toolbar.f691n & UMErrorCode.E_UM_BE_DEFLATE_FAILED) | 8388611;
            q3VarH.b = 2;
            toolbar.f686i.setLayoutParams(q3VarH);
            toolbar.addView(toolbar.f686i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((q3) childAt.getLayoutParams()).b != 2 && childAt != toolbar.f680a) {
                toolbar.removeViewAt(childCount);
                toolbar.E.add(childAt);
            }
        }
        toolbar.requestLayout();
        nVar.C = true;
        nVar.f5793n.p(false);
        KeyEvent.Callback callback = toolbar.f686i;
        if (callback instanceof f.b) {
            ((f.b) callback).onActionViewExpanded();
        }
        toolbar.u();
        return true;
    }

    @Override // g.y
    public final void f(Parcelable parcelable) {
    }

    @Override // g.y
    public final boolean g(g.n nVar) {
        Toolbar toolbar = this.f882c;
        KeyEvent.Callback callback = toolbar.f686i;
        if (callback instanceof f.b) {
            ((f.b) callback).onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.f686i);
        toolbar.removeView(toolbar.f685h);
        toolbar.f686i = null;
        ArrayList arrayList = toolbar.E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        nVar.C = false;
        nVar.f5793n.p(false);
        toolbar.u();
        return true;
    }

    @Override // g.y
    public final int getId() {
        return 0;
    }

    @Override // g.y
    public final void i(boolean z6) {
        if (this.b != null) {
            g.l lVar = this.f881a;
            if (lVar != null) {
                int size = lVar.f5761f.size();
                for (int i7 = 0; i7 < size; i7++) {
                    if (this.f881a.getItem(i7) == this.b) {
                        return;
                    }
                }
            }
            g(this.b);
        }
    }

    @Override // g.y
    public final boolean j(g.e0 e0Var) {
        return false;
    }

    @Override // g.y
    public final boolean k() {
        return false;
    }

    @Override // g.y
    public final Parcelable l() {
        return null;
    }

    @Override // g.y
    public final void m(Context context, g.l lVar) {
        g.n nVar;
        g.l lVar2 = this.f881a;
        if (lVar2 != null && (nVar = this.b) != null) {
            lVar2.d(nVar);
        }
        this.f881a = lVar;
    }
}
