package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h0 extends RatingBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f784a;

    public h0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969487);
        i3.a(this, getContext());
        f0 f0Var = new f0(this);
        this.f784a = f0Var;
        f0Var.b(attributeSet, 2130969487);
    }

    @Override // android.widget.RatingBar, android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onMeasure(int i7, int i8) {
        super.onMeasure(i7, i8);
        Bitmap bitmap = (Bitmap) this.f784a.f750c;
        if (bitmap != null) {
            setMeasuredDimension(View.resolveSizeAndState(bitmap.getWidth() * getNumStars(), i7, 0), getMeasuredHeight());
        }
    }
}
