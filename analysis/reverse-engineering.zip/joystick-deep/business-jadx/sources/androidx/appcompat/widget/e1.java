package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.PrecomputedText;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class e1 extends TextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r f737a;
    public final c1 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public z f738c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f739d;
    public f0 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Future f740f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e1(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        j3.a(context);
        this.f739d = false;
        this.e = null;
        i3.a(this, getContext());
        r rVar = new r(this);
        this.f737a = rVar;
        rVar.l(attributeSet, i7);
        c1 c1Var = new c1(this);
        this.b = c1Var;
        c1Var.f(attributeSet, i7);
        c1Var.b();
        getEmojiTextViewHelper().a(attributeSet, i7);
    }

    private z getEmojiTextViewHelper() {
        if (this.f738c == null) {
            this.f738c = new z(this);
        }
        return this.f738c;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f737a;
        if (rVar != null) {
            rVar.a();
        }
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        Method method = z3.f986a;
        return super.getAutoSizeMaxTextSize();
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        Method method = z3.f986a;
        return super.getAutoSizeMinTextSize();
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        Method method = z3.f986a;
        return super.getAutoSizeStepGranularity();
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        Method method = z3.f986a;
        return super.getAutoSizeTextAvailableSizes();
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        Method method = z3.f986a;
        return super.getAutoSizeTextType() == 1 ? 1 : 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return super.getCustomSelectionActionModeCallback();
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public d1 getSuperCaller() {
        if (this.e == null) {
            this.e = new f0(this);
        }
        return this.e;
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f737a;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f737a;
        if (rVar != null) {
            return rVar.j();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        Future future = this.f740f;
        if (future != null) {
            try {
                this.f740f = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                PrecomputedText.Params paramsB = androidx.core.widget.r.b(this);
                paramsB.getTextPaint();
                paramsB.getTextDirection();
                paramsB.getBreakStrategy();
                paramsB.getHyphenationFrequency();
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        return super.getTextClassifier();
    }

    public d0.d getTextMetricsParamsCompat() {
        return new d0.d(androidx.core.widget.r.b(this));
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.b.getClass();
        c1.h(editorInfo, inputConnectionOnCreateInputConnection, this);
        a5.h.P(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        super.onLayout(z6, i7, i8, i9, i10);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.getClass();
            Method method = z3.f986a;
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i7, int i8) {
        Future future = this.f740f;
        if (future != null) {
            try {
                this.f740f = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                PrecomputedText.Params paramsB = androidx.core.widget.r.b(this);
                paramsB.getTextPaint();
                paramsB.getTextDirection();
                paramsB.getBreakStrategy();
                paramsB.getHyphenationFrequency();
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i7, i8);
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
        super.onTextChanged(charSequence, i7, i8, i9);
        if (this.b != null) {
            Method method = z3.f986a;
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z6) {
        super.setAllCaps(z6);
        getEmojiTextViewHelper().b(z6);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i7, int i8, int i9, int i10) {
        Method method = z3.f986a;
        super.setAutoSizeTextTypeUniformWithConfiguration(i7, i8, i9, i10);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i7) {
        Method method = z3.f986a;
        super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i7);
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i7) {
        Method method = z3.f986a;
        super.setAutoSizeTextTypeWithDefaults(i7);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f737a;
        if (rVar != null) {
            rVar.n();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i7) {
        super.setBackgroundResource(i7);
        r rVar = this.f737a;
        if (rVar != null) {
            rVar.o(i7);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i7, int i8, int i9, int i10) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i7 != 0 ? a5.h.E(context, i7) : null, i8 != 0 ? a5.h.E(context, i8) : null, i9 != 0 ? a5.h.E(context, i9) : null, i10 != 0 ? a5.h.E(context, i10) : null);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i7, int i8, int i9, int i10) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i7 != 0 ? a5.h.E(context, i7) : null, i8 != 0 ? a5.h.E(context, i8) : null, i9 != 0 ? a5.h.E(context, i9) : null, i10 != 0 ? a5.h.E(context, i10) : null);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(callback);
    }

    public void setEmojiCompatEnabled(boolean z6) {
        getEmojiTextViewHelper().c(z6);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((m4.f) getEmojiTextViewHelper().b.b).q(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i7) {
        super.setFirstBaselineToTopHeight(i7);
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i7) {
        super.setLastBaselineToBottomHeight(i7);
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i7) {
        a5.h.g(i7);
        if (i7 != getPaint().getFontMetricsInt(null)) {
            setLineSpacing(i7 - r0, 1.0f);
        }
    }

    public void setPrecomputedText(d0.e eVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        PrecomputedText.Params paramsB = androidx.core.widget.r.b(this);
        paramsB.getTextPaint();
        paramsB.getTextDirection();
        paramsB.getBreakStrategy();
        paramsB.getHyphenationFrequency();
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f737a;
        if (rVar != null) {
            rVar.t(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f737a;
        if (rVar != null) {
            rVar.u(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        c1 c1Var = this.b;
        c1Var.i(colorStateList);
        c1Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        c1 c1Var = this.b;
        c1Var.j(mode);
        c1Var.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i7) {
        super.setTextAppearance(context, i7);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.g(context, i7);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        super.setTextClassifier(textClassifier);
    }

    public void setTextFuture(Future<d0.e> future) {
        this.f740f = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(d0.d dVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = dVar.b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i7 = 1;
        if (textDirectionHeuristic2 != textDirectionHeuristic3 && textDirectionHeuristic2 != (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i7 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i7 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i7 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i7 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i7 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i7 = 7;
            }
        }
        androidx.core.widget.p.h(this, i7);
        getPaint().set(dVar.f5233a);
        androidx.core.widget.q.e(this, dVar.f5234c);
        androidx.core.widget.q.h(this, dVar.f5235d);
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i7, float f2) {
        Method method = z3.f986a;
        super.setTextSize(i7, f2);
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i7) {
        Typeface typefaceCreate;
        if (this.f739d) {
            return;
        }
        if (typeface == null || i7 <= 0) {
            typefaceCreate = null;
        } else {
            Context context = getContext();
            v1.e eVar = x.g.f8677a;
            if (context == null) {
                f3.q("Context cannot be null");
                return;
            }
            typefaceCreate = Typeface.create(typeface, i7);
        }
        this.f739d = true;
        if (typefaceCreate != null) {
            typeface = typefaceCreate;
        }
        try {
            super.setTypeface(typeface, i7);
        } finally {
            this.f739d = false;
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        c1 c1Var = this.b;
        if (c1Var != null) {
            c1Var.b();
        }
    }

    public e1(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }
}
