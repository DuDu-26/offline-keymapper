package androidx.appcompat.widget;

import android.view.View;
import androidx.appcompat.view.menu.ActionMenuItemView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i extends v1 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f802j = 1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ View f803k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(ActionMenuItemView actionMenuItemView) {
        super(actionMenuItemView);
        this.f803k = actionMenuItemView;
    }

    @Override // androidx.appcompat.widget.v1
    public final g.c0 b() {
        f fVar;
        switch (this.f802j) {
            case 0:
                f fVar2 = ((j) this.f803k).f815d.f850t;
                if (fVar2 == null) {
                    return null;
                }
                return fVar2.a();
            default:
                g.b bVar = ((ActionMenuItemView) this.f803k).f566l;
                if (bVar == null || (fVar = ((g) bVar).f776a.f851u) == null) {
                    return null;
                }
                return fVar.a();
        }
    }

    @Override // androidx.appcompat.widget.v1
    public final boolean c() {
        g.c0 c0VarB;
        switch (this.f802j) {
            case 0:
                ((j) this.f803k).f815d.n();
                return true;
            default:
                ActionMenuItemView actionMenuItemView = (ActionMenuItemView) this.f803k;
                g.k kVar = actionMenuItemView.f564j;
                return kVar != null && kVar.a(actionMenuItemView.f561g) && (c0VarB = b()) != null && c0VarB.a();
        }
    }

    @Override // androidx.appcompat.widget.v1
    public boolean d() {
        switch (this.f802j) {
            case 0:
                l lVar = ((j) this.f803k).f815d;
                if (lVar.f852v != null) {
                    return false;
                }
                lVar.c();
                return true;
            default:
                return super.d();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(j jVar, j jVar2) {
        super(jVar2);
        this.f803k = jVar;
    }
}
