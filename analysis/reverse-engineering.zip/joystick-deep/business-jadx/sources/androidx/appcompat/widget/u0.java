package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u0 extends f2 implements v0 {
    public CharSequence C;
    public r0 D;
    public final Rect E;
    public int F;
    public final /* synthetic */ w0 G;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u0(w0 w0Var, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969560, 0);
        this.G = w0Var;
        this.E = new Rect();
        this.f763o = w0Var;
        this.f773y = true;
        this.f774z.setFocusable(true);
        this.f764p = new s0(0, this);
    }

    @Override // androidx.appcompat.widget.v0
    public final void e(CharSequence charSequence) {
        this.C = charSequence;
    }

    @Override // androidx.appcompat.widget.v0
    public final void k(int i7) {
        this.F = i7;
    }

    @Override // androidx.appcompat.widget.v0
    public final void m(int i7, int i8) {
        ViewTreeObserver viewTreeObserver;
        e0 e0Var = this.f774z;
        boolean zIsShowing = e0Var.isShowing();
        s();
        e0Var.setInputMethodMode(2);
        c();
        s1 s1Var = this.f752c;
        s1Var.setChoiceMode(1);
        o0.d(s1Var, i7);
        o0.c(s1Var, i8);
        w0 w0Var = this.G;
        int selectedItemPosition = w0Var.getSelectedItemPosition();
        s1 s1Var2 = this.f752c;
        if (e0Var.isShowing() && s1Var2 != null) {
            s1Var2.setListSelectionHidden(false);
            s1Var2.setSelection(selectedItemPosition);
            if (s1Var2.getChoiceMode() != 0) {
                s1Var2.setItemChecked(selectedItemPosition, true);
            }
        }
        if (zIsShowing || (viewTreeObserver = w0Var.getViewTreeObserver()) == null) {
            return;
        }
        m0 m0Var = new m0(1, this);
        viewTreeObserver.addOnGlobalLayoutListener(m0Var);
        e0Var.setOnDismissListener(new t0(this, m0Var));
    }

    @Override // androidx.appcompat.widget.v0
    public final CharSequence o() {
        return this.C;
    }

    @Override // androidx.appcompat.widget.f2, androidx.appcompat.widget.v0
    public final void p(ListAdapter listAdapter) {
        super.p(listAdapter);
        this.D = (r0) listAdapter;
    }

    public final void s() {
        int i7;
        e0 e0Var = this.f774z;
        Drawable background = e0Var.getBackground();
        w0 w0Var = this.G;
        Rect rect = w0Var.f959h;
        if (background != null) {
            background.getPadding(rect);
            i7 = z3.a(w0Var) ? rect.right : -rect.left;
        } else {
            i7 = 0;
            rect.right = 0;
            rect.left = 0;
        }
        int paddingLeft = w0Var.getPaddingLeft();
        int paddingRight = w0Var.getPaddingRight();
        int width = w0Var.getWidth();
        int i8 = w0Var.f958g;
        if (i8 == -2) {
            int iA = w0Var.a(this.D, e0Var.getBackground());
            int i9 = (w0Var.getContext().getResources().getDisplayMetrics().widthPixels - rect.left) - rect.right;
            if (iA > i9) {
                iA = i9;
            }
            r(Math.max(iA, (width - paddingLeft) - paddingRight));
        } else if (i8 == -1) {
            r((width - paddingLeft) - paddingRight);
        } else {
            r(i8);
        }
        this.f754f = z3.a(w0Var) ? (((width - paddingRight) - this.e) - this.F) + i7 : paddingLeft + this.F + i7;
    }
}
