package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f875a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f876c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f877d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f878f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f879g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f880h;

    public final void a(int i7, int i8) {
        this.f876c = i7;
        this.f877d = i8;
        this.f880h = true;
        if (this.f879g) {
            if (i8 != Integer.MIN_VALUE) {
                this.f875a = i8;
            }
            if (i7 != Integer.MIN_VALUE) {
                this.b = i7;
                return;
            }
            return;
        }
        if (i7 != Integer.MIN_VALUE) {
            this.f875a = i7;
        }
        if (i8 != Integer.MIN_VALUE) {
            this.b = i8;
        }
    }
}
