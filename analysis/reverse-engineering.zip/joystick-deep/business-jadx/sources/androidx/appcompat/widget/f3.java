package androidx.appcompat.widget;

import android.content.SharedPreferences;
import com.umeng.analytics.pro.bw;
import com.umeng.analytics.pro.ee;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class f3 implements e4.q, e4.i, m3.d, m3.f, com.google.android.material.textfield.z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f775a;

    public /* synthetic */ f3(int i7) {
        this.f775a = i7;
    }

    public static /* synthetic */ void b() {
        throw new ClassCastException();
    }

    public static /* synthetic */ void d(int i7, int i8) throws EOFException {
        throw new EOFException("DEF length " + i7 + ((Object) " object truncated by ") + i8);
    }

    public static /* synthetic */ void e(int i7, String str) {
        throw new IllegalArgumentException(str + i7);
    }

    public static /* synthetic */ void f(Object obj) {
        throw new IllegalArgumentException(obj.toString());
    }

    public static /* synthetic */ void g(Object obj, Object obj2, Object obj3, Throwable th) {
        StringBuilder sb = new StringBuilder();
        sb.append(obj);
        sb.append(obj2);
        sb.append(obj3);
        throw new IllegalStateException(sb.toString(), th);
    }

    public static /* synthetic */ void h(Object obj, String str) throws FileNotFoundException {
        throw new FileNotFoundException(str + obj);
    }

    public static /* synthetic */ void i(String str) {
        throw new RuntimeException(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void j(String str, int i7, int i8) {
        throw new IllegalArgumentException((str + i7 + ((char) i8)).toString());
    }

    public static /* synthetic */ void k(String str, int i7, Object obj, int i8) {
        throw new IllegalArgumentException((str + i7 + obj + i8).toString());
    }

    public static /* synthetic */ void l(String str, bw bwVar) throws ee {
        throw new ee(str + ((Object) bwVar.toString()));
    }

    public static /* synthetic */ void m(String str, Object obj, Exception exc) {
        throw new h5.s(str + obj, exc);
    }

    public static /* synthetic */ void n(String str, Object obj, Object obj2) {
        throw new IllegalArgumentException(str + obj + obj2);
    }

    public static /* synthetic */ void o(String str, Object obj, Object obj2, Object obj3) {
        throw new IllegalArgumentException(str + obj + obj2 + obj3);
    }

    public static /* synthetic */ void p(Object obj, String str) {
        throw new IllegalStateException(str + obj);
    }

    public static /* synthetic */ void q(String str) {
        throw new IllegalArgumentException(str);
    }

    public static /* synthetic */ void r(String str, Object obj, Object obj2) {
        throw new IllegalStateException(str + obj + obj2);
    }

    public static /* synthetic */ void s(Object obj, String str) {
        throw new IllegalStateException(str + obj);
    }

    public static /* synthetic */ void t(String str) {
        throw new IllegalStateException(str);
    }

    public static /* synthetic */ void u(Object obj, String str) throws ee {
        throw new ee(str + ((Object) obj.toString()));
    }

    public static /* synthetic */ void v(String str) throws IOException {
        throw new IOException(str);
    }

    public static /* synthetic */ void w(Object obj, String str) {
        throw new IllegalArgumentException(str + obj);
    }

    public static /* synthetic */ void x(String str) {
        throw new NullPointerException(str);
    }

    public static /* synthetic */ void y(Object obj, String str) throws h5.i {
        throw new h5.i(str + obj);
    }

    @Override // m3.d
    public void a(int i7) {
        ((SharedPreferences) y2.l.i().f8978a).edit().putInt("sc_view_control_type", i7).apply();
    }

    @Override // m3.f
    public void c(boolean z6) {
        SharedPreferences sharedPreferences;
        String str;
        switch (this.f775a) {
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                sharedPreferences = (SharedPreferences) y2.l.i().f8978a;
                str = "sc_control_view_with_aiming";
                break;
            default:
                sharedPreferences = (SharedPreferences) y2.l.i().f8978a;
                str = "sc_control_view_with_peek";
                break;
        }
        s.h.f(sharedPreferences, str, z6);
    }
}
