package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l0 extends v1 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ u0 f856j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ w0 f857k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l0(w0 w0Var, w0 w0Var2, u0 u0Var) {
        super(w0Var2);
        this.f857k = w0Var;
        this.f856j = u0Var;
    }

    @Override // androidx.appcompat.widget.v1
    public final g.c0 b() {
        return this.f856j;
    }

    @Override // androidx.appcompat.widget.v1
    public final boolean c() {
        w0 w0Var = this.f857k;
        if (w0Var.getInternalPopup().a()) {
            return true;
        }
        w0Var.f957f.m(o0.b(w0Var), o0.a(w0Var));
        return true;
    }
}
