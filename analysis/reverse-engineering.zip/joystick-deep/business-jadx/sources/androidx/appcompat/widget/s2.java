package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class s2 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f911a;
    public final /* synthetic */ SearchView b;

    public /* synthetic */ s2(SearchView searchView, int i7) {
        this.f911a = i7;
        this.b = searchView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f911a) {
            case 0:
                this.b.s();
                break;
            default:
                j0.b bVar = this.b.O;
                if (bVar instanceof h3) {
                    bVar.b(null);
                }
                break;
        }
    }
}
