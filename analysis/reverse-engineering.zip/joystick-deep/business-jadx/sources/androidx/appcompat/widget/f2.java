package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class f2 implements g.c0 {
    public static final Method A;
    public static final Method B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f751a;
    public ListAdapter b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public s1 f752c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f754f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f755g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f757i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f758j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f759k;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public c2 f762n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f763o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public AdapterView.OnItemClickListener f764p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public AdapterView.OnItemSelectedListener f765q;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Handler f770v;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Rect f772x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f773y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final e0 f774z;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f753d = -2;
    public int e = -2;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f756h = 1002;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f760l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f761m = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final b2 f766r = new b2(this, 1);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final e2 f767s = new e2(this);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final d2 f768t = new d2(this);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final b2 f769u = new b2(this, 0);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Rect f771w = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                A = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
            }
            try {
                B = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
            }
        }
    }

    public f2(Context context, AttributeSet attributeSet, int i7, int i8) {
        int resourceId;
        this.f751a = context;
        this.f770v = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, d.a.f5215o, i7, 0);
        this.f754f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f755g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f757i = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        e0 e0Var = new e0(context, attributeSet, i7, 0);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, d.a.f5219s, i7, 0);
        if (typedArrayObtainStyledAttributes2.hasValue(2)) {
            androidx.core.widget.n.c(e0Var, typedArrayObtainStyledAttributes2.getBoolean(2, false));
        }
        e0Var.setBackgroundDrawable((!typedArrayObtainStyledAttributes2.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes2.getDrawable(0) : a5.h.E(context, resourceId));
        typedArrayObtainStyledAttributes2.recycle();
        this.f774z = e0Var;
        e0Var.setInputMethodMode(1);
    }

    @Override // g.c0
    public final boolean a() {
        return this.f774z.isShowing();
    }

    public final int b() {
        return this.f754f;
    }

    @Override // g.c0
    public final void c() {
        int i7;
        int paddingBottom;
        s1 s1Var;
        s1 s1Var2 = this.f752c;
        Context context = this.f751a;
        e0 e0Var = this.f774z;
        if (s1Var2 == null) {
            s1 s1VarQ = q(context, !this.f773y);
            this.f752c = s1VarQ;
            s1VarQ.setAdapter(this.b);
            this.f752c.setOnItemClickListener(this.f764p);
            this.f752c.setFocusable(true);
            this.f752c.setFocusableInTouchMode(true);
            this.f752c.setOnItemSelectedListener(new y1(0, this));
            this.f752c.setOnScrollListener(this.f768t);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f765q;
            if (onItemSelectedListener != null) {
                this.f752c.setOnItemSelectedListener(onItemSelectedListener);
            }
            e0Var.setContentView(this.f752c);
        }
        Drawable background = e0Var.getBackground();
        Rect rect = this.f771w;
        if (background != null) {
            background.getPadding(rect);
            int i8 = rect.top;
            i7 = rect.bottom + i8;
            if (!this.f757i) {
                this.f755g = -i8;
            }
        } else {
            rect.setEmpty();
            i7 = 0;
        }
        int iA = z1.a(e0Var, this.f763o, this.f755g, e0Var.getInputMethodMode() == 2);
        int i9 = this.f753d;
        if (i9 == -1) {
            paddingBottom = iA + i7;
        } else {
            int i10 = this.e;
            int iA2 = this.f752c.a(i10 != -2 ? i10 != -1 ? View.MeasureSpec.makeMeasureSpec(i10, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.f752c.getPaddingBottom() + this.f752c.getPaddingTop() + i7 : 0);
        }
        boolean z6 = e0Var.getInputMethodMode() == 2;
        androidx.core.widget.n.d(e0Var, this.f756h);
        if (e0Var.isShowing()) {
            View view = this.f763o;
            WeakHashMap weakHashMap = f0.s0.f5582a;
            if (f0.e0.b(view)) {
                int width = this.e;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.f763o.getWidth();
                }
                if (i9 == -1) {
                    i9 = z6 ? paddingBottom : -1;
                    int i11 = this.e;
                    if (z6) {
                        e0Var.setWidth(i11 == -1 ? -1 : 0);
                        e0Var.setHeight(0);
                    } else {
                        e0Var.setWidth(i11 == -1 ? -1 : 0);
                        e0Var.setHeight(-1);
                    }
                } else if (i9 == -2) {
                    i9 = paddingBottom;
                }
                e0Var.setOutsideTouchable(true);
                View view2 = this.f763o;
                int i12 = width;
                int i13 = this.f754f;
                int i14 = this.f755g;
                int i15 = i12 < 0 ? -1 : i12;
                if (i9 < 0) {
                    i9 = -1;
                }
                e0Var.update(view2, i13, i14, i15, i9);
                return;
            }
            return;
        }
        int width2 = this.e;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.f763o.getWidth();
        }
        if (i9 == -1) {
            i9 = -1;
        } else if (i9 == -2) {
            i9 = paddingBottom;
        }
        e0Var.setWidth(width2);
        e0Var.setHeight(i9);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = A;
            if (method != null) {
                try {
                    method.invoke(e0Var, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        } else {
            a2.b(e0Var, true);
        }
        e0Var.setOutsideTouchable(true);
        e0Var.setTouchInterceptor(this.f767s);
        if (this.f759k) {
            androidx.core.widget.n.c(e0Var, this.f758j);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = B;
            if (method2 != null) {
                try {
                    method2.invoke(e0Var, this.f772x);
                } catch (Exception e) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
        } else {
            a2.a(e0Var, this.f772x);
        }
        androidx.core.widget.m.a(e0Var, this.f763o, this.f754f, this.f755g, this.f760l);
        this.f752c.setSelection(-1);
        if ((!this.f773y || this.f752c.isInTouchMode()) && (s1Var = this.f752c) != null) {
            s1Var.setListSelectionHidden(true);
            s1Var.requestLayout();
        }
        if (this.f773y) {
            return;
        }
        this.f770v.post(this.f769u);
    }

    public final Drawable d() {
        return this.f774z.getBackground();
    }

    @Override // g.c0
    public final void dismiss() {
        e0 e0Var = this.f774z;
        e0Var.dismiss();
        e0Var.setContentView(null);
        this.f752c = null;
        this.f770v.removeCallbacks(this.f766r);
    }

    @Override // g.c0
    public final s1 h() {
        return this.f752c;
    }

    public final void i(Drawable drawable) {
        this.f774z.setBackgroundDrawable(drawable);
    }

    public final void j(int i7) {
        this.f755g = i7;
        this.f757i = true;
    }

    public final void l(int i7) {
        this.f754f = i7;
    }

    public final int n() {
        if (this.f757i) {
            return this.f755g;
        }
        return 0;
    }

    public void p(ListAdapter listAdapter) {
        c2 c2Var = this.f762n;
        if (c2Var == null) {
            this.f762n = new c2(0, this);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(c2Var);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f762n);
        }
        s1 s1Var = this.f752c;
        if (s1Var != null) {
            s1Var.setAdapter(this.b);
        }
    }

    public s1 q(Context context, boolean z6) {
        return new s1(context, z6);
    }

    public final void r(int i7) {
        Drawable background = this.f774z.getBackground();
        if (background == null) {
            this.e = i7;
            return;
        }
        Rect rect = this.f771w;
        background.getPadding(rect);
        this.e = rect.left + rect.right + i7;
    }
}
