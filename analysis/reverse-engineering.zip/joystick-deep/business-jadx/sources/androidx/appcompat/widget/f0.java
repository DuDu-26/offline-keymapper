package androidx.appcompat.widget;

import android.R;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AbsSeekBar;
import android.widget.EditText;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class f0 implements d1 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f748d = {R.attr.indeterminateDrawable, R.attr.progressDrawable};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f749a = 0;
    public final View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f750c;

    public f0(EditText editText) {
        this.b = editText;
        this.f750c = new g.d(editText);
    }

    public KeyListener a(KeyListener keyListener) {
        if (keyListener instanceof NumberKeyListener) {
            return keyListener;
        }
        ((y2.o) ((g.d) this.f750c).b).getClass();
        if (keyListener instanceof n0.e) {
            return keyListener;
        }
        if (keyListener == null) {
            return null;
        }
        return keyListener instanceof NumberKeyListener ? keyListener : new n0.e(keyListener);
    }

    public void b(AttributeSet attributeSet, int i7) {
        switch (this.f749a) {
            case 0:
                AbsSeekBar absSeekBar = (AbsSeekBar) this.b;
                y2.e eVarA = y2.e.A(absSeekBar.getContext(), attributeSet, f748d, i7);
                Drawable drawableP = eVarA.p(0);
                if (drawableP != null) {
                    if (drawableP instanceof AnimationDrawable) {
                        AnimationDrawable animationDrawable = (AnimationDrawable) drawableP;
                        int numberOfFrames = animationDrawable.getNumberOfFrames();
                        AnimationDrawable animationDrawable2 = new AnimationDrawable();
                        animationDrawable2.setOneShot(animationDrawable.isOneShot());
                        for (int i8 = 0; i8 < numberOfFrames; i8++) {
                            Drawable drawableE = e(animationDrawable.getFrame(i8), true);
                            drawableE.setLevel(10000);
                            animationDrawable2.addFrame(drawableE, animationDrawable.getDuration(i8));
                        }
                        animationDrawable2.setLevel(10000);
                        drawableP = animationDrawable2;
                    }
                    absSeekBar.setIndeterminateDrawable(drawableP);
                }
                Drawable drawableP2 = eVarA.p(1);
                if (drawableP2 != null) {
                    absSeekBar.setProgressDrawable(e(drawableP2, false));
                }
                eVarA.C();
                return;
            default:
                TypedArray typedArrayObtainStyledAttributes = ((EditText) this.b).getContext().obtainStyledAttributes(attributeSet, d.a.f5209i, i7, 0);
                try {
                    boolean z6 = true;
                    if (typedArrayObtainStyledAttributes.hasValue(14)) {
                        z6 = typedArrayObtainStyledAttributes.getBoolean(14, true);
                        break;
                    }
                    typedArrayObtainStyledAttributes.recycle();
                    d(z6);
                    return;
                } catch (Throwable th) {
                    typedArrayObtainStyledAttributes.recycle();
                    throw th;
                }
        }
    }

    public n0.b c(InputConnection inputConnection, EditorInfo editorInfo) {
        g.d dVar = (g.d) this.f750c;
        if (inputConnection == null) {
            dVar.getClass();
            inputConnection = null;
        } else {
            y2.o oVar = (y2.o) dVar.b;
            oVar.getClass();
            if (!(inputConnection instanceof n0.b)) {
                inputConnection = new n0.b(editorInfo, inputConnection, (EditText) oVar.b);
            }
        }
        return (n0.b) inputConnection;
    }

    public void d(boolean z6) {
        n0.i iVar = (n0.i) ((y2.o) ((g.d) this.f750c).b).f8985c;
        if (iVar.f6949c != z6) {
            if (iVar.b != null) {
                androidx.emoji2.text.j jVarA = androidx.emoji2.text.j.a();
                n0.h hVar = iVar.b;
                jVarA.getClass();
                a5.h.h(hVar, "initCallback cannot be null");
                ReentrantReadWriteLock reentrantReadWriteLock = jVarA.f1117a;
                reentrantReadWriteLock.writeLock().lock();
                try {
                    jVarA.b.remove(hVar);
                } finally {
                    reentrantReadWriteLock.writeLock().unlock();
                }
            }
            iVar.f6949c = z6;
            if (z6) {
                n0.i.a(iVar.f6948a, androidx.emoji2.text.j.a().b());
            }
        }
    }

    public Drawable e(Drawable drawable, boolean z6) {
        if (!(drawable instanceof LayerDrawable)) {
            if (!(drawable instanceof BitmapDrawable)) {
                return drawable;
            }
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            Bitmap bitmap = bitmapDrawable.getBitmap();
            if (((Bitmap) this.f750c) == null) {
                this.f750c = bitmap;
            }
            ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, null, null));
            shapeDrawable.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
            shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
            return z6 ? new ClipDrawable(shapeDrawable, 3, 1) : shapeDrawable;
        }
        LayerDrawable layerDrawable = (LayerDrawable) drawable;
        int numberOfLayers = layerDrawable.getNumberOfLayers();
        Drawable[] drawableArr = new Drawable[numberOfLayers];
        for (int i7 = 0; i7 < numberOfLayers; i7++) {
            int id = layerDrawable.getId(i7);
            drawableArr[i7] = e(layerDrawable.getDrawable(i7), id == 16908301 || id == 16908303);
        }
        LayerDrawable layerDrawable2 = new LayerDrawable(drawableArr);
        for (int i8 = 0; i8 < numberOfLayers; i8++) {
            layerDrawable2.setId(i8, layerDrawable.getId(i8));
            layerDrawable2.setLayerGravity(i8, layerDrawable.getLayerGravity(i8));
            layerDrawable2.setLayerWidth(i8, layerDrawable.getLayerWidth(i8));
            layerDrawable2.setLayerHeight(i8, layerDrawable.getLayerHeight(i8));
            layerDrawable2.setLayerInsetLeft(i8, layerDrawable.getLayerInsetLeft(i8));
            layerDrawable2.setLayerInsetRight(i8, layerDrawable.getLayerInsetRight(i8));
            layerDrawable2.setLayerInsetTop(i8, layerDrawable.getLayerInsetTop(i8));
            layerDrawable2.setLayerInsetBottom(i8, layerDrawable.getLayerInsetBottom(i8));
            layerDrawable2.setLayerInsetStart(i8, layerDrawable.getLayerInsetStart(i8));
            layerDrawable2.setLayerInsetEnd(i8, layerDrawable.getLayerInsetEnd(i8));
        }
        return layerDrawable2;
    }

    public f0(AbsSeekBar absSeekBar) {
        this.b = absSeekBar;
    }

    public f0(e1 e1Var) {
        this.f750c = e1Var;
        this.b = e1Var;
    }
}
