package androidx.appcompat.widget;

import android.view.View;
import android.view.ViewConfiguration;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class v1 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f930a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f931c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final View f932d;
    public u1 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public u1 f933f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f934g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f935h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f936i = new int[2];

    public v1(View view) {
        this.f932d = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f930a = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.b = tapTimeout;
        this.f931c = (ViewConfiguration.getLongPressTimeout() + tapTimeout) / 2;
    }

    public final void a() {
        u1 u1Var = this.f933f;
        View view = this.f932d;
        if (u1Var != null) {
            view.removeCallbacks(u1Var);
        }
        u1 u1Var2 = this.e;
        if (u1Var2 != null) {
            view.removeCallbacks(u1Var2);
        }
    }

    public abstract g.c0 b();

    public abstract boolean c();

    public boolean d() {
        g.c0 c0VarB = b();
        if (c0VarB == null || !c0VarB.a()) {
            return true;
        }
        c0VarB.dismiss();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0100  */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouch(android.view.View r13, android.view.MotionEvent r14) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.v1.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.f934g = false;
        this.f935h = -1;
        u1 u1Var = this.e;
        if (u1Var != null) {
            this.f932d.removeCallbacks(u1Var);
        }
    }
}
