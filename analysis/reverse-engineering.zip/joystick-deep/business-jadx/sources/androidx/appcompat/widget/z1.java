package androidx.appcompat.widget;

import android.view.View;
import android.widget.PopupWindow;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class z1 {
    public static int a(PopupWindow popupWindow, View view, int i7, boolean z6) {
        return popupWindow.getMaxAvailableHeight(view, i7, z6);
    }
}
