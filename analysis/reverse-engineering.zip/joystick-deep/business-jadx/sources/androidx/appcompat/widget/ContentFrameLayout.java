package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f653a;
    public TypedValue b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f654c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f655d;
    public TypedValue e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TypedValue f656f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Rect f657g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public k1 f658h;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f657g = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        return this.e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f656f == null) {
            this.f656f = new TypedValue();
        }
        return this.f656f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f654c == null) {
            this.f654c = new TypedValue();
        }
        return this.f654c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f655d == null) {
            this.f655d = new TypedValue();
        }
        return this.f655d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f653a == null) {
            this.f653a = new TypedValue();
        }
        return this.f653a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.b == null) {
            this.b = new TypedValue();
        }
        return this.b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        k1 k1Var = this.f658h;
        if (k1Var != null) {
            k1Var.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        l lVar;
        super.onDetachedFromWindow();
        k1 k1Var = this.f658h;
        if (k1Var != null) {
            androidx.appcompat.app.c0 c0Var = ((androidx.appcompat.app.r) k1Var).b;
            ActionBarOverlayLayout actionBarOverlayLayout = c0Var.f448r;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((v3) actionBarOverlayLayout.e).f938a.f680a;
                if (actionMenuView != null && (lVar = actionMenuView.f642t) != null) {
                    lVar.c();
                    f fVar = lVar.f851u;
                    if (fVar != null && fVar.b()) {
                        fVar.f5820i.dismiss();
                    }
                }
            }
            if (c0Var.f453w != null) {
                c0Var.f442l.getDecorView().removeCallbacks(c0Var.f454x);
                if (c0Var.f453w.isShowing()) {
                    try {
                        c0Var.f453w.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                c0Var.f453w = null;
            }
            f0.x0 x0Var = c0Var.f455y;
            if (x0Var != null) {
                x0Var.b();
            }
            g.l lVar2 = c0Var.y(0).f407h;
            if (lVar2 != null) {
                lVar2.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onMeasure(int r17, int r18) {
        /*
            Method dump skipped, instruction units count: 229
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(k1 k1Var) {
        this.f658h = k1Var;
    }
}
