package androidx.appcompat.widget;

import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class o0 {
    public static int a(View view) {
        return view.getTextAlignment();
    }

    public static int b(View view) {
        return view.getTextDirection();
    }

    public static void c(View view, int i7) {
        view.setTextAlignment(i7);
    }

    public static void d(View view, int i7) {
        view.setTextDirection(i7);
    }
}
