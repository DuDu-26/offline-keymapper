package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class i0 {
    public static boolean a(DragEvent dragEvent, TextView textView, Activity activity) {
        f0.e eVar;
        activity.requestDragAndDropPermissions(dragEvent);
        int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
        textView.beginBatchEdit();
        try {
            Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                eVar = new w3.e(clipData, 3);
            } else {
                f0.f fVar = new f0.f();
                fVar.b = clipData;
                fVar.f5544c = 3;
                eVar = fVar;
            }
            f0.s0.f(textView, eVar.build());
            textView.endBatchEdit();
            return true;
        } catch (Throwable th) {
            textView.endBatchEdit();
            throw th;
        }
    }

    public static boolean b(DragEvent dragEvent, View view, Activity activity) {
        f0.e eVar;
        activity.requestDragAndDropPermissions(dragEvent);
        ClipData clipData = dragEvent.getClipData();
        if (Build.VERSION.SDK_INT >= 31) {
            eVar = new w3.e(clipData, 3);
        } else {
            f0.f fVar = new f0.f();
            fVar.b = clipData;
            fVar.f5544c = 3;
            eVar = fVar;
        }
        f0.s0.f(view, eVar.build());
        return true;
    }
}
