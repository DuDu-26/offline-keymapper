package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.RectF;
import android.os.Build;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f804a = 0;
    public float b = -1.0f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f805c = -1.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f806d = -1.0f;
    public int[] e = new int[0];

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f807f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final TextView f808g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Context f809h;

    static {
        new RectF();
        new ConcurrentHashMap();
        new ConcurrentHashMap();
    }

    public i1(TextView textView) {
        this.f808g = textView;
        this.f809h = textView.getContext();
        if (Build.VERSION.SDK_INT >= 29) {
            new g1();
        } else {
            new f1();
        }
    }

    public static int[] a(int[] iArr) {
        int length = iArr.length;
        if (length != 0) {
            Arrays.sort(iArr);
            ArrayList arrayList = new ArrayList();
            for (int i7 : iArr) {
                if (i7 > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i7)) < 0) {
                    arrayList.add(Integer.valueOf(i7));
                }
            }
            if (length != arrayList.size()) {
                int size = arrayList.size();
                int[] iArr2 = new int[size];
                for (int i8 = 0; i8 < size; i8++) {
                    iArr2[i8] = ((Integer) arrayList.get(i8)).intValue();
                }
                return iArr2;
            }
        }
        return iArr;
    }

    public final boolean b() {
        return !(this.f808g instanceof y);
    }
}
