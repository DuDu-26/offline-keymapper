package androidx.appcompat.widget;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o extends w1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f868a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f869c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f870d;
    public boolean e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f871f;
}
