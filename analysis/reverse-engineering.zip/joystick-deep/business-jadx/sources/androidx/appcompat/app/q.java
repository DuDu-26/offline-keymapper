package androidx.appcompat.app;

import android.view.ViewGroup;
import f0.s0;
import f0.x0;
import java.util.WeakHashMap;
import moe.heroman.eventtest.adbhelper.AdbProtocol;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f550a;
    public final /* synthetic */ c0 b;

    public /* synthetic */ q(c0 c0Var, int i7) {
        this.f550a = i7;
        this.b = c0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ViewGroup viewGroup;
        int i7 = this.f550a;
        c0 c0Var = this.b;
        switch (i7) {
            case 0:
                if ((c0Var.Z & 1) != 0) {
                    c0Var.u(0);
                }
                if ((c0Var.Z & AdbProtocol.A_MAXDATA) != 0) {
                    c0Var.u(108);
                }
                c0Var.Y = false;
                c0Var.Z = 0;
                break;
            default:
                c0Var.f453w.showAtLocation(c0Var.f452v, 55, 0, 0);
                x0 x0Var = c0Var.f455y;
                if (x0Var != null) {
                    x0Var.b();
                }
                if (c0Var.f456z && (viewGroup = c0Var.A) != null) {
                    WeakHashMap weakHashMap = s0.f5582a;
                    if (f0.e0.c(viewGroup)) {
                        c0Var.f452v.setAlpha(0.0f);
                        x0 x0VarA = s0.a(c0Var.f452v);
                        x0VarA.a(1.0f);
                        c0Var.f455y = x0VarA;
                        x0VarA.d(new s(0, this));
                    }
                }
                c0Var.f452v.setAlpha(1.0f);
                c0Var.f452v.setVisibility(0);
                break;
        }
    }
}
