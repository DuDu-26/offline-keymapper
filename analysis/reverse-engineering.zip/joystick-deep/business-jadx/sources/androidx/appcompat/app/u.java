package androidx.appcompat.app;

import android.app.Activity;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class u {
    public static OnBackInvokedDispatcher a(Activity activity) {
        return androidx.activity.n.c(activity);
    }

    public static OnBackInvokedCallback b(Object obj, c0 c0Var) {
        Objects.requireNonNull(c0Var);
        androidx.activity.r rVar = new androidx.activity.r(1, c0Var);
        androidx.activity.n.h(androidx.activity.n.e(obj), rVar);
        return rVar;
    }

    public static void c(Object obj, Object obj2) {
        androidx.activity.n.g(androidx.activity.n.e(obj), androidx.activity.n.b(obj2));
    }
}
