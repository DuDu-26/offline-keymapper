package androidx.appcompat.app;

import android.os.Message;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.p3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f400a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(int i7, Object obj) {
        this.f400a = i7;
        this.b = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        Message message;
        Message message2;
        Message message3;
        switch (this.f400a) {
            case 0:
                f fVar = (f) this.b;
                Message messageObtain = (view != fVar.f466g || (message3 = fVar.f468i) == null) ? (view != fVar.f469j || (message2 = fVar.f471l) == null) ? (view != fVar.f472m || (message = fVar.f474o) == null) ? null : Message.obtain(message) : Message.obtain(message2) : Message.obtain(message3);
                if (messageObtain != null) {
                    messageObtain.sendToTarget();
                }
                fVar.C.obtainMessage(1, fVar.b).sendToTarget();
                break;
            case 1:
                ((f.a) this.b).a();
                break;
            case 2:
                p3 p3Var = ((Toolbar) this.b).L;
                g.n nVar = p3Var == null ? null : p3Var.b;
                if (nVar != null) {
                    nVar.collapseActionView();
                }
                break;
            case 3:
                com.google.android.material.datepicker.r rVar = (com.google.android.material.datepicker.r) this.b;
                int i7 = rVar.Y;
                if (i7 == 2) {
                    rVar.Q(1);
                } else if (i7 == 1) {
                    rVar.Q(2);
                }
                break;
            default:
                g.n itemData = ((com.google.android.material.navigation.d) view).getItemData();
                j1.b bVar = (j1.b) this.b;
                if (!bVar.E.q(itemData, bVar.D, 0)) {
                    itemData.setChecked(true);
                }
                break;
        }
    }
}
