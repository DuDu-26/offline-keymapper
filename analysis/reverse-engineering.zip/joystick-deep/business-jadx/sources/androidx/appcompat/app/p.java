package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import com.umeng.analytics.pro.bc;
import java.lang.ref.WeakReference;
import java.util.Iterator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final i0 f543a = new i0(new j0());
    public static int b = -100;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static b0.e f544c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static b0.e f545d = null;
    public static Boolean e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f546f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final l.c f547g = new l.c();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final Object f548h = new Object();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final Object f549i = new Object();

    public static boolean b(Context context) {
        if (e == null) {
            try {
                int i7 = h0.f497a;
                Bundle bundle = context.getPackageManager().getServiceInfo(new ComponentName(context, (Class<?>) h0.class), g0.a() | bc.f3796d).metaData;
                if (bundle != null) {
                    e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                e = Boolean.FALSE;
            }
        }
        return e.booleanValue();
    }

    public static void e(c0 c0Var) {
        synchronized (f548h) {
            try {
                Iterator it = f547g.iterator();
                while (true) {
                    l.g gVar = (l.g) it;
                    if (gVar.hasNext()) {
                        p pVar = (p) ((WeakReference) gVar.next()).get();
                        if (pVar == c0Var || pVar == null) {
                            gVar.remove();
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public abstract void a();

    public abstract void c();

    public abstract void d();

    public abstract boolean f(int i7);

    public abstract void g(int i7);

    public abstract void i(View view);

    public abstract void j(View view, ViewGroup.LayoutParams layoutParams);

    public abstract void k(CharSequence charSequence);
}
