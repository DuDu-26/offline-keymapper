package androidx.appcompat.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k0 {
    public static k0 e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f509a = 0;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f510c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f511d;

    public k0(int i7) {
        this.b = i7;
    }

    public static void c(k0 k0Var, long j7, long j8, int i7) {
        if ((i7 & 1) != 0) {
            j7 = 0;
        }
        if ((i7 & 2) != 0) {
            j8 = 0;
        }
        synchronized (k0Var) {
            try {
                if (j7 < 0) {
                    throw new IllegalStateException("Check failed.");
                }
                if (j8 < 0) {
                    throw new IllegalStateException("Check failed.");
                }
                long j9 = k0Var.f510c + j7;
                k0Var.f510c = j9;
                long j10 = k0Var.f511d + j8;
                k0Var.f511d = j10;
                if (j10 > j9) {
                    throw new IllegalStateException("Check failed.");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void a(long j7, double d3, double d7) {
        double d8 = (0.01720197f * ((j7 - 946728000000L) / 8.64E7f)) + 6.24006f;
        double dSin = (Math.sin(r3 * 3.0f) * 5.236000106378924E-6d) + (Math.sin(2.0f * r3) * 3.4906598739326E-4d) + (Math.sin(d8) * 0.03341960161924362d) + d8 + 1.796593063d + 3.141592653589793d;
        double dSin2 = (Math.sin(2.0d * dSin) * (-0.0069d)) + (Math.sin(d8) * 0.0053d) + ((double) (Math.round(((double) (r2 - 9.0E-4f)) - r6) + 9.0E-4f)) + ((-d7) / 360.0d);
        double dAsin = Math.asin(Math.sin(0.4092797040939331d) * Math.sin(dSin));
        double d9 = 0.01745329238474369d * d3;
        double dSin3 = (Math.sin(-0.10471975803375244d) - (Math.sin(dAsin) * Math.sin(d9))) / (Math.cos(dAsin) * Math.cos(d9));
        if (dSin3 >= 1.0d) {
            this.b = 1;
            this.f510c = -1L;
            this.f511d = -1L;
        } else {
            if (dSin3 <= -1.0d) {
                this.b = 0;
                this.f510c = -1L;
                this.f511d = -1L;
                return;
            }
            double dAcos = (float) (Math.acos(dSin3) / 6.283185307179586d);
            this.f510c = Math.round((dSin2 + dAcos) * 8.64E7d) + 946728000000L;
            long jRound = Math.round((dSin2 - dAcos) * 8.64E7d) + 946728000000L;
            this.f511d = jRound;
            if (jRound >= j7 || this.f510c <= j7) {
                this.b = 1;
            } else {
                this.b = 0;
            }
        }
    }

    public synchronized long b() {
        return this.f510c - this.f511d;
    }

    public String toString() {
        switch (this.f509a) {
            case 1:
                return "WindowCounter(streamId=" + this.b + ", total=" + this.f510c + ", acknowledged=" + this.f511d + ", unacknowledged=" + b() + ')';
            default:
                return super.toString();
        }
    }

    public /* synthetic */ k0() {
    }
}
