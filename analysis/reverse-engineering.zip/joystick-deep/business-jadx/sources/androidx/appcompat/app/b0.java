package androidx.appcompat.app;

import android.os.Bundle;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f402a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f403c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f404d;
    public z e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public View f405f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f406g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public g.l f407h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public g.h f408i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public f.d f409j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f410k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f411l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f412m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f413n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f414o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Bundle f415p;
}
