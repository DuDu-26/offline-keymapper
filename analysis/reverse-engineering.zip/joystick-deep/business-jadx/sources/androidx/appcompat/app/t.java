package androidx.appcompat.app;

import android.content.res.Configuration;
import android.os.LocaleList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class t {
    public static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
        LocaleList locales = configuration.getLocales();
        LocaleList locales2 = configuration2.getLocales();
        if (locales.equals(locales2)) {
            return;
        }
        configuration3.setLocales(locales2);
        configuration3.locale = configuration2.locale;
    }

    public static b0.e b(Configuration configuration) {
        return b0.e.a(configuration.getLocales().toLanguageTags());
    }

    public static void c(b0.e eVar) {
        LocaleList.setDefault(LocaleList.forLanguageTags(eVar.f1782a.f1783a.toLanguageTags()));
    }

    public static void d(Configuration configuration, b0.e eVar) {
        configuration.setLocales(LocaleList.forLanguageTags(eVar.f1782a.f1783a.toLanguageTags()));
    }
}
