package androidx.appcompat.app;

import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import e4.r0;
import f0.s0;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class s extends r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f552a;
    public final /* synthetic */ Object b;

    public /* synthetic */ s(int i7, Object obj) {
        this.f552a = i7;
        this.b = obj;
    }

    @Override // f0.y0
    public final void c() {
        int i7 = this.f552a;
        Object obj = this.b;
        switch (i7) {
            case 0:
                c0 c0Var = ((q) obj).b;
                c0Var.f452v.setAlpha(1.0f);
                c0Var.f455y.d(null);
                c0Var.f455y = null;
                break;
            case 1:
                c0 c0Var2 = (c0) obj;
                c0Var2.f452v.setAlpha(1.0f);
                c0Var2.f455y.d(null);
                c0Var2.f455y = null;
                break;
            default:
                c0 c0Var3 = (c0) ((y2.o) obj).f8985c;
                c0Var3.f452v.setVisibility(8);
                PopupWindow popupWindow = c0Var3.f453w;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (c0Var3.f452v.getParent() instanceof View) {
                    View view = (View) c0Var3.f452v.getParent();
                    WeakHashMap weakHashMap = s0.f5582a;
                    f0.f0.c(view);
                }
                c0Var3.f452v.e();
                c0Var3.f455y.d(null);
                c0Var3.f455y = null;
                ViewGroup viewGroup = c0Var3.A;
                WeakHashMap weakHashMap2 = s0.f5582a;
                f0.f0.c(viewGroup);
                break;
        }
    }

    @Override // e4.r0, f0.y0
    public void e() {
        int i7 = this.f552a;
        Object obj = this.b;
        switch (i7) {
            case 0:
                ((q) obj).b.f452v.setVisibility(0);
                break;
            case 1:
                c0 c0Var = (c0) obj;
                c0Var.f452v.setVisibility(0);
                if (c0Var.f452v.getParent() instanceof View) {
                    View view = (View) c0Var.f452v.getParent();
                    WeakHashMap weakHashMap = s0.f5582a;
                    f0.f0.c(view);
                }
                break;
        }
    }
}
