package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.f3;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class f {
    public final int A;
    public final boolean B;
    public final d C;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f462a;
    public final h b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Window f463c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f464d;
    public CharSequence e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public AlertController$RecycleListView f465f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Button f466g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f467h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Message f468i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Button f469j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f470k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Message f471l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Button f472m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public CharSequence f473n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Message f474o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public NestedScrollView f475p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Drawable f476q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ImageView f477r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public TextView f478s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public TextView f479t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public View f480u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ListAdapter f481v;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f483x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f484y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f485z;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f482w = -1;
    public final a D = new a(0, this);

    public f(Context context, h hVar, Window window) {
        this.f462a = context;
        this.b = hVar;
        this.f463c = window;
        d dVar = new d();
        dVar.f457a = new WeakReference(hVar);
        this.C = dVar;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, d.a.e, 2130968619, 0);
        this.f483x = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.getResourceId(2, 0);
        this.f484y = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f485z = typedArrayObtainStyledAttributes.getResourceId(7, 0);
        this.A = typedArrayObtainStyledAttributes.getResourceId(3, 0);
        this.B = typedArrayObtainStyledAttributes.getBoolean(6, true);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        hVar.c().f(1);
    }

    public static ViewGroup a(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    public final void b(int i7, CharSequence charSequence, m4.a aVar) {
        Message messageObtainMessage = aVar != null ? this.C.obtainMessage(i7, aVar) : null;
        if (i7 == -3) {
            this.f473n = charSequence;
            this.f474o = messageObtainMessage;
        } else if (i7 == -2) {
            this.f470k = charSequence;
            this.f471l = messageObtainMessage;
        } else if (i7 != -1) {
            f3.q("Button does not exist");
        } else {
            this.f467h = charSequence;
            this.f468i = messageObtainMessage;
        }
    }
}
