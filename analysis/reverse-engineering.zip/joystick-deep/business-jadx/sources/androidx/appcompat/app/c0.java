package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.f3;
import androidx.appcompat.widget.l1;
import androidx.appcompat.widget.p3;
import androidx.appcompat.widget.v3;
import androidx.appcompat.widget.z3;
import com.umeng.commonsdk.statistics.UMErrorCode;
import f0.s0;
import f0.x0;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c0 extends p implements g.j, LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public static final l.k f430h0 = new l.k();

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public static final int[] f431i0 = {R.attr.windowBackground};

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public static final boolean f432j0 = !"robolectric".equals(Build.FINGERPRINT);

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public static final boolean f433k0 = true;
    public ViewGroup A;
    public TextView B;
    public View C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    public boolean K;
    public b0[] L;
    public b0 M;
    public boolean N;
    public boolean O;
    public boolean P;
    public boolean Q;
    public Configuration R;
    public final int S;
    public int T;
    public int U;
    public boolean V;
    public w W;
    public w X;
    public boolean Y;
    public int Z;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public boolean f434b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public Rect f435c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public Rect f436d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public f0 f437e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public OnBackInvokedDispatcher f438f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public OnBackInvokedCallback f439g0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Object f440j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Context f441k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Window f442l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public v f443m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f444n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public o0 f445o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public f.i f446p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f447q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ActionBarOverlayLayout f448r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public r f449s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public r f450t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public f.a f451u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ActionBarContextView f452v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public PopupWindow f453w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public q f454x;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f456z;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public x0 f455y = null;
    public final q a0 = new q(this, 0);

    public c0(Context context, Window window, l lVar, Object obj) {
        k kVar;
        this.S = -100;
        this.f441k = context;
        this.f444n = lVar;
        this.f440j = obj;
        if (obj instanceof Dialog) {
            while (context != null) {
                if (!(context instanceof k)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    kVar = (k) context;
                    break;
                }
            }
            kVar = null;
            if (kVar != null) {
                this.S = ((c0) kVar.j()).S;
            }
        }
        if (this.S == -100) {
            String name = this.f440j.getClass().getName();
            l.k kVar2 = f430h0;
            Integer num = (Integer) kVar2.getOrDefault(name, null);
            if (num != null) {
                this.S = num.intValue();
                kVar2.remove(this.f440j.getClass().getName());
            }
        }
        if (window != null) {
            n(window);
        }
        androidx.appcompat.widget.w.d();
    }

    public static b0.e o(Context context) {
        b0.e eVar;
        b0.e eVar2;
        if (Build.VERSION.SDK_INT >= 33 || (eVar = p.f544c) == null) {
            return null;
        }
        b0.f fVar = eVar.f1782a;
        b0.e eVarB = t.b(context.getApplicationContext().getResources().getConfiguration());
        if (fVar.f1783a.isEmpty()) {
            eVar2 = b0.e.b;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            int i7 = 0;
            while (i7 < eVarB.f1782a.f1783a.size() + fVar.f1783a.size()) {
                Locale locale = i7 < fVar.f1783a.size() ? fVar.f1783a.get(i7) : eVarB.f1782a.f1783a.get(i7 - fVar.f1783a.size());
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
                i7++;
            }
            eVar2 = new b0.e(new b0.f(b0.d.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]))));
        }
        return eVar2.f1782a.f1783a.isEmpty() ? eVarB : eVar2;
    }

    public static Configuration s(Context context, int i7, b0.e eVar, Configuration configuration, boolean z6) {
        int i8 = i7 != 1 ? i7 != 2 ? z6 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i8 | (configuration2.uiMode & (-49));
        if (eVar != null) {
            t.d(configuration2, eVar);
        }
        return configuration2;
    }

    public final void A(int i7) {
        this.Z = (1 << i7) | this.Z;
        if (this.Y) {
            return;
        }
        View decorView = this.f442l.getDecorView();
        WeakHashMap weakHashMap = s0.f5582a;
        f0.b0.m(decorView, this.a0);
        this.Y = true;
    }

    public final int B(Context context, int i7) {
        if (i7 != -100) {
            if (i7 != -1) {
                if (i7 != 0) {
                    if (i7 != 1 && i7 != 2) {
                        if (i7 != 3) {
                            f3.t("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                            return 0;
                        }
                        if (this.X == null) {
                            this.X = new w(this, context);
                        }
                        return this.X.f();
                    }
                } else if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() != 0) {
                    return x(context).f();
                }
            }
            return i7;
        }
        return -1;
    }

    public final boolean C() {
        l1 l1Var;
        p3 p3Var;
        boolean z6 = this.N;
        this.N = false;
        b0 b0VarY = y(0);
        if (!b0VarY.f412m) {
            f.a aVar = this.f451u;
            if (aVar != null) {
                aVar.a();
                return true;
            }
            z();
            o0 o0Var = this.f445o;
            if (o0Var == null || (l1Var = o0Var.e) == null || (p3Var = ((v3) l1Var).f938a.L) == null || p3Var.b == null) {
                return false;
            }
            p3 p3Var2 = ((v3) l1Var).f938a.L;
            g.n nVar = p3Var2 == null ? null : p3Var2.b;
            if (nVar != null) {
                nVar.collapseActionView();
            }
        } else if (!z6) {
            r(b0VarY, true);
            return true;
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:87:0x0176, code lost:
    
        if (r2.f5752f.getCount() > 0) goto L88;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x01d3  */
    /* JADX WARN: Removed duplicated region for block: B:105:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void D(androidx.appcompat.app.b0 r18, android.view.KeyEvent r19) {
        /*
            Method dump skipped, instruction units count: 474
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.D(androidx.appcompat.app.b0, android.view.KeyEvent):void");
    }

    public final boolean E(b0 b0Var, int i7, KeyEvent keyEvent) {
        g.l lVar;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((b0Var.f410k || F(b0Var, keyEvent)) && (lVar = b0Var.f407h) != null) {
            return lVar.performShortcut(i7, keyEvent, 1);
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x00ce  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean F(androidx.appcompat.app.b0 r13, android.view.KeyEvent r14) {
        /*
            Method dump skipped, instruction units count: 353
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.F(androidx.appcompat.app.b0, android.view.KeyEvent):boolean");
    }

    public final void G() {
        if (this.f456z) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void H() {
        OnBackInvokedCallback onBackInvokedCallback;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z6 = false;
            if (this.f438f0 != null && (y(0).f412m || this.f451u != null)) {
                z6 = true;
            }
            if (z6 && this.f439g0 == null) {
                this.f439g0 = u.b(this.f438f0, this);
            } else {
                if (z6 || (onBackInvokedCallback = this.f439g0) == null) {
                    return;
                }
                u.c(this.f438f0, onBackInvokedCallback);
            }
        }
    }

    @Override // androidx.appcompat.app.p
    public final void a() {
        if (this.f445o != null) {
            z();
            this.f445o.getClass();
            A(0);
        }
    }

    @Override // androidx.appcompat.app.p
    public final void c() {
        String strJ;
        this.O = true;
        m(false, true);
        w();
        Object obj = this.f440j;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    strJ = a5.h.J(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e) {
                    throw new IllegalArgumentException(e);
                }
            } catch (IllegalArgumentException unused) {
                strJ = null;
            }
            if (strJ != null) {
                o0 o0Var = this.f445o;
                if (o0Var == null) {
                    this.f434b0 = true;
                } else {
                    o0Var.d(true);
                }
            }
            synchronized (p.f548h) {
                p.e(this);
                p.f547g.add(new WeakReference(this));
            }
        }
        this.R = new Configuration(this.f441k.getResources().getConfiguration());
        this.P = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x004d  */
    @Override // androidx.appcompat.app.p
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void d() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f440j
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L11
            java.lang.Object r0 = androidx.appcompat.app.p.f548h
            monitor-enter(r0)
            androidx.appcompat.app.p.e(r3)     // Catch: java.lang.Throwable -> Le
            monitor-exit(r0)     // Catch: java.lang.Throwable -> Le
            goto L11
        Le:
            r1 = move-exception
            monitor-exit(r0)     // Catch: java.lang.Throwable -> Le
            throw r1
        L11:
            boolean r0 = r3.Y
            if (r0 == 0) goto L20
            android.view.Window r0 = r3.f442l
            android.view.View r0 = r0.getDecorView()
            androidx.appcompat.app.q r1 = r3.a0
            r0.removeCallbacks(r1)
        L20:
            r0 = 1
            r3.Q = r0
            int r0 = r3.S
            r1 = -100
            if (r0 == r1) goto L4d
            java.lang.Object r0 = r3.f440j
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L4d
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L4d
            l.k r0 = androidx.appcompat.app.c0.f430h0
            java.lang.Object r1 = r3.f440j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.S
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L5c
        L4d:
            l.k r0 = androidx.appcompat.app.c0.f430h0
            java.lang.Object r1 = r3.f440j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L5c:
            androidx.appcompat.app.w r0 = r3.W
            if (r0 == 0) goto L63
            r0.c()
        L63:
            androidx.appcompat.app.w r0 = r3.X
            if (r0 == 0) goto L6a
            r0.c()
        L6a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.d():void");
    }

    @Override // androidx.appcompat.app.p
    public final boolean f(int i7) {
        if (i7 == 8) {
            i7 = 108;
        } else if (i7 == 9) {
            i7 = 109;
        }
        if (this.J && i7 == 108) {
            return false;
        }
        if (this.F && i7 == 1) {
            this.F = false;
        }
        if (i7 == 1) {
            G();
            this.J = true;
            return true;
        }
        if (i7 == 2) {
            G();
            this.D = true;
            return true;
        }
        if (i7 == 5) {
            G();
            this.E = true;
            return true;
        }
        if (i7 == 10) {
            G();
            this.H = true;
            return true;
        }
        if (i7 == 108) {
            G();
            this.F = true;
            return true;
        }
        if (i7 != 109) {
            return this.f442l.requestFeature(i7);
        }
        G();
        this.G = true;
        return true;
    }

    @Override // androidx.appcompat.app.p
    public final void g(int i7) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f441k).inflate(i7, viewGroup);
        this.f443m.a(this.f442l.getCallback());
    }

    @Override // g.j
    public final boolean h(g.l lVar, MenuItem menuItem) {
        b0 b0Var;
        Window.Callback callback = this.f442l.getCallback();
        if (callback != null && !this.Q) {
            g.l lVarK = lVar.k();
            b0[] b0VarArr = this.L;
            int length = b0VarArr != null ? b0VarArr.length : 0;
            int i7 = 0;
            while (true) {
                if (i7 < length) {
                    b0Var = b0VarArr[i7];
                    if (b0Var != null && b0Var.f407h == lVarK) {
                        break;
                    }
                    i7++;
                } else {
                    b0Var = null;
                    break;
                }
            }
            if (b0Var != null) {
                return callback.onMenuItemSelected(b0Var.f402a, menuItem);
            }
        }
        return false;
    }

    @Override // androidx.appcompat.app.p
    public final void i(View view) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f443m.a(this.f442l.getCallback());
    }

    @Override // androidx.appcompat.app.p
    public final void j(View view, ViewGroup.LayoutParams layoutParams) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f443m.a(this.f442l.getCallback());
    }

    @Override // androidx.appcompat.app.p
    public final void k(CharSequence charSequence) {
        this.f447q = charSequence;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f448r;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setWindowTitle(charSequence);
            return;
        }
        o0 o0Var = this.f445o;
        if (o0Var == null) {
            TextView textView = this.B;
            if (textView != null) {
                textView.setText(charSequence);
                return;
            }
            return;
        }
        v3 v3Var = (v3) o0Var.e;
        if (v3Var.f942g) {
            return;
        }
        Toolbar toolbar = v3Var.f938a;
        v3Var.f943h = charSequence;
        if ((v3Var.b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (v3Var.f942g) {
                s0.k(toolbar.getRootView(), charSequence);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0044, code lost:
    
        if (r6.h() != false) goto L20;
     */
    @Override // g.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void l(g.l r6) {
        /*
            Method dump skipped, instruction units count: 231
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.l(g.l):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00c0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean m(boolean r12, boolean r13) {
        /*
            Method dump skipped, instruction units count: 358
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.m(boolean, boolean):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x0074  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void n(android.view.Window r8) {
        /*
            r7 = this;
            java.lang.String r0 = "AppCompat has already installed itself into the Window"
            android.view.Window r1 = r7.f442l
            if (r1 != 0) goto L7e
            android.view.Window$Callback r1 = r8.getCallback()
            boolean r2 = r1 instanceof androidx.appcompat.app.v
            if (r2 != 0) goto L7a
            androidx.appcompat.app.v r0 = new androidx.appcompat.app.v
            r0.<init>(r7, r1)
            r7.f443m = r0
            r8.setCallback(r0)
            android.content.Context r0 = r7.f441k
            int[] r1 = androidx.appcompat.app.c0.f431i0
            r2 = 0
            android.content.res.TypedArray r1 = r0.obtainStyledAttributes(r2, r1)
            r3 = 0
            boolean r4 = r1.hasValue(r3)
            if (r4 == 0) goto L3f
            int r3 = r1.getResourceId(r3, r3)
            if (r3 == 0) goto L3f
            androidx.appcompat.widget.w r4 = androidx.appcompat.widget.w.a()
            monitor-enter(r4)
            androidx.appcompat.widget.n2 r5 = r4.f952a     // Catch: java.lang.Throwable -> L3c
            r6 = 1
            android.graphics.drawable.Drawable r0 = r5.d(r0, r3, r6)     // Catch: java.lang.Throwable -> L3c
            monitor-exit(r4)
            goto L40
        L3c:
            r8 = move-exception
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L3c
            throw r8
        L3f:
            r0 = r2
        L40:
            if (r0 == 0) goto L45
            r8.setBackgroundDrawable(r0)
        L45:
            r1.recycle()
            r7.f442l = r8
            int r8 = android.os.Build.VERSION.SDK_INT
            r0 = 33
            if (r8 < r0) goto L79
            android.window.OnBackInvokedDispatcher r8 = r7.f438f0
            if (r8 != 0) goto L79
            java.lang.Object r0 = r7.f440j
            if (r8 == 0) goto L61
            android.window.OnBackInvokedCallback r1 = r7.f439g0
            if (r1 == 0) goto L61
            androidx.appcompat.app.u.c(r8, r1)
            r7.f439g0 = r2
        L61:
            boolean r8 = r0 instanceof android.app.Activity
            if (r8 == 0) goto L74
            android.app.Activity r0 = (android.app.Activity) r0
            android.view.Window r8 = r0.getWindow()
            if (r8 == 0) goto L74
            android.window.OnBackInvokedDispatcher r8 = androidx.appcompat.app.u.a(r0)
            r7.f438f0 = r8
            goto L76
        L74:
            r7.f438f0 = r2
        L76:
            r7.H()
        L79:
            return
        L7a:
            androidx.appcompat.widget.f3.t(r0)
            return
        L7e:
            androidx.appcompat.widget.f3.t(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.n(android.view.Window):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:113:0x01bd
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1182)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.collectHandlerRegions(ExcHandlersRegionMaker.java:53)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.process(ExcHandlersRegionMaker.java:38)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:27)
        */
    @Override // android.view.LayoutInflater.Factory2
    public final android.view.View onCreateView(android.view.View r9, java.lang.String r10, android.content.Context r11, android.util.AttributeSet r12) {
        /*
            Method dump skipped, instruction units count: 690
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.onCreateView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    public final void p(int i7, b0 b0Var, g.l lVar) {
        if (lVar == null) {
            if (b0Var == null && i7 >= 0) {
                b0[] b0VarArr = this.L;
                if (i7 < b0VarArr.length) {
                    b0Var = b0VarArr[i7];
                }
            }
            if (b0Var != null) {
                lVar = b0Var.f407h;
            }
        }
        if ((b0Var == null || b0Var.f412m) && !this.Q) {
            v vVar = this.f443m;
            Window.Callback callback = this.f442l.getCallback();
            vVar.getClass();
            try {
                vVar.f555d = true;
                callback.onPanelClosed(i7, lVar);
            } finally {
                vVar.f555d = false;
            }
        }
    }

    public final void q(g.l lVar) {
        androidx.appcompat.widget.l lVar2;
        if (this.K) {
            return;
        }
        this.K = true;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f448r;
        actionBarOverlayLayout.k();
        ActionMenuView actionMenuView = ((v3) actionBarOverlayLayout.e).f938a.f680a;
        if (actionMenuView != null && (lVar2 = actionMenuView.f642t) != null) {
            lVar2.c();
            androidx.appcompat.widget.f fVar = lVar2.f851u;
            if (fVar != null && fVar.b()) {
                fVar.f5820i.dismiss();
            }
        }
        Window.Callback callback = this.f442l.getCallback();
        if (callback != null && !this.Q) {
            callback.onPanelClosed(108, lVar);
        }
        this.K = false;
    }

    public final void r(b0 b0Var, boolean z6) {
        z zVar;
        ActionBarOverlayLayout actionBarOverlayLayout;
        androidx.appcompat.widget.l lVar;
        if (z6 && b0Var.f402a == 0 && (actionBarOverlayLayout = this.f448r) != null) {
            actionBarOverlayLayout.k();
            ActionMenuView actionMenuView = ((v3) actionBarOverlayLayout.e).f938a.f680a;
            if (actionMenuView != null && (lVar = actionMenuView.f642t) != null && lVar.h()) {
                q(b0Var.f407h);
                return;
            }
        }
        WindowManager windowManager = (WindowManager) this.f441k.getSystemService("window");
        if (windowManager != null && b0Var.f412m && (zVar = b0Var.e) != null) {
            windowManager.removeView(zVar);
            if (z6) {
                p(b0Var.f402a, b0Var, null);
            }
        }
        b0Var.f410k = false;
        b0Var.f411l = false;
        b0Var.f412m = false;
        b0Var.f405f = null;
        b0Var.f413n = true;
        if (this.M == b0Var) {
            this.M = null;
        }
        if (b0Var.f402a == 0) {
            H();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0115  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean t(android.view.KeyEvent r7) {
        /*
            Method dump skipped, instruction units count: 313
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.c0.t(android.view.KeyEvent):boolean");
    }

    public final void u(int i7) {
        b0 b0VarY = y(i7);
        if (b0VarY.f407h != null) {
            Bundle bundle = new Bundle();
            b0VarY.f407h.t(bundle);
            if (bundle.size() > 0) {
                b0VarY.f415p = bundle;
            }
            b0VarY.f407h.w();
            b0VarY.f407h.clear();
        }
        b0VarY.f414o = true;
        b0VarY.f413n = true;
        if ((i7 == 108 || i7 == 0) && this.f448r != null) {
            b0 b0VarY2 = y(0);
            b0VarY2.f410k = false;
            F(b0VarY2, null);
        }
    }

    public final void v() {
        ViewGroup viewGroup;
        if (this.f456z) {
            return;
        }
        Context context = this.f441k;
        int[] iArr = d.a.f5210j;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(iArr);
        if (!typedArrayObtainStyledAttributes.hasValue(117)) {
            typedArrayObtainStyledAttributes.recycle();
            f3.t("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
            return;
        }
        if (typedArrayObtainStyledAttributes.getBoolean(126, false)) {
            f(1);
        } else if (typedArrayObtainStyledAttributes.getBoolean(117, false)) {
            f(108);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(118, false)) {
            f(109);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(119, false)) {
            f(10);
        }
        this.I = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        w();
        this.f442l.getDecorView();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        if (this.J) {
            viewGroup = this.H ? (ViewGroup) layoutInflaterFrom.inflate(2131492886, (ViewGroup) null) : (ViewGroup) layoutInflaterFrom.inflate(2131492885, (ViewGroup) null);
        } else if (this.I) {
            viewGroup = (ViewGroup) layoutInflaterFrom.inflate(2131492876, (ViewGroup) null);
            this.G = false;
            this.F = false;
        } else if (this.F) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(2130968587, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new f.d(context, typedValue.resourceId) : context).inflate(2131492887, (ViewGroup) null);
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) viewGroup.findViewById(2131296417);
            this.f448r = actionBarOverlayLayout;
            actionBarOverlayLayout.setWindowCallback(this.f442l.getCallback());
            if (this.G) {
                this.f448r.j(109);
            }
            if (this.D) {
                this.f448r.j(2);
            }
            if (this.E) {
                this.f448r.j(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.F + ", windowActionBarOverlay: " + this.G + ", android:windowIsFloating: " + this.I + ", windowActionModeOverlay: " + this.H + ", windowNoTitle: " + this.J + " }");
        }
        r rVar = new r(this, 0);
        WeakHashMap weakHashMap = s0.f5582a;
        f0.h0.u(viewGroup, rVar);
        if (this.f448r == null) {
            this.B = (TextView) viewGroup.findViewById(2131296778);
        }
        Method method = z3.f986a;
        try {
            Method method2 = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
            if (!method2.isAccessible()) {
                method2.setAccessible(true);
            }
            method2.invoke(viewGroup, null);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
        }
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(2131296309);
        ViewGroup viewGroup2 = (ViewGroup) this.f442l.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f442l.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new r(this, 1));
        this.A = viewGroup;
        Object obj = this.f440j;
        CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.f447q;
        if (!TextUtils.isEmpty(title)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f448r;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setWindowTitle(title);
            } else {
                o0 o0Var = this.f445o;
                if (o0Var != null) {
                    v3 v3Var = (v3) o0Var.e;
                    if (!v3Var.f942g) {
                        Toolbar toolbar = v3Var.f938a;
                        v3Var.f943h = title;
                        if ((v3Var.b & 8) != 0) {
                            toolbar.setTitle(title);
                            if (v3Var.f942g) {
                                s0.k(toolbar.getRootView(), title);
                            }
                        }
                    }
                } else {
                    TextView textView = this.B;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
        }
        ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.A.findViewById(R.id.content);
        View decorView = this.f442l.getDecorView();
        contentFrameLayout2.f657g.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        WeakHashMap weakHashMap2 = s0.f5582a;
        if (f0.e0.c(contentFrameLayout2)) {
            contentFrameLayout2.requestLayout();
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(iArr);
        typedArrayObtainStyledAttributes2.getValue(124, contentFrameLayout2.getMinWidthMajor());
        typedArrayObtainStyledAttributes2.getValue(125, contentFrameLayout2.getMinWidthMinor());
        if (typedArrayObtainStyledAttributes2.hasValue(UMErrorCode.E_UM_BE_ERROR_WORK_MODE)) {
            typedArrayObtainStyledAttributes2.getValue(UMErrorCode.E_UM_BE_ERROR_WORK_MODE, contentFrameLayout2.getFixedWidthMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(123)) {
            typedArrayObtainStyledAttributes2.getValue(123, contentFrameLayout2.getFixedWidthMinor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(UMErrorCode.E_UM_BE_NOT_MAINPROCESS)) {
            typedArrayObtainStyledAttributes2.getValue(UMErrorCode.E_UM_BE_NOT_MAINPROCESS, contentFrameLayout2.getFixedHeightMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(UMErrorCode.E_UM_BE_EMPTY_URL_PATH)) {
            typedArrayObtainStyledAttributes2.getValue(UMErrorCode.E_UM_BE_EMPTY_URL_PATH, contentFrameLayout2.getFixedHeightMinor());
        }
        typedArrayObtainStyledAttributes2.recycle();
        contentFrameLayout2.requestLayout();
        this.f456z = true;
        b0 b0VarY = y(0);
        if (this.Q || b0VarY.f407h != null) {
            return;
        }
        A(108);
    }

    public final void w() {
        if (this.f442l == null) {
            Object obj = this.f440j;
            if (obj instanceof Activity) {
                n(((Activity) obj).getWindow());
            }
        }
        if (this.f442l != null) {
            return;
        }
        f3.t("We have not been given a Window");
    }

    public final y x(Context context) {
        if (this.W == null) {
            if (y2.e.f8963f == null) {
                Context applicationContext = context.getApplicationContext();
                y2.e.f8963f = new y2.e(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.W = new w(this, y2.e.f8963f);
        }
        return this.W;
    }

    public final b0 y(int i7) {
        b0[] b0VarArr = this.L;
        if (b0VarArr == null || b0VarArr.length <= i7) {
            b0[] b0VarArr2 = new b0[i7 + 1];
            if (b0VarArr != null) {
                System.arraycopy(b0VarArr, 0, b0VarArr2, 0, b0VarArr.length);
            }
            this.L = b0VarArr2;
            b0VarArr = b0VarArr2;
        }
        b0 b0Var = b0VarArr[i7];
        if (b0Var != null) {
            return b0Var;
        }
        b0 b0Var2 = new b0();
        b0Var2.f402a = i7;
        b0Var2.f413n = false;
        b0VarArr[i7] = b0Var2;
        return b0Var2;
    }

    public final void z() {
        v();
        if (this.F && this.f445o == null) {
            Object obj = this.f440j;
            if (obj instanceof Activity) {
                this.f445o = new o0((Activity) obj, this.G);
            } else if (obj instanceof Dialog) {
                this.f445o = new o0((Dialog) obj);
            }
            o0 o0Var = this.f445o;
            if (o0Var != null) {
                o0Var.d(this.f434b0);
            }
        }
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
