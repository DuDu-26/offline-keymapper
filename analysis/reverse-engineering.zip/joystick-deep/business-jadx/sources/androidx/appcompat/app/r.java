package androidx.appcompat.app;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.k1;
import androidx.appcompat.widget.z3;
import f0.l1;
import f0.m1;
import f0.n1;
import f0.o1;
import f0.s0;
import f0.w1;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class r implements f0.r, k1, g.x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f551a;
    public final /* synthetic */ c0 b;

    public /* synthetic */ r(c0 c0Var, int i7) {
        this.f551a = i7;
        this.b = c0Var;
    }

    @Override // g.x
    public void d(g.l lVar, boolean z6) {
        b0 b0Var;
        switch (this.f551a) {
            case 2:
                this.b.q(lVar);
                break;
            default:
                g.l lVarK = lVar.k();
                int i7 = 0;
                boolean z7 = lVarK != lVar;
                if (z7) {
                    lVar = lVarK;
                }
                c0 c0Var = this.b;
                b0[] b0VarArr = c0Var.L;
                int length = b0VarArr != null ? b0VarArr.length : 0;
                while (true) {
                    if (i7 >= length) {
                        b0Var = null;
                    } else {
                        b0Var = b0VarArr[i7];
                        if (b0Var == null || b0Var.f407h != lVar) {
                            i7++;
                        }
                    }
                }
                if (b0Var != null) {
                    if (!z7) {
                        c0Var.r(b0Var, z6);
                    } else {
                        c0Var.p(b0Var.f402a, b0Var, lVarK);
                        c0Var.r(b0Var, true);
                    }
                }
                break;
        }
    }

    @Override // f0.r
    public w1 k(View view, w1 w1Var) {
        boolean z6;
        boolean z7;
        boolean z8;
        w1 w1VarB = w1Var;
        int iD = w1VarB.d();
        c0 c0Var = this.b;
        Context context = c0Var.f441k;
        int iD2 = w1VarB.d();
        ActionBarContextView actionBarContextView = c0Var.f452v;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z6 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) c0Var.f452v.getLayoutParams();
            if (c0Var.f452v.isShown()) {
                if (c0Var.f435c0 == null) {
                    c0Var.f435c0 = new Rect();
                    c0Var.f436d0 = new Rect();
                }
                Rect rect = c0Var.f435c0;
                Rect rect2 = c0Var.f436d0;
                rect.set(w1VarB.b(), w1VarB.d(), w1VarB.c(), w1VarB.a());
                ViewGroup viewGroup = c0Var.A;
                Method method = z3.f986a;
                if (method != null) {
                    try {
                        method.invoke(viewGroup, rect, rect2);
                    } catch (Exception unused) {
                    }
                }
                int i7 = rect.top;
                int i8 = rect.left;
                int i9 = rect.right;
                ViewGroup viewGroup2 = c0Var.A;
                WeakHashMap weakHashMap = s0.f5582a;
                w1 w1VarA = f0.i0.a(viewGroup2);
                int iB = w1VarA == null ? 0 : w1VarA.b();
                int iC = w1VarA == null ? 0 : w1VarA.c();
                if (marginLayoutParams.topMargin == i7 && marginLayoutParams.leftMargin == i8 && marginLayoutParams.rightMargin == i9) {
                    z8 = false;
                } else {
                    marginLayoutParams.topMargin = i7;
                    marginLayoutParams.leftMargin = i8;
                    marginLayoutParams.rightMargin = i9;
                    z8 = true;
                }
                if (i7 <= 0 || c0Var.C != null) {
                    View view2 = c0Var.C;
                    if (view2 != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
                        int i10 = marginLayoutParams2.height;
                        int i11 = marginLayoutParams.topMargin;
                        if (i10 != i11 || marginLayoutParams2.leftMargin != iB || marginLayoutParams2.rightMargin != iC) {
                            marginLayoutParams2.height = i11;
                            marginLayoutParams2.leftMargin = iB;
                            marginLayoutParams2.rightMargin = iC;
                            c0Var.C.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view3 = new View(context);
                    c0Var.C = view3;
                    view3.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = iB;
                    layoutParams.rightMargin = iC;
                    c0Var.A.addView(c0Var.C, -1, layoutParams);
                }
                View view4 = c0Var.C;
                boolean z9 = view4 != null;
                if (z9 && view4.getVisibility() != 0) {
                    View view5 = c0Var.C;
                    view5.setBackgroundColor((f0.b0.g(view5) & 8192) != 0 ? androidx.core.content.c.a(context, 2131099654) : androidx.core.content.c.a(context, 2131099653));
                }
                if (!c0Var.H && z9) {
                    iD2 = 0;
                }
                z6 = z9;
                z7 = z8;
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                z6 = false;
                z7 = true;
            } else {
                z6 = false;
                z7 = false;
            }
            if (z7) {
                c0Var.f452v.setLayoutParams(marginLayoutParams);
            }
        }
        View view6 = c0Var.C;
        if (view6 != null) {
            view6.setVisibility(z6 ? 0 : 8);
        }
        if (iD != iD2) {
            int iB2 = w1VarB.b();
            int iC2 = w1VarB.c();
            int iA = w1VarB.a();
            int i12 = Build.VERSION.SDK_INT;
            o1 n1Var = i12 >= 30 ? new n1(w1VarB) : i12 >= 29 ? new m1(w1VarB) : new l1(w1VarB);
            n1Var.g(x.c.b(iB2, iD2, iC2, iA));
            w1VarB = n1Var.b();
        }
        WeakHashMap weakHashMap2 = s0.f5582a;
        WindowInsets windowInsetsF = w1VarB.f();
        if (windowInsetsF == null) {
            return w1VarB;
        }
        WindowInsets windowInsetsB = f0.f0.b(view, windowInsetsF);
        return !windowInsetsB.equals(windowInsetsF) ? w1.g(view, windowInsetsB) : w1VarB;
    }

    @Override // g.x
    public boolean m(g.l lVar) {
        Window.Callback callback;
        switch (this.f551a) {
            case 2:
                Window.Callback callback2 = this.b.f442l.getCallback();
                if (callback2 != null) {
                    callback2.onMenuOpened(108, lVar);
                }
                break;
            default:
                if (lVar == lVar.k()) {
                    c0 c0Var = this.b;
                    if (c0Var.F && (callback = c0Var.f442l.getCallback()) != null && !c0Var.Q) {
                        callback.onMenuOpened(108, lVar);
                        break;
                    }
                }
                break;
        }
        return true;
    }
}
