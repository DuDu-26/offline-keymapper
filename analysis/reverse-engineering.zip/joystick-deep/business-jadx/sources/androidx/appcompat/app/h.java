package androidx.appcompat.app;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.window.OnBackInvokedDispatcher;
import androidx.core.widget.NestedScrollView;
import f0.s0;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h extends Dialog implements DialogInterface, l, androidx.lifecycle.r, u0.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.lifecycle.t f493a;
    public final androidx.activity.o b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final androidx.activity.x f494c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public c0 f495d;
    public final d0 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final f f496f;

    public h(ContextThemeWrapper contextThemeWrapper, int i7) {
        int i8;
        int iH = h(contextThemeWrapper, i7);
        if (iH == 0) {
            TypedValue typedValue = new TypedValue();
            contextThemeWrapper.getTheme().resolveAttribute(2130968954, typedValue, true);
            i8 = typedValue.resourceId;
        } else {
            i8 = iH;
        }
        super(contextThemeWrapper, i8);
        this.b = new androidx.activity.o(this);
        this.f494c = new androidx.activity.x(new a4.n(10, this));
        this.e = new d0(this);
        p pVarC = c();
        if (iH == 0) {
            TypedValue typedValue2 = new TypedValue();
            contextThemeWrapper.getTheme().resolveAttribute(2130968954, typedValue2, true);
            iH = typedValue2.resourceId;
        }
        ((c0) pVarC).T = iH;
        pVarC.c();
        this.f496f = new f(getContext(), this, getWindow());
    }

    public static void b(h hVar) {
        super.onBackPressed();
    }

    public static int h(Context context, int i7) {
        if (((i7 >>> 24) & 255) >= 1) {
            return i7;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(2130968620, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // u0.d
    public final androidx.appcompat.widget.v a() {
        return (androidx.appcompat.widget.v) this.b.f362c;
    }

    @Override // android.app.Dialog
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c0 c0Var = (c0) c();
        c0Var.v();
        ((ViewGroup) c0Var.A.findViewById(R.id.content)).addView(view, layoutParams);
        c0Var.f443m.a(c0Var.f442l.getCallback());
    }

    public final p c() {
        if (this.f495d == null) {
            i0 i0Var = p.f543a;
            this.f495d = new c0(getContext(), getWindow(), this, this);
        }
        return this.f495d;
    }

    @Override // androidx.lifecycle.r
    public final androidx.lifecycle.t d() {
        androidx.lifecycle.t tVar = this.f493a;
        if (tVar != null) {
            return tVar;
        }
        androidx.lifecycle.t tVar2 = new androidx.lifecycle.t(this);
        this.f493a = tVar2;
        return tVar2;
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public final void dismiss() {
        super.dismiss();
        c().d();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        getWindow().getDecorView();
        d0 d0Var = this.e;
        if (d0Var == null) {
            return false;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public final void e(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherD = androidx.activity.n.d(this);
            onBackInvokedDispatcherD.getClass();
            androidx.activity.x xVar = this.f494c;
            xVar.getClass();
            xVar.e = onBackInvokedDispatcherD;
            xVar.c(xVar.f396g);
        }
        this.b.b(bundle);
        androidx.lifecycle.t tVar = this.f493a;
        if (tVar == null) {
            tVar = new androidx.lifecycle.t(this);
            this.f493a = tVar;
        }
        tVar.d(androidx.lifecycle.l.ON_CREATE);
    }

    public final void f(Bundle bundle) {
        c0 c0Var = (c0) c();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(c0Var.f441k);
        if (layoutInflaterFrom.getFactory() == null) {
            layoutInflaterFrom.setFactory2(c0Var);
        } else {
            layoutInflaterFrom.getFactory2();
        }
        e(bundle);
        c().c();
    }

    @Override // android.app.Dialog
    public final View findViewById(int i7) {
        c0 c0Var = (c0) c();
        c0Var.v();
        return c0Var.f442l.findViewById(i7);
    }

    public final void g() {
        androidx.lifecycle.t tVar = this.f493a;
        if (tVar == null) {
            tVar = new androidx.lifecycle.t(this);
            this.f493a = tVar;
        }
        tVar.d(androidx.lifecycle.l.ON_DESTROY);
        this.f493a = null;
        super.onStop();
    }

    public final void i(CharSequence charSequence) {
        super.setTitle(charSequence);
        c().k(charSequence);
    }

    @Override // android.app.Dialog
    public final void invalidateOptionsMenu() {
        c().a();
    }

    @Override // android.app.Dialog
    public final void onBackPressed() {
        this.f494c.b();
    }

    @Override // android.app.Dialog
    public final void onCreate(Bundle bundle) {
        int i7;
        ListAdapter listAdapter;
        View viewFindViewById;
        f(bundle);
        f fVar = this.f496f;
        fVar.b.setContentView(fVar.f483x);
        Context context = fVar.f462a;
        Window window = fVar.f463c;
        View viewFindViewById2 = window.findViewById(2131296643);
        View viewFindViewById3 = viewFindViewById2.findViewById(2131296787);
        View viewFindViewById4 = viewFindViewById2.findViewById(2131296403);
        View viewFindViewById5 = viewFindViewById2.findViewById(2131296372);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById2.findViewById(2131296412);
        window.setFlags(131072, 131072);
        viewGroup.setVisibility(8);
        View viewFindViewById6 = viewGroup.findViewById(2131296787);
        View viewFindViewById7 = viewGroup.findViewById(2131296403);
        View viewFindViewById8 = viewGroup.findViewById(2131296372);
        ViewGroup viewGroupA = f.a(viewFindViewById6, viewFindViewById3);
        ViewGroup viewGroupA2 = f.a(viewFindViewById7, viewFindViewById4);
        ViewGroup viewGroupA3 = f.a(viewFindViewById8, viewFindViewById5);
        NestedScrollView nestedScrollView = (NestedScrollView) window.findViewById(2131296685);
        fVar.f475p = nestedScrollView;
        nestedScrollView.setFocusable(false);
        fVar.f475p.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroupA2.findViewById(R.id.message);
        fVar.f479t = textView;
        if (textView != null) {
            CharSequence charSequence = fVar.e;
            if (charSequence != null) {
                textView.setText(charSequence);
            } else {
                textView.setVisibility(8);
                fVar.f475p.removeView(fVar.f479t);
                if (fVar.f465f != null) {
                    ViewGroup viewGroup2 = (ViewGroup) fVar.f475p.getParent();
                    int iIndexOfChild = viewGroup2.indexOfChild(fVar.f475p);
                    viewGroup2.removeViewAt(iIndexOfChild);
                    viewGroup2.addView(fVar.f465f, iIndexOfChild, new ViewGroup.LayoutParams(-1, -1));
                } else {
                    viewGroupA2.setVisibility(8);
                }
            }
        }
        Button button = (Button) viewGroupA3.findViewById(R.id.button1);
        fVar.f466g = button;
        a aVar = fVar.D;
        button.setOnClickListener(aVar);
        boolean zIsEmpty = TextUtils.isEmpty(fVar.f467h);
        Button button2 = fVar.f466g;
        if (zIsEmpty) {
            button2.setVisibility(8);
            i7 = 0;
        } else {
            button2.setText(fVar.f467h);
            fVar.f466g.setVisibility(0);
            i7 = 1;
        }
        Button button3 = (Button) viewGroupA3.findViewById(R.id.button2);
        fVar.f469j = button3;
        button3.setOnClickListener(aVar);
        boolean zIsEmpty2 = TextUtils.isEmpty(fVar.f470k);
        Button button4 = fVar.f469j;
        if (zIsEmpty2) {
            button4.setVisibility(8);
        } else {
            button4.setText(fVar.f470k);
            fVar.f469j.setVisibility(0);
            i7 |= 2;
        }
        Button button5 = (Button) viewGroupA3.findViewById(R.id.button3);
        fVar.f472m = button5;
        button5.setOnClickListener(aVar);
        boolean zIsEmpty3 = TextUtils.isEmpty(fVar.f473n);
        Button button6 = fVar.f472m;
        if (zIsEmpty3) {
            button6.setVisibility(8);
        } else {
            button6.setText(fVar.f473n);
            fVar.f472m.setVisibility(0);
            i7 |= 4;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(2130968618, typedValue, true);
        if (typedValue.data != 0) {
            if (i7 == 1) {
                Button button7 = fVar.f466g;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button7.getLayoutParams();
                layoutParams.gravity = 1;
                layoutParams.weight = 0.5f;
                button7.setLayoutParams(layoutParams);
            } else if (i7 == 2) {
                Button button8 = fVar.f469j;
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) button8.getLayoutParams();
                layoutParams2.gravity = 1;
                layoutParams2.weight = 0.5f;
                button8.setLayoutParams(layoutParams2);
            } else if (i7 == 4) {
                Button button9 = fVar.f472m;
                LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) button9.getLayoutParams();
                layoutParams3.gravity = 1;
                layoutParams3.weight = 0.5f;
                button9.setLayoutParams(layoutParams3);
            }
        }
        if (i7 == 0) {
            viewGroupA3.setVisibility(8);
        }
        if (fVar.f480u != null) {
            viewGroupA.addView(fVar.f480u, 0, new ViewGroup.LayoutParams(-1, -2));
            window.findViewById(2131296782).setVisibility(8);
        } else {
            fVar.f477r = (ImageView) window.findViewById(R.id.icon);
            if (TextUtils.isEmpty(fVar.f464d) || !fVar.B) {
                window.findViewById(2131296782).setVisibility(8);
                fVar.f477r.setVisibility(8);
                viewGroupA.setVisibility(8);
            } else {
                TextView textView2 = (TextView) window.findViewById(2131296331);
                fVar.f478s = textView2;
                textView2.setText(fVar.f464d);
                Drawable drawable = fVar.f476q;
                if (drawable != null) {
                    fVar.f477r.setImageDrawable(drawable);
                } else {
                    fVar.f478s.setPadding(fVar.f477r.getPaddingLeft(), fVar.f477r.getPaddingTop(), fVar.f477r.getPaddingRight(), fVar.f477r.getPaddingBottom());
                    fVar.f477r.setVisibility(8);
                }
            }
        }
        boolean z6 = viewGroup.getVisibility() != 8;
        int i8 = (viewGroupA == null || viewGroupA.getVisibility() == 8) ? 0 : 1;
        boolean z7 = viewGroupA3.getVisibility() != 8;
        if (!z7 && (viewFindViewById = viewGroupA2.findViewById(2131296764)) != null) {
            viewFindViewById.setVisibility(0);
        }
        if (i8 != 0) {
            NestedScrollView nestedScrollView2 = fVar.f475p;
            if (nestedScrollView2 != null) {
                nestedScrollView2.setClipToPadding(true);
            }
            View viewFindViewById9 = (fVar.e == null && fVar.f465f == null) ? null : viewGroupA.findViewById(2131296779);
            if (viewFindViewById9 != null) {
                viewFindViewById9.setVisibility(0);
            }
        } else {
            View viewFindViewById10 = viewGroupA2.findViewById(2131296765);
            if (viewFindViewById10 != null) {
                viewFindViewById10.setVisibility(0);
            }
        }
        AlertController$RecycleListView alertController$RecycleListView = fVar.f465f;
        if (alertController$RecycleListView != null && (!z7 || i8 == 0)) {
            alertController$RecycleListView.setPadding(alertController$RecycleListView.getPaddingLeft(), i8 != 0 ? alertController$RecycleListView.getPaddingTop() : alertController$RecycleListView.f397a, alertController$RecycleListView.getPaddingRight(), z7 ? alertController$RecycleListView.getPaddingBottom() : alertController$RecycleListView.b);
        }
        if (!z6) {
            View view = fVar.f465f;
            if (view == null) {
                view = fVar.f475p;
            }
            if (view != null) {
                int i9 = z7 ? 2 : 0;
                View viewFindViewById11 = window.findViewById(2131296684);
                View viewFindViewById12 = window.findViewById(2131296683);
                WeakHashMap weakHashMap = s0.f5582a;
                f0.i0.d(view, i8 | i9, 3);
                if (viewFindViewById11 != null) {
                    viewGroupA2.removeView(viewFindViewById11);
                }
                if (viewFindViewById12 != null) {
                    viewGroupA2.removeView(viewFindViewById12);
                }
            }
        }
        AlertController$RecycleListView alertController$RecycleListView2 = fVar.f465f;
        if (alertController$RecycleListView2 == null || (listAdapter = fVar.f481v) == null) {
            return;
        }
        alertController$RecycleListView2.setAdapter(listAdapter);
        int i10 = fVar.f482w;
        if (i10 > -1) {
            alertController$RecycleListView2.setItemChecked(i10, true);
            alertController$RecycleListView2.setSelection(i10);
        }
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i7, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f496f.f475p;
        if (nestedScrollView == null || !nestedScrollView.j(keyEvent)) {
            return super.onKeyDown(i7, keyEvent);
        }
        return true;
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i7, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f496f.f475p;
        if (nestedScrollView == null || !nestedScrollView.j(keyEvent)) {
            return super.onKeyUp(i7, keyEvent);
        }
        return true;
    }

    @Override // android.app.Dialog
    public final Bundle onSaveInstanceState() {
        Bundle bundleOnSaveInstanceState = super.onSaveInstanceState();
        bundleOnSaveInstanceState.getClass();
        this.b.c(bundleOnSaveInstanceState);
        return bundleOnSaveInstanceState;
    }

    @Override // android.app.Dialog
    public final void onStart() {
        super.onStart();
        androidx.lifecycle.t tVar = this.f493a;
        if (tVar == null) {
            tVar = new androidx.lifecycle.t(this);
            this.f493a = tVar;
        }
        tVar.d(androidx.lifecycle.l.ON_RESUME);
    }

    @Override // android.app.Dialog
    public final void onStop() {
        g();
        c0 c0Var = (c0) c();
        c0Var.z();
        o0 o0Var = c0Var.f445o;
        if (o0Var != null) {
            o0Var.f538t = false;
            f.j jVar = o0Var.f537s;
            if (jVar != null) {
                jVar.a();
            }
        }
    }

    @Override // android.app.Dialog
    public final void setContentView(int i7) {
        c().g(i7);
    }

    @Override // android.app.Dialog
    public final void setTitle(int i7) {
        super.setTitle(i7);
        c().k(getContext().getString(i7));
    }

    @Override // android.app.Dialog
    public final void setContentView(View view) {
        c().i(view);
    }

    @Override // android.app.Dialog
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c().j(view, layoutParams);
    }

    @Override // android.app.Dialog
    public final void setTitle(CharSequence charSequence) {
        i(charSequence);
        f fVar = this.f496f;
        fVar.f464d = charSequence;
        TextView textView = fVar.f478s;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }
}
