package androidx.appcompat.app;

import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import e4.r0;
import f0.s0;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class m0 extends r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f514a;
    public final /* synthetic */ o0 b;

    public /* synthetic */ m0(o0 o0Var, int i7) {
        this.f514a = i7;
        this.b = o0Var;
    }

    @Override // f0.y0
    public final void c() {
        View view;
        int i7 = this.f514a;
        o0 o0Var = this.b;
        switch (i7) {
            case 0:
                if (o0Var.f533o && (view = o0Var.f525g) != null) {
                    view.setTranslationY(0.0f);
                    o0Var.f523d.setTranslationY(0.0f);
                }
                o0Var.f523d.setVisibility(8);
                o0Var.f523d.setTransitioning(false);
                o0Var.f537s = null;
                y2.o oVar = o0Var.f529k;
                if (oVar != null) {
                    oVar.y(o0Var.f528j);
                    o0Var.f528j = null;
                    o0Var.f529k = null;
                }
                ActionBarOverlayLayout actionBarOverlayLayout = o0Var.f522c;
                if (actionBarOverlayLayout != null) {
                    WeakHashMap weakHashMap = s0.f5582a;
                    f0.f0.c(actionBarOverlayLayout);
                }
                break;
            default:
                o0Var.f537s = null;
                o0Var.f523d.requestLayout();
                break;
        }
    }
}
