package androidx.appcompat.app;

import android.content.Context;
import androidx.profileinstaller.ProfileInstallerInitializer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f513a;
    public final /* synthetic */ Context b;

    public /* synthetic */ m(ProfileInstallerInitializer profileInstallerInitializer, Context context) {
        this.f513a = 1;
        this.b = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00c3  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instruction units count: 232
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.m.run():void");
    }

    public /* synthetic */ m(Context context, int i7) {
        this.f513a = i7;
        this.b = context;
    }
}
