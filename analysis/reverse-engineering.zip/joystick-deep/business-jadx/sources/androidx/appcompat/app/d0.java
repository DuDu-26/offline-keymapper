package androidx.appcompat.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class d0 implements f0.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ h f458a;

    public /* synthetic */ d0(h hVar) {
        this.f458a = hVar;
    }
}
