package androidx.appcompat.app;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i0 implements Executor {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f499a = new Object();
    public final ArrayDeque b = new ArrayDeque();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final j0 f500c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Runnable f501d;

    public i0(j0 j0Var) {
        this.f500c = j0Var;
    }

    public final void a() {
        synchronized (this.f499a) {
            try {
                Runnable runnable = (Runnable) this.b.poll();
                this.f501d = runnable;
                if (runnable != null) {
                    this.f500c.execute(runnable);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        synchronized (this.f499a) {
            try {
                this.b.add(new a3.e(this, 18, runnable));
                if (this.f501d == null) {
                    a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
