package androidx.appcompat.app;

import a4.y0;
import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n0 extends f.a implements g.j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f515c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final g.l f516d;
    public y2.o e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public WeakReference f517f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ o0 f518g;

    public n0(o0 o0Var, Context context, y2.o oVar) {
        this.f518g = o0Var;
        this.f515c = context;
        this.e = oVar;
        g.l lVar = new g.l(context);
        lVar.f5767l = 1;
        this.f516d = lVar;
        lVar.e = this;
    }

    @Override // f.a
    public final void a() {
        o0 o0Var = this.f518g;
        if (o0Var.f527i != this) {
            return;
        }
        if (o0Var.f534p) {
            o0Var.f528j = this;
            o0Var.f529k = this.e;
        } else {
            this.e.y(this);
        }
        this.e = null;
        o0Var.a(false);
        ActionBarContextView actionBarContextView = o0Var.f524f;
        if (actionBarContextView.f603k == null) {
            actionBarContextView.e();
        }
        o0Var.f522c.setHideOnContentScrollEnabled(o0Var.f539u);
        o0Var.f527i = null;
    }

    @Override // f.a
    public final View b() {
        WeakReference weakReference = this.f517f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // f.a
    public final g.l c() {
        return this.f516d;
    }

    @Override // f.a
    public final MenuInflater d() {
        return new f.i(this.f515c);
    }

    @Override // f.a
    public final CharSequence e() {
        return this.f518g.f524f.getSubtitle();
    }

    @Override // f.a
    public final CharSequence f() {
        return this.f518g.f524f.getTitle();
    }

    @Override // f.a
    public final void g() {
        if (this.f518g.f527i != this) {
            return;
        }
        g.l lVar = this.f516d;
        lVar.w();
        try {
            this.e.z(this, lVar);
        } finally {
            lVar.v();
        }
    }

    @Override // g.j
    public final boolean h(g.l lVar, MenuItem menuItem) {
        y2.o oVar = this.e;
        if (oVar != null) {
            return ((y0) oVar.b).k(this, menuItem);
        }
        return false;
    }

    @Override // f.a
    public final boolean i() {
        return this.f518g.f524f.f611s;
    }

    @Override // f.a
    public final void j(View view) {
        this.f518g.f524f.setCustomView(view);
        this.f517f = new WeakReference(view);
    }

    @Override // f.a
    public final void k(int i7) {
        m(this.f518g.f521a.getResources().getString(i7));
    }

    @Override // g.j
    public final void l(g.l lVar) {
        if (this.e == null) {
            return;
        }
        g();
        androidx.appcompat.widget.l lVar2 = this.f518g.f524f.f597d;
        if (lVar2 != null) {
            lVar2.n();
        }
    }

    @Override // f.a
    public final void m(CharSequence charSequence) {
        this.f518g.f524f.setSubtitle(charSequence);
    }

    @Override // f.a
    public final void n(int i7) {
        o(this.f518g.f521a.getResources().getString(i7));
    }

    @Override // f.a
    public final void o(CharSequence charSequence) {
        this.f518g.f524f.setTitle(charSequence);
    }

    @Override // f.a
    public final void p(boolean z6) {
        this.b = z6;
        this.f518g.f524f.setTitleOptional(z6);
    }
}
