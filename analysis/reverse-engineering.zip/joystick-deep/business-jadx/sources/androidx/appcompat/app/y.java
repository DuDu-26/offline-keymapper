package androidx.appcompat.app;

import android.content.Context;
import android.content.IntentFilter;
import android.view.MenuItem;
import androidx.fragment.app.t0;
import java.util.HashSet;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f559a;
    public Object b;

    public y(t0 t0Var, b0.b bVar) {
        this.f559a = t0Var;
        this.b = bVar;
    }

    public void c() {
        x xVar = (x) this.f559a;
        if (xVar != null) {
            try {
                ((c0) this.b).f441k.unregisterReceiver(xVar);
            } catch (IllegalArgumentException unused) {
            }
            this.f559a = null;
        }
    }

    public void d() {
        t0 t0Var = (t0) this.f559a;
        b0.b bVar = (b0.b) this.b;
        HashSet hashSet = t0Var.e;
        if (hashSet.remove(bVar) && hashSet.isEmpty()) {
            t0Var.b();
        }
    }

    public abstract IntentFilter e();

    public abstract int f();

    public MenuItem g(MenuItem menuItem) {
        if (!(menuItem instanceof z.a)) {
            return menuItem;
        }
        z.a aVar = (z.a) menuItem;
        if (((l.k) this.b) == null) {
            this.b = new l.k();
        }
        MenuItem menuItem2 = (MenuItem) ((l.k) this.b).getOrDefault(aVar, null);
        if (menuItem2 != null) {
            return menuItem2;
        }
        g.s sVar = new g.s((Context) this.f559a, aVar);
        ((l.k) this.b).put(aVar, sVar);
        return sVar;
    }

    public abstract void h();

    public void i() {
        c();
        IntentFilter intentFilterE = e();
        if (intentFilterE.countActions() == 0) {
            return;
        }
        if (((x) this.f559a) == null) {
            this.f559a = new x(this);
        }
        ((c0) this.b).f441k.registerReceiver((x) this.f559a, intentFilterE);
    }

    public y(Context context) {
        this.f559a = context;
    }

    public y(c0 c0Var) {
        this.b = c0Var;
    }
}
