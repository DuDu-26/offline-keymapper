package androidx.appcompat.app;

import android.view.LayoutInflater;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j implements a.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f502a;

    public j(MainActivity mainActivity) {
        this.f502a = mainActivity;
    }

    @Override // a.a
    public final void a() {
        MainActivity mainActivity = this.f502a;
        p pVarJ = mainActivity.j();
        c0 c0Var = (c0) pVarJ;
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(c0Var.f441k);
        if (layoutInflaterFrom.getFactory() == null) {
            layoutInflaterFrom.setFactory2(c0Var);
        } else {
            layoutInflaterFrom.getFactory2();
        }
        ((androidx.appcompat.widget.v) mainActivity.e.f362c).c("androidx:appcompat");
        pVarJ.c();
    }
}
