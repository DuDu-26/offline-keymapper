package androidx.appcompat.app;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListAdapter;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ContextThemeWrapper f416a;
    public final LayoutInflater b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f417c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f418d;
    public View e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public CharSequence f419f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public CharSequence f420g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f421h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public m4.a f422i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public m4.c f424k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public g.m f425l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ListAdapter f426m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public DialogInterface.OnClickListener f427n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f428o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f429p = -1;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f423j = true;

    public c(ContextThemeWrapper contextThemeWrapper) {
        this.f416a = contextThemeWrapper;
        this.b = (LayoutInflater) contextThemeWrapper.getSystemService("layout_inflater");
    }
}
