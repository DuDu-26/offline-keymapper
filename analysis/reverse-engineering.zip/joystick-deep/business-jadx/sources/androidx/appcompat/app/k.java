package androidx.appcompat.app;

import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import androidx.appcompat.widget.n2;
import androidx.appcompat.widget.v3;
import androidx.appcompat.widget.x3;
import androidx.fragment.app.q0;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class k extends androidx.activity.m implements l {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final androidx.fragment.app.e f503p;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f505r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f506s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public c0 f508u;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final androidx.lifecycle.t f504q = new androidx.lifecycle.t(this);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f507t = true;

    public k() {
        MainActivity mainActivity = (MainActivity) this;
        this.f503p = new androidx.fragment.app.e(3, new androidx.fragment.app.x(mainActivity));
        ((androidx.appcompat.widget.v) this.e.f362c).e("android:support:fragments", new androidx.fragment.app.v(mainActivity));
        f(new androidx.fragment.app.w(mainActivity));
        ((androidx.appcompat.widget.v) this.e.f362c).e("androidx:appcompat", new i(mainActivity));
        f(new j(mainActivity));
    }

    public static boolean m(androidx.fragment.app.k0 k0Var) {
        boolean zM = false;
        for (androidx.fragment.app.u uVar : k0Var.f1226c.r()) {
            if (uVar != null) {
                androidx.fragment.app.x xVar = uVar.f1313s;
                if ((xVar == null ? null : xVar.e) != null) {
                    zM |= m(uVar.h());
                }
                q0 q0Var = uVar.M;
                androidx.lifecycle.m mVar = androidx.lifecycle.m.f1359c;
                androidx.lifecycle.m mVar2 = androidx.lifecycle.m.f1360d;
                if (q0Var != null) {
                    q0Var.f();
                    if (q0Var.b.f1365c.compareTo(mVar2) >= 0) {
                        androidx.lifecycle.t tVar = uVar.M.b;
                        tVar.c("setCurrentState");
                        tVar.e(mVar);
                        zM = true;
                    }
                }
                if (uVar.L.f1365c.compareTo(mVar2) >= 0) {
                    androidx.lifecycle.t tVar2 = uVar.L;
                    tVar2.c("setCurrentState");
                    tVar2.e(mVar);
                    zM = true;
                }
            }
        }
        return zM;
    }

    @Override // android.app.Activity
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        l();
        c0 c0Var = (c0) j();
        c0Var.v();
        ((ViewGroup) c0Var.A.findViewById(R.id.content)).addView(view, layoutParams);
        c0Var.f443m.a(c0Var.f442l.getCallback());
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00ae  */
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void attachBaseContext(android.content.Context r10) {
        /*
            Method dump skipped, instruction units count: 540
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.k.attachBaseContext(android.content.Context):void");
    }

    @Override // android.app.Activity
    public final void closeOptionsMenu() {
        ((c0) j()).z();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    @Override // androidx.activity.m, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getKeyCode();
        ((c0) j()).z();
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        r0.a aVar;
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f505r);
        printWriter.print(" mResumed=");
        printWriter.print(this.f506s);
        printWriter.print(" mStopped=");
        printWriter.print(this.f507t);
        if (getApplication() != null) {
            androidx.lifecycle.l0 l0VarC = c();
            l0VarC.getClass();
            q0.a aVar2 = q0.a.f7728c;
            aVar2.getClass();
            String canonicalName = r0.a.class.getCanonicalName();
            if (canonicalName == null) {
                f3.q("Local and anonymous classes can not be ViewModels");
                return;
            }
            String strConcat = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
            LinkedHashMap linkedHashMap = l0VarC.f1357a;
            androidx.lifecycle.j0 j0Var = (androidx.lifecycle.j0) linkedHashMap.get(strConcat);
            if (r0.a.class.isInstance(j0Var)) {
                j0Var.getClass();
            } else {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                linkedHashMap2.putAll((LinkedHashMap) aVar2.b);
                linkedHashMap2.put(androidx.lifecycle.k0.b, strConcat);
                try {
                    aVar = new r0.a();
                } catch (AbstractMethodError unused) {
                    aVar = new r0.a();
                }
                j0Var = aVar;
                androidx.lifecycle.j0 j0Var2 = (androidx.lifecycle.j0) linkedHashMap.put(strConcat, j0Var);
                if (j0Var2 != null) {
                    j0Var2.a();
                }
            }
            l.l lVar = ((r0.a) j0Var).f7875c;
            if (lVar.f6717c > 0) {
                printWriter.print(str2);
                printWriter.println("Loaders:");
                if (lVar.f6717c > 0) {
                    if (lVar.b[0] != null) {
                        f3.b();
                        return;
                    }
                    printWriter.print(str2);
                    printWriter.print("  #");
                    printWriter.print(lVar.f6716a[0]);
                    printWriter.print(": ");
                    throw null;
                }
            }
        }
        ((androidx.fragment.app.x) this.f503p.b).f1325d.t(str, fileDescriptor, printWriter, strArr);
    }

    @Override // android.app.Activity
    public final View findViewById(int i7) {
        c0 c0Var = (c0) j();
        c0Var.v();
        return c0Var.f442l.findViewById(i7);
    }

    @Override // android.app.Activity
    public final MenuInflater getMenuInflater() {
        c0 c0Var = (c0) j();
        if (c0Var.f446p == null) {
            c0Var.z();
            o0 o0Var = c0Var.f445o;
            c0Var.f446p = new f.i(o0Var != null ? o0Var.b() : c0Var.f441k);
        }
        return c0Var.f446p;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        int i7 = x3.f980a;
        return super.getResources();
    }

    @Override // android.app.Activity
    public final void invalidateOptionsMenu() {
        j().a();
    }

    public final p j() {
        if (this.f508u == null) {
            i0 i0Var = p.f543a;
            this.f508u = new c0(this, null, this, this);
        }
        return this.f508u;
    }

    public final androidx.fragment.app.k0 k() {
        return ((androidx.fragment.app.x) this.f503p.b).f1325d;
    }

    public final void l() {
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131296809, this);
        View decorView2 = getWindow().getDecorView();
        decorView2.getClass();
        decorView2.setTag(2131296812, this);
        View decorView3 = getWindow().getDecorView();
        decorView3.getClass();
        decorView3.setTag(2131296811, this);
        View decorView4 = getWindow().getDecorView();
        decorView4.getClass();
        decorView4.setTag(2131296810, this);
    }

    public final void n(Configuration configuration) {
        androidx.fragment.app.e eVar = this.f503p;
        eVar.a();
        super.onConfigurationChanged(configuration);
        ((androidx.fragment.app.x) eVar.b).f1325d.h();
    }

    public final void o() {
        super.onDestroy();
        ((androidx.fragment.app.x) this.f503p.b).f1325d.k();
        this.f504q.d(androidx.lifecycle.l.ON_DESTROY);
    }

    @Override // androidx.activity.m, android.app.Activity
    public final void onActivityResult(int i7, int i8, Intent intent) {
        this.f503p.a();
        super.onActivityResult(i7, i8, intent);
    }

    @Override // androidx.activity.m, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        n(configuration);
        c0 c0Var = (c0) j();
        if (c0Var.F && c0Var.f456z) {
            c0Var.z();
            o0 o0Var = c0Var.f445o;
            if (o0Var != null) {
                o0Var.e(o0Var.f521a.getResources().getBoolean(2131034112));
            }
        }
        androidx.appcompat.widget.w wVarA = androidx.appcompat.widget.w.a();
        Context context = c0Var.f441k;
        synchronized (wVarA) {
            n2 n2Var = wVarA.f952a;
            synchronized (n2Var) {
                l.e eVar = (l.e) n2Var.b.get(context);
                if (eVar != null) {
                    eVar.a();
                }
            }
        }
        c0Var.R = new Configuration(c0Var.f441k.getResources().getConfiguration());
        c0Var.m(false, false);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onContentChanged() {
    }

    @Override // androidx.activity.m, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f504q.d(androidx.lifecycle.l.ON_CREATE);
        androidx.fragment.app.k0 k0Var = ((androidx.fragment.app.x) this.f503p.b).f1325d;
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(1);
    }

    @Override // androidx.activity.m, android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i7, Menu menu) {
        if (i7 != 0) {
            super.onCreatePanelMenu(i7, menu);
            return true;
        }
        super.onCreatePanelMenu(i7, menu);
        getMenuInflater();
        ((androidx.fragment.app.x) this.f503p.b).f1325d.j();
        return true;
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.x) this.f503p.b).f1325d.f1228f.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        o();
        j().d();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public final void onLowMemory() {
        super.onLowMemory();
        ((androidx.fragment.app.x) this.f503p.b).f1325d.l();
    }

    @Override // androidx.activity.m, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i7, MenuItem menuItem) {
        Intent intentH;
        if (!p(i7, menuItem)) {
            c0 c0Var = (c0) j();
            c0Var.z();
            o0 o0Var = c0Var.f445o;
            if (menuItem.getItemId() != 16908332 || o0Var == null || (((v3) o0Var.e).b & 4) == 0 || (intentH = a5.h.H(this)) == null) {
                return false;
            }
            if (!androidx.core.app.e.c(this, intentH)) {
                androidx.core.app.e.b(this, intentH);
                return true;
            }
            ArrayList arrayList = new ArrayList();
            Intent intentH2 = a5.h.H(this);
            if (intentH2 == null) {
                intentH2 = a5.h.H(this);
            }
            if (intentH2 != null) {
                ComponentName component = intentH2.getComponent();
                if (component == null) {
                    component = intentH2.resolveActivity(getPackageManager());
                }
                int size = arrayList.size();
                try {
                    Intent intentI = a5.h.I(this, component);
                    while (intentI != null) {
                        arrayList.add(size, intentI);
                        intentI = a5.h.I(this, intentI.getComponent());
                    }
                    arrayList.add(intentH2);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                    throw new IllegalArgumentException(e);
                }
            }
            if (arrayList.isEmpty()) {
                f3.t("No intents added to TaskStackBuilder; cannot startActivities");
                return false;
            }
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            androidx.core.content.a.a(this, intentArr, null);
            try {
                androidx.core.app.a.a(this);
            } catch (IllegalStateException unused) {
                finish();
            }
        }
        return true;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z6) {
        ((androidx.fragment.app.x) this.f503p.b).f1325d.m();
    }

    @Override // androidx.activity.m, android.app.Activity
    public final void onNewIntent(Intent intent) {
        this.f503p.a();
        super.onNewIntent(intent);
    }

    @Override // androidx.activity.m, android.app.Activity, android.view.Window.Callback
    public final void onPanelClosed(int i7, Menu menu) {
        q(i7, menu);
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.f506s = false;
        ((androidx.fragment.app.x) this.f503p.b).f1325d.s(5);
        this.f504q.d(androidx.lifecycle.l.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z6) {
        ((androidx.fragment.app.x) this.f503p.b).f1325d.q();
    }

    @Override // android.app.Activity
    public final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((c0) j()).v();
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        r();
        c0 c0Var = (c0) j();
        c0Var.z();
        o0 o0Var = c0Var.f445o;
        if (o0Var != null) {
            o0Var.f538t = true;
        }
    }

    @Override // androidx.activity.m, android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i7, View view, Menu menu) {
        if (i7 != 0) {
            super.onPreparePanel(i7, view, menu);
            return true;
        }
        super.onPreparePanel(0, view, menu);
        ((androidx.fragment.app.x) this.f503p.b).f1325d.r();
        return true;
    }

    @Override // androidx.activity.m, android.app.Activity
    public final void onRequestPermissionsResult(int i7, String[] strArr, int[] iArr) {
        this.f503p.a();
        super.onRequestPermissionsResult(i7, strArr, iArr);
    }

    @Override // android.app.Activity
    public final void onResume() {
        androidx.fragment.app.e eVar = this.f503p;
        eVar.a();
        super.onResume();
        this.f506s = true;
        ((androidx.fragment.app.x) eVar.b).f1325d.x(true);
    }

    @Override // android.app.Activity
    public final void onStart() {
        s();
        ((c0) j()).m(true, false);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f503p.a();
    }

    @Override // android.app.Activity
    public final void onStop() {
        t();
        c0 c0Var = (c0) j();
        c0Var.z();
        o0 o0Var = c0Var.f445o;
        if (o0Var != null) {
            o0Var.f538t = false;
            f.j jVar = o0Var.f537s;
            if (jVar != null) {
                jVar.a();
            }
        }
    }

    @Override // android.app.Activity
    public final void onTitleChanged(CharSequence charSequence, int i7) {
        super.onTitleChanged(charSequence, i7);
        j().k(charSequence);
    }

    @Override // android.app.Activity
    public final void openOptionsMenu() {
        ((c0) j()).z();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    public final boolean p(int i7, MenuItem menuItem) {
        if (super.onMenuItemSelected(i7, menuItem)) {
            return true;
        }
        androidx.fragment.app.e eVar = this.f503p;
        if (i7 == 0) {
            return ((androidx.fragment.app.x) eVar.b).f1325d.n();
        }
        if (i7 != 6) {
            return false;
        }
        return ((androidx.fragment.app.x) eVar.b).f1325d.i();
    }

    public final void q(int i7, Menu menu) {
        if (i7 == 0) {
            ((androidx.fragment.app.x) this.f503p.b).f1325d.o();
        }
        super.onPanelClosed(i7, menu);
    }

    public final void r() {
        super.onPostResume();
        this.f504q.d(androidx.lifecycle.l.ON_RESUME);
        androidx.fragment.app.k0 k0Var = ((androidx.fragment.app.x) this.f503p.b).f1325d;
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(7);
    }

    public final void s() {
        androidx.fragment.app.e eVar = this.f503p;
        eVar.a();
        androidx.fragment.app.x xVar = (androidx.fragment.app.x) eVar.b;
        super.onStart();
        this.f507t = false;
        if (!this.f505r) {
            this.f505r = true;
            androidx.fragment.app.k0 k0Var = xVar.f1325d;
            k0Var.f1248z = false;
            k0Var.A = false;
            k0Var.G.f1254h = false;
            k0Var.s(4);
        }
        xVar.f1325d.x(true);
        this.f504q.d(androidx.lifecycle.l.ON_START);
        androidx.fragment.app.k0 k0Var2 = xVar.f1325d;
        k0Var2.f1248z = false;
        k0Var2.A = false;
        k0Var2.G.f1254h = false;
        k0Var2.s(5);
    }

    @Override // android.app.Activity
    public final void setContentView(int i7) {
        l();
        j().g(i7);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i7) {
        super.setTheme(i7);
        ((c0) j()).T = i7;
    }

    public final void t() {
        super.onStop();
        this.f507t = true;
        while (m(k())) {
        }
        androidx.fragment.app.k0 k0Var = ((androidx.fragment.app.x) this.f503p.b).f1325d;
        k0Var.A = true;
        k0Var.G.f1254h = true;
        k0Var.s(4);
        this.f504q.d(androidx.lifecycle.l.ON_STOP);
    }

    @Override // androidx.activity.m, android.app.Activity
    public void setContentView(View view) {
        l();
        j().i(view);
    }

    @Override // android.app.Activity
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        l();
        j().j(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.x) this.f503p.b).f1325d.f1228f.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }
}
