package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.f3;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import h3.h1;
import h3.j1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class g implements g0.t, h1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f492a;
    public Object b;

    public g(Context context, int i7) {
        this.b = new c(new ContextThemeWrapper(context, h.h(context, i7)));
        this.f492a = i7;
    }

    @Override // h3.h1
    public void a(String str) {
        androidx.activity.g.w("Failed to save mapping config: ", str, "OverlayController");
        k3.l lVar = ((k3.j) this.b).b;
        lVar.l(lVar.f6559a.getString(2131820646));
    }

    @Override // h3.h1
    public void b() {
        k3.j jVar = (k3.j) this.b;
        k3.l lVar = jVar.b;
        k3.l lVar2 = jVar.b;
        if (k3.l.b(lVar, this.f492a)) {
            return;
        }
        h3.o0 o0Var = lVar2.f6569m;
        if (o0Var != null) {
            List<j3.k> nodes = o0Var.getNodes();
            lVar2.f6580x = new ArrayList();
            Iterator<j3.k> it = nodes.iterator();
            while (it.hasNext()) {
                j3.k kVarA = k3.l.a(lVar2, it.next());
                if (kVarA != null) {
                    lVar2.f6580x.add(kVarA);
                }
            }
        }
        lVar2.f6560c.m(k3.o.f6597l);
        if (lVar2.f6564h) {
            lVar2.n();
        }
        String str = j1.m().f6021f;
        if (str != null) {
            j1.m().g(str, null);
        }
    }

    @Override // g0.t
    public boolean c(View view) {
        ((BottomSheetBehavior) this.b).B(this.f492a);
        return true;
    }

    public h d() {
        c cVar = (c) this.b;
        h hVar = new h(cVar.f416a, this.f492a);
        View view = cVar.e;
        f fVar = hVar.f496f;
        if (view != null) {
            fVar.f480u = view;
        } else {
            CharSequence charSequence = cVar.f418d;
            if (charSequence != null) {
                fVar.f464d = charSequence;
                TextView textView = fVar.f478s;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = cVar.f417c;
            if (drawable != null) {
                fVar.f476q = drawable;
                ImageView imageView = fVar.f477r;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    fVar.f477r.setImageDrawable(drawable);
                }
            }
        }
        CharSequence charSequence2 = cVar.f419f;
        if (charSequence2 != null) {
            fVar.e = charSequence2;
            TextView textView2 = fVar.f479t;
            if (textView2 != null) {
                textView2.setText(charSequence2);
            }
        }
        CharSequence charSequence3 = cVar.f420g;
        if (charSequence3 != null) {
            fVar.b(-1, charSequence3, null);
        }
        CharSequence charSequence4 = cVar.f421h;
        if (charSequence4 != null) {
            fVar.b(-2, charSequence4, cVar.f422i);
        }
        if (cVar.f426m != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) cVar.b.inflate(fVar.f484y, (ViewGroup) null);
            int i7 = cVar.f428o ? fVar.f485z : fVar.A;
            ListAdapter eVar = cVar.f426m;
            if (eVar == null) {
                eVar = new e(cVar.f416a, i7, R.id.text1, null);
            }
            fVar.f481v = eVar;
            fVar.f482w = cVar.f429p;
            if (cVar.f427n != null) {
                alertController$RecycleListView.setOnItemClickListener(new b(cVar, fVar));
            }
            if (cVar.f428o) {
                alertController$RecycleListView.setChoiceMode(1);
            }
            fVar.f465f = alertController$RecycleListView;
        }
        hVar.setCancelable(cVar.f423j);
        if (cVar.f423j) {
            hVar.setCanceledOnTouchOutside(true);
        }
        hVar.setOnCancelListener(null);
        hVar.setOnDismissListener(cVar.f424k);
        g.m mVar = cVar.f425l;
        if (mVar != null) {
            hVar.setOnKeyListener(mVar);
        }
        return hVar;
    }

    public int e() {
        if ((this.f492a & 16) != 0) {
            return ((int[]) this.b)[4];
        }
        return 65535;
    }

    public void f(int i7, f5.c cVar) {
        while (true) {
            int i8 = i7 >> 1;
            if (i8 == 0) {
                break;
            }
            f5.c cVar2 = ((f5.c[]) this.b)[i8];
            cVar2.getClass();
            if (q2.c.c(0L, cVar.f5654g - cVar2.f5654g) <= 0) {
                break;
            }
            cVar2.f5653f = i7;
            ((f5.c[]) this.b)[i7] = cVar2;
            i7 = i8;
        }
        ((f5.c[]) this.b)[i7] = cVar;
        cVar.f5653f = i7;
    }

    public void g(Object obj) {
        int i7 = this.f492a;
        f4.g gVar = (f4.g) this.b;
        if (i7 != gVar.f5641f) {
            return;
        }
        gVar.e = false;
        int i8 = gVar.f5642g;
        gVar.f5642g = 0;
        if (i8 == 0) {
            return;
        }
        Object objO = gVar.b.o();
        if (objO != null) {
            obj = objO;
        }
        gVar.a(i8, obj);
    }

    public void h(f5.c cVar) {
        f5.c cVar2;
        int i7 = cVar.f5653f;
        if (i7 == -1) {
            f3.q("Failed requirement.");
            return;
        }
        int i8 = this.f492a;
        f5.c cVar3 = ((f5.c[]) this.b)[i8];
        cVar3.getClass();
        cVar.f5653f = -1;
        ((f5.c[]) this.b)[i8] = null;
        this.f492a = i8 - 1;
        if (cVar == cVar3) {
            return;
        }
        int iC = q2.c.c(0L, cVar3.f5654g - cVar.f5654g);
        if (iC == 0) {
            ((f5.c[]) this.b)[i7] = cVar3;
            cVar3.f5653f = i7;
            return;
        }
        if (iC >= 0) {
            f(i7, cVar3);
            return;
        }
        while (true) {
            int i9 = i7 << 1;
            int i10 = i9 + 1;
            int i11 = this.f492a;
            if (i10 > i11) {
                if (i9 > i11) {
                    break;
                }
                cVar2 = ((f5.c[]) this.b)[i9];
                cVar2.getClass();
            } else {
                cVar2 = ((f5.c[]) this.b)[i9];
                cVar2.getClass();
                f5.c cVar4 = ((f5.c[]) this.b)[i10];
                cVar4.getClass();
                if (q2.c.c(0L, cVar4.f5654g - cVar2.f5654g) >= 0) {
                    cVar2 = cVar4;
                }
            }
            if (q2.c.c(0L, cVar2.f5654g - cVar3.f5654g) <= 0) {
                break;
            }
            int i12 = cVar2.f5653f;
            cVar2.f5653f = i7;
            ((f5.c[]) this.b)[i7] = cVar2;
            i7 = i12;
        }
        ((f5.c[]) this.b)[i7] = cVar3;
        cVar3.f5653f = i7;
    }

    public void i(int i7, int i8) {
        if (i7 >= 0) {
            int[] iArr = (int[]) this.b;
            if (i7 >= iArr.length) {
                return;
            }
            this.f492a = (1 << i7) | this.f492a;
            iArr[i7] = i8;
        }
    }

    public void j() {
        d().show();
    }

    public g() {
        this.b = new int[10];
    }

    public g(Context context) {
        this(context, h.h(context, 0));
    }

    public /* synthetic */ g(int i7, Object obj) {
        this.b = obj;
        this.f492a = i7;
    }

    public g(int i7, c0.i[] iVarArr) {
        this.f492a = i7;
        this.b = iVarArr;
    }
}
