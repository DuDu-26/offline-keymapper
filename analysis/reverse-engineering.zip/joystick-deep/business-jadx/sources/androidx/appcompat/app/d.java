package androidx.appcompat.app;

import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakReference f457a;

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        int i7 = message.what;
        if (i7 == -3 || i7 == -2 || i7 == -1) {
            ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f457a.get(), message.what);
        } else {
            if (i7 != 1) {
                return;
            }
            ((DialogInterface) message.obj).dismiss();
        }
    }
}
