package androidx.appcompat.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f512a;
    public long b;
}
