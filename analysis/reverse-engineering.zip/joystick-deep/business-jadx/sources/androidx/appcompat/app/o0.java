package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.f3;
import androidx.appcompat.widget.l1;
import androidx.appcompat.widget.u3;
import androidx.appcompat.widget.v3;
import f0.s0;
import f0.w0;
import f0.x0;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o0 implements androidx.appcompat.widget.d {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final AccelerateInterpolator f519y = new AccelerateInterpolator();

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final DecelerateInterpolator f520z = new DecelerateInterpolator();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f521a;
    public Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionBarOverlayLayout f522c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f523d;
    public l1 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ActionBarContextView f524f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final View f525g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f526h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public n0 f527i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public n0 f528j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public y2.o f529k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f530l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f531m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f532n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f533o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f534p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f535q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f536r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public f.j f537s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f538t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f539u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final m0 f540v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final m0 f541w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final w3.e f542x;

    public o0(Activity activity, boolean z6) {
        new ArrayList();
        this.f531m = new ArrayList();
        this.f532n = 0;
        this.f533o = true;
        this.f536r = true;
        this.f540v = new m0(this, 0);
        this.f541w = new m0(this, 1);
        this.f542x = new w3.e(6, this);
        View decorView = activity.getWindow().getDecorView();
        c(decorView);
        if (z6) {
            return;
        }
        this.f525g = decorView.findViewById(R.id.content);
    }

    public final void a(boolean z6) {
        x0 x0VarA;
        x0 x0VarI;
        boolean z7 = this.f535q;
        if (z6) {
            if (!z7) {
                this.f535q = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.f522c;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                f(false);
            }
        } else if (z7) {
            this.f535q = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f522c;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            f(false);
        }
        ActionBarContainer actionBarContainer = this.f523d;
        WeakHashMap weakHashMap = s0.f5582a;
        boolean zC = f0.e0.c(actionBarContainer);
        l1 l1Var = this.e;
        if (!zC) {
            if (z6) {
                ((v3) l1Var).f938a.setVisibility(4);
                this.f524f.setVisibility(0);
                return;
            } else {
                ((v3) l1Var).f938a.setVisibility(0);
                this.f524f.setVisibility(8);
                return;
            }
        }
        if (z6) {
            v3 v3Var = (v3) l1Var;
            x0VarI = s0.a(v3Var.f938a);
            x0VarI.a(0.0f);
            x0VarI.c(100L);
            x0VarI.d(new u3(v3Var, 4));
            x0VarA = this.f524f.i(0, 200L);
        } else {
            v3 v3Var2 = (v3) l1Var;
            x0VarA = s0.a(v3Var2.f938a);
            x0VarA.a(1.0f);
            x0VarA.c(200L);
            x0VarA.d(new u3(v3Var2, 0));
            x0VarI = this.f524f.i(8, 100L);
        }
        f.j jVar = new f.j();
        ArrayList arrayList = jVar.f5530a;
        arrayList.add(x0VarI);
        View view = (View) x0VarI.f5594a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = (View) x0VarA.f5594a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        arrayList.add(x0VarA);
        jVar.b();
    }

    public final Context b() {
        if (this.b == null) {
            TypedValue typedValue = new TypedValue();
            this.f521a.getTheme().resolveAttribute(2130968588, typedValue, true);
            int i7 = typedValue.resourceId;
            if (i7 != 0) {
                this.b = new ContextThemeWrapper(this.f521a, i7);
            } else {
                this.b = this.f521a;
            }
        }
        return this.b;
    }

    public final void c(View view) {
        l1 wrapper;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(2131296417);
        this.f522c = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback callbackFindViewById = view.findViewById(2131296308);
        if (callbackFindViewById instanceof l1) {
            wrapper = (l1) callbackFindViewById;
        } else {
            if (!(callbackFindViewById instanceof Toolbar)) {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById != null ? callbackFindViewById.getClass().getSimpleName() : "null"));
            }
            wrapper = ((Toolbar) callbackFindViewById).getWrapper();
        }
        this.e = wrapper;
        this.f524f = (ActionBarContextView) view.findViewById(2131296316);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(2131296310);
        this.f523d = actionBarContainer;
        l1 l1Var = this.e;
        if (l1Var == null || this.f524f == null || actionBarContainer == null) {
            f3.t(o0.class.getSimpleName().concat(" can only be used with a compatible window decor layout"));
            return;
        }
        Context context = ((v3) l1Var).f938a.getContext();
        this.f521a = context;
        if ((((v3) this.e).b & 4) != 0) {
            this.f526h = true;
        }
        int i7 = context.getApplicationInfo().targetSdkVersion;
        this.e.getClass();
        e(context.getResources().getBoolean(2131034112));
        TypedArray typedArrayObtainStyledAttributes = this.f521a.obtainStyledAttributes(null, d.a.f5203a, 2130968583, 0);
        if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f522c;
            if (!actionBarOverlayLayout2.f618h) {
                f3.t("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
                return;
            } else {
                this.f539u = true;
                actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
            }
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f523d;
            WeakHashMap weakHashMap = s0.f5582a;
            f0.h0.s(actionBarContainer2, dimensionPixelSize);
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public final void d(boolean z6) {
        if (this.f526h) {
            return;
        }
        int i7 = z6 ? 4 : 0;
        v3 v3Var = (v3) this.e;
        int i8 = v3Var.b;
        this.f526h = true;
        v3Var.a((i7 & 4) | (i8 & (-5)));
    }

    public final void e(boolean z6) {
        if (z6) {
            this.f523d.setTabContainer(null);
            ((v3) this.e).getClass();
        } else {
            ((v3) this.e).getClass();
            this.f523d.setTabContainer(null);
        }
        this.e.getClass();
        ((v3) this.e).f938a.setCollapsible(false);
        this.f522c.setHasNonEmbeddedTabs(false);
    }

    public final void f(boolean z6) {
        boolean z7 = this.f535q || !this.f534p;
        boolean z8 = this.f536r;
        w3.e eVar = this.f542x;
        View view = this.f525g;
        if (!z7) {
            if (z8) {
                this.f536r = false;
                f.j jVar = this.f537s;
                if (jVar != null) {
                    jVar.a();
                }
                int i7 = this.f532n;
                m0 m0Var = this.f540v;
                if (i7 != 0 || (!this.f538t && !z6)) {
                    m0Var.c();
                    return;
                }
                this.f523d.setAlpha(1.0f);
                this.f523d.setTransitioning(true);
                f.j jVar2 = new f.j();
                float f2 = -this.f523d.getHeight();
                if (z6) {
                    this.f523d.getLocationInWindow(new int[]{0, 0});
                    f2 -= r12[1];
                }
                x0 x0VarA = s0.a(this.f523d);
                x0VarA.e(f2);
                View view2 = (View) x0VarA.f5594a.get();
                if (view2 != null) {
                    w0.a(view2.animate(), eVar != null ? new com.google.android.material.textfield.g(eVar, view2) : null);
                }
                boolean z9 = jVar2.e;
                ArrayList arrayList = jVar2.f5530a;
                if (!z9) {
                    arrayList.add(x0VarA);
                }
                if (this.f533o && view != null) {
                    x0 x0VarA2 = s0.a(view);
                    x0VarA2.e(f2);
                    if (!jVar2.e) {
                        arrayList.add(x0VarA2);
                    }
                }
                boolean z10 = jVar2.e;
                if (!z10) {
                    jVar2.f5531c = f519y;
                }
                if (!z10) {
                    jVar2.b = 250L;
                }
                if (!z10) {
                    jVar2.f5532d = m0Var;
                }
                this.f537s = jVar2;
                jVar2.b();
                return;
            }
            return;
        }
        if (z8) {
            return;
        }
        this.f536r = true;
        f.j jVar3 = this.f537s;
        if (jVar3 != null) {
            jVar3.a();
        }
        this.f523d.setVisibility(0);
        int i8 = this.f532n;
        m0 m0Var2 = this.f541w;
        if (i8 == 0 && (this.f538t || z6)) {
            this.f523d.setTranslationY(0.0f);
            float f7 = -this.f523d.getHeight();
            if (z6) {
                this.f523d.getLocationInWindow(new int[]{0, 0});
                f7 -= r12[1];
            }
            this.f523d.setTranslationY(f7);
            f.j jVar4 = new f.j();
            x0 x0VarA3 = s0.a(this.f523d);
            x0VarA3.e(0.0f);
            View view3 = (View) x0VarA3.f5594a.get();
            if (view3 != null) {
                w0.a(view3.animate(), eVar != null ? new com.google.android.material.textfield.g(eVar, view3) : null);
            }
            boolean z11 = jVar4.e;
            ArrayList arrayList2 = jVar4.f5530a;
            if (!z11) {
                arrayList2.add(x0VarA3);
            }
            if (this.f533o && view != null) {
                view.setTranslationY(f7);
                x0 x0VarA4 = s0.a(view);
                x0VarA4.e(0.0f);
                if (!jVar4.e) {
                    arrayList2.add(x0VarA4);
                }
            }
            boolean z12 = jVar4.e;
            if (!z12) {
                jVar4.f5531c = f520z;
            }
            if (!z12) {
                jVar4.b = 250L;
            }
            if (!z12) {
                jVar4.f5532d = m0Var2;
            }
            this.f537s = jVar4;
            jVar4.b();
        } else {
            this.f523d.setAlpha(1.0f);
            this.f523d.setTranslationY(0.0f);
            if (this.f533o && view != null) {
                view.setTranslationY(0.0f);
            }
            m0Var2.c();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f522c;
        if (actionBarOverlayLayout != null) {
            WeakHashMap weakHashMap = s0.f5582a;
            f0.f0.c(actionBarOverlayLayout);
        }
    }

    public o0(Dialog dialog) {
        new ArrayList();
        this.f531m = new ArrayList();
        this.f532n = 0;
        this.f533o = true;
        this.f536r = true;
        this.f540v = new m0(this, 0);
        this.f541w = new m0(this, 1);
        this.f542x = new w3.e(6, this);
        c(dialog.getWindow().getDecorView());
    }
}
