package androidx.appcompat.app;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i implements u0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f498a;
    public final Object b;

    public i(androidx.appcompat.widget.v vVar) {
        this.f498a = 1;
        this.b = new LinkedHashSet();
        vVar.e("androidx.savedstate.Restarter", this);
    }

    @Override // u0.c
    public final Bundle a() {
        switch (this.f498a) {
            case 0:
                Bundle bundle = new Bundle();
                ((MainActivity) this.b).j().getClass();
                return bundle;
            default:
                Bundle bundle2 = new Bundle();
                bundle2.putStringArrayList("classes_to_restore", new ArrayList<>((LinkedHashSet) this.b));
                return bundle2;
        }
    }

    public i(MainActivity mainActivity) {
        this.f498a = 0;
        this.b = mainActivity;
    }
}
