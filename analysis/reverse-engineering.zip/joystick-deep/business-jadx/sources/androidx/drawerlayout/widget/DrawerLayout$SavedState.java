package androidx.drawerlayout.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.customview.view.AbsSavedState;
import androidx.customview.view.a;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class DrawerLayout$SavedState extends AbsSavedState {
    public static final Parcelable.Creator<DrawerLayout$SavedState> CREATOR = new a(4);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1101c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1102d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f1103f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1104g;

    public DrawerLayout$SavedState(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f1101c = 0;
        this.f1101c = parcel.readInt();
        this.f1102d = parcel.readInt();
        this.e = parcel.readInt();
        this.f1103f = parcel.readInt();
        this.f1104g = parcel.readInt();
    }

    @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i7) {
        super.writeToParcel(parcel, i7);
        parcel.writeInt(this.f1101c);
        parcel.writeInt(this.f1102d);
        parcel.writeInt(this.e);
        parcel.writeInt(this.f1103f);
        parcel.writeInt(this.f1104g);
    }
}
