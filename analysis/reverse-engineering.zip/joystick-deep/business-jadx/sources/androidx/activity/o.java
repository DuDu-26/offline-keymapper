package androidx.activity;

import android.os.Bundle;
import androidx.appcompat.widget.f3;
import androidx.appcompat.widget.v;
import androidx.lifecycle.l;
import androidx.lifecycle.r;
import androidx.savedstate.Recreator;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f361a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f362c;

    public o(l lVar, d dVar) {
        this.b = new Object();
        this.f362c = new ArrayList();
    }

    public void a() {
        u0.d dVar = (u0.d) this.b;
        androidx.lifecycle.t tVarD = dVar.d();
        if (tVarD.f1365c != androidx.lifecycle.m.b) {
            f3.t("Restarter must be created only during owner's initialization stage");
            return;
        }
        tVarD.a(new Recreator(dVar));
        final androidx.appcompat.widget.v vVar = (androidx.appcompat.widget.v) this.f362c;
        vVar.getClass();
        if (vVar.f927c) {
            f3.t("SavedStateRegistry was already attached.");
            return;
        }
        tVarD.a(new androidx.lifecycle.p() { // from class: u0.a
            @Override // androidx.lifecycle.p
            public final void a(r rVar, l lVar) {
                v vVar2 = vVar;
                vVar2.getClass();
                if (lVar == l.ON_START) {
                    vVar2.e = true;
                } else if (lVar == l.ON_STOP) {
                    vVar2.e = false;
                }
            }
        });
        vVar.f927c = true;
        this.f361a = true;
    }

    public void b(Bundle bundle) {
        if (!this.f361a) {
            a();
        }
        androidx.lifecycle.t tVarD = ((u0.d) this.b).d();
        if (tVarD.f1365c.compareTo(androidx.lifecycle.m.f1360d) >= 0) {
            k3.g.l(tVarD.f1365c, "performRestore cannot be called when owner is ");
            return;
        }
        androidx.appcompat.widget.v vVar = (androidx.appcompat.widget.v) this.f362c;
        if (!vVar.f927c) {
            f3.t("You must call performAttach() before calling performRestore(Bundle).");
        } else if (vVar.f928d) {
            f3.t("SavedStateRegistry was already restored.");
        } else {
            vVar.f926a = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
            vVar.f928d = true;
        }
    }

    public void c(Bundle bundle) {
        bundle.getClass();
        androidx.appcompat.widget.v vVar = (androidx.appcompat.widget.v) this.f362c;
        vVar.getClass();
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = (Bundle) vVar.f926a;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        i.f fVar = (i.f) vVar.f929f;
        fVar.getClass();
        i.d dVar = new i.d(fVar);
        fVar.f6259c.put(dVar, Boolean.FALSE);
        while (dVar.hasNext()) {
            Map.Entry entry = (Map.Entry) dVar.next();
            bundle2.putBundle((String) entry.getKey(), ((u0.c) entry.getValue()).a());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public o(u0.d dVar) {
        this.b = dVar;
        this.f362c = new androidx.appcompat.widget.v();
    }
}
