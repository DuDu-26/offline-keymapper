package androidx.activity;

import android.view.inputmethod.InputMethodManager;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
final class ImmLeaksCleaner implements androidx.lifecycle.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f329a;

    @Override // androidx.lifecycle.p
    public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar) {
        if (lVar != androidx.lifecycle.l.ON_DESTROY) {
            return;
        }
        if (f329a == 0) {
            try {
                f329a = 2;
                InputMethodManager.class.getDeclaredField("mServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mNextServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mH").setAccessible(true);
                f329a = 1;
            } catch (NoSuchFieldException unused) {
            }
        }
        if (f329a == 1) {
            throw null;
        }
    }
}
