package androidx.activity.result;

import a5.h;
import android.content.Intent;
import android.os.Bundle;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.p;
import androidx.lifecycle.r;
import androidx.lifecycle.t;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f378a = new HashMap();
    public final HashMap b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f379c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f380d = new ArrayList();
    public final transient HashMap e = new HashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final HashMap f381f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Bundle f382g = new Bundle();

    public final boolean a(int i7, int i8, Intent intent) {
        String str = (String) this.f378a.get(Integer.valueOf(i7));
        if (str == null) {
            return false;
        }
        d dVar = (d) this.e.get(str);
        if (dVar != null) {
            a aVar = dVar.f376a;
            if (this.f380d.contains(str)) {
                aVar.c(dVar.b.X(i8, intent));
                this.f380d.remove(str);
                return true;
            }
        }
        this.f381f.remove(str);
        this.f382g.putParcelable(str, new ActivityResult(i8, intent));
        return true;
    }

    public abstract void b(int i7, h hVar, Object obj);

    public final c c(String str, h hVar, a aVar) {
        e(str);
        this.e.put(str, new d(hVar, aVar));
        HashMap map = this.f381f;
        if (map.containsKey(str)) {
            Object obj = map.get(str);
            map.remove(str);
            aVar.c(obj);
        }
        Bundle bundle = this.f382g;
        ActivityResult activityResult = (ActivityResult) bundle.getParcelable(str);
        if (activityResult != null) {
            bundle.remove(str);
            aVar.c(hVar.X(activityResult.f366a, activityResult.b));
        }
        return new c(this, str, hVar, 1);
    }

    public final c d(final String str, r rVar, final h hVar, final a aVar) {
        t tVarD = rVar.d();
        if (tVarD.f1365c.compareTo(m.f1360d) >= 0) {
            StringBuilder sb = new StringBuilder("LifecycleOwner ");
            sb.append(rVar);
            m mVar = tVarD.f1365c;
            sb.append(" is attempting to register while current state is ");
            sb.append(mVar);
            sb.append(". LifecycleOwners must call register before they are STARTED.");
            throw new IllegalStateException(sb.toString());
        }
        e(str);
        HashMap map = this.f379c;
        e eVar = (e) map.get(str);
        if (eVar == null) {
            eVar = new e(tVarD);
        }
        p pVar = new p() { // from class: androidx.activity.result.ActivityResultRegistry$1
            @Override // androidx.lifecycle.p
            public final void a(r rVar2, l lVar) {
                boolean zEquals = l.ON_START.equals(lVar);
                String str2 = str;
                f fVar = this.f369d;
                if (!zEquals) {
                    if (l.ON_STOP.equals(lVar)) {
                        fVar.e.remove(str2);
                        return;
                    } else {
                        if (l.ON_DESTROY.equals(lVar)) {
                            fVar.f(str2);
                            return;
                        }
                        return;
                    }
                }
                HashMap map2 = fVar.e;
                Bundle bundle = fVar.f382g;
                HashMap map3 = fVar.f381f;
                h hVar2 = hVar;
                a aVar2 = aVar;
                map2.put(str2, new d(hVar2, aVar2));
                if (map3.containsKey(str2)) {
                    Object obj = map3.get(str2);
                    map3.remove(str2);
                    aVar2.c(obj);
                }
                ActivityResult activityResult = (ActivityResult) bundle.getParcelable(str2);
                if (activityResult != null) {
                    bundle.remove(str2);
                    aVar2.c(hVar2.X(activityResult.f366a, activityResult.b));
                }
            }
        };
        eVar.f377a.a(pVar);
        eVar.b.add(pVar);
        map.put(str, eVar);
        return new c(this, str, hVar, 0);
    }

    public final void e(String str) {
        HashMap map = this.b;
        if (((Integer) map.get(str)) != null) {
            return;
        }
        r2.a aVar = r2.e.f7877a;
        int iNextInt = r2.e.f7877a.a().nextInt(2147418112);
        while (true) {
            int i7 = iNextInt + 65536;
            Integer numValueOf = Integer.valueOf(i7);
            HashMap map2 = this.f378a;
            if (!map2.containsKey(numValueOf)) {
                map2.put(Integer.valueOf(i7), str);
                map.put(str, Integer.valueOf(i7));
                return;
            } else {
                r2.a aVar2 = r2.e.f7877a;
                iNextInt = r2.e.f7877a.a().nextInt(2147418112);
            }
        }
    }

    public final void f(String str) {
        Integer num;
        if (!this.f380d.contains(str) && (num = (Integer) this.b.remove(str)) != null) {
            this.f378a.remove(num);
        }
        this.e.remove(str);
        HashMap map = this.f381f;
        if (map.containsKey(str)) {
            Objects.toString(map.get(str));
            map.remove(str);
        }
        Bundle bundle = this.f382g;
        if (bundle.containsKey(str)) {
            Objects.toString(bundle.getParcelable(str));
            bundle.remove(str);
        }
        HashMap map2 = this.f379c;
        e eVar = (e) map2.get(str);
        if (eVar != null) {
            ArrayList arrayList = eVar.b;
            int size = arrayList.size();
            int i7 = 0;
            while (i7 < size) {
                Object obj = arrayList.get(i7);
                i7++;
                eVar.f377a.f((p) obj);
            }
            arrayList.clear();
            map2.remove(str);
        }
    }
}
