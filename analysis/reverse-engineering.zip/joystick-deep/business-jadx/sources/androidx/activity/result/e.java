package androidx.activity.result;

import androidx.lifecycle.t;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final t f377a;
    public final ArrayList b = new ArrayList();

    public e(t tVar) {
        this.f377a = tVar;
    }
}
