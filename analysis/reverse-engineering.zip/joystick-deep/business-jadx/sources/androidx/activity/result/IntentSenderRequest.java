package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new android.support.v4.os.b(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final IntentSender f370a;
    public final Intent b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f371c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f372d;

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i7, int i8) {
        this.f370a = intentSender;
        this.b = intent;
        this.f371c = i7;
        this.f372d = i8;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i7) {
        parcel.getClass();
        parcel.writeParcelable(this.f370a, i7);
        parcel.writeParcelable(this.b, i7);
        parcel.writeInt(this.f371c);
        parcel.writeInt(this.f372d);
    }
}
