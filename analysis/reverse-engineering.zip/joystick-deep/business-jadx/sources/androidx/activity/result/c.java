package androidx.activity.result;

import a5.h;
import java.util.HashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c extends b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f373a;
    public final /* synthetic */ String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h f374c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ f f375d;

    public /* synthetic */ c(f fVar, String str, h hVar, int i7) {
        this.f373a = i7;
        this.f375d = fVar;
        this.b = str;
        this.f374c = hVar;
    }

    @Override // androidx.activity.result.b
    public final void a(Object obj) {
        switch (this.f373a) {
            case 0:
                f fVar = this.f375d;
                HashMap map = fVar.b;
                String str = this.b;
                Integer num = (Integer) map.get(str);
                h hVar = this.f374c;
                if (num != null) {
                    fVar.f380d.add(str);
                    try {
                        fVar.b(num.intValue(), hVar, obj);
                        return;
                    } catch (Exception e) {
                        fVar.f380d.remove(str);
                        throw e;
                    }
                }
                throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + hVar + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
            default:
                f fVar2 = this.f375d;
                HashMap map2 = fVar2.b;
                String str2 = this.b;
                Integer num2 = (Integer) map2.get(str2);
                h hVar2 = this.f374c;
                if (num2 != null) {
                    fVar2.f380d.add(str2);
                    try {
                        fVar2.b(num2.intValue(), hVar2, obj);
                        return;
                    } catch (Exception e3) {
                        fVar2.f380d.remove(str2);
                        throw e3;
                    }
                }
                throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + hVar2 + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }
    }

    public void b() {
        this.f375d.f(this.b);
    }
}
