package androidx.activity;

import java.io.IOException;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class d implements p2.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f337a;
    public final /* synthetic */ Object b;

    public /* synthetic */ d(int i7, Object obj) {
        this.f337a = i7;
        this.b = obj;
    }

    @Override // p2.a
    public final Object invoke() {
        switch (this.f337a) {
            case 0:
                ((androidx.appcompat.app.k) this.b).reportFullyDrawn();
                return null;
            case 1:
                try {
                    return (List) ((p2.a) this.b).invoke();
                } catch (SSLPeerUnverifiedException unused) {
                    return h2.p.f5907a;
                }
            case 2:
                return (List) this.b;
            case 3:
                return this.b;
            default:
                w4.r rVar = (w4.r) this.b;
                rVar.getClass();
                try {
                    rVar.f8632w.s(2, 0, false);
                    break;
                } catch (IOException e) {
                    w4.b bVar = w4.b.f8563d;
                    rVar.d(bVar, bVar, e);
                }
                return g2.d.f5845c;
        }
    }
}
