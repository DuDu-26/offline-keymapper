package androidx.activity;

import androidx.fragment.app.d0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class v implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0 f388a;
    public final /* synthetic */ x b;

    public v(x xVar, d0 d0Var) {
        d0Var.getClass();
        this.b = xVar;
        this.f388a = d0Var;
    }

    @Override // androidx.activity.c
    public final void cancel() {
        x xVar = this.b;
        h2.g gVar = xVar.b;
        d0 d0Var = this.f388a;
        gVar.remove(d0Var);
        if (q2.c.a(xVar.f393c, d0Var)) {
            d0Var.getClass();
            xVar.f393c = null;
        }
        d0Var.getClass();
        d0Var.b.remove(this);
        w wVar = d0Var.f1208c;
        if (wVar != null) {
            wVar.invoke();
        }
        d0Var.f1208c = null;
    }
}
