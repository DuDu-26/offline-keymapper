package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.d0;
import androidx.fragment.app.k0;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f392a;
    public final h2.g b = new h2.g();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public d0 f393c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OnBackInvokedCallback f394d;
    public OnBackInvokedDispatcher e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f395f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f396g;

    public x(Runnable runnable) {
        OnBackInvokedCallback onBackInvokedCallbackA;
        this.f392a = runnable;
        int i7 = Build.VERSION.SDK_INT;
        if (i7 >= 33) {
            if (i7 >= 34) {
                onBackInvokedCallbackA = u.f387a.a(new p(this, 0), new p(this, 1), new q(0, this), new q(1, this));
            } else {
                onBackInvokedCallbackA = s.f383a.a(new q(2, this));
            }
            this.f394d = onBackInvokedCallbackA;
        }
    }

    public final void a(androidx.lifecycle.r rVar, d0 d0Var) {
        d0Var.getClass();
        androidx.lifecycle.t tVarD = rVar.d();
        if (tVarD.f1365c == androidx.lifecycle.m.f1358a) {
            return;
        }
        d0Var.b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(this, tVarD, d0Var));
        d();
        d0Var.f1208c = new w(0, this);
    }

    public final void b() {
        Object objPrevious;
        h2.g gVar = this.b;
        ListIterator listIterator = gVar.listIterator(gVar.a());
        while (true) {
            if (!listIterator.hasPrevious()) {
                objPrevious = null;
                break;
            } else {
                objPrevious = listIterator.previous();
                if (((d0) objPrevious).f1207a) {
                    break;
                }
            }
        }
        d0 d0Var = (d0) objPrevious;
        this.f393c = null;
        if (d0Var == null) {
            this.f392a.run();
            return;
        }
        k0 k0Var = d0Var.f1209d;
        k0Var.x(true);
        if (k0Var.f1230h.f1207a) {
            k0Var.L();
        } else {
            k0Var.f1229g.b();
        }
    }

    public final void c(boolean z6) {
        OnBackInvokedCallback onBackInvokedCallback;
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
        if (onBackInvokedDispatcher == null || (onBackInvokedCallback = this.f394d) == null) {
            return;
        }
        s sVar = s.f383a;
        if (z6 && !this.f395f) {
            sVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f395f = true;
        } else {
            if (z6 || !this.f395f) {
                return;
            }
            sVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f395f = false;
        }
    }

    public final void d() {
        boolean z6 = this.f396g;
        boolean z7 = false;
        h2.g gVar = this.b;
        if (gVar == null || !gVar.isEmpty()) {
            Iterator it = gVar.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (((d0) it.next()).f1207a) {
                    z7 = true;
                    break;
                }
            }
        }
        this.f396g = z7;
        if (z7 == z6 || Build.VERSION.SDK_INT < 33) {
            return;
        }
        c(z7);
    }
}
