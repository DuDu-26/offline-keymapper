package androidx.activity;

import a4.w1;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.f3;
import androidx.lifecycle.SavedStateHandleAttacher;
import androidx.lifecycle.d0;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.h0;
import androidx.lifecycle.k0;
import androidx.lifecycle.l0;
import androidx.lifecycle.m0;
import f0.s0;
import h5.a0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class m extends Activity implements m0, androidx.lifecycle.h, u0.d, androidx.lifecycle.r, f0.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.lifecycle.t f348a = new androidx.lifecycle.t(this);
    public final y2.j b = new y2.j(1);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y2.o f349c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final androidx.lifecycle.t f350d;
    public final o e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public l0 f351f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public x f352g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final l f353h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final o f354i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final i f355j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CopyOnWriteArrayList f356k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final CopyOnWriteArrayList f357l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f358m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final CopyOnWriteArrayList f359n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final CopyOnWriteArrayList f360o;

    public m() {
        final androidx.appcompat.app.k kVar = (androidx.appcompat.app.k) this;
        this.f349c = new y2.o(new a4.n(8, kVar));
        androidx.lifecycle.t tVar = new androidx.lifecycle.t(this);
        this.f350d = tVar;
        o oVar = new o(this);
        this.e = oVar;
        u0.c cVar = null;
        this.f352g = null;
        l lVar = new l(kVar);
        this.f353h = lVar;
        this.f354i = new o(lVar, new d(0, kVar));
        new AtomicInteger();
        this.f355j = new i(kVar);
        this.f356k = new CopyOnWriteArrayList();
        this.f357l = new CopyOnWriteArrayList();
        this.f358m = new CopyOnWriteArrayList();
        this.f359n = new CopyOnWriteArrayList();
        this.f360o = new CopyOnWriteArrayList();
        tVar.a(new androidx.lifecycle.p() { // from class: androidx.activity.ComponentActivity$2
            @Override // androidx.lifecycle.p
            public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar2) {
                if (lVar2 == androidx.lifecycle.l.ON_STOP) {
                    Window window = kVar.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        viewPeekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        tVar.a(new androidx.lifecycle.p() { // from class: androidx.activity.ComponentActivity$3
            @Override // androidx.lifecycle.p
            public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar2) {
                if (lVar2 == androidx.lifecycle.l.ON_DESTROY) {
                    kVar.b.b = null;
                    if (!kVar.isChangingConfigurations()) {
                        kVar.c().a();
                    }
                    l lVar3 = kVar.f353h;
                    androidx.appcompat.app.k kVar2 = lVar3.f347d;
                    kVar2.getWindow().getDecorView().removeCallbacks(lVar3);
                    kVar2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(lVar3);
                }
            }
        });
        tVar.a(new androidx.lifecycle.p() { // from class: androidx.activity.ComponentActivity$4
            @Override // androidx.lifecycle.p
            public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar2) {
                androidx.appcompat.app.k kVar2 = kVar;
                if (kVar2.f351f == null) {
                    k kVar3 = (k) kVar2.getLastNonConfigurationInstance();
                    if (kVar3 != null) {
                        kVar2.f351f = kVar3.f344a;
                    }
                    if (kVar2.f351f == null) {
                        kVar2.f351f = new l0();
                    }
                }
                kVar2.f350d.f(this);
            }
        });
        oVar.a();
        androidx.lifecycle.m mVar = tVar.f1365c;
        if (mVar != androidx.lifecycle.m.b && mVar != androidx.lifecycle.m.f1359c) {
            f3.q("Failed requirement.");
            throw null;
        }
        androidx.appcompat.widget.v vVar = (androidx.appcompat.widget.v) oVar.f362c;
        vVar.getClass();
        Iterator it = ((i.f) vVar.f929f).iterator();
        while (true) {
            i.b bVar = (i.b) it;
            if (!bVar.hasNext()) {
                break;
            }
            Map.Entry entry = (Map.Entry) bVar.next();
            entry.getClass();
            String str = (String) entry.getKey();
            u0.c cVar2 = (u0.c) entry.getValue();
            if (q2.c.a(str, "androidx.lifecycle.internal.SavedStateHandlesProvider")) {
                cVar = cVar2;
                break;
            }
        }
        if (cVar == null) {
            h0 h0Var = new h0((androidx.appcompat.widget.v) this.e.f362c, kVar);
            ((androidx.appcompat.widget.v) this.e.f362c).e("androidx.lifecycle.internal.SavedStateHandlesProvider", h0Var);
            this.f350d.a(new SavedStateHandleAttacher(h0Var));
        }
        ((androidx.appcompat.widget.v) this.e.f362c).e("android:support:activity-result", new u0.c() { // from class: androidx.activity.e
            @Override // u0.c
            public final Bundle a() {
                Bundle bundle = new Bundle();
                i iVar = kVar.f355j;
                iVar.getClass();
                HashMap map = iVar.b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(map.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(map.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(iVar.f380d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) iVar.f382g.clone());
                return bundle;
            }
        });
        f(new a.a() { // from class: androidx.activity.f
            @Override // a.a
            public final void a() {
                androidx.appcompat.app.k kVar2 = kVar;
                Bundle bundleC = ((androidx.appcompat.widget.v) kVar2.e.f362c).c("android:support:activity-result");
                if (bundleC != null) {
                    i iVar = kVar2.f355j;
                    HashMap map = iVar.b;
                    HashMap map2 = iVar.f378a;
                    Bundle bundle = iVar.f382g;
                    ArrayList<Integer> integerArrayList = bundleC.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList == null || integerArrayList == null) {
                        return;
                    }
                    iVar.f380d = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                    bundle.putAll(bundleC.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
                    for (int i7 = 0; i7 < stringArrayList.size(); i7++) {
                        String str2 = stringArrayList.get(i7);
                        if (map.containsKey(str2)) {
                            Integer num = (Integer) map.remove(str2);
                            if (!bundle.containsKey(str2)) {
                                map2.remove(num);
                            }
                        }
                        Integer num2 = integerArrayList.get(i7);
                        num2.intValue();
                        String str3 = stringArrayList.get(i7);
                        map2.put(num2, str3);
                        iVar.b.put(str3, num2);
                    }
                }
            }
        });
    }

    public static /* synthetic */ void e(m mVar) {
        super.onBackPressed();
    }

    @Override // u0.d
    public final androidx.appcompat.widget.v a() {
        return (androidx.appcompat.widget.v) this.e.f362c;
    }

    @Override // androidx.lifecycle.h
    public final a0 b() {
        q0.a aVar = q0.a.f7728c;
        aVar.getClass();
        q0.b bVar = new q0.b();
        ((LinkedHashMap) bVar.b).putAll((LinkedHashMap) aVar.b);
        LinkedHashMap linkedHashMap = (LinkedHashMap) bVar.b;
        if (getApplication() != null) {
            linkedHashMap.put(k0.f1356a, getApplication());
        }
        linkedHashMap.put(g0.f1348a, this);
        linkedHashMap.put(g0.b, this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            linkedHashMap.put(g0.f1349c, getIntent().getExtras());
        }
        return bVar;
    }

    @Override // androidx.lifecycle.m0
    public final l0 c() {
        if (getApplication() == null) {
            f3.t("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
            return null;
        }
        if (this.f351f == null) {
            k kVar = (k) getLastNonConfigurationInstance();
            if (kVar != null) {
                this.f351f = kVar.f344a;
            }
            if (this.f351f == null) {
                this.f351f = new l0();
            }
        }
        return this.f351f;
    }

    @Override // androidx.lifecycle.r
    public final androidx.lifecycle.t d() {
        return this.f350d;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (getWindow().getDecorView() != null) {
            WeakHashMap weakHashMap = s0.f5582a;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        if (getWindow().getDecorView() != null) {
            WeakHashMap weakHashMap = s0.f5582a;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    public final void f(a.a aVar) {
        y2.j jVar = this.b;
        jVar.getClass();
        if (((m) jVar.b) != null) {
            aVar.a();
        }
        ((CopyOnWriteArraySet) jVar.f8974a).add(aVar);
    }

    public final x g() {
        if (this.f352g == null) {
            this.f352g = new x(new w1(1, this));
            this.f350d.a(new androidx.lifecycle.p() { // from class: androidx.activity.ComponentActivity$6
                @Override // androidx.lifecycle.p
                public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar) {
                    if (lVar != androidx.lifecycle.l.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                        return;
                    }
                    x xVar = this.f328a.f352g;
                    OnBackInvokedDispatcher onBackInvokedDispatcherA = j.a((m) rVar);
                    xVar.getClass();
                    onBackInvokedDispatcherA.getClass();
                    xVar.e = onBackInvokedDispatcherA;
                    xVar.c(xVar.f396g);
                }
            });
        }
        return this.f352g;
    }

    public final void h(Bundle bundle) {
        super.onCreate(bundle);
        int i7 = f0.b;
        d0.b(this);
    }

    public final void i(Bundle bundle) {
        androidx.lifecycle.t tVar = this.f348a;
        tVar.getClass();
        tVar.c("markState");
        tVar.c("setCurrentState");
        tVar.e(androidx.lifecycle.m.f1359c);
        super.onSaveInstanceState(bundle);
    }

    @Override // android.app.Activity
    public void onActivityResult(int i7, int i8, Intent intent) {
        if (this.f355j.a(i7, i8, intent)) {
            return;
        }
        super.onActivityResult(i7, i8, intent);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        g().b();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f356k.iterator();
        while (it.hasNext()) {
            ((c0.f) it.next()).a(configuration);
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        this.e.b(bundle);
        y2.j jVar = this.b;
        jVar.getClass();
        jVar.b = this;
        Iterator it = ((CopyOnWriteArraySet) jVar.f8974a).iterator();
        while (it.hasNext()) {
            ((a.a) it.next()).a();
        }
        h(bundle);
        int i7 = f0.b;
        d0.b(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int i7, Menu menu) {
        if (i7 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i7, menu);
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.f349c.f8985c).iterator();
        if (!it.hasNext()) {
            return true;
        }
        it.next().getClass();
        f3.b();
        return false;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i7, MenuItem menuItem) {
        if (super.onMenuItemSelected(i7, menuItem)) {
            return true;
        }
        if (i7 != 0) {
            return false;
        }
        Iterator it = ((CopyOnWriteArrayList) this.f349c.f8985c).iterator();
        if (!it.hasNext()) {
            return false;
        }
        it.next().getClass();
        f3.b();
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z6, Configuration configuration) {
        super.onMultiWindowModeChanged(z6, configuration);
        Iterator it = this.f359n.iterator();
        while (it.hasNext()) {
            ((c0.f) it.next()).a(new y1.e(4));
        }
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f358m.iterator();
        while (it.hasNext()) {
            ((c0.f) it.next()).a(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i7, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.f349c.f8985c).iterator();
        if (!it.hasNext()) {
            super.onPanelClosed(i7, menu);
        } else {
            it.next().getClass();
            f3.b();
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z6, Configuration configuration) {
        super.onPictureInPictureModeChanged(z6, configuration);
        Iterator it = this.f360o.iterator();
        while (it.hasNext()) {
            ((c0.f) it.next()).a(new y1.e(5));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int i7, View view, Menu menu) {
        if (i7 != 0) {
            return true;
        }
        super.onPreparePanel(i7, view, menu);
        Iterator it = ((CopyOnWriteArrayList) this.f349c.f8985c).iterator();
        if (!it.hasNext()) {
            return true;
        }
        it.next().getClass();
        f3.b();
        return false;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i7, String[] strArr, int[] iArr) {
        if (this.f355j.a(i7, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i7, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        k kVar;
        l0 l0Var = this.f351f;
        if (l0Var == null && (kVar = (k) getLastNonConfigurationInstance()) != null) {
            l0Var = kVar.f344a;
        }
        if (l0Var == null) {
            return null;
        }
        k kVar2 = new k();
        kVar2.f344a = l0Var;
        return kVar2;
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.t tVar = this.f350d;
        if (tVar != null) {
            tVar.c("setCurrentState");
            tVar.e(androidx.lifecycle.m.f1359c);
        }
        i(bundle);
        this.e.c(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i7) {
        super.onTrimMemory(i7);
        Iterator it = this.f357l.iterator();
        while (it.hasNext()) {
            ((c0.f) it.next()).a(Integer.valueOf(i7));
        }
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (v1.e.C()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            o oVar = this.f354i;
            synchronized (oVar.b) {
                try {
                    oVar.f361a = true;
                    ArrayList arrayList = (ArrayList) oVar.f362c;
                    int size = arrayList.size();
                    int i7 = 0;
                    while (i7 < size) {
                        Object obj = arrayList.get(i7);
                        i7++;
                        ((p2.a) obj).invoke();
                    }
                    ((ArrayList) oVar.f362c).clear();
                } finally {
                }
            }
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131296809, this);
        View decorView2 = getWindow().getDecorView();
        decorView2.getClass();
        decorView2.setTag(2131296812, this);
        View decorView3 = getWindow().getDecorView();
        decorView3.getClass();
        decorView3.setTag(2131296811, this);
        View decorView4 = getWindow().getDecorView();
        decorView4.getClass();
        decorView4.setTag(2131296810, this);
        View decorView5 = getWindow().getDecorView();
        decorView5.getClass();
        decorView5.setTag(2131296668, this);
        View decorView6 = getWindow().getDecorView();
        l lVar = this.f353h;
        if (!lVar.f346c) {
            lVar.f346c = true;
            decorView6.getViewTreeObserver().addOnDrawListener(lVar);
        }
        super.setContentView(view);
    }
}
