package androidx.activity;

import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l implements ViewTreeObserver.OnDrawListener, Runnable, Executor {
    public Runnable b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ androidx.appcompat.app.k f347d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f345a = SystemClock.uptimeMillis() + 10000;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f346c = false;

    public l(androidx.appcompat.app.k kVar) {
        this.f347d = kVar;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.b = runnable;
        View decorView = this.f347d.getWindow().getDecorView();
        if (!this.f346c) {
            decorView.postOnAnimation(new a4.n(9, this));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    @Override // android.view.ViewTreeObserver.OnDrawListener
    public final void onDraw() {
        boolean z6;
        Runnable runnable = this.b;
        if (runnable == null) {
            if (SystemClock.uptimeMillis() > this.f345a) {
                this.f346c = false;
                this.f347d.getWindow().getDecorView().post(this);
                return;
            }
            return;
        }
        runnable.run();
        this.b = null;
        o oVar = this.f347d.f354i;
        synchronized (oVar.b) {
            z6 = oVar.f361a;
        }
        if (z6) {
            this.f346c = false;
            this.f347d.getWindow().getDecorView().post(this);
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f347d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
