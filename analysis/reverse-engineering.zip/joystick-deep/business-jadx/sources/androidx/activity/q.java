package androidx.activity;

import androidx.fragment.app.d0;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.l0;
import h5.a0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.ListIterator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q extends q2.d implements p2.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f364d;
    public final /* synthetic */ Object e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q(int i7, Object obj) {
        super(0);
        this.f364d = i7;
        this.e = obj;
    }

    @Override // p2.a
    public final Object invoke() {
        Object objPrevious;
        switch (this.f364d) {
            case 0:
                ((x) this.e).b();
                return g2.d.f5845c;
            case 1:
                x xVar = (x) this.e;
                h2.g gVar = xVar.b;
                ListIterator listIterator = gVar.listIterator(gVar.a());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((d0) objPrevious).f1207a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                xVar.f393c = null;
                return g2.d.f5845c;
            case 2:
                ((x) this.e).b();
                return g2.d.f5845c;
            default:
                androidx.appcompat.app.k kVar = (androidx.appcompat.app.k) this.e;
                ArrayList arrayList = new ArrayList();
                Class cls = q2.i.a(i0.class).f7734a;
                cls.getClass();
                arrayList.add(new q0.c(cls));
                q0.c[] cVarArr = (q0.c[]) arrayList.toArray(new q0.c[0]);
                q0.c[] cVarArr2 = (q0.c[]) Arrays.copyOf(cVarArr, cVarArr.length);
                l0 l0VarC = kVar.c();
                a0 a0VarB = kVar.b();
                l0VarC.getClass();
                a0VarB.getClass();
                LinkedHashMap linkedHashMap = l0VarC.f1357a;
                j0 i0Var = (j0) linkedHashMap.get("androidx.lifecycle.internal.SavedStateHandlesVM");
                if (i0.class.isInstance(i0Var)) {
                    i0Var.getClass();
                } else {
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                    linkedHashMap2.putAll((LinkedHashMap) a0VarB.b);
                    linkedHashMap2.put(k0.b, "androidx.lifecycle.internal.SavedStateHandlesVM");
                    try {
                        i0Var = null;
                        for (q0.c cVar : cVarArr2) {
                            if (cVar.f7729a.equals(i0.class)) {
                                i0Var = new i0();
                            }
                        }
                        if (i0Var == null) {
                            throw new IllegalArgumentException("No initializer set for given class ".concat(i0.class.getName()));
                        }
                        j0 j0Var = (j0) linkedHashMap.put("androidx.lifecycle.internal.SavedStateHandlesVM", i0Var);
                        if (j0Var != null) {
                            j0Var.a();
                        }
                    } catch (AbstractMethodError unused) {
                        k3.g.i("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
                        return null;
                    }
                }
                return (i0) i0Var;
        }
    }
}
