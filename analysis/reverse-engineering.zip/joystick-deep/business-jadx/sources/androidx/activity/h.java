package androidx.activity;

import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Point;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.io.Serializable;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f340a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f341c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f342d;

    public h(Point point, Point point2, int i7) {
        this.f340a = 4;
        this.f342d = point;
        this.f341c = new Point(point2.x, point2.y);
        this.b = i7;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f340a) {
            case 0:
                i iVar = (i) this.f341c;
                int i7 = this.b;
                Serializable serializable = (Serializable) ((w3.e) this.f342d).b;
                String str = (String) iVar.f378a.get(Integer.valueOf(i7));
                if (str == null) {
                    return;
                }
                androidx.activity.result.d dVar = (androidx.activity.result.d) iVar.e.get(str);
                if (dVar == null) {
                    iVar.f382g.remove(str);
                    iVar.f381f.put(str, serializable);
                    return;
                } else {
                    androidx.activity.result.a aVar = dVar.f376a;
                    if (iVar.f380d.remove(str)) {
                        aVar.c(serializable);
                        return;
                    }
                    return;
                }
            case 1:
                ((i) this.f341c).a(this.b, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (IntentSender.SendIntentException) this.f342d));
                return;
            case 2:
                ((TextView) this.f342d).setTypeface((Typeface) this.f341c, this.b);
                return;
            case 3:
                ((BottomSheetBehavior) this.f341c).E((View) this.f342d, this.b, false);
                return;
            default:
                synchronized (((Point) this.f342d)) {
                    try {
                        if (Thread.currentThread().isInterrupted()) {
                            return;
                        }
                        Point point = (Point) this.f342d;
                        Point point2 = (Point) this.f341c;
                        point.x = point2.x;
                        point.y = point2.y;
                        NativeAuth.E0(this.b, point2.x, point2.y);
                        return;
                    } finally {
                    }
                }
        }
    }

    public /* synthetic */ h(i iVar, int i7, Object obj, int i8) {
        this.f340a = i8;
        this.f341c = iVar;
        this.b = i7;
        this.f342d = obj;
    }

    public h(TextView textView, Typeface typeface, int i7) {
        this.f340a = 2;
        this.f342d = textView;
        this.f341c = typeface;
        this.b = i7;
    }

    public h(BottomSheetBehavior bottomSheetBehavior, View view, int i7) {
        this.f340a = 3;
        this.f341c = bottomSheetBehavior;
        this.f342d = view;
        this.b = i7;
    }
}
