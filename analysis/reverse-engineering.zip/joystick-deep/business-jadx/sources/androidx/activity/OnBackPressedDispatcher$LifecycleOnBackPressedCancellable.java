package androidx.activity;

import androidx.fragment.app.d0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements androidx.lifecycle.p, c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.lifecycle.t f330a;
    public final d0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public v f331c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ x f332d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(x xVar, androidx.lifecycle.t tVar, d0 d0Var) {
        d0Var.getClass();
        this.f332d = xVar;
        this.f330a = tVar;
        this.b = d0Var;
        tVar.a(this);
    }

    @Override // androidx.lifecycle.p
    public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar) {
        if (lVar != androidx.lifecycle.l.ON_START) {
            if (lVar != androidx.lifecycle.l.ON_STOP) {
                if (lVar == androidx.lifecycle.l.ON_DESTROY) {
                    cancel();
                    return;
                }
                return;
            } else {
                v vVar = this.f331c;
                if (vVar != null) {
                    vVar.cancel();
                    return;
                }
                return;
            }
        }
        x xVar = this.f332d;
        xVar.getClass();
        d0 d0Var = this.b;
        d0Var.getClass();
        xVar.b.addLast(d0Var);
        v vVar2 = new v(xVar, d0Var);
        d0Var.b.add(vVar2);
        xVar.d();
        d0Var.f1208c = new w(1, xVar);
        this.f331c = vVar2;
    }

    @Override // androidx.activity.c
    public final void cancel() {
        this.f330a.f(this);
        d0 d0Var = this.b;
        d0Var.getClass();
        d0Var.b.remove(this);
        v vVar = this.f331c;
        if (vVar != null) {
            vVar.cancel();
        }
        this.f331c = null;
    }
}
