package androidx.activity;

import androidx.fragment.app.d0;
import java.util.ListIterator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p extends q2.d implements p2.l {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f363d;
    public final /* synthetic */ x e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ p(x xVar, int i7) {
        super(1);
        this.f363d = i7;
        this.e = xVar;
    }

    @Override // p2.l
    public final Object invoke(Object obj) {
        Object objPrevious;
        Object objPrevious2;
        switch (this.f363d) {
            case 0:
                ((b) obj).getClass();
                x xVar = this.e;
                h2.g gVar = xVar.b;
                ListIterator listIterator = gVar.listIterator(gVar.a());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((d0) objPrevious).f1207a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                xVar.f393c = (d0) objPrevious;
                break;
            default:
                ((b) obj).getClass();
                h2.g gVar2 = this.e.b;
                ListIterator listIterator2 = gVar2.listIterator(gVar2.a());
                while (true) {
                    if (listIterator2.hasPrevious()) {
                        objPrevious2 = listIterator2.previous();
                        if (((d0) objPrevious2).f1207a) {
                        }
                    } else {
                        objPrevious2 = null;
                    }
                }
                break;
        }
        return g2.d.f5845c;
    }
}
