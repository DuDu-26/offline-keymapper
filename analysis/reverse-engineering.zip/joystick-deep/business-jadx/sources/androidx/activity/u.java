package androidx.activity;

import android.window.OnBackInvokedCallback;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final u f387a = new u();

    public final OnBackInvokedCallback a(p2.l lVar, p2.l lVar2, p2.a aVar, p2.a aVar2) {
        lVar.getClass();
        lVar2.getClass();
        aVar.getClass();
        aVar2.getClass();
        return new t(lVar, lVar2, aVar, aVar2);
    }
}
