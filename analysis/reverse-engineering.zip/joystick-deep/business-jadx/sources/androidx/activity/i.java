package androidx.activity;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.activity.result.IntentSenderRequest;
import androidx.appcompat.widget.f3;
import java.util.Arrays;
import java.util.HashSet;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i extends androidx.activity.result.f {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ androidx.appcompat.app.k f343h;

    public i(androidx.appcompat.app.k kVar) {
        this.f343h = kVar;
    }

    @Override // androidx.activity.result.f
    public final void b(int i7, a5.h hVar, Object obj) {
        Bundle bundleExtra;
        int i8;
        androidx.appcompat.app.k kVar = this.f343h;
        w3.e eVarK = hVar.K(kVar, obj);
        if (eVarK != null) {
            new Handler(Looper.getMainLooper()).post(new h(this, i7, eVarK, 0));
            return;
        }
        Intent intentS = hVar.s(kVar, obj);
        if (intentS.getExtras() != null && intentS.getExtras().getClassLoader() == null) {
            intentS.setExtrasClassLoader(kVar.getClassLoader());
        }
        if (intentS.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
            bundleExtra = intentS.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            intentS.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        } else {
            bundleExtra = null;
        }
        Bundle bundle = bundleExtra;
        if (!"androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intentS.getAction())) {
            if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intentS.getAction())) {
                androidx.core.app.a.b(kVar, intentS, i7, bundle);
                return;
            }
            IntentSenderRequest intentSenderRequest = (IntentSenderRequest) intentS.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
            try {
                i8 = i7;
            } catch (IntentSender.SendIntentException e) {
                e = e;
                i8 = i7;
            }
            try {
                androidx.core.app.a.c(kVar, intentSenderRequest.f370a, i8, intentSenderRequest.b, intentSenderRequest.f371c, intentSenderRequest.f372d, 0, bundle);
                return;
            } catch (IntentSender.SendIntentException e3) {
                e = e3;
                new Handler(Looper.getMainLooper()).post(new h(this, i8, e, 1));
                return;
            }
        }
        String[] stringArrayExtra = intentS.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        if (stringArrayExtra == null) {
            stringArrayExtra = new String[0];
        }
        HashSet hashSet = new HashSet();
        for (int i9 = 0; i9 < stringArrayExtra.length; i9++) {
            if (TextUtils.isEmpty(stringArrayExtra[i9])) {
                f3.q(g.o(new StringBuilder("Permission request for permissions "), Arrays.toString(stringArrayExtra), " must not contain null or empty values"));
                return;
            }
            if (!a5.h.M() && TextUtils.equals(stringArrayExtra[i9], "android.permission.POST_NOTIFICATIONS")) {
                hashSet.add(Integer.valueOf(i9));
            }
        }
        int size = hashSet.size();
        String[] strArr = size > 0 ? new String[stringArrayExtra.length - size] : stringArrayExtra;
        if (size > 0) {
            if (size == stringArrayExtra.length) {
                return;
            }
            int i10 = 0;
            for (int i11 = 0; i11 < stringArrayExtra.length; i11++) {
                if (!hashSet.contains(Integer.valueOf(i11))) {
                    strArr[i10] = stringArrayExtra[i11];
                    i10++;
                }
            }
        }
        androidx.core.app.b.b(kVar, stringArrayExtra, i7);
    }
}
