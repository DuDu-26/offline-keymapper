package androidx.activity;

import java.io.Serializable;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class w implements p2.a, Serializable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public transient w f389a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f390c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f391d = 0;
    public final /* synthetic */ int e;

    public w(int i7, Object obj) {
        this.e = i7;
        this.b = obj;
    }

    public final q2.a a() {
        if (!this.f390c) {
            return q2.i.a(x.class);
        }
        q2.i.f7739a.getClass();
        return new q2.e();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof w) {
            w wVar = (w) obj;
            return this.f391d == wVar.f391d && q2.c.a(this.b, wVar.b) && a().equals(wVar.a());
        }
        if (!(obj instanceof w)) {
            return false;
        }
        w wVar2 = this.f389a;
        if (wVar2 == null) {
            q2.i.f7739a.getClass();
            this.f389a = this;
            wVar2 = this;
        }
        return obj.equals(wVar2);
    }

    public final int hashCode() {
        a();
        return (((a().hashCode() * 31) + 986734966) * 31) + 1065238079;
    }

    @Override // p2.a
    public final Object invoke() {
        switch (this.e) {
            case 0:
                ((x) this.b).d();
                break;
            default:
                ((x) this.b).d();
                break;
        }
        return g2.d.f5845c;
    }

    public final String toString() {
        w wVar = this.f389a;
        if (wVar == null) {
            q2.i.f7739a.getClass();
            this.f389a = this;
            wVar = this;
        }
        return wVar != this ? wVar.toString() : "function updateEnabledCallbacks (Kotlin reflection is not available)";
    }
}
