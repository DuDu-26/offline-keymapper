package androidx.activity;

import android.window.OnBackInvokedCallback;
import androidx.appcompat.app.c0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class r implements OnBackInvokedCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f365a;
    public final /* synthetic */ Object b;

    public /* synthetic */ r(int i7, Object obj) {
        this.f365a = i7;
        this.b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f365a) {
            case 0:
                ((p2.a) this.b).invoke();
                break;
            case 1:
                ((c0) this.b).C();
                break;
            default:
                ((Runnable) this.b).run();
                break;
        }
    }
}
