package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f334a;
    public final float b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f335c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f336d;

    public b(BackEvent backEvent) {
        a aVar = a.f333a;
        float fD = aVar.d(backEvent);
        float fE = aVar.e(backEvent);
        float fB = aVar.b(backEvent);
        int iC = aVar.c(backEvent);
        this.f334a = fD;
        this.b = fE;
        this.f335c = fB;
        this.f336d = iC;
    }

    public final String toString() {
        return "BackEventCompat{touchX=" + this.f334a + ", touchY=" + this.b + ", progress=" + this.f335c + ", swipeEdge=" + this.f336d + '}';
    }
}
