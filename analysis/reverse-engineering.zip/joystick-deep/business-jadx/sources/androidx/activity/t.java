package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class t implements OnBackAnimationCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ p2.l f384a;
    public final /* synthetic */ p2.l b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p2.a f385c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ p2.a f386d;

    public t(p2.l lVar, p2.l lVar2, p2.a aVar, p2.a aVar2) {
        this.f384a = lVar;
        this.b = lVar2;
        this.f385c = aVar;
        this.f386d = aVar2;
    }

    public final void onBackCancelled() {
        this.f386d.invoke();
    }

    public final void onBackInvoked() {
        this.f385c.invoke();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        backEvent.getClass();
        this.b.invoke(new b(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        backEvent.getClass();
        this.f384a.invoke(new b(backEvent));
    }
}
