package androidx.activity;

import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.f3;
import androidx.fragment.app.k0;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.debug.UMLogUtils;
import com.umeng.commonsdk.debug.UMRTLog;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.util.HashSet;
import java.util.Objects;
import java.util.Random;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract /* synthetic */ class g {
    public static /* synthetic */ String A(int i7) {
        switch (i7) {
            case 1:
                return "NONE";
            case 2:
                return "LEFT";
            case 3:
                return "TOP";
            case 4:
                return "RIGHT";
            case 5:
                return "BOTTOM";
            case 6:
                return "BASELINE";
            case dd.f4082h /* 7 */:
                return "CENTER";
            case 8:
                return "CENTER_X";
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                return "CENTER_Y";
            default:
                throw null;
        }
    }

    public static final void a(View view, int i7) {
        int iD = n.e.d(i7);
        if (iD == 0) {
            ViewGroup viewGroup = (ViewGroup) view.getParent();
            if (viewGroup != null) {
                if (k0.E(2)) {
                    view.toString();
                    viewGroup.toString();
                }
                viewGroup.removeView(view);
                return;
            }
            return;
        }
        if (iD == 1) {
            if (k0.E(2)) {
                Objects.toString(view);
            }
            view.setVisibility(0);
        } else if (iD == 2) {
            if (k0.E(2)) {
                Objects.toString(view);
            }
            view.setVisibility(8);
        } else {
            if (iD != 3) {
                return;
            }
            if (k0.E(2)) {
                Objects.toString(view);
            }
            view.setVisibility(4);
        }
    }

    public static int b(int i7) {
        if (i7 == 0) {
            return 2;
        }
        if (i7 == 4) {
            return 4;
        }
        if (i7 == 8) {
            return 3;
        }
        f3.q(j(i7, "Unknown visibility "));
        return 0;
    }

    public static int c(View view) {
        if (view.getAlpha() == 0.0f && view.getVisibility() == 0) {
            return 4;
        }
        return b(view.getVisibility());
    }

    public static /* synthetic */ String d(int i7) {
        if (i7 == 1) {
            return "mapping";
        }
        if (i7 == 2) {
            return "recognition";
        }
        if (i7 == 3) {
            return "recoil";
        }
        throw null;
    }

    public static /* synthetic */ String e(int i7) {
        switch (i7) {
            case 1:
                return "tap";
            case 2:
                return "swipe";
            case 3:
                return "wait";
            case 4:
                return "trigger_recoil";
            case 5:
                return "trigger_anti_stuck_view";
            case 6:
                return "trigger_anti_stuck_joystick";
            default:
                throw null;
        }
    }

    public static /* synthetic */ String f(int i7) {
        switch (i7) {
            case 1:
                return "normal_press";
            case 2:
                return "continuous_tap";
            case 3:
                return "joystick";
            case 4:
                return "link_move";
            case 5:
                return "fps_view";
            case 6:
                return "normal_swipe";
            case dd.f4082h /* 7 */:
                return "smart_long_press_group";
            case 8:
                return "macro";
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                return "mouse_scroll";
            case 10:
                return "toggle_ball_visibility";
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                return "sc_touch_point";
            case 12:
                return "sc_scope_switch";
            case 13:
                return "sc_horizontal_rc";
            case 14:
                return "sc_cancel_houyao";
            case 15:
                return "sc_macro";
            case 16:
                return "sc_macro_terminate";
            case 17:
                return "sc_switch_rc";
            case 18:
                return "sc_adjust_rc_mult";
            default:
                throw null;
        }
    }

    public static float g(Random random, float f2, float f7, float f8) {
        return ((random.nextFloat() * f2) + f7) * f8;
    }

    public static GradientDrawable h(LinearLayout linearLayout, int i7, int i8, int i9, int i10) {
        linearLayout.setPadding(i7, i8, i9, i10);
        return new GradientDrawable();
    }

    public static String i(int i7, int i8, String str, String str2) {
        return str + i7 + str2 + i8;
    }

    public static String j(int i7, String str) {
        return str + i7;
    }

    public static String k(int i7, String str, String str2) {
        return str + i7 + str2;
    }

    public static String l(long j7, String str) {
        return str + j7;
    }

    public static String m(String str, androidx.fragment.app.u uVar, String str2) {
        return str + uVar + str2;
    }

    public static String n(String str, StringBuilder sb) {
        sb.append(UMLogUtils.makeUrl(str));
        return sb.toString();
    }

    public static String o(StringBuilder sb, String str, String str2) {
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    public static void p(int i7, int i8, float f2, TextView textView) {
        textView.setLayoutParams(new LinearLayout.LayoutParams(i7, i8, f2));
    }

    public static void q(int i7, HashSet hashSet, int i8, int i9, int i10) {
        hashSet.add(Integer.valueOf(i7));
        hashSet.add(Integer.valueOf(i8));
        hashSet.add(Integer.valueOf(i9));
        hashSet.add(Integer.valueOf(i10));
    }

    public static void r(TextView textView, int i7, int i8, float f2) {
        textView.setText(i7);
        textView.setTextColor(i8);
        textView.setTextSize(f2);
    }

    public static void s(h5.p pVar, String str, String str2, String str3, String str4) {
        pVar.r(str);
        pVar.r(str2);
        pVar.r(str3);
        pVar.r(str4);
    }

    public static void t(Exception exc, StringBuilder sb, String str) {
        sb.append(exc.getMessage());
        Log.e(str, sb.toString());
    }

    public static /* synthetic */ void u(Object obj) {
        if (obj == null) {
            return;
        }
        f3.b();
    }

    public static void v(String str, Exception exc, String str2) {
        Log.e(str2, str + exc);
    }

    public static void w(String str, String str2, String str3) {
        Log.e(str3, str + str2);
    }

    public static void x(String str, String str2, Throwable th) {
        Log.e(str2, str + th);
    }

    public static void y(Throwable th, StringBuilder sb, String str) {
        sb.append(th.getMessage());
        UMRTLog.e(str, sb.toString());
    }

    public static void z(HashSet hashSet, h5.p pVar, h5.p pVar2, h5.p pVar3, h5.p pVar4) {
        hashSet.add(pVar);
        hashSet.add(pVar2);
        hashSet.add(pVar3);
        hashSet.add(pVar4);
    }
}
