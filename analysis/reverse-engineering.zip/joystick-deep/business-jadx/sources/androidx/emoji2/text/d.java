package androidx.emoji2.text;

import a4.i0;
import a4.y0;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d extends a5.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e f1108a;

    public d(e eVar) {
        this.f1108a = eVar;
    }

    @Override // a5.h
    public final void Q(Throwable th) {
        this.f1108a.f1109a.d(th);
    }

    @Override // a5.h
    public final void T(y0 y0Var) {
        e eVar = this.f1108a;
        eVar.f1110c = y0Var;
        eVar.b = new i0(eVar.f1110c, new y1.e(6), eVar.f1109a.f1122h);
        j jVar = eVar.f1109a;
        ArrayList arrayList = new ArrayList();
        jVar.f1117a.writeLock().lock();
        try {
            jVar.f1118c = 1;
            arrayList.addAll(jVar.b);
            jVar.b.clear();
            jVar.f1117a.writeLock().unlock();
            jVar.f1119d.post(new h(arrayList, jVar.f1118c, (Throwable) null));
        } catch (Throwable th) {
            jVar.f1117a.writeLock().unlock();
            throw th;
        }
    }
}
