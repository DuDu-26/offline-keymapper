package androidx.emoji2.text;

import a4.y0;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.style.ReplacementSpan;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u extends ReplacementSpan {
    public final n b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint.FontMetricsInt f1142a = new Paint.FontMetricsInt();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f1143c = 1.0f;

    public u(n nVar) {
        a5.h.h(nVar, "metadata cannot be null");
        this.b = nVar;
    }

    @Override // android.text.style.ReplacementSpan
    public final void draw(Canvas canvas, CharSequence charSequence, int i7, int i8, float f2, int i9, int i10, int i11, Paint paint) {
        j.a().getClass();
        n nVar = this.b;
        y0 y0Var = nVar.b;
        Typeface typeface = (Typeface) y0Var.e;
        Typeface typeface2 = paint.getTypeface();
        paint.setTypeface(typeface);
        canvas.drawText((char[]) y0Var.f272c, nVar.f1126a * 2, 2, f2, i10, paint);
        paint.setTypeface(typeface2);
    }

    @Override // android.text.style.ReplacementSpan
    public final int getSize(Paint paint, CharSequence charSequence, int i7, int i8, Paint.FontMetricsInt fontMetricsInt) {
        Paint.FontMetricsInt fontMetricsInt2 = this.f1142a;
        paint.getFontMetricsInt(fontMetricsInt2);
        float fAbs = Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f;
        n nVar = this.b;
        this.f1143c = fAbs / (nVar.b().a(14) != 0 ? ((ByteBuffer) r8.f5600d).getShort(r1 + r8.f5598a) : (short) 0);
        m0.a aVarB = nVar.b();
        int iA = aVarB.a(14);
        if (iA != 0) {
            ((ByteBuffer) aVarB.f5600d).getShort(iA + aVarB.f5598a);
        }
        short s7 = (short) ((nVar.b().a(12) != 0 ? ((ByteBuffer) r5.f5600d).getShort(r7 + r5.f5598a) : (short) 0) * this.f1143c);
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = fontMetricsInt2.ascent;
            fontMetricsInt.descent = fontMetricsInt2.descent;
            fontMetricsInt.top = fontMetricsInt2.top;
            fontMetricsInt.bottom = fontMetricsInt2.bottom;
        }
        return s7;
    }
}
