package androidx.emoji2.text;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q extends f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final y1.e f1138d = new y1.e(7);
}
