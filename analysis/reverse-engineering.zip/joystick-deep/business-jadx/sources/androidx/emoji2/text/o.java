package androidx.emoji2.text;

import android.util.SparseArray;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1128a = 1;
    public final r b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public r f1129c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public r f1130d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1131f;

    public o(r rVar) {
        this.b = rVar;
        this.f1129c = rVar;
    }

    public final int a(int i7) {
        SparseArray sparseArray = this.f1129c.f1139a;
        r rVar = sparseArray == null ? null : (r) sparseArray.get(i7);
        int i8 = 1;
        int i9 = 2;
        if (this.f1128a == 2) {
            if (rVar != null) {
                this.f1129c = rVar;
                this.f1131f++;
            } else if (i7 == 65038) {
                b();
            } else if (i7 != 65039) {
                r rVar2 = this.f1129c;
                if (rVar2.b != null) {
                    i9 = 3;
                    if (this.f1131f != 1) {
                        this.f1130d = rVar2;
                        b();
                    } else if (c()) {
                        this.f1130d = this.f1129c;
                        b();
                    } else {
                        b();
                    }
                } else {
                    b();
                }
            }
            i8 = i9;
        } else if (rVar == null) {
            b();
        } else {
            this.f1128a = 2;
            this.f1129c = rVar;
            this.f1131f = 1;
            i8 = i9;
        }
        this.e = i7;
        return i8;
    }

    public final void b() {
        this.f1128a = 1;
        this.f1129c = this.b;
        this.f1131f = 0;
    }

    public final boolean c() {
        m0.a aVarB = this.f1129c.b.b();
        int iA = aVarB.a(6);
        return !(iA == 0 || ((ByteBuffer) aVarB.f5600d).get(iA + aVarB.f5598a) == 0) || this.e == 65039;
    }
}
