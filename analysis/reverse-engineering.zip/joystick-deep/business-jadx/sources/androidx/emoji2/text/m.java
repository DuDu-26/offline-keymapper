package androidx.emoji2.text;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class m implements Runnable {
    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i7 = b0.h.f1784a;
            b0.g.a("EmojiCompat.EmojiCompatInitializer.run");
            if (j.f1116j != null) {
                j.a().c();
            }
            b0.g.b();
        } catch (Throwable th) {
            int i8 = b0.h.f1784a;
            b0.g.b();
            throw th;
        }
    }
}
