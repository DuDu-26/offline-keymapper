package androidx.emoji2.text;

import android.content.Context;
import android.os.Looper;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class EmojiCompatInitializer implements v0.b {
    @Override // v0.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // v0.b
    public final Object b(Context context) {
        Object objB;
        q qVar = new q(new l(context, 0));
        qVar.f1111a = 1;
        if (j.f1116j == null) {
            synchronized (j.f1115i) {
                try {
                    if (j.f1116j == null) {
                        j.f1116j = new j(qVar);
                    }
                } finally {
                }
            }
        }
        v0.a aVarC = v0.a.c(context);
        aVarC.getClass();
        synchronized (v0.a.e) {
            try {
                objB = aVarC.f8427a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } finally {
            }
        }
        final androidx.lifecycle.t tVarD = ((androidx.lifecycle.r) objB).d();
        tVarD.a(new androidx.lifecycle.d(this) { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // androidx.lifecycle.d
            public final void b() {
                b.a(Looper.getMainLooper()).postDelayed(new m(), 500L);
                tVarD.f(this);
            }
        });
        return Boolean.TRUE;
    }
}
