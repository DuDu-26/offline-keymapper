package androidx.emoji2.text;

import android.text.TextPaint;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c {
    public static final ThreadLocal b = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextPaint f1107a;

    public c() {
        TextPaint textPaint = new TextPaint();
        this.f1107a = textPaint;
        textPaint.setTextSize(10.0f);
    }
}
