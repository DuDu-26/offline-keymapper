package androidx.emoji2.text;

import android.util.SparseArray;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f1139a;
    public n b;

    public r(int i7) {
        this.f1139a = new SparseArray(i7);
    }

    public final void a(n nVar, int i7, int i8) {
        int iA = nVar.a(i7);
        SparseArray sparseArray = this.f1139a;
        r rVar = sparseArray == null ? null : (r) sparseArray.get(iA);
        if (rVar == null) {
            rVar = new r(1);
            sparseArray.put(nVar.a(i7), rVar);
        }
        if (i8 > i7) {
            rVar.a(nVar, i7 + 1, i8);
        } else {
            rVar.b = nVar;
        }
    }
}
