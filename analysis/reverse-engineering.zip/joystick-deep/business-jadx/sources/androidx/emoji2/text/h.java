package androidx.emoji2.text;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1113a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1114c;

    public h(List list, int i7, Throwable th) {
        this.f1113a = 0;
        a5.h.h(list, "initCallbacks cannot be null");
        this.f1114c = new ArrayList(list);
        this.b = i7;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1113a) {
            case 0:
                ArrayList arrayList = (ArrayList) this.f1114c;
                int size = arrayList.size();
                int i7 = 0;
                if (this.b == 1) {
                    while (i7 < size) {
                        ((g) arrayList.get(i7)).a();
                        i7++;
                    }
                } else {
                    while (i7 < size) {
                        ((g) arrayList.get(i7)).getClass();
                        i7++;
                    }
                }
                break;
            case 1:
                ((RecyclerView) this.f1114c).e0(this.b);
                break;
            case 2:
                w.b bVar = (w.b) ((g.d) this.f1114c).b;
                if (bVar != null) {
                    bVar.g(this.b);
                }
                break;
            case 3:
                ((com.google.android.material.navigation.d) this.f1114c).j(this.b);
                break;
            default:
                f3.g gVar = (f3.g) this.f1114c;
                int iMax = Math.max(1, Math.min(99, gVar.f5626f + this.b));
                if (iMax != gVar.f5626f) {
                    gVar.f5626f = iMax;
                    gVar.c();
                    gVar.f5623a.postDelayed(this, 50L);
                    break;
                }
                break;
        }
    }

    public h(int i7, androidx.viewpager2.widget.n nVar) {
        this.f1113a = 1;
        this.b = i7;
        this.f1114c = nVar;
    }

    public /* synthetic */ h(Object obj, int i7, int i8) {
        this.f1113a = i8;
        this.f1114c = obj;
        this.b = i7;
    }
}
