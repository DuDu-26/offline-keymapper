package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import androidx.appcompat.widget.f3;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p implements i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1132a;
    public final c0.d b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y1.e f1133c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f1134d = new Object();
    public Handler e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ThreadPoolExecutor f1135f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ThreadPoolExecutor f1136g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public a5.h f1137h;

    public p(Context context, c0.d dVar) {
        a5.h.h(context, "Context cannot be null");
        this.f1132a = context.getApplicationContext();
        this.b = dVar;
        this.f1133c = q.f1138d;
    }

    @Override // androidx.emoji2.text.i
    public final void a(a5.h hVar) {
        synchronized (this.f1134d) {
            this.f1137h = hVar;
        }
        synchronized (this.f1134d) {
            try {
                if (this.f1137h == null) {
                    return;
                }
                if (this.f1135f == null) {
                    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat"));
                    threadPoolExecutor.allowCoreThreadTimeOut(true);
                    this.f1136g = threadPoolExecutor;
                    this.f1135f = threadPoolExecutor;
                }
                this.f1135f.execute(new a4.n(11, this));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.f1134d) {
            try {
                this.f1137h = null;
                Handler handler = this.e;
                if (handler != null) {
                    handler.removeCallbacks(null);
                }
                this.e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f1136g;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f1135f = null;
                this.f1136g = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final c0.i c() {
        try {
            y1.e eVar = this.f1133c;
            Context context = this.f1132a;
            c0.d dVar = this.b;
            eVar.getClass();
            androidx.appcompat.app.g gVarA = c0.c.a(context, dVar);
            int i7 = gVarA.f492a;
            if (i7 != 0) {
                f3.i(androidx.activity.g.k(i7, "fetchFonts failed (", ")"));
                return null;
            }
            c0.i[] iVarArr = (c0.i[]) gVarA.b;
            if (iVarArr != null && iVarArr.length != 0) {
                return iVarArr[0];
            }
            f3.i("fetchFonts failed (empty result)");
            return null;
        } catch (PackageManager.NameNotFoundException e) {
            k3.g.j("provider not found", e);
            return null;
        }
    }
}
