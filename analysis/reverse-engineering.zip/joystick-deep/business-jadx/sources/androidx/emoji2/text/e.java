package androidx.emoji2.text;

import a4.i0;
import a4.y0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f1109a;
    public volatile i0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile y0 f1110c;

    public e(j jVar) {
        this.f1109a = jVar;
    }
}
