package androidx.emoji2.text;

import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.widget.f3;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final Object f1115i = new Object();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static volatile j f1116j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ReentrantReadWriteLock f1117a;
    public final l.c b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f1118c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Handler f1119d;
    public final e e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f1120f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1121g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final c f1122h;

    public j(q qVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f1117a = reentrantReadWriteLock;
        this.f1118c = 3;
        i iVar = (i) qVar.b;
        this.f1120f = iVar;
        int i7 = qVar.f1111a;
        this.f1121g = i7;
        this.f1122h = (c) qVar.f1112c;
        this.f1119d = new Handler(Looper.getMainLooper());
        this.b = new l.c();
        e eVar = new e(this);
        this.e = eVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i7 == 0) {
            try {
                this.f1118c = 0;
            } catch (Throwable th) {
                this.f1117a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                iVar.a(new d(eVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static j a() {
        j jVar;
        synchronized (f1115i) {
            try {
                jVar = f1116j;
                if (!(jVar != null)) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } finally {
            }
        }
        return jVar;
    }

    public final int b() {
        this.f1117a.readLock().lock();
        try {
            return this.f1118c;
        } finally {
            this.f1117a.readLock().unlock();
        }
    }

    public final void c() {
        if (!(this.f1121g == 1)) {
            f3.t("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
            return;
        }
        if (b() == 1) {
            return;
        }
        this.f1117a.writeLock().lock();
        try {
            if (this.f1118c == 0) {
                return;
            }
            this.f1118c = 0;
            this.f1117a.writeLock().unlock();
            e eVar = this.e;
            j jVar = eVar.f1109a;
            try {
                jVar.f1120f.a(new d(eVar));
            } catch (Throwable th) {
                jVar.d(th);
            }
        } finally {
            this.f1117a.writeLock().unlock();
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f1117a.writeLock().lock();
        try {
            this.f1118c = 2;
            arrayList.addAll(this.b);
            this.b.clear();
            this.f1117a.writeLock().unlock();
            this.f1119d.post(new h(arrayList, this.f1118c, th));
        } catch (Throwable th2) {
            this.f1117a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x0172 A[DONT_GENERATE] */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0174 A[DONT_GENERATE] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0083 A[Catch: all -> 0x0076, TryCatch #0 {all -> 0x0076, blocks: (B:32:0x005a, B:35:0x005f, B:37:0x0063, B:39:0x0070, B:44:0x0083, B:46:0x008d, B:48:0x0090, B:50:0x0094, B:52:0x00a4, B:53:0x00a7, B:55:0x00b4, B:58:0x00bc, B:63:0x00db, B:69:0x00e7, B:72:0x00f3, B:73:0x00fd, B:74:0x010c, B:76:0x0113, B:77:0x0118, B:79:0x0123, B:81:0x012a, B:83:0x012e, B:85:0x0134, B:87:0x0138, B:90:0x0140, B:93:0x014c, B:94:0x0151, B:96:0x015f, B:42:0x0079), top: B:116:0x005a }] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0094 A[Catch: all -> 0x0076, TryCatch #0 {all -> 0x0076, blocks: (B:32:0x005a, B:35:0x005f, B:37:0x0063, B:39:0x0070, B:44:0x0083, B:46:0x008d, B:48:0x0090, B:50:0x0094, B:52:0x00a4, B:53:0x00a7, B:55:0x00b4, B:58:0x00bc, B:63:0x00db, B:69:0x00e7, B:72:0x00f3, B:73:0x00fd, B:74:0x010c, B:76:0x0113, B:77:0x0118, B:79:0x0123, B:81:0x012a, B:83:0x012e, B:85:0x0134, B:87:0x0138, B:90:0x0140, B:93:0x014c, B:94:0x0151, B:96:0x015f, B:42:0x0079), top: B:116:0x005a }] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00b4 A[Catch: all -> 0x0076, TryCatch #0 {all -> 0x0076, blocks: (B:32:0x005a, B:35:0x005f, B:37:0x0063, B:39:0x0070, B:44:0x0083, B:46:0x008d, B:48:0x0090, B:50:0x0094, B:52:0x00a4, B:53:0x00a7, B:55:0x00b4, B:58:0x00bc, B:63:0x00db, B:69:0x00e7, B:72:0x00f3, B:73:0x00fd, B:74:0x010c, B:76:0x0113, B:77:0x0118, B:79:0x0123, B:81:0x012a, B:83:0x012e, B:85:0x0134, B:87:0x0138, B:90:0x0140, B:93:0x014c, B:94:0x0151, B:96:0x015f, B:42:0x0079), top: B:116:0x005a }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.CharSequence e(java.lang.CharSequence r12, int r13, int r14) {
        /*
            Method dump skipped, instruction units count: 409
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.j.e(java.lang.CharSequence, int, int):java.lang.CharSequence");
    }

    public final void f(g gVar) {
        a5.h.h(gVar, "initCallback cannot be null");
        this.f1117a.writeLock().lock();
        try {
            if (this.f1118c == 1 || this.f1118c == 2) {
                this.f1119d.post(new h(Arrays.asList(gVar), this.f1118c, (Throwable) null));
            } else {
                this.b.add(gVar);
            }
            this.f1117a.writeLock().unlock();
        } catch (Throwable th) {
            this.f1117a.writeLock().unlock();
            throw th;
        }
    }
}
