package androidx.emoji2.text;

import android.content.Context;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l implements i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f1124a;

    public l(Context context, int i7) {
        switch (i7) {
            case 1:
                this.f1124a = context;
                break;
            default:
                this.f1124a = context.getApplicationContext();
                break;
        }
    }

    @Override // androidx.emoji2.text.i
    public void a(a5.h hVar) {
        a aVar = new a("EmojiCompatInitializer");
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), aVar);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new a3.f(this, hVar, threadPoolExecutor, 13));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0065 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0066 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v0 */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v2, types: [android.database.Cursor] */
    /* JADX WARN: Type inference failed for: r9v22 */
    /* JADX WARN: Type inference failed for: r9v23 */
    /* JADX WARN: Type inference failed for: r9v4 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String b(int r9, java.lang.String r10) throws java.lang.Throwable {
        /*
            r8 = this;
            r1 = 0
            if (r9 == 0) goto L5c
            r0 = 1
            if (r9 == r0) goto L49
            r0 = 2
            if (r9 == r0) goto L36
            r0 = 3
            if (r9 == r0) goto L2f
            r0 = 4
            if (r9 == r0) goto L1c
            r10 = 5
            if (r9 == r10) goto L14
            r3 = r1
            goto L63
        L14:
            java.lang.String r9 = "content://com.vivo.abe.exidentifier/guid"
            android.net.Uri r9 = android.net.Uri.parse(r9)
        L1a:
            r3 = r9
            goto L63
        L1c:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r0 = "content://com.vivo.vms.IdProvider/IdentifierId/OAIDSTATUS_"
            r9.<init>(r0)
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.net.Uri r9 = android.net.Uri.parse(r9)
            goto L1a
        L2f:
            java.lang.String r9 = "content://com.vivo.vms.IdProvider/IdentifierId/UDID"
            android.net.Uri r9 = android.net.Uri.parse(r9)
            goto L1a
        L36:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r0 = "content://com.vivo.vms.IdProvider/IdentifierId/AAID_"
            r9.<init>(r0)
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.net.Uri r9 = android.net.Uri.parse(r9)
            goto L1a
        L49:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r0 = "content://com.vivo.vms.IdProvider/IdentifierId/VAID_"
            r9.<init>(r0)
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.net.Uri r9 = android.net.Uri.parse(r9)
            goto L1a
        L5c:
            java.lang.String r9 = "content://com.vivo.vms.IdProvider/IdentifierId/OAID"
            android.net.Uri r9 = android.net.Uri.parse(r9)
            goto L1a
        L63:
            if (r3 != 0) goto L66
            return r1
        L66:
            android.content.Context r9 = r8.f1124a     // Catch: java.lang.Throwable -> L91 java.lang.Exception -> L94
            android.content.ContentResolver r2 = r9.getContentResolver()     // Catch: java.lang.Throwable -> L91 java.lang.Exception -> L94
            r6 = 0
            r7 = 0
            r4 = 0
            r5 = 0
            android.database.Cursor r9 = r2.query(r3, r4, r5, r6, r7)     // Catch: java.lang.Throwable -> L91 java.lang.Exception -> L94
            if (r9 == 0) goto L8b
            boolean r10 = r9.moveToNext()     // Catch: java.lang.Throwable -> L87 java.lang.Exception -> L95
            if (r10 == 0) goto L8b
            java.lang.String r10 = "value"
            int r10 = r9.getColumnIndex(r10)     // Catch: java.lang.Throwable -> L87 java.lang.Exception -> L95
            java.lang.String r1 = r9.getString(r10)     // Catch: java.lang.Throwable -> L87 java.lang.Exception -> L95
            goto L8b
        L87:
            r0 = move-exception
            r10 = r0
            r1 = r9
            goto La2
        L8b:
            if (r9 == 0) goto L90
            r9.close()
        L90:
            return r1
        L91:
            r0 = move-exception
            r10 = r0
            goto La2
        L94:
            r9 = r1
        L95:
            java.lang.String r10 = "VMS_SDK_DB"
            java.lang.String r0 = "return cursor is error"
            android.util.Log.e(r10, r0)     // Catch: java.lang.Throwable -> L87
            if (r9 == 0) goto La1
            r9.close()
        La1:
            return r1
        La2:
            if (r1 == 0) goto La7
            r1.close()
        La7:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.l.b(int, java.lang.String):java.lang.String");
    }
}
