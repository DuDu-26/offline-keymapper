package androidx.emoji2.text;

import android.graphics.Rect;
import android.view.View;
import androidx.appcompat.widget.f3;
import androidx.recyclerview.widget.f0;
import androidx.recyclerview.widget.u0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1111a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1112c;

    public f(u0 u0Var) {
        this.f1111a = Integer.MIN_VALUE;
        this.f1112c = new Rect();
        this.b = u0Var;
    }

    public static f a(u0 u0Var, int i7) {
        if (i7 == 0) {
            return new f0(u0Var, 0);
        }
        if (i7 == 1) {
            return new f0(u0Var, 1);
        }
        f3.q("invalid orientation");
        return null;
    }

    public abstract int b(View view);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public abstract int m(View view);

    public abstract int n(View view);

    public abstract void o(int i7);

    public f(i iVar) {
        this.f1111a = 0;
        this.f1112c = new c();
        this.b = iVar;
    }
}
