package androidx.emoji2.text;

import a4.y0;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class n {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ThreadLocal f1125d = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1126a;
    public final y0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f1127c = 0;

    public n(y0 y0Var, int i7) {
        this.b = y0Var;
        this.f1126a = i7;
    }

    public final int a(int i7) {
        m0.a aVarB = b();
        int iA = aVarB.a(16);
        if (iA == 0) {
            return 0;
        }
        ByteBuffer byteBuffer = (ByteBuffer) aVarB.f5600d;
        int i8 = iA + aVarB.f5598a;
        return byteBuffer.getInt((i7 * 4) + byteBuffer.getInt(i8) + i8 + 4);
    }

    public final m0.a b() {
        ThreadLocal threadLocal = f1125d;
        m0.a aVar = (m0.a) threadLocal.get();
        if (aVar == null) {
            aVar = new m0.a();
            threadLocal.set(aVar);
        }
        m0.b bVar = (m0.b) this.b.b;
        int iA = bVar.a(6);
        if (iA != 0) {
            int i7 = iA + bVar.f5598a;
            int i8 = (this.f1126a * 4) + ((ByteBuffer) bVar.f5600d).getInt(i7) + i7 + 4;
            int i9 = ((ByteBuffer) bVar.f5600d).getInt(i8) + i8;
            ByteBuffer byteBuffer = (ByteBuffer) bVar.f5600d;
            aVar.f5600d = byteBuffer;
            if (byteBuffer != null) {
                aVar.f5598a = i9;
                int i10 = i9 - byteBuffer.getInt(i9);
                aVar.b = i10;
                aVar.f5599c = ((ByteBuffer) aVar.f5600d).getShort(i10);
                return aVar;
            }
            aVar.f5598a = 0;
            aVar.b = 0;
            aVar.f5599c = 0;
        }
        return aVar;
    }

    public final String toString() {
        int i7;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        m0.a aVarB = b();
        int iA = aVarB.a(4);
        sb.append(Integer.toHexString(iA != 0 ? ((ByteBuffer) aVarB.f5600d).getInt(iA + aVarB.f5598a) : 0));
        sb.append(", codepoints:");
        m0.a aVarB2 = b();
        int iA2 = aVarB2.a(16);
        if (iA2 != 0) {
            int i8 = iA2 + aVarB2.f5598a;
            i7 = ((ByteBuffer) aVarB2.f5600d).getInt(((ByteBuffer) aVarB2.f5600d).getInt(i8) + i8);
        } else {
            i7 = 0;
        }
        for (int i9 = 0; i9 < i7; i9++) {
            sb.append(Integer.toHexString(a(i9)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
