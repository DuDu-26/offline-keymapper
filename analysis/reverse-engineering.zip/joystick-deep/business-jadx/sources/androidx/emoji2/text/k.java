package androidx.emoji2.text;

import a4.y0;
import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k extends a5.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ a5.h f1123a;
    public final /* synthetic */ ThreadPoolExecutor b;

    public k(a5.h hVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f1123a = hVar;
        this.b = threadPoolExecutor;
    }

    @Override // a5.h
    public final void Q(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.b;
        try {
            this.f1123a.Q(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    @Override // a5.h
    public final void T(y0 y0Var) {
        ThreadPoolExecutor threadPoolExecutor = this.b;
        try {
            this.f1123a.T(y0Var);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
