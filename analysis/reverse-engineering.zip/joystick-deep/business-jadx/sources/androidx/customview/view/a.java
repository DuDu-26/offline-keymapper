package androidx.customview.view;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.appcompat.widget.f3;
import androidx.drawerlayout.widget.DrawerLayout$SavedState;
import androidx.viewpager.widget.ViewPager$SavedState;
import com.google.android.material.internal.ParcelableSparseArray;
import com.google.android.material.stateful.ExtendableSavedState;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements Parcelable.ClassLoaderCreator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1100a;

    public /* synthetic */ a(int i7) {
        this.f1100a = i7;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f1100a) {
            case 0:
                if (parcel.readParcelable(null) == null) {
                    return AbsSavedState.b;
                }
                f3.t("superState must be null");
                return null;
            case 1:
                return new ViewPager$SavedState(parcel, null);
            case 2:
                return new ExtendableSavedState(parcel, null);
            case 3:
                return new ParcelableSparseArray(parcel, null);
            default:
                return new DrawerLayout$SavedState(parcel, null);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i7) {
        switch (this.f1100a) {
            case 0:
                return new AbsSavedState[i7];
            case 1:
                return new ViewPager$SavedState[i7];
            case 2:
                return new ExtendableSavedState[i7];
            case 3:
                return new ParcelableSparseArray[i7];
            default:
                return new DrawerLayout$SavedState[i7];
        }
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        switch (this.f1100a) {
            case 0:
                if (parcel.readParcelable(classLoader) == null) {
                    return AbsSavedState.b;
                }
                f3.t("superState must be null");
                return null;
            case 1:
                return new ViewPager$SavedState(parcel, classLoader);
            case 2:
                return new ExtendableSavedState(parcel, classLoader);
            case 3:
                return new ParcelableSparseArray(parcel, classLoader);
            default:
                return new DrawerLayout$SavedState(parcel, classLoader);
        }
    }
}
