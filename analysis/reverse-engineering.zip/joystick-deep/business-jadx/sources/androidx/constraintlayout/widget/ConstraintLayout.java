package androidx.constraintlayout.widget;

import a4.i0;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.a;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import moe.heroman.eventtest.adbhelper.AdbMessage;
import org.xmlpull.v1.XmlPullParserException;
import p.e;
import p.h;
import s.b;
import s.c;
import s.d;
import s.f;
import s.g;
import s.o;
import s.p;
import s.q;
import s.s;
import s.t;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class ConstraintLayout extends ViewGroup {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static t f995r;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f996a;
    public final ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f997c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f998d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f999f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1000g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1001h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1002i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public o f1003j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public i0 f1004k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f1005l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public HashMap f1006m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final SparseArray f1007n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final s.e f1008o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1009p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f1010q;

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f996a = new SparseArray();
        this.b = new ArrayList(4);
        this.f997c = new e();
        this.f998d = 0;
        this.e = 0;
        this.f999f = Integer.MAX_VALUE;
        this.f1000g = Integer.MAX_VALUE;
        this.f1001h = true;
        this.f1002i = 257;
        this.f1003j = null;
        this.f1004k = null;
        this.f1005l = -1;
        this.f1006m = new HashMap();
        this.f1007n = new SparseArray();
        this.f1008o = new s.e(this, this);
        this.f1009p = 0;
        this.f1010q = 0;
        i(attributeSet, 0);
    }

    public static d g() {
        d dVar = new d(-2, -2);
        dVar.f7974a = -1;
        dVar.b = -1;
        dVar.f7976c = -1.0f;
        dVar.f7978d = true;
        dVar.e = -1;
        dVar.f7981f = -1;
        dVar.f7983g = -1;
        dVar.f7985h = -1;
        dVar.f7987i = -1;
        dVar.f7989j = -1;
        dVar.f7991k = -1;
        dVar.f7993l = -1;
        dVar.f7994m = -1;
        dVar.f7996n = -1;
        dVar.f7998o = -1;
        dVar.f8000p = -1;
        dVar.f8002q = 0;
        dVar.f8003r = 0.0f;
        dVar.f8004s = -1;
        dVar.f8005t = -1;
        dVar.f8006u = -1;
        dVar.f8007v = -1;
        dVar.f8008w = Integer.MIN_VALUE;
        dVar.f8009x = Integer.MIN_VALUE;
        dVar.f8010y = Integer.MIN_VALUE;
        dVar.f8011z = Integer.MIN_VALUE;
        dVar.A = Integer.MIN_VALUE;
        dVar.B = Integer.MIN_VALUE;
        dVar.C = Integer.MIN_VALUE;
        dVar.D = 0;
        dVar.E = 0.5f;
        dVar.F = 0.5f;
        dVar.G = null;
        dVar.H = -1.0f;
        dVar.I = -1.0f;
        dVar.J = 0;
        dVar.K = 0;
        dVar.L = 0;
        dVar.M = 0;
        dVar.N = 0;
        dVar.O = 0;
        dVar.P = 0;
        dVar.Q = 0;
        dVar.R = 1.0f;
        dVar.S = 1.0f;
        dVar.T = -1;
        dVar.U = -1;
        dVar.V = -1;
        dVar.W = false;
        dVar.X = false;
        dVar.Y = null;
        dVar.Z = 0;
        dVar.a0 = true;
        dVar.f7975b0 = true;
        dVar.f7977c0 = false;
        dVar.f7979d0 = false;
        dVar.f7980e0 = false;
        dVar.f7982f0 = -1;
        dVar.f7984g0 = -1;
        dVar.f7986h0 = -1;
        dVar.f7988i0 = -1;
        dVar.f7990j0 = Integer.MIN_VALUE;
        dVar.f7992k0 = Integer.MIN_VALUE;
        dVar.l0 = 0.5f;
        dVar.f8001p0 = new p.d();
        return dVar;
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int iMax2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static t getSharedValues() {
        if (f995r == null) {
            t tVar = new t();
            new SparseIntArray();
            new HashMap();
            f995r = tVar;
        }
        return f995r;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof d;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                ((b) arrayList.get(i7)).getClass();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i8 = 0; i8 < childCount; i8++) {
                View childAt = getChildAt(i8);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i9 = Integer.parseInt(strArrSplit[0]);
                        int i10 = Integer.parseInt(strArrSplit[1]);
                        int i11 = Integer.parseInt(strArrSplit[2]);
                        int i12 = (int) ((i9 / 1080.0f) * width);
                        int i13 = (int) ((i10 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f2 = i12;
                        float f7 = i13;
                        float f8 = i12 + ((int) ((i11 / 1080.0f) * width));
                        canvas.drawLine(f2, f7, f8, f7, paint);
                        float f9 = i13 + ((int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height));
                        canvas.drawLine(f8, f7, f8, f9, paint);
                        canvas.drawLine(f8, f9, f2, f9, paint);
                        canvas.drawLine(f2, f9, f2, f7, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f2, f7, f8, f9, paint);
                        canvas.drawLine(f2, f9, f8, f7, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.f1001h = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        d dVar = new d(context, attributeSet);
        dVar.f7974a = -1;
        dVar.b = -1;
        dVar.f7976c = -1.0f;
        dVar.f7978d = true;
        dVar.e = -1;
        dVar.f7981f = -1;
        dVar.f7983g = -1;
        dVar.f7985h = -1;
        dVar.f7987i = -1;
        dVar.f7989j = -1;
        dVar.f7991k = -1;
        dVar.f7993l = -1;
        dVar.f7994m = -1;
        dVar.f7996n = -1;
        dVar.f7998o = -1;
        dVar.f8000p = -1;
        dVar.f8002q = 0;
        dVar.f8003r = 0.0f;
        dVar.f8004s = -1;
        dVar.f8005t = -1;
        dVar.f8006u = -1;
        dVar.f8007v = -1;
        dVar.f8008w = Integer.MIN_VALUE;
        dVar.f8009x = Integer.MIN_VALUE;
        dVar.f8010y = Integer.MIN_VALUE;
        dVar.f8011z = Integer.MIN_VALUE;
        dVar.A = Integer.MIN_VALUE;
        dVar.B = Integer.MIN_VALUE;
        dVar.C = Integer.MIN_VALUE;
        dVar.D = 0;
        dVar.E = 0.5f;
        dVar.F = 0.5f;
        dVar.G = null;
        dVar.H = -1.0f;
        dVar.I = -1.0f;
        dVar.J = 0;
        dVar.K = 0;
        dVar.L = 0;
        dVar.M = 0;
        dVar.N = 0;
        dVar.O = 0;
        dVar.P = 0;
        dVar.Q = 0;
        dVar.R = 1.0f;
        dVar.S = 1.0f;
        dVar.T = -1;
        dVar.U = -1;
        dVar.V = -1;
        dVar.W = false;
        dVar.X = false;
        dVar.Y = null;
        dVar.Z = 0;
        dVar.a0 = true;
        dVar.f7975b0 = true;
        dVar.f7977c0 = false;
        dVar.f7979d0 = false;
        dVar.f7980e0 = false;
        dVar.f7982f0 = -1;
        dVar.f7984g0 = -1;
        dVar.f7986h0 = -1;
        dVar.f7988i0 = -1;
        dVar.f7990j0 = Integer.MIN_VALUE;
        dVar.f7992k0 = Integer.MIN_VALUE;
        dVar.l0 = 0.5f;
        dVar.f8001p0 = new p.d();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s.b);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i7 = 0; i7 < indexCount; i7++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i7);
            int i8 = c.f7973a.get(index);
            switch (i8) {
                case 1:
                    dVar.V = typedArrayObtainStyledAttributes.getInt(index, dVar.V);
                    break;
                case 2:
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f8000p);
                    dVar.f8000p = resourceId;
                    if (resourceId == -1) {
                        dVar.f8000p = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 3:
                    dVar.f8002q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f8002q);
                    break;
                case 4:
                    float f2 = typedArrayObtainStyledAttributes.getFloat(index, dVar.f8003r) % 360.0f;
                    dVar.f8003r = f2;
                    if (f2 < 0.0f) {
                        dVar.f8003r = (360.0f - f2) % 360.0f;
                    }
                    break;
                case 5:
                    dVar.f7974a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.f7974a);
                    break;
                case 6:
                    dVar.b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.b);
                    break;
                case dd.f4082h /* 7 */:
                    dVar.f7976c = typedArrayObtainStyledAttributes.getFloat(index, dVar.f7976c);
                    break;
                case 8:
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.e);
                    dVar.e = resourceId2;
                    if (resourceId2 == -1) {
                        dVar.e = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                    int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7981f);
                    dVar.f7981f = resourceId3;
                    if (resourceId3 == -1) {
                        dVar.f7981f = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 10:
                    int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7983g);
                    dVar.f7983g = resourceId4;
                    if (resourceId4 == -1) {
                        dVar.f7983g = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                    int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7985h);
                    dVar.f7985h = resourceId5;
                    if (resourceId5 == -1) {
                        dVar.f7985h = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 12:
                    int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7987i);
                    dVar.f7987i = resourceId6;
                    if (resourceId6 == -1) {
                        dVar.f7987i = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 13:
                    int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7989j);
                    dVar.f7989j = resourceId7;
                    if (resourceId7 == -1) {
                        dVar.f7989j = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 14:
                    int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7991k);
                    dVar.f7991k = resourceId8;
                    if (resourceId8 == -1) {
                        dVar.f7991k = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 15:
                    int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7993l);
                    dVar.f7993l = resourceId9;
                    if (resourceId9 == -1) {
                        dVar.f7993l = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 16:
                    int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7994m);
                    dVar.f7994m = resourceId10;
                    if (resourceId10 == -1) {
                        dVar.f7994m = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 17:
                    int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f8004s);
                    dVar.f8004s = resourceId11;
                    if (resourceId11 == -1) {
                        dVar.f8004s = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 18:
                    int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f8005t);
                    dVar.f8005t = resourceId12;
                    if (resourceId12 == -1) {
                        dVar.f8005t = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 19:
                    int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f8006u);
                    dVar.f8006u = resourceId13;
                    if (resourceId13 == -1) {
                        dVar.f8006u = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 20:
                    int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f8007v);
                    dVar.f8007v = resourceId14;
                    if (resourceId14 == -1) {
                        dVar.f8007v = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 21:
                    dVar.f8008w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f8008w);
                    break;
                case 22:
                    dVar.f8009x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f8009x);
                    break;
                case 23:
                    dVar.f8010y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f8010y);
                    break;
                case AdbMessage.HEADER_LENGTH /* 24 */:
                    dVar.f8011z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f8011z);
                    break;
                case 25:
                    dVar.A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.A);
                    break;
                case 26:
                    dVar.B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.B);
                    break;
                case 27:
                    dVar.W = typedArrayObtainStyledAttributes.getBoolean(index, dVar.W);
                    break;
                case 28:
                    dVar.X = typedArrayObtainStyledAttributes.getBoolean(index, dVar.X);
                    break;
                case 29:
                    dVar.E = typedArrayObtainStyledAttributes.getFloat(index, dVar.E);
                    break;
                case 30:
                    dVar.F = typedArrayObtainStyledAttributes.getFloat(index, dVar.F);
                    break;
                case 31:
                    int i9 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    dVar.L = i9;
                    if (i9 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                    }
                    break;
                case a.f3643d /* 32 */:
                    int i10 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    dVar.M = i10;
                    if (i10 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                    }
                    break;
                case 33:
                    try {
                        dVar.N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.N);
                    } catch (Exception unused) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.N) == -2) {
                            dVar.N = -2;
                        }
                    }
                    break;
                case 34:
                    try {
                        dVar.P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.P);
                    } catch (Exception unused2) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.P) == -2) {
                            dVar.P = -2;
                        }
                    }
                    break;
                case 35:
                    dVar.R = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, dVar.R));
                    dVar.L = 2;
                    break;
                case 36:
                    try {
                        dVar.O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.O);
                    } catch (Exception unused3) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.O) == -2) {
                            dVar.O = -2;
                        }
                    }
                    break;
                case 37:
                    try {
                        dVar.Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.Q);
                    } catch (Exception unused4) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.Q) == -2) {
                            dVar.Q = -2;
                        }
                    }
                    break;
                case 38:
                    dVar.S = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, dVar.S));
                    dVar.M = 2;
                    break;
                default:
                    switch (i8) {
                        case 44:
                            o.h(dVar, typedArrayObtainStyledAttributes.getString(index));
                            break;
                        case 45:
                            dVar.H = typedArrayObtainStyledAttributes.getFloat(index, dVar.H);
                            break;
                        case 46:
                            dVar.I = typedArrayObtainStyledAttributes.getFloat(index, dVar.I);
                            break;
                        case 47:
                            dVar.J = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 48:
                            dVar.K = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 49:
                            dVar.T = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.T);
                            break;
                        case 50:
                            dVar.U = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.U);
                            break;
                        case 51:
                            dVar.Y = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 52:
                            int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7996n);
                            dVar.f7996n = resourceId15;
                            if (resourceId15 == -1) {
                                dVar.f7996n = typedArrayObtainStyledAttributes.getInt(index, -1);
                            }
                            break;
                        case 53:
                            int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f7998o);
                            dVar.f7998o = resourceId16;
                            if (resourceId16 == -1) {
                                dVar.f7998o = typedArrayObtainStyledAttributes.getInt(index, -1);
                            }
                            break;
                        case 54:
                            dVar.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.D);
                            break;
                        case 55:
                            dVar.C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.C);
                            break;
                        default:
                            switch (i8) {
                                case 64:
                                    o.g(dVar, typedArrayObtainStyledAttributes, index, 0);
                                    break;
                                case 65:
                                    o.g(dVar, typedArrayObtainStyledAttributes, index, 1);
                                    break;
                                case 66:
                                    dVar.Z = typedArrayObtainStyledAttributes.getInt(index, dVar.Z);
                                    break;
                                case 67:
                                    dVar.f7978d = typedArrayObtainStyledAttributes.getBoolean(index, dVar.f7978d);
                                    break;
                            }
                            break;
                    }
                    break;
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        dVar.a();
        return dVar;
    }

    public int getMaxHeight() {
        return this.f1000g;
    }

    public int getMaxWidth() {
        return this.f999f;
    }

    public int getMinHeight() {
        return this.e;
    }

    public int getMinWidth() {
        return this.f998d;
    }

    public int getOptimizationLevel() {
        return this.f997c.D0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        e eVar = this.f997c;
        if (eVar.f7305j == null) {
            int id2 = getId();
            if (id2 != -1) {
                eVar.f7305j = getContext().getResources().getResourceEntryName(id2);
            } else {
                eVar.f7305j = "parent";
            }
        }
        if (eVar.f7302h0 == null) {
            eVar.f7302h0 = eVar.f7305j;
        }
        ArrayList arrayList = eVar.f7328q0;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            p.d dVar = (p.d) obj;
            View view = dVar.f7298f0;
            if (view != null) {
                if (dVar.f7305j == null && (id = view.getId()) != -1) {
                    dVar.f7305j = getContext().getResources().getResourceEntryName(id);
                }
                if (dVar.f7302h0 == null) {
                    dVar.f7302h0 = dVar.f7305j;
                }
            }
        }
        eVar.n(sb);
        return sb.toString();
    }

    public final p.d h(View view) {
        if (view == this) {
            return this.f997c;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof d) {
            return ((d) view.getLayoutParams()).f8001p0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof d) {
            return ((d) view.getLayoutParams()).f8001p0;
        }
        return null;
    }

    public final void i(AttributeSet attributeSet, int i7) {
        e eVar = this.f997c;
        eVar.f7298f0 = this;
        s.e eVar2 = this.f1008o;
        eVar.f7332u0 = eVar2;
        eVar.f7330s0.f7696f = eVar2;
        this.f996a.put(getId(), this);
        this.f1003j = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.b, i7, 0);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i8 = 0; i8 < indexCount; i8++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i8);
                if (index == 16) {
                    this.f998d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f998d);
                } else if (index == 17) {
                    this.e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.e);
                } else if (index == 14) {
                    this.f999f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f999f);
                } else if (index == 15) {
                    this.f1000g = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f1000g);
                } else if (index == 113) {
                    this.f1002i = typedArrayObtainStyledAttributes.getInt(index, this.f1002i);
                } else if (index == 56) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            j(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1004k = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        o oVar = new o();
                        this.f1003j = oVar;
                        oVar.e(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1003j = null;
                    }
                    this.f1005l = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        eVar.D0 = this.f1002i;
        n.c.f6907p = eVar.W(512);
    }

    public final void j(int i7) {
        String str;
        Context context = getContext();
        i0 i0Var = new i0(12);
        i0Var.b = new SparseArray();
        i0Var.f124c = new SparseArray();
        XmlResourceParser xml = context.getResources().getXml(i7);
        try {
            f fVar = null;
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                i0Var.z(context, xml);
                            }
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                fVar = new f(context, xml);
                                ((SparseArray) i0Var.b).put(fVar.f8018a, fVar);
                            }
                            break;
                        case 1382829617:
                            str = "StateSet";
                            name.equals(str);
                            break;
                        case 1657696882:
                            str = "layoutDescription";
                            name.equals(str);
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                g gVar = new g(context, xml);
                                if (fVar != null) {
                                    ((ArrayList) fVar.f8019c).add(gVar);
                                }
                            }
                            break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
        this.f1004k = i0Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:160:0x030c  */
    /* JADX WARN: Removed duplicated region for block: B:164:0x032d  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x034c  */
    /* JADX WARN: Removed duplicated region for block: B:176:0x0368  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void k(p.e r29, int r30, int r31, int r32) {
        /*
            Method dump skipped, instruction units count: 1762
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.k(p.e, int, int, int):void");
    }

    public final void l(p.d dVar, d dVar2, SparseArray sparseArray, int i7, int i8) {
        View view = (View) this.f996a.get(i7);
        p.d dVar3 = (p.d) sparseArray.get(i7);
        if (dVar3 == null || view == null || !(view.getLayoutParams() instanceof d)) {
            return;
        }
        dVar2.f7977c0 = true;
        if (i8 == 6) {
            d dVar4 = (d) view.getLayoutParams();
            dVar4.f7977c0 = true;
            dVar4.f8001p0.E = true;
        }
        dVar.i(6).b(dVar3.i(i8), dVar2.D, dVar2.C, true);
        dVar.E = true;
        dVar.i(3).j();
        dVar.i(5).j();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            d dVar = (d) childAt.getLayoutParams();
            p.d dVar2 = dVar.f8001p0;
            if (childAt.getVisibility() != 8 || dVar.f7979d0 || dVar.f7980e0 || zIsInEditMode) {
                int iR = dVar2.r();
                int iS = dVar2.s();
                childAt.layout(iR, iS, dVar2.q() + iR, dVar2.k() + iS);
            }
        }
        ArrayList arrayList = this.b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i12 = 0; i12 < size; i12++) {
                ((b) arrayList.get(i12)).getClass();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:114:0x01d7  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x033c  */
    /* JADX WARN: Removed duplicated region for block: B:172:0x0354  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x0372  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x0394  */
    /* JADX WARN: Removed duplicated region for block: B:192:0x03bf  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x03dc  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x03fe  */
    /* JADX WARN: Removed duplicated region for block: B:206:0x0409  */
    /* JADX WARN: Removed duplicated region for block: B:214:0x0427  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x042f  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x0554  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x055a  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onMeasure(int r35, int r36) {
        /*
            Method dump skipped, instruction units count: 1562
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        p.d dVarH = h(view);
        if ((view instanceof q) && !(dVarH instanceof h)) {
            d dVar = (d) view.getLayoutParams();
            h hVar = new h();
            dVar.f8001p0 = hVar;
            dVar.f7979d0 = true;
            hVar.S(dVar.V);
        }
        if (view instanceof b) {
            b bVar = (b) view;
            bVar.i();
            ((d) view.getLayoutParams()).f7980e0 = true;
            ArrayList arrayList = this.b;
            if (!arrayList.contains(bVar)) {
                arrayList.add(bVar);
            }
        }
        this.f996a.put(view.getId(), view);
        this.f1001h = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f996a.remove(view.getId());
        p.d dVarH = h(view);
        this.f997c.f7328q0.remove(dVarH);
        dVarH.C();
        this.b.remove(view);
        this.f1001h = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f1001h = true;
        super.requestLayout();
    }

    public void setConstraintSet(o oVar) {
        this.f1003j = oVar;
    }

    @Override // android.view.View
    public void setId(int i7) {
        int id = getId();
        SparseArray sparseArray = this.f996a;
        sparseArray.remove(id);
        super.setId(i7);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i7) {
        if (i7 == this.f1000g) {
            return;
        }
        this.f1000g = i7;
        requestLayout();
    }

    public void setMaxWidth(int i7) {
        if (i7 == this.f999f) {
            return;
        }
        this.f999f = i7;
        requestLayout();
    }

    public void setMinHeight(int i7) {
        if (i7 == this.e) {
            return;
        }
        this.e = i7;
        requestLayout();
    }

    public void setMinWidth(int i7) {
        if (i7 == this.f998d) {
            return;
        }
        this.f998d = i7;
        requestLayout();
    }

    public void setOnConstraintsChanged(p pVar) {
        i0 i0Var = this.f1004k;
        if (i0Var != null) {
            i0Var.getClass();
        }
    }

    public void setOptimizationLevel(int i7) {
        this.f1002i = i7;
        e eVar = this.f997c;
        eVar.D0 = i7;
        n.c.f6907p = eVar.W(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i7) {
        super(context, attributeSet, i7);
        this.f996a = new SparseArray();
        this.b = new ArrayList(4);
        this.f997c = new e();
        this.f998d = 0;
        this.e = 0;
        this.f999f = Integer.MAX_VALUE;
        this.f1000g = Integer.MAX_VALUE;
        this.f1001h = true;
        this.f1002i = 257;
        this.f1003j = null;
        this.f1004k = null;
        this.f1005l = -1;
        this.f1006m = new HashMap();
        this.f1007n = new SparseArray();
        this.f1008o = new s.e(this, this);
        this.f1009p = 0;
        this.f1010q = 0;
        i(attributeSet, i7);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        d dVar = new d(layoutParams);
        dVar.f7974a = -1;
        dVar.b = -1;
        dVar.f7976c = -1.0f;
        dVar.f7978d = true;
        dVar.e = -1;
        dVar.f7981f = -1;
        dVar.f7983g = -1;
        dVar.f7985h = -1;
        dVar.f7987i = -1;
        dVar.f7989j = -1;
        dVar.f7991k = -1;
        dVar.f7993l = -1;
        dVar.f7994m = -1;
        dVar.f7996n = -1;
        dVar.f7998o = -1;
        dVar.f8000p = -1;
        dVar.f8002q = 0;
        dVar.f8003r = 0.0f;
        dVar.f8004s = -1;
        dVar.f8005t = -1;
        dVar.f8006u = -1;
        dVar.f8007v = -1;
        dVar.f8008w = Integer.MIN_VALUE;
        dVar.f8009x = Integer.MIN_VALUE;
        dVar.f8010y = Integer.MIN_VALUE;
        dVar.f8011z = Integer.MIN_VALUE;
        dVar.A = Integer.MIN_VALUE;
        dVar.B = Integer.MIN_VALUE;
        dVar.C = Integer.MIN_VALUE;
        dVar.D = 0;
        dVar.E = 0.5f;
        dVar.F = 0.5f;
        dVar.G = null;
        dVar.H = -1.0f;
        dVar.I = -1.0f;
        dVar.J = 0;
        dVar.K = 0;
        dVar.L = 0;
        dVar.M = 0;
        dVar.N = 0;
        dVar.O = 0;
        dVar.P = 0;
        dVar.Q = 0;
        dVar.R = 1.0f;
        dVar.S = 1.0f;
        dVar.T = -1;
        dVar.U = -1;
        dVar.V = -1;
        dVar.W = false;
        dVar.X = false;
        dVar.Y = null;
        dVar.Z = 0;
        dVar.a0 = true;
        dVar.f7975b0 = true;
        dVar.f7977c0 = false;
        dVar.f7979d0 = false;
        dVar.f7980e0 = false;
        dVar.f7982f0 = -1;
        dVar.f7984g0 = -1;
        dVar.f7986h0 = -1;
        dVar.f7988i0 = -1;
        dVar.f7990j0 = Integer.MIN_VALUE;
        dVar.f7992k0 = Integer.MIN_VALUE;
        dVar.l0 = 0.5f;
        dVar.f8001p0 = new p.d();
        return dVar;
    }
}
