package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import java.util.HashMap;
import p.a;
import p.d;
import s.b;
import s.s;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class Barrier extends b {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f992h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f993i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public a f994j;

    public Barrier(Context context) {
        super(context);
        this.f7968a = new int[32];
        this.f7972g = new HashMap();
        this.f7969c = context;
        g(null);
        super.setVisibility(8);
    }

    @Override // s.b
    public final void g(AttributeSet attributeSet) {
        super.g(attributeSet);
        a aVar = new a();
        aVar.f7264s0 = 0;
        aVar.f7265t0 = true;
        aVar.f7266u0 = 0;
        aVar.f7267v0 = false;
        this.f994j = aVar;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i7 = 0; i7 < indexCount; i7++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i7);
                if (index == 26) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.f994j.f7265t0 = typedArrayObtainStyledAttributes.getBoolean(index, true);
                } else if (index == 27) {
                    this.f994j.f7266u0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f7970d = this.f994j;
        i();
    }

    public boolean getAllowsGoneWidget() {
        return this.f994j.f7265t0;
    }

    public int getMargin() {
        return this.f994j.f7266u0;
    }

    public int getType() {
        return this.f992h;
    }

    @Override // s.b
    public final void h(d dVar, boolean z6) {
        int i7 = this.f992h;
        this.f993i = i7;
        if (z6) {
            if (i7 == 5) {
                this.f993i = 1;
            } else if (i7 == 6) {
                this.f993i = 0;
            }
        } else if (i7 == 5) {
            this.f993i = 0;
        } else if (i7 == 6) {
            this.f993i = 1;
        }
        if (dVar instanceof a) {
            ((a) dVar).f7264s0 = this.f993i;
        }
    }

    public void setAllowsGoneWidget(boolean z6) {
        this.f994j.f7265t0 = z6;
    }

    public void setDpMargin(int i7) {
        this.f994j.f7266u0 = (int) ((i7 * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i7) {
        this.f994j.f7266u0 = i7;
    }

    public void setType(int i7) {
        this.f992h = i7;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }
}
