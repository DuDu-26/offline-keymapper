package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import java.util.ArrayList;
import p.d;
import p.g;
import q.b;
import s.s;
import s.u;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class Flow extends u {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public g f991j;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // s.u, s.b
    public final void g(AttributeSet attributeSet) {
        super.g(attributeSet);
        g gVar = new g();
        gVar.f7353s0 = 0;
        gVar.f7354t0 = 0;
        gVar.f7355u0 = 0;
        gVar.f7356v0 = 0;
        gVar.w0 = 0;
        gVar.f7357x0 = 0;
        gVar.f7358y0 = false;
        gVar.f7359z0 = 0;
        gVar.A0 = 0;
        gVar.B0 = new b();
        gVar.C0 = null;
        gVar.D0 = -1;
        gVar.E0 = -1;
        gVar.F0 = -1;
        gVar.G0 = -1;
        gVar.H0 = -1;
        gVar.I0 = -1;
        gVar.J0 = 0.5f;
        gVar.K0 = 0.5f;
        gVar.L0 = 0.5f;
        gVar.M0 = 0.5f;
        gVar.N0 = 0.5f;
        gVar.O0 = 0.5f;
        gVar.P0 = 0;
        gVar.Q0 = 0;
        gVar.R0 = 2;
        gVar.S0 = 2;
        gVar.T0 = 0;
        gVar.U0 = -1;
        gVar.V0 = 0;
        gVar.W0 = new ArrayList();
        gVar.X0 = null;
        gVar.Y0 = null;
        gVar.Z0 = null;
        gVar.b1 = 0;
        this.f991j = gVar;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i7 = 0; i7 < indexCount; i7++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i7);
                if (index == 0) {
                    this.f991j.V0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    g gVar2 = this.f991j;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar2.f7353s0 = dimensionPixelSize;
                    gVar2.f7354t0 = dimensionPixelSize;
                    gVar2.f7355u0 = dimensionPixelSize;
                    gVar2.f7356v0 = dimensionPixelSize;
                } else if (index == 18) {
                    g gVar3 = this.f991j;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar3.f7355u0 = dimensionPixelSize2;
                    gVar3.w0 = dimensionPixelSize2;
                    gVar3.f7357x0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f991j.f7356v0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f991j.w0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f991j.f7353s0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f991j.f7357x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f991j.f7354t0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f991j.T0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f991j.D0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f991j.E0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f991j.F0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f991j.H0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f991j.G0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f991j.I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f991j.J0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f991j.L0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f991j.N0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f991j.M0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f991j.O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f991j.K0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f991j.R0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f991j.S0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f991j.P0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f991j.Q0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f991j.U0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f7970d = this.f991j;
        i();
    }

    @Override // s.b
    public final void h(d dVar, boolean z6) {
        g gVar = this.f991j;
        int i7 = gVar.f7355u0;
        if (i7 > 0 || gVar.f7356v0 > 0) {
            if (z6) {
                gVar.w0 = gVar.f7356v0;
                gVar.f7357x0 = i7;
            } else {
                gVar.w0 = i7;
                gVar.f7357x0 = gVar.f7356v0;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:387:0x0684  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:401:0x071f  */
    /* JADX WARN: Removed duplicated region for block: B:407:0x072d  */
    /* JADX WARN: Removed duplicated region for block: B:408:0x0730  */
    /* JADX WARN: Removed duplicated region for block: B:415:0x074c  */
    /* JADX WARN: Removed duplicated region for block: B:416:0x074e  */
    /* JADX WARN: Removed duplicated region for block: B:426:0x0108 A[EDGE_INSN: B:426:0x0108->B:61:0x0108 BREAK  A[LOOP:1: B:55:0x00f1->B:60:0x0103], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00e0  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x012e  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0139  */
    @Override // s.u
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void j(p.g r39, int r40, int r41) {
        /*
            Method dump skipped, instruction units count: 1890
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.helper.widget.Flow.j(p.g, int, int):void");
    }

    @Override // s.b, android.view.View
    public final void onMeasure(int i7, int i8) {
        j(this.f991j, i7, i8);
    }

    public void setFirstHorizontalBias(float f2) {
        this.f991j.L0 = f2;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i7) {
        this.f991j.F0 = i7;
        requestLayout();
    }

    public void setFirstVerticalBias(float f2) {
        this.f991j.M0 = f2;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i7) {
        this.f991j.G0 = i7;
        requestLayout();
    }

    public void setHorizontalAlign(int i7) {
        this.f991j.R0 = i7;
        requestLayout();
    }

    public void setHorizontalBias(float f2) {
        this.f991j.J0 = f2;
        requestLayout();
    }

    public void setHorizontalGap(int i7) {
        this.f991j.P0 = i7;
        requestLayout();
    }

    public void setHorizontalStyle(int i7) {
        this.f991j.D0 = i7;
        requestLayout();
    }

    public void setLastHorizontalBias(float f2) {
        this.f991j.N0 = f2;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i7) {
        this.f991j.H0 = i7;
        requestLayout();
    }

    public void setLastVerticalBias(float f2) {
        this.f991j.O0 = f2;
        requestLayout();
    }

    public void setLastVerticalStyle(int i7) {
        this.f991j.I0 = i7;
        requestLayout();
    }

    public void setMaxElementsWrap(int i7) {
        this.f991j.U0 = i7;
        requestLayout();
    }

    public void setOrientation(int i7) {
        this.f991j.V0 = i7;
        requestLayout();
    }

    public void setPadding(int i7) {
        g gVar = this.f991j;
        gVar.f7353s0 = i7;
        gVar.f7354t0 = i7;
        gVar.f7355u0 = i7;
        gVar.f7356v0 = i7;
        requestLayout();
    }

    public void setPaddingBottom(int i7) {
        this.f991j.f7354t0 = i7;
        requestLayout();
    }

    public void setPaddingLeft(int i7) {
        this.f991j.w0 = i7;
        requestLayout();
    }

    public void setPaddingRight(int i7) {
        this.f991j.f7357x0 = i7;
        requestLayout();
    }

    public void setPaddingTop(int i7) {
        this.f991j.f7353s0 = i7;
        requestLayout();
    }

    public void setVerticalAlign(int i7) {
        this.f991j.S0 = i7;
        requestLayout();
    }

    public void setVerticalBias(float f2) {
        this.f991j.K0 = f2;
        requestLayout();
    }

    public void setVerticalGap(int i7) {
        this.f991j.Q0 = i7;
        requestLayout();
    }

    public void setVerticalStyle(int i7) {
        this.f991j.E0 = i7;
        requestLayout();
    }

    public void setWrapMode(int i7) {
        this.f991j.T0 = i7;
        requestLayout();
    }
}
