package androidx.fragment.app;

import android.graphics.Typeface;
import android.view.View;
import com.google.android.material.behavior.SwipeDismissBehavior;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1201a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1202c;

    public c(j jVar, ArrayList arrayList, t0 t0Var) {
        this.f1201a = 0;
        this.b = arrayList;
        this.f1202c = t0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i7 = this.f1201a;
        Object obj = this.b;
        Object obj2 = this.f1202c;
        switch (i7) {
            case 0:
                ArrayList arrayList = (ArrayList) obj;
                t0 t0Var = (t0) obj2;
                if (arrayList.contains(t0Var)) {
                    arrayList.remove(t0Var);
                    androidx.activity.g.a(t0Var.f1292c.E, t0Var.f1291a);
                }
                break;
            case 1:
                Typeface typeface = (Typeface) obj2;
                w.b bVar = (w.b) ((g.d) obj).b;
                if (bVar != null) {
                    bVar.h(typeface);
                }
                break;
            case 2:
                ((c0.f) obj).a(obj2);
                break;
            default:
                k0.e eVar = ((SwipeDismissBehavior) obj2).f3035a;
                if (eVar != null && eVar.f()) {
                    WeakHashMap weakHashMap = f0.s0.f5582a;
                    f0.b0.m((View) obj, this);
                    break;
                }
                break;
        }
    }

    public /* synthetic */ c(Object obj, int i7, Object obj2) {
        this.f1201a = i7;
        this.b = obj;
        this.f1202c = obj2;
    }

    public c(SwipeDismissBehavior swipeDismissBehavior, View view, boolean z6) {
        this.f1201a = 3;
        this.f1202c = swipeDismissBehavior;
        this.b = view;
    }
}
