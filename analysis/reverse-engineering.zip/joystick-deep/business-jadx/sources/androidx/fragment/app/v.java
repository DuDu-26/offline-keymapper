package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcelable;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class v implements u0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f1321a;

    public v(MainActivity mainActivity) {
        this.f1321a = mainActivity;
    }

    @Override // u0.c
    public final Bundle a() {
        MainActivity mainActivity;
        Bundle bundle = new Bundle();
        do {
            mainActivity = this.f1321a;
        } while (androidx.appcompat.app.k.m(mainActivity.k()));
        mainActivity.f504q.d(androidx.lifecycle.l.ON_STOP);
        Parcelable parcelableQ = ((x) mainActivity.f503p.b).f1325d.Q();
        if (parcelableQ != null) {
            bundle.putParcelable("android:support:fragments", parcelableQ);
        }
        return bundle;
    }
}
