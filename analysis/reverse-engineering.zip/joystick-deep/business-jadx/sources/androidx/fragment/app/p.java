package androidx.fragment.app;

import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e f1267a;
    public final /* synthetic */ AtomicReference b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ a5.h f1268c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ androidx.activity.result.a f1269d;
    public final /* synthetic */ u e;

    public p(u uVar, e eVar, AtomicReference atomicReference, a5.h hVar, androidx.activity.result.a aVar) {
        this.e = uVar;
        this.f1267a = eVar;
        this.b = atomicReference;
        this.f1268c = hVar;
        this.f1269d = aVar;
    }

    public final void a() {
        StringBuilder sb = new StringBuilder("fragment_");
        u uVar = this.e;
        sb.append(uVar.e);
        sb.append("_rq#");
        sb.append(uVar.P.getAndIncrement());
        String string = sb.toString();
        u uVar2 = (u) this.f1267a.b;
        x xVar = uVar2.f1313s;
        this.b.set((xVar != null ? xVar.e : uVar2.H()).f355j.d(string, uVar, this.f1268c, this.f1269d));
    }
}
