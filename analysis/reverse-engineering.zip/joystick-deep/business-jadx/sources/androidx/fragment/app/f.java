package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1211a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(int i7, Object obj) {
        this.f1211a = i7;
        this.b = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1211a) {
            case 0:
                g gVar = (g) this.b;
                gVar.f1213a.endViewTransition(gVar.b);
                gVar.f1214c.d();
                break;
            case 1:
                n nVar = (n) this.b;
                nVar.V.onDismiss(nVar.f1258d0);
                break;
            default:
                ((k0) this.b).x(true);
                break;
        }
    }
}
