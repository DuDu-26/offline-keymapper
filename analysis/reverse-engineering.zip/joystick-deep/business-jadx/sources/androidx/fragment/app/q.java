package androidx.fragment.app;

import androidx.appcompat.widget.f3;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q extends androidx.activity.result.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AtomicReference f1276a;

    public q(AtomicReference atomicReference) {
        this.f1276a = atomicReference;
    }

    @Override // androidx.activity.result.b
    public final void a(Object obj) {
        androidx.activity.result.b bVar = (androidx.activity.result.b) this.f1276a.get();
        if (bVar != null) {
            bVar.a(obj);
        } else {
            f3.t("Operation cannot be started before fragment is in created state");
        }
    }
}
