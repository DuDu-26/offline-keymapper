package androidx.fragment.app;

import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class s0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1289a;
    public final /* synthetic */ t0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ j f1290c;

    public /* synthetic */ s0(j jVar, t0 t0Var, int i7) {
        this.f1289a = i7;
        this.f1290c = jVar;
        this.b = t0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1289a) {
            case 0:
                ArrayList arrayList = this.f1290c.b;
                t0 t0Var = this.b;
                if (arrayList.contains(t0Var)) {
                    androidx.activity.g.a(t0Var.f1292c.E, t0Var.f1291a);
                }
                break;
            default:
                j jVar = this.f1290c;
                ArrayList arrayList2 = jVar.b;
                t0 t0Var2 = this.b;
                arrayList2.remove(t0Var2);
                jVar.f1220c.remove(t0Var2);
                break;
        }
    }
}
