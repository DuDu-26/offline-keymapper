package androidx.fragment.app;

import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import com.umeng.analytics.pro.bc;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k0 {
    public boolean A;
    public boolean B;
    public boolean C;
    public ArrayList D;
    public ArrayList E;
    public ArrayList F;
    public l0 G;
    public final f H;
    public boolean b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f1227d;
    public ArrayList e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public androidx.activity.x f1229g;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ArrayList f1233k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final y2.o f1234l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f1235m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f1236n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public x f1237o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public a5.h f1238p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public u f1239q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public u f1240r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final f0 f1241s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final e0 f1242t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public androidx.activity.result.c f1243u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public androidx.activity.result.c f1244v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public androidx.activity.result.c f1245w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ArrayDeque f1246x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f1247y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1248z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f1225a = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y2.e f1226c = new y2.e(7);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final a0 f1228f = new a0(this);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final d0 f1230h = new d0(this);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final AtomicInteger f1231i = new AtomicInteger();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Map f1232j = Collections.synchronizedMap(new HashMap());

    public k0() {
        Collections.synchronizedMap(new HashMap());
        Collections.synchronizedMap(new HashMap());
        this.f1234l = new y2.o(this);
        this.f1235m = new CopyOnWriteArrayList();
        this.f1236n = -1;
        this.f1241s = new f0(this);
        this.f1242t = new e0();
        this.f1246x = new ArrayDeque();
        this.H = new f(2, this);
    }

    public static boolean E(int i7) {
        return Log.isLoggable("FragmentManager", i7);
    }

    public static boolean F(u uVar) {
        uVar.getClass();
        y2.e eVar = uVar.f1314t.f1226c;
        eVar.getClass();
        ArrayList arrayList = new ArrayList();
        for (o0 o0Var : ((HashMap) eVar.b).values()) {
            if (o0Var != null) {
                arrayList.add(o0Var.f1265c);
            } else {
                arrayList.add(null);
            }
        }
        int size = arrayList.size();
        boolean zF = false;
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            u uVar2 = (u) obj;
            if (uVar2 != null) {
                zF = F(uVar2);
            }
            if (zF) {
                return true;
            }
        }
        return false;
    }

    public static boolean G(u uVar) {
        if (uVar == null) {
            return true;
        }
        if (uVar.B) {
            return uVar.f1312r == null || G(uVar.f1315u);
        }
        return false;
    }

    public static boolean H(u uVar) {
        if (uVar == null) {
            return true;
        }
        k0 k0Var = uVar.f1312r;
        return uVar.equals(k0Var.f1240r) && H(k0Var.f1239q);
    }

    public final u A(int i7) {
        y2.e eVar = this.f1226c;
        ArrayList arrayList = (ArrayList) eVar.f8965c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            u uVar = (u) arrayList.get(size);
            if (uVar != null && uVar.f1316v == i7) {
                return uVar;
            }
        }
        for (o0 o0Var : ((HashMap) eVar.b).values()) {
            if (o0Var != null) {
                u uVar2 = o0Var.f1265c;
                if (uVar2.f1316v == i7) {
                    return uVar2;
                }
            }
        }
        return null;
    }

    public final ViewGroup B(u uVar) {
        ViewGroup viewGroup = uVar.D;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (uVar.f1317w <= 0 || !this.f1238p.S()) {
            return null;
        }
        View viewR = this.f1238p.R(uVar.f1317w);
        if (viewR instanceof ViewGroup) {
            return (ViewGroup) viewR;
        }
        return null;
    }

    public final f0 C() {
        u uVar = this.f1239q;
        return uVar != null ? uVar.f1312r.C() : this.f1241s;
    }

    public final e0 D() {
        u uVar = this.f1239q;
        return uVar != null ? uVar.f1312r.D() : this.f1242t;
    }

    public final boolean I() {
        return this.f1248z || this.A;
    }

    public final void J(int i7, boolean z6) {
        x xVar;
        if (this.f1237o == null && i7 != -1) {
            f3.t("No activity");
            return;
        }
        if (z6 || i7 != this.f1236n) {
            this.f1236n = i7;
            y2.e eVar = this.f1226c;
            HashMap map = (HashMap) eVar.b;
            ArrayList arrayList = (ArrayList) eVar.f8965c;
            int size = arrayList.size();
            int i8 = 0;
            while (i8 < size) {
                Object obj = arrayList.get(i8);
                i8++;
                o0 o0Var = (o0) map.get(((u) obj).e);
                if (o0Var != null) {
                    o0Var.k();
                }
            }
            for (o0 o0Var2 : map.values()) {
                if (o0Var2 != null) {
                    o0Var2.k();
                    u uVar = o0Var2.f1265c;
                    if (uVar.f1306l && uVar.f1311q <= 0) {
                        eVar.x(o0Var2);
                    }
                }
            }
            W();
            if (this.f1247y && (xVar = this.f1237o) != null && this.f1236n == 7) {
                xVar.e.j().a();
                this.f1247y = false;
            }
        }
    }

    public final void K() {
        if (this.f1237o == null) {
            return;
        }
        this.f1248z = false;
        this.A = false;
        this.G.f1254h = false;
        for (u uVar : this.f1226c.r()) {
            if (uVar != null) {
                uVar.f1314t.K();
            }
        }
    }

    public final boolean L() {
        x(false);
        w(true);
        u uVar = this.f1240r;
        if (uVar != null && uVar.h().L()) {
            return true;
        }
        boolean zM = M(this.D, this.E, -1, 0);
        if (zM) {
            this.b = true;
            try {
                O(this.D, this.E);
            } finally {
                d();
            }
        }
        Y();
        if (this.C) {
            this.C = false;
            W();
        }
        ((HashMap) this.f1226c.b).values().removeAll(Collections.singleton(null));
        return zM;
    }

    public final boolean M(ArrayList arrayList, ArrayList arrayList2, int i7, int i8) {
        int size;
        a aVar;
        ArrayList arrayList3 = this.f1227d;
        if (arrayList3 == null) {
            return false;
        }
        if (i7 < 0 && (i8 & 1) == 0) {
            int size2 = arrayList3.size() - 1;
            if (size2 < 0) {
                return false;
            }
            arrayList.add(this.f1227d.remove(size2));
            arrayList2.add(Boolean.TRUE);
            return true;
        }
        if (i7 >= 0) {
            size = arrayList3.size() - 1;
            while (size >= 0) {
                a aVar2 = (a) this.f1227d.get(size);
                if (i7 >= 0 && i7 == aVar2.f1197s) {
                    break;
                }
                size--;
            }
            if (size < 0) {
                return false;
            }
            if ((i8 & 1) != 0) {
                do {
                    size--;
                    if (size < 0) {
                        break;
                    }
                    aVar = (a) this.f1227d.get(size);
                    if (i7 < 0) {
                        break;
                    }
                } while (i7 == aVar.f1197s);
            }
        } else {
            size = -1;
        }
        if (size == this.f1227d.size() - 1) {
            return false;
        }
        for (int size3 = this.f1227d.size() - 1; size3 > size; size3--) {
            arrayList.add(this.f1227d.remove(size3));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    public final void N(u uVar) {
        if (E(2)) {
            Objects.toString(uVar);
        }
        boolean z6 = uVar.f1311q > 0;
        if (uVar.f1320z && z6) {
            return;
        }
        y2.e eVar = this.f1226c;
        synchronized (((ArrayList) eVar.f8965c)) {
            ((ArrayList) eVar.f8965c).remove(uVar);
        }
        uVar.f1305k = false;
        if (F(uVar)) {
            this.f1247y = true;
        }
        uVar.f1306l = true;
        V(uVar);
    }

    public final void O(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            f3.t("Internal error with the back stack records");
            return;
        }
        int size = arrayList.size();
        int i7 = 0;
        int i8 = 0;
        while (i7 < size) {
            if (!((a) arrayList.get(i7)).f1194p) {
                if (i8 != i7) {
                    z(arrayList, arrayList2, i8, i7);
                }
                i8 = i7 + 1;
                if (((Boolean) arrayList2.get(i7)).booleanValue()) {
                    while (i8 < size && ((Boolean) arrayList2.get(i8)).booleanValue() && !((a) arrayList.get(i8)).f1194p) {
                        i8++;
                    }
                }
                z(arrayList, arrayList2, i7, i8);
                i7 = i8 - 1;
            }
            i7++;
        }
        if (i8 != size) {
            z(arrayList, arrayList2, i8, size);
        }
    }

    public final void P(Parcelable parcelable) {
        y2.o oVar;
        int i7;
        o0 o0Var;
        if (parcelable == null) {
            return;
        }
        FragmentManagerState fragmentManagerState = (FragmentManagerState) parcelable;
        if (fragmentManagerState.f1163a == null) {
            return;
        }
        y2.e eVar = this.f1226c;
        ((HashMap) eVar.b).clear();
        ArrayList arrayList = fragmentManagerState.f1163a;
        int size = arrayList.size();
        int i8 = 0;
        while (true) {
            oVar = this.f1234l;
            i7 = 2;
            if (i8 >= size) {
                break;
            }
            Object obj = arrayList.get(i8);
            i8++;
            FragmentState fragmentState = (FragmentState) obj;
            if (fragmentState != null) {
                u uVar = (u) this.G.f1250c.get(fragmentState.b);
                if (uVar != null) {
                    if (E(2)) {
                        uVar.toString();
                    }
                    o0Var = new o0(oVar, eVar, uVar, fragmentState);
                } else {
                    o0Var = new o0(this.f1234l, this.f1226c, this.f1237o.b.getClassLoader(), C(), fragmentState);
                }
                u uVar2 = o0Var.f1265c;
                uVar2.f1312r = this;
                if (E(2)) {
                    uVar2.toString();
                }
                o0Var.m(this.f1237o.b.getClassLoader());
                eVar.w(o0Var);
                o0Var.e = this.f1236n;
            }
        }
        l0 l0Var = this.G;
        l0Var.getClass();
        ArrayList arrayList2 = new ArrayList(l0Var.f1250c.values());
        int size2 = arrayList2.size();
        int i9 = 0;
        while (i9 < size2) {
            Object obj2 = arrayList2.get(i9);
            i9++;
            u uVar3 = (u) obj2;
            if (((HashMap) eVar.b).get(uVar3.e) == null) {
                if (E(2)) {
                    uVar3.toString();
                    Objects.toString(fragmentManagerState.f1163a);
                }
                this.G.b(uVar3);
                uVar3.f1312r = this;
                o0 o0Var2 = new o0(oVar, eVar, uVar3);
                o0Var2.e = 1;
                o0Var2.k();
                uVar3.f1306l = true;
                o0Var2.k();
            }
        }
        ArrayList arrayList3 = fragmentManagerState.b;
        ((ArrayList) eVar.f8965c).clear();
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            int i10 = 0;
            while (i10 < size3) {
                Object obj3 = arrayList3.get(i10);
                i10++;
                String str = (String) obj3;
                u uVarI = eVar.i(str);
                if (uVarI == null) {
                    f3.t(s.h.e("No instantiated fragment for (", str, ")"));
                    return;
                } else {
                    if (E(2)) {
                        uVarI.toString();
                    }
                    eVar.c(uVarI);
                }
            }
        }
        u uVar4 = null;
        if (fragmentManagerState.f1164c != null) {
            this.f1227d = new ArrayList(fragmentManagerState.f1164c.length);
            int i11 = 0;
            while (true) {
                BackStackState[] backStackStateArr = fragmentManagerState.f1164c;
                if (i11 >= backStackStateArr.length) {
                    break;
                }
                BackStackState backStackState = backStackStateArr[i11];
                int[] iArr = backStackState.f1145a;
                a aVar = new a(this);
                int i12 = 0;
                int i13 = 0;
                while (i12 < iArr.length) {
                    p0 p0Var = new p0();
                    int i14 = i12 + 1;
                    p0Var.f1270a = iArr[i12];
                    if (E(i7)) {
                        aVar.toString();
                        int i15 = iArr[i14];
                    }
                    String str2 = (String) backStackState.b.get(i13);
                    if (str2 != null) {
                        p0Var.b = eVar.i(str2);
                    } else {
                        p0Var.b = uVar4;
                    }
                    int i16 = i7;
                    p0Var.f1274g = androidx.lifecycle.m.values()[backStackState.f1146c[i13]];
                    p0Var.f1275h = androidx.lifecycle.m.values()[backStackState.f1147d[i13]];
                    int i17 = iArr[i14];
                    p0Var.f1271c = i17;
                    int i18 = iArr[i12 + 2];
                    p0Var.f1272d = i18;
                    int i19 = i12 + 4;
                    int i20 = iArr[i12 + 3];
                    p0Var.e = i20;
                    i12 += 5;
                    int i21 = iArr[i19];
                    p0Var.f1273f = i21;
                    aVar.b = i17;
                    aVar.f1182c = i18;
                    aVar.f1183d = i20;
                    aVar.e = i21;
                    aVar.b(p0Var);
                    i13++;
                    i7 = i16;
                    uVar4 = null;
                }
                int i22 = i7;
                aVar.f1184f = backStackState.e;
                aVar.f1187i = backStackState.f1148f;
                aVar.f1197s = backStackState.f1149g;
                aVar.f1185g = true;
                aVar.f1188j = backStackState.f1150h;
                aVar.f1189k = backStackState.f1151i;
                aVar.f1190l = backStackState.f1152j;
                aVar.f1191m = backStackState.f1153k;
                aVar.f1192n = backStackState.f1154l;
                aVar.f1193o = backStackState.f1155m;
                aVar.f1194p = backStackState.f1156n;
                aVar.c(1);
                if (E(i22)) {
                    aVar.toString();
                    PrintWriter printWriter = new PrintWriter(new r0());
                    aVar.g("  ", printWriter, false);
                    printWriter.close();
                }
                this.f1227d.add(aVar);
                i11++;
                i7 = i22;
                uVar4 = null;
            }
        } else {
            this.f1227d = null;
        }
        this.f1231i.set(fragmentManagerState.f1165d);
        String str3 = fragmentManagerState.e;
        if (str3 != null) {
            u uVarI2 = eVar.i(str3);
            this.f1240r = uVarI2;
            p(uVarI2);
        }
        ArrayList arrayList4 = fragmentManagerState.f1166f;
        if (arrayList4 != null) {
            for (int i23 = 0; i23 < arrayList4.size(); i23++) {
                Bundle bundle = (Bundle) fragmentManagerState.f1167g.get(i23);
                bundle.setClassLoader(this.f1237o.b.getClassLoader());
                this.f1232j.put(arrayList4.get(i23), bundle);
            }
        }
        this.f1246x = new ArrayDeque(fragmentManagerState.f1168h);
    }

    public final Parcelable Q() {
        int i7;
        ArrayList arrayList;
        BackStackState[] backStackStateArr;
        int size;
        Iterator it = e().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            j jVar = (j) it.next();
            if (jVar.e) {
                jVar.e = false;
                jVar.c();
            }
        }
        u();
        x(true);
        this.f1248z = true;
        this.G.f1254h = true;
        y2.e eVar = this.f1226c;
        eVar.getClass();
        HashMap map = (HashMap) eVar.b;
        ArrayList arrayList2 = new ArrayList(map.size());
        for (o0 o0Var : map.values()) {
            if (o0Var != null) {
                u uVar = o0Var.f1265c;
                FragmentState fragmentState = new FragmentState(uVar);
                if (uVar.f1297a <= -1 || fragmentState.f1179m != null) {
                    fragmentState.f1179m = uVar.b;
                } else {
                    Bundle bundleO = o0Var.o();
                    fragmentState.f1179m = bundleO;
                    if (uVar.f1302h != null) {
                        if (bundleO == null) {
                            fragmentState.f1179m = new Bundle();
                        }
                        fragmentState.f1179m.putString("android:target_state", uVar.f1302h);
                        int i8 = uVar.f1303i;
                        if (i8 != 0) {
                            fragmentState.f1179m.putInt("android:target_req_state", i8);
                        }
                    }
                }
                arrayList2.add(fragmentState);
                if (E(2)) {
                    Objects.toString(uVar);
                    Objects.toString(fragmentState.f1179m);
                }
            }
        }
        if (arrayList2.isEmpty()) {
            E(2);
            return null;
        }
        y2.e eVar2 = this.f1226c;
        synchronized (((ArrayList) eVar2.f8965c)) {
            try {
                if (((ArrayList) eVar2.f8965c).isEmpty()) {
                    arrayList = null;
                } else {
                    arrayList = new ArrayList(((ArrayList) eVar2.f8965c).size());
                    ArrayList arrayList3 = (ArrayList) eVar2.f8965c;
                    int size2 = arrayList3.size();
                    int i9 = 0;
                    while (i9 < size2) {
                        Object obj = arrayList3.get(i9);
                        i9++;
                        u uVar2 = (u) obj;
                        arrayList.add(uVar2.e);
                        if (E(2)) {
                            uVar2.toString();
                        }
                    }
                }
            } finally {
            }
        }
        ArrayList arrayList4 = this.f1227d;
        if (arrayList4 == null || (size = arrayList4.size()) <= 0) {
            backStackStateArr = null;
        } else {
            backStackStateArr = new BackStackState[size];
            for (i7 = 0; i7 < size; i7++) {
                backStackStateArr[i7] = new BackStackState((a) this.f1227d.get(i7));
                if (E(2)) {
                    Objects.toString(this.f1227d.get(i7));
                }
            }
        }
        FragmentManagerState fragmentManagerState = new FragmentManagerState();
        fragmentManagerState.e = null;
        ArrayList arrayList5 = new ArrayList();
        fragmentManagerState.f1166f = arrayList5;
        ArrayList arrayList6 = new ArrayList();
        fragmentManagerState.f1167g = arrayList6;
        fragmentManagerState.f1163a = arrayList2;
        fragmentManagerState.b = arrayList;
        fragmentManagerState.f1164c = backStackStateArr;
        fragmentManagerState.f1165d = this.f1231i.get();
        u uVar3 = this.f1240r;
        if (uVar3 != null) {
            fragmentManagerState.e = uVar3.e;
        }
        arrayList5.addAll(this.f1232j.keySet());
        arrayList6.addAll(this.f1232j.values());
        fragmentManagerState.f1168h = new ArrayList(this.f1246x);
        return fragmentManagerState;
    }

    public final void R() {
        synchronized (this.f1225a) {
            try {
                if (this.f1225a.size() == 1) {
                    this.f1237o.f1324c.removeCallbacks(this.H);
                    this.f1237o.f1324c.post(this.H);
                    Y();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void S(u uVar, boolean z6) {
        ViewGroup viewGroupB = B(uVar);
        if (viewGroupB == null || !(viewGroupB instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) viewGroupB).setDrawDisappearingViewsLast(!z6);
    }

    public final void T(u uVar, androidx.lifecycle.m mVar) {
        if (uVar.equals(this.f1226c.i(uVar.e)) && (uVar.f1313s == null || uVar.f1312r == this)) {
            uVar.K = mVar;
        } else {
            f3.o("Fragment ", uVar, " is not an active fragment of FragmentManager ", this);
        }
    }

    public final void U(u uVar) {
        if (uVar != null) {
            if (!uVar.equals(this.f1226c.i(uVar.e)) || (uVar.f1313s != null && uVar.f1312r != this)) {
                f3.o("Fragment ", uVar, " is not an active fragment of FragmentManager ", this);
                return;
            }
        }
        u uVar2 = this.f1240r;
        this.f1240r = uVar;
        p(uVar2);
        p(this.f1240r);
    }

    public final void V(u uVar) {
        ViewGroup viewGroupB = B(uVar);
        if (viewGroupB != null) {
            r rVar = uVar.H;
            if ((rVar == null ? 0 : rVar.e) + (rVar == null ? 0 : rVar.f1281d) + (rVar == null ? 0 : rVar.f1280c) + (rVar == null ? 0 : rVar.b) > 0) {
                if (viewGroupB.getTag(2131296814) == null) {
                    viewGroupB.setTag(2131296814, uVar);
                }
                u uVar2 = (u) viewGroupB.getTag(2131296814);
                r rVar2 = uVar.H;
                boolean z6 = rVar2 != null ? rVar2.f1279a : false;
                if (uVar2.H == null) {
                    return;
                }
                uVar2.f().f1279a = z6;
            }
        }
    }

    public final void W() {
        ArrayList arrayListK = this.f1226c.k();
        int size = arrayListK.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayListK.get(i7);
            i7++;
            o0 o0Var = (o0) obj;
            u uVar = o0Var.f1265c;
            if (uVar.F) {
                if (this.b) {
                    this.C = true;
                } else {
                    uVar.F = false;
                    o0Var.k();
                }
            }
        }
    }

    public final void X(IllegalStateException illegalStateException) {
        Log.e("FragmentManager", illegalStateException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new r0());
        x xVar = this.f1237o;
        if (xVar == null) {
            try {
                t("  ", null, printWriter, new String[0]);
                throw illegalStateException;
            } catch (Exception e) {
                Log.e("FragmentManager", "Failed dumping state", e);
                throw illegalStateException;
            }
        }
        try {
            xVar.e.dump("  ", null, printWriter, new String[0]);
            throw illegalStateException;
        } catch (Exception e3) {
            Log.e("FragmentManager", "Failed dumping state", e3);
            throw illegalStateException;
        }
    }

    public final void Y() {
        synchronized (this.f1225a) {
            try {
                if (!this.f1225a.isEmpty()) {
                    d0 d0Var = this.f1230h;
                    d0Var.f1207a = true;
                    androidx.activity.w wVar = d0Var.f1208c;
                    if (wVar != null) {
                        wVar.invoke();
                    }
                    return;
                }
                d0 d0Var2 = this.f1230h;
                ArrayList arrayList = this.f1227d;
                d0Var2.f1207a = (arrayList != null ? arrayList.size() : 0) > 0 && H(this.f1239q);
                androidx.activity.w wVar2 = d0Var2.f1208c;
                if (wVar2 != null) {
                    wVar2.invoke();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final o0 a(u uVar) {
        if (E(2)) {
            Objects.toString(uVar);
        }
        o0 o0VarF = f(uVar);
        uVar.f1312r = this;
        y2.e eVar = this.f1226c;
        eVar.w(o0VarF);
        if (!uVar.f1320z) {
            eVar.c(uVar);
            uVar.f1306l = false;
            if (uVar.E == null) {
                uVar.I = false;
            }
            if (F(uVar)) {
                this.f1247y = true;
            }
        }
        return o0VarF;
    }

    public final void b(x xVar, a5.h hVar, u uVar) {
        l0 l0Var;
        if (this.f1237o != null) {
            f3.t("Already attached");
            return;
        }
        this.f1237o = xVar;
        this.f1238p = hVar;
        this.f1239q = uVar;
        CopyOnWriteArrayList copyOnWriteArrayList = this.f1235m;
        if (uVar != null) {
            copyOnWriteArrayList.add(new g0(uVar));
        } else if (xVar != null) {
            copyOnWriteArrayList.add(xVar);
        }
        if (this.f1239q != null) {
            Y();
        }
        if (xVar != null) {
            androidx.activity.x xVarG = xVar.e.g();
            this.f1229g = xVarG;
            xVarG.a(uVar != null ? uVar : xVar, this.f1230h);
        }
        if (uVar != null) {
            l0 l0Var2 = uVar.f1312r.G;
            HashMap map = l0Var2.f1251d;
            l0 l0Var3 = (l0) map.get(uVar.e);
            if (l0Var3 == null) {
                l0Var3 = new l0(l0Var2.f1252f);
                map.put(uVar.e, l0Var3);
            }
            this.G = l0Var3;
        } else if (xVar != null) {
            androidx.lifecycle.l0 l0VarC = xVar.e.c();
            l0VarC.getClass();
            q0.a aVar = q0.a.f7728c;
            aVar.getClass();
            String canonicalName = l0.class.getCanonicalName();
            if (canonicalName == null) {
                f3.q("Local and anonymous classes can not be ViewModels");
                return;
            }
            String strConcat = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
            LinkedHashMap linkedHashMap = l0VarC.f1357a;
            androidx.lifecycle.j0 j0Var = (androidx.lifecycle.j0) linkedHashMap.get(strConcat);
            if (l0.class.isInstance(j0Var)) {
                j0Var.getClass();
            } else {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                linkedHashMap2.putAll((LinkedHashMap) aVar.b);
                linkedHashMap2.put(androidx.lifecycle.k0.b, strConcat);
                try {
                    l0Var = new l0(true);
                } catch (AbstractMethodError unused) {
                    l0Var = new l0(true);
                }
                j0Var = l0Var;
                androidx.lifecycle.j0 j0Var2 = (androidx.lifecycle.j0) linkedHashMap.put(strConcat, j0Var);
                if (j0Var2 != null) {
                    j0Var2.a();
                }
            }
            this.G = (l0) j0Var;
        } else {
            this.G = new l0(false);
        }
        this.G.f1254h = I();
        this.f1226c.f8966d = this.G;
        x xVar2 = this.f1237o;
        if (xVar2 != null) {
            androidx.activity.i iVar = xVar2.e.f355j;
            String strConcat2 = "FragmentManager:".concat(uVar != null ? androidx.activity.g.o(new StringBuilder(), uVar.e, ":") : "");
            this.f1243u = iVar.c(strConcat2.concat("StartActivityForResult"), new h0(4), new c0(this, 2));
            this.f1244v = iVar.c(strConcat2.concat("StartIntentSenderForResult"), new h0(0), new c0(this, 0));
            this.f1245w = iVar.c(strConcat2.concat("RequestPermissions"), new h0(2), new c0(this, 1));
        }
    }

    public final void c(u uVar) {
        if (E(2)) {
            Objects.toString(uVar);
        }
        if (uVar.f1320z) {
            uVar.f1320z = false;
            if (uVar.f1305k) {
                return;
            }
            this.f1226c.c(uVar);
            if (E(2)) {
                uVar.toString();
            }
            if (F(uVar)) {
                this.f1247y = true;
            }
        }
    }

    public final void d() {
        this.b = false;
        this.E.clear();
        this.D.clear();
    }

    public final HashSet e() {
        HashSet hashSet = new HashSet();
        ArrayList arrayListK = this.f1226c.k();
        int size = arrayListK.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayListK.get(i7);
            i7++;
            ViewGroup viewGroup = ((o0) obj).f1265c.D;
            if (viewGroup != null) {
                hashSet.add(j.f(viewGroup, D()));
            }
        }
        return hashSet;
    }

    public final o0 f(u uVar) {
        String str = uVar.e;
        y2.e eVar = this.f1226c;
        o0 o0Var = (o0) ((HashMap) eVar.b).get(str);
        if (o0Var != null) {
            return o0Var;
        }
        o0 o0Var2 = new o0(this.f1234l, eVar, uVar);
        o0Var2.m(this.f1237o.b.getClassLoader());
        o0Var2.e = this.f1236n;
        return o0Var2;
    }

    public final void g(u uVar) {
        if (E(2)) {
            Objects.toString(uVar);
        }
        if (uVar.f1320z) {
            return;
        }
        uVar.f1320z = true;
        if (uVar.f1305k) {
            if (E(2)) {
                uVar.toString();
            }
            y2.e eVar = this.f1226c;
            synchronized (((ArrayList) eVar.f8965c)) {
                ((ArrayList) eVar.f8965c).remove(uVar);
            }
            uVar.f1305k = false;
            if (F(uVar)) {
                this.f1247y = true;
            }
            V(uVar);
        }
    }

    public final void h() {
        for (u uVar : this.f1226c.r()) {
            if (uVar != null) {
                uVar.C = true;
                uVar.f1314t.h();
            }
        }
    }

    public final boolean i() {
        if (this.f1236n >= 1) {
            for (u uVar : this.f1226c.r()) {
                if (uVar != null) {
                    if (!uVar.f1319y ? uVar.f1314t.i() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final boolean j() {
        if (this.f1236n < 1) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z6 = false;
        for (u uVar : this.f1226c.r()) {
            if (uVar != null && G(uVar)) {
                if (!uVar.f1319y ? uVar.f1314t.j() : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(uVar);
                    z6 = true;
                }
            }
        }
        if (this.e != null) {
            for (int i7 = 0; i7 < this.e.size(); i7++) {
                u uVar2 = (u) this.e.get(i7);
                if (arrayList == null || !arrayList.contains(uVar2)) {
                    uVar2.getClass();
                }
            }
        }
        this.e = arrayList;
        return z6;
    }

    public final void k() {
        this.B = true;
        x(true);
        u();
        s(-1);
        this.f1237o = null;
        this.f1238p = null;
        this.f1239q = null;
        if (this.f1229g != null) {
            Iterator it = this.f1230h.b.iterator();
            while (it.hasNext()) {
                ((androidx.activity.c) it.next()).cancel();
            }
            this.f1229g = null;
        }
        androidx.activity.result.c cVar = this.f1243u;
        if (cVar != null) {
            cVar.b();
            this.f1244v.b();
            this.f1245w.b();
        }
    }

    public final void l() {
        for (u uVar : this.f1226c.r()) {
            if (uVar != null) {
                uVar.C = true;
                uVar.f1314t.l();
            }
        }
    }

    public final void m() {
        for (u uVar : this.f1226c.r()) {
            if (uVar != null) {
                uVar.f1314t.m();
            }
        }
    }

    public final boolean n() {
        if (this.f1236n >= 1) {
            for (u uVar : this.f1226c.r()) {
                if (uVar != null) {
                    if (!uVar.f1319y ? uVar.f1314t.n() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final void o() {
        if (this.f1236n < 1) {
            return;
        }
        for (u uVar : this.f1226c.r()) {
            if (uVar != null && !uVar.f1319y) {
                uVar.f1314t.o();
            }
        }
    }

    public final void p(u uVar) {
        if (uVar != null) {
            if (uVar.equals(this.f1226c.i(uVar.e))) {
                uVar.f1312r.getClass();
                boolean zH = H(uVar);
                Boolean bool = uVar.f1304j;
                if (bool == null || bool.booleanValue() != zH) {
                    uVar.f1304j = Boolean.valueOf(zH);
                    k0 k0Var = uVar.f1314t;
                    k0Var.Y();
                    k0Var.p(k0Var.f1240r);
                }
            }
        }
    }

    public final void q() {
        for (u uVar : this.f1226c.r()) {
            if (uVar != null) {
                uVar.f1314t.q();
            }
        }
    }

    public final boolean r() {
        if (this.f1236n < 1) {
            return false;
        }
        boolean z6 = false;
        for (u uVar : this.f1226c.r()) {
            if (uVar != null && G(uVar)) {
                if (!uVar.f1319y ? uVar.f1314t.r() : false) {
                    z6 = true;
                }
            }
        }
        return z6;
    }

    public final void s(int i7) {
        try {
            this.b = true;
            for (o0 o0Var : ((HashMap) this.f1226c.b).values()) {
                if (o0Var != null) {
                    o0Var.e = i7;
                }
            }
            J(i7, false);
            Iterator it = e().iterator();
            while (it.hasNext()) {
                ((j) it.next()).e();
            }
            this.b = false;
            x(true);
        } catch (Throwable th) {
            this.b = false;
            throw th;
        }
    }

    public final void t(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        r0.a aVar;
        String str2;
        String strA = n.e.a(str, "    ");
        y2.e eVar = this.f1226c;
        ArrayList arrayList = (ArrayList) eVar.f8965c;
        String strA2 = n.e.a(str, "    ");
        HashMap map = (HashMap) eVar.b;
        if (!map.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (o0 o0Var : map.values()) {
                printWriter.print(str);
                if (o0Var != null) {
                    u uVar = o0Var.f1265c;
                    printWriter.println(uVar);
                    uVar.getClass();
                    printWriter.print(strA2);
                    printWriter.print("mFragmentId=#");
                    printWriter.print(Integer.toHexString(uVar.f1316v));
                    printWriter.print(" mContainerId=#");
                    printWriter.print(Integer.toHexString(uVar.f1317w));
                    printWriter.print(" mTag=");
                    printWriter.println(uVar.f1318x);
                    printWriter.print(strA2);
                    printWriter.print("mState=");
                    printWriter.print(uVar.f1297a);
                    printWriter.print(" mWho=");
                    printWriter.print(uVar.e);
                    printWriter.print(" mBackStackNesting=");
                    printWriter.println(uVar.f1311q);
                    printWriter.print(strA2);
                    printWriter.print("mAdded=");
                    printWriter.print(uVar.f1305k);
                    printWriter.print(" mRemoving=");
                    printWriter.print(uVar.f1306l);
                    printWriter.print(" mFromLayout=");
                    printWriter.print(uVar.f1307m);
                    printWriter.print(" mInLayout=");
                    printWriter.println(uVar.f1308n);
                    printWriter.print(strA2);
                    printWriter.print("mHidden=");
                    printWriter.print(uVar.f1319y);
                    printWriter.print(" mDetached=");
                    printWriter.print(uVar.f1320z);
                    printWriter.print(" mMenuVisible=");
                    printWriter.print(uVar.B);
                    printWriter.print(" mHasMenu=");
                    printWriter.println(false);
                    printWriter.print(strA2);
                    printWriter.print("mRetainInstance=");
                    printWriter.print(uVar.A);
                    printWriter.print(" mUserVisibleHint=");
                    printWriter.println(uVar.G);
                    if (uVar.f1312r != null) {
                        printWriter.print(strA2);
                        printWriter.print("mFragmentManager=");
                        printWriter.println(uVar.f1312r);
                    }
                    if (uVar.f1313s != null) {
                        printWriter.print(strA2);
                        printWriter.print("mHost=");
                        printWriter.println(uVar.f1313s);
                    }
                    if (uVar.f1315u != null) {
                        printWriter.print(strA2);
                        printWriter.print("mParentFragment=");
                        printWriter.println(uVar.f1315u);
                    }
                    if (uVar.f1300f != null) {
                        printWriter.print(strA2);
                        printWriter.print("mArguments=");
                        printWriter.println(uVar.f1300f);
                    }
                    if (uVar.b != null) {
                        printWriter.print(strA2);
                        printWriter.print("mSavedFragmentState=");
                        printWriter.println(uVar.b);
                    }
                    if (uVar.f1298c != null) {
                        printWriter.print(strA2);
                        printWriter.print("mSavedViewState=");
                        printWriter.println(uVar.f1298c);
                    }
                    if (uVar.f1299d != null) {
                        printWriter.print(strA2);
                        printWriter.print("mSavedViewRegistryState=");
                        printWriter.println(uVar.f1299d);
                    }
                    Object objI = uVar.f1301g;
                    if (objI == null) {
                        k0 k0Var = uVar.f1312r;
                        objI = (k0Var == null || (str2 = uVar.f1302h) == null) ? null : k0Var.f1226c.i(str2);
                    }
                    if (objI != null) {
                        printWriter.print(strA2);
                        printWriter.print("mTarget=");
                        printWriter.print(objI);
                        printWriter.print(" mTargetRequestCode=");
                        printWriter.println(uVar.f1303i);
                    }
                    printWriter.print(strA2);
                    printWriter.print("mPopDirection=");
                    r rVar = uVar.H;
                    printWriter.println(rVar == null ? false : rVar.f1279a);
                    r rVar2 = uVar.H;
                    if ((rVar2 == null ? 0 : rVar2.b) != 0) {
                        printWriter.print(strA2);
                        printWriter.print("getEnterAnim=");
                        r rVar3 = uVar.H;
                        printWriter.println(rVar3 == null ? 0 : rVar3.b);
                    }
                    r rVar4 = uVar.H;
                    if ((rVar4 == null ? 0 : rVar4.f1280c) != 0) {
                        printWriter.print(strA2);
                        printWriter.print("getExitAnim=");
                        r rVar5 = uVar.H;
                        printWriter.println(rVar5 == null ? 0 : rVar5.f1280c);
                    }
                    r rVar6 = uVar.H;
                    if ((rVar6 == null ? 0 : rVar6.f1281d) != 0) {
                        printWriter.print(strA2);
                        printWriter.print("getPopEnterAnim=");
                        r rVar7 = uVar.H;
                        printWriter.println(rVar7 == null ? 0 : rVar7.f1281d);
                    }
                    r rVar8 = uVar.H;
                    if ((rVar8 == null ? 0 : rVar8.e) != 0) {
                        printWriter.print(strA2);
                        printWriter.print("getPopExitAnim=");
                        r rVar9 = uVar.H;
                        printWriter.println(rVar9 == null ? 0 : rVar9.e);
                    }
                    if (uVar.D != null) {
                        printWriter.print(strA2);
                        printWriter.print("mContainer=");
                        printWriter.println(uVar.D);
                    }
                    if (uVar.E != null) {
                        printWriter.print(strA2);
                        printWriter.print("mView=");
                        printWriter.println(uVar.E);
                    }
                    if (uVar.i() != null) {
                        androidx.lifecycle.l0 l0VarC = uVar.c();
                        l0VarC.getClass();
                        q0.a aVar2 = q0.a.f7728c;
                        aVar2.getClass();
                        String canonicalName = r0.a.class.getCanonicalName();
                        if (canonicalName == null) {
                            f3.q("Local and anonymous classes can not be ViewModels");
                            return;
                        }
                        String strConcat = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
                        LinkedHashMap linkedHashMap = l0VarC.f1357a;
                        androidx.lifecycle.j0 j0Var = (androidx.lifecycle.j0) linkedHashMap.get(strConcat);
                        if (r0.a.class.isInstance(j0Var)) {
                            j0Var.getClass();
                        } else {
                            LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                            linkedHashMap2.putAll((LinkedHashMap) aVar2.b);
                            linkedHashMap2.put(androidx.lifecycle.k0.b, strConcat);
                            try {
                                aVar = new r0.a();
                            } catch (AbstractMethodError unused) {
                                aVar = new r0.a();
                            }
                            j0Var = aVar;
                            androidx.lifecycle.j0 j0Var2 = (androidx.lifecycle.j0) linkedHashMap.put(strConcat, j0Var);
                            if (j0Var2 != null) {
                                j0Var2.a();
                            }
                        }
                        l.l lVar = ((r0.a) j0Var).f7875c;
                        if (lVar.f6717c > 0) {
                            printWriter.print(strA2);
                            printWriter.println("Loaders:");
                            if (lVar.f6717c > 0) {
                                if (lVar.b[0] != null) {
                                    f3.b();
                                    return;
                                }
                                printWriter.print(strA2);
                                printWriter.print("  #");
                                printWriter.print(lVar.f6716a[0]);
                                printWriter.print(": ");
                                throw null;
                            }
                        }
                    }
                    printWriter.print(strA2);
                    printWriter.println("Child " + uVar.f1314t + ":");
                    uVar.f1314t.t(strA2.concat("  "), fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size3 = arrayList.size();
        if (size3 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i7 = 0; i7 < size3; i7++) {
                u uVar2 = (u) arrayList.get(i7);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i7);
                printWriter.print(": ");
                printWriter.println(uVar2.toString());
            }
        }
        ArrayList arrayList2 = this.e;
        if (arrayList2 != null && (size2 = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i8 = 0; i8 < size2; i8++) {
                u uVar3 = (u) this.e.get(i8);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i8);
                printWriter.print(": ");
                printWriter.println(uVar3.toString());
            }
        }
        ArrayList arrayList3 = this.f1227d;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i9 = 0; i9 < size; i9++) {
                a aVar3 = (a) this.f1227d.get(i9);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i9);
                printWriter.print(": ");
                printWriter.println(aVar3.toString());
                aVar3.g(strA, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f1231i.get());
        synchronized (this.f1225a) {
            try {
                int size4 = this.f1225a.size();
                if (size4 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i10 = 0; i10 < size4; i10++) {
                        Object obj = (i0) this.f1225a.get(i10);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i10);
                        printWriter.print(": ");
                        printWriter.println(obj);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f1237o);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f1238p);
        if (this.f1239q != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f1239q);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f1236n);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f1248z);
        printWriter.print(" mStopped=");
        printWriter.print(this.A);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.B);
        if (this.f1247y) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f1247y);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(bc.f3796d);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        u uVar = this.f1239q;
        if (uVar != null) {
            sb.append(uVar.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f1239q)));
            sb.append("}");
        } else {
            x xVar = this.f1237o;
            if (xVar != null) {
                sb.append(xVar.getClass().getSimpleName());
                sb.append("{");
                sb.append(Integer.toHexString(System.identityHashCode(this.f1237o)));
                sb.append("}");
            } else {
                sb.append("null");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    public final void u() {
        Iterator it = e().iterator();
        while (it.hasNext()) {
            ((j) it.next()).e();
        }
    }

    public final void v(i0 i0Var, boolean z6) {
        if (!z6) {
            if (this.f1237o == null) {
                if (this.B) {
                    f3.t("FragmentManager has been destroyed");
                    return;
                } else {
                    f3.t("FragmentManager has not been attached to a host.");
                    return;
                }
            }
            if (I()) {
                f3.t("Can not perform this action after onSaveInstanceState");
                return;
            }
        }
        synchronized (this.f1225a) {
            try {
                if (this.f1237o == null) {
                    if (!z6) {
                        throw new IllegalStateException("Activity has been destroyed");
                    }
                } else {
                    this.f1225a.add(i0Var);
                    R();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void w(boolean z6) {
        if (this.b) {
            f3.t("FragmentManager is already executing transactions");
            return;
        }
        if (this.f1237o == null) {
            if (this.B) {
                f3.t("FragmentManager has been destroyed");
                return;
            } else {
                f3.t("FragmentManager has not been attached to a host.");
                return;
            }
        }
        if (Looper.myLooper() != this.f1237o.f1324c.getLooper()) {
            f3.t("Must be called from main thread of fragment host");
            return;
        }
        if (!z6 && I()) {
            f3.t("Can not perform this action after onSaveInstanceState");
            return;
        }
        if (this.D == null) {
            this.D = new ArrayList();
            this.E = new ArrayList();
        }
        this.b = false;
    }

    public final boolean x(boolean z6) {
        boolean zA;
        ArrayList arrayList;
        w(z6);
        boolean z7 = false;
        while (true) {
            ArrayList arrayList2 = this.D;
            ArrayList arrayList3 = this.E;
            synchronized (this.f1225a) {
                try {
                    if (this.f1225a.isEmpty()) {
                        zA = false;
                    } else {
                        int size = this.f1225a.size();
                        int i7 = 0;
                        zA = false;
                        while (true) {
                            arrayList = this.f1225a;
                            if (i7 >= size) {
                                break;
                            }
                            zA |= ((i0) arrayList.get(i7)).a(arrayList2, arrayList3);
                            i7++;
                        }
                        arrayList.clear();
                        this.f1237o.f1324c.removeCallbacks(this.H);
                    }
                } finally {
                }
            }
            if (!zA) {
                break;
            }
            z7 = true;
            this.b = true;
            try {
                O(this.D, this.E);
            } finally {
                d();
            }
        }
        Y();
        if (this.C) {
            this.C = false;
            W();
        }
        ((HashMap) this.f1226c.b).values().removeAll(Collections.singleton(null));
        return z7;
    }

    public final void y(a aVar, boolean z6) {
        if (z6 && (this.f1237o == null || this.B)) {
            return;
        }
        w(z6);
        aVar.a(this.D, this.E);
        this.b = true;
        try {
            O(this.D, this.E);
            d();
            Y();
            if (this.C) {
                this.C = false;
                W();
            }
            ((HashMap) this.f1226c.b).values().removeAll(Collections.singleton(null));
        } catch (Throwable th) {
            d();
            throw th;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:63:0x0161  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0167  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void z(java.util.ArrayList r25, java.util.ArrayList r26, int r27, int r28) {
        /*
            Method dump skipped, instruction units count: 1408
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.k0.z(java.util.ArrayList, java.util.ArrayList, int, int):void");
    }
}
