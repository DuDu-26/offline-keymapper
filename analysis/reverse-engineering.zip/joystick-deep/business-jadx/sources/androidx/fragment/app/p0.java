package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class p0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1270a;
    public u b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1271c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1272d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1273f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public androidx.lifecycle.m f1274g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public androidx.lifecycle.m f1275h;

    public p0(int i7, u uVar) {
        this.f1270a = i7;
        this.b = uVar;
        androidx.lifecycle.m mVar = androidx.lifecycle.m.e;
        this.f1274g = mVar;
        this.f1275h = mVar;
    }
}
