package androidx.fragment.app;

import android.animation.Animator;
import android.view.View;
import androidx.appcompat.widget.f3;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e implements b0.a, androidx.lifecycle.y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1210a;
    public final Object b;

    public /* synthetic */ e(int i7, Object obj) {
        this.f1210a = i7;
        this.b = obj;
    }

    public void a() {
        ((x) this.b).f1325d.K();
    }

    @Override // androidx.lifecycle.y
    public void e(Object obj) {
        androidx.lifecycle.r rVar = (androidx.lifecycle.r) obj;
        n nVar = (n) this.b;
        if (rVar == null || !nVar.Z) {
            return;
        }
        View viewJ = nVar.J();
        if (viewJ.getParent() != null) {
            f3.t("DialogFragment can not be attached to a container view");
        } else if (nVar.f1258d0 != null) {
            if (k0.E(3)) {
                Objects.toString(nVar.f1258d0);
            }
            nVar.f1258d0.setContentView(viewJ);
        }
    }

    @Override // b0.a
    public void onCancel() {
        switch (this.f1210a) {
            case 0:
                ((Animator) this.b).end();
                break;
            default:
                ((t0) this.b).a();
                break;
        }
    }
}
