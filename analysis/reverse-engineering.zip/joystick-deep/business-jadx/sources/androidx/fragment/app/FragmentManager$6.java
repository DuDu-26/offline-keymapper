package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
class FragmentManager$6 implements androidx.lifecycle.p {
    @Override // androidx.lifecycle.p
    public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar) {
        if (lVar == androidx.lifecycle.l.ON_START || lVar == androidx.lifecycle.l.ON_DESTROY) {
            throw null;
        }
    }
}
