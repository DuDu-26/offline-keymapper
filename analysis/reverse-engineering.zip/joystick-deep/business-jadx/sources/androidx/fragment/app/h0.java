package androidx.fragment.app;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h0 extends a5.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1218a;

    public /* synthetic */ h0(int i7) {
        this.f1218a = i7;
    }

    @Override // a5.h
    public w3.e K(androidx.appcompat.app.k kVar, Object obj) {
        switch (this.f1218a) {
            case 1:
                ((String) obj).getClass();
                return null;
            case 2:
                String[] strArr = (String[]) obj;
                strArr.getClass();
                if (strArr.length == 0) {
                    return new w3.e(12, h2.q.f5908a);
                }
                for (String str : strArr) {
                    if (a5.h.i(kVar, str) != 0) {
                        return null;
                    }
                }
                int iM0 = h2.t.m0(strArr.length);
                if (iM0 < 16) {
                    iM0 = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(iM0);
                for (String str2 : strArr) {
                    linkedHashMap.put(str2, Boolean.TRUE);
                }
                return new w3.e(12, linkedHashMap);
            case 3:
                String str3 = (String) obj;
                str3.getClass();
                if (a5.h.i(kVar, str3) == 0) {
                    return new w3.e(12, Boolean.TRUE);
                }
                return null;
            default:
                return super.K(kVar, obj);
        }
    }

    @Override // a5.h
    public final Object X(int i7, Intent intent) {
        switch (this.f1218a) {
            case 0:
                return new ActivityResult(i7, intent);
            case 1:
                if (i7 != -1) {
                    intent = null;
                }
                if (intent != null) {
                    return intent.getData();
                }
                return null;
            case 2:
                if (i7 == -1 && intent != null) {
                    String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                    int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                    if (intArrayExtra != null && stringArrayExtra != null) {
                        ArrayList arrayList = new ArrayList(intArrayExtra.length);
                        for (int i8 : intArrayExtra) {
                            arrayList.add(Boolean.valueOf(i8 == 0));
                        }
                        ArrayList arrayListP0 = h2.h.p0(stringArrayExtra);
                        Iterator it = arrayListP0.iterator();
                        Iterator it2 = arrayList.iterator();
                        ArrayList arrayList2 = new ArrayList(Math.min(h2.k.m0(arrayListP0), h2.k.m0(arrayList)));
                        while (it.hasNext() && it2.hasNext()) {
                            arrayList2.add(new g2.b(it.next(), it2.next()));
                        }
                        return h2.t.n0(arrayList2);
                    }
                }
                return h2.q.f5908a;
            case 3:
                if (intent == null || i7 != -1) {
                    return Boolean.FALSE;
                }
                int[] intArrayExtra2 = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                boolean z6 = false;
                if (intArrayExtra2 != null) {
                    int length = intArrayExtra2.length;
                    int i9 = 0;
                    while (true) {
                        if (i9 < length) {
                            if (intArrayExtra2[i9] == 0) {
                                z6 = true;
                            } else {
                                i9++;
                            }
                        }
                    }
                }
                return Boolean.valueOf(z6);
            default:
                return new ActivityResult(i7, intent);
        }
    }

    @Override // a5.h
    public final Intent s(androidx.appcompat.app.k kVar, Object obj) {
        Bundle bundleExtra;
        switch (this.f1218a) {
            case 0:
                IntentSenderRequest intentSenderRequest = (IntentSenderRequest) obj;
                Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
                Intent intent2 = intentSenderRequest.b;
                if (intent2 != null && (bundleExtra = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                    intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                    intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                    if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                        intentSenderRequest = new IntentSenderRequest(intentSenderRequest.f370a, null, intentSenderRequest.f371c, intentSenderRequest.f372d);
                    }
                }
                intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", intentSenderRequest);
                if (k0.E(2)) {
                    intent.toString();
                }
                return intent;
            case 1:
                String str = (String) obj;
                str.getClass();
                Intent type = new Intent("android.intent.action.GET_CONTENT").addCategory("android.intent.category.OPENABLE").setType(str);
                type.getClass();
                return type;
            case 2:
                String[] strArr = (String[]) obj;
                strArr.getClass();
                Intent intentPutExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
                intentPutExtra.getClass();
                return intentPutExtra;
            case 3:
                String str2 = (String) obj;
                str2.getClass();
                Intent intentPutExtra2 = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", new String[]{str2});
                intentPutExtra2.getClass();
                return intentPutExtra2;
            default:
                Intent intent3 = (Intent) obj;
                intent3.getClass();
                return intent3;
        }
    }
}
