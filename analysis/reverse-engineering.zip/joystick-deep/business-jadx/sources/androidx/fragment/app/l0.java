package androidx.fragment.app;

import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class l0 extends androidx.lifecycle.j0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f1252f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f1250c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f1251d = new HashMap();
    public final HashMap e = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1253g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1254h = false;

    public l0(boolean z6) {
        this.f1252f = z6;
    }

    @Override // androidx.lifecycle.j0
    public final void a() {
        if (k0.E(3)) {
            toString();
        }
        this.f1253g = true;
    }

    public final void b(u uVar) {
        if (this.f1254h) {
            k0.E(2);
        } else {
            if (this.f1250c.remove(uVar.e) == null || !k0.E(2)) {
                return;
            }
            uVar.toString();
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && l0.class == obj.getClass()) {
            l0 l0Var = (l0) obj;
            if (this.f1250c.equals(l0Var.f1250c) && this.f1251d.equals(l0Var.f1251d) && this.e.equals(l0Var.e)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() + ((this.f1251d.hashCode() + (this.f1250c.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f1250c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f1251d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
