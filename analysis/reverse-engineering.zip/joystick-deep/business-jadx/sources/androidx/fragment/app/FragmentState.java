package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.umeng.analytics.pro.bc;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
@SuppressLint({"BanParcelableUsage"})
final class FragmentState implements Parcelable {
    public static final Parcelable.Creator<FragmentState> CREATOR = new b(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f1169a;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f1170c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1171d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f1172f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f1173g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f1174h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f1175i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Bundle f1176j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f1177k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f1178l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Bundle f1179m;

    public FragmentState(Parcel parcel) {
        this.f1169a = parcel.readString();
        this.b = parcel.readString();
        this.f1170c = parcel.readInt() != 0;
        this.f1171d = parcel.readInt();
        this.e = parcel.readInt();
        this.f1172f = parcel.readString();
        this.f1173g = parcel.readInt() != 0;
        this.f1174h = parcel.readInt() != 0;
        this.f1175i = parcel.readInt() != 0;
        this.f1176j = parcel.readBundle();
        this.f1177k = parcel.readInt() != 0;
        this.f1179m = parcel.readBundle();
        this.f1178l = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(bc.f3796d);
        sb.append("FragmentState{");
        sb.append(this.f1169a);
        sb.append(" (");
        sb.append(this.b);
        sb.append(")}:");
        if (this.f1170c) {
            sb.append(" fromLayout");
        }
        int i7 = this.e;
        if (i7 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i7));
        }
        String str = this.f1172f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.f1173g) {
            sb.append(" retainInstance");
        }
        if (this.f1174h) {
            sb.append(" removing");
        }
        if (this.f1175i) {
            sb.append(" detached");
        }
        if (this.f1177k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i7) {
        parcel.writeString(this.f1169a);
        parcel.writeString(this.b);
        parcel.writeInt(this.f1170c ? 1 : 0);
        parcel.writeInt(this.f1171d);
        parcel.writeInt(this.e);
        parcel.writeString(this.f1172f);
        parcel.writeInt(this.f1173g ? 1 : 0);
        parcel.writeInt(this.f1174h ? 1 : 0);
        parcel.writeInt(this.f1175i ? 1 : 0);
        parcel.writeBundle(this.f1176j);
        parcel.writeInt(this.f1177k ? 1 : 0);
        parcel.writeBundle(this.f1179m);
        parcel.writeInt(this.f1178l);
    }

    public FragmentState(u uVar) {
        this.f1169a = uVar.getClass().getName();
        this.b = uVar.e;
        this.f1170c = uVar.f1307m;
        this.f1171d = uVar.f1316v;
        this.e = uVar.f1317w;
        this.f1172f = uVar.f1318x;
        this.f1173g = uVar.A;
        this.f1174h = uVar.f1306l;
        this.f1175i = uVar.f1320z;
        this.f1176j = uVar.f1300f;
        this.f1177k = uVar.f1319y;
        this.f1178l = uVar.K.ordinal();
    }
}
