package androidx.fragment.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class n extends u implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    public Handler S;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public boolean f1256b0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public Dialog f1258d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f1259e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f1260f0;
    public final f T = new f(1, this);
    public final k U = new k(this);
    public final l V = new l(this);
    public int W = 0;
    public int X = 0;
    public boolean Y = true;
    public boolean Z = true;
    public int a0 = -1;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final e f1257c0 = new e(1, this);

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f1261g0 = false;

    @Override // androidx.fragment.app.u
    public void A() {
        this.C = true;
        Dialog dialog = this.f1258d0;
        if (dialog != null) {
            this.f1259e0 = false;
            dialog.show();
            View decorView = this.f1258d0.getWindow().getDecorView();
            decorView.getClass();
            decorView.setTag(2131296809, this);
            decorView.setTag(2131296812, this);
            decorView.setTag(2131296811, this);
        }
    }

    @Override // androidx.fragment.app.u
    public void B() {
        this.C = true;
        Dialog dialog = this.f1258d0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.u
    public final void D(Bundle bundle) {
        Bundle bundle2;
        this.C = true;
        if (this.f1258d0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f1258d0.onRestoreInstanceState(bundle2);
    }

    @Override // androidx.fragment.app.u
    public final void E(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.E(layoutInflater, viewGroup, bundle);
        if (this.E != null || this.f1258d0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f1258d0.onRestoreInstanceState(bundle2);
    }

    public final void O(boolean z6, boolean z7) {
        if (this.f1260f0) {
            return;
        }
        this.f1260f0 = true;
        Dialog dialog = this.f1258d0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f1258d0.dismiss();
            if (!z7) {
                if (Looper.myLooper() == this.S.getLooper()) {
                    onDismiss(this.f1258d0);
                } else {
                    this.S.post(this.T);
                }
            }
        }
        this.f1259e0 = true;
        if (this.a0 < 0) {
            a aVar = new a(k());
            aVar.h(this);
            if (z6) {
                aVar.d(true);
                return;
            } else {
                aVar.d(false);
                return;
            }
        }
        k0 k0VarK = k();
        int i7 = this.a0;
        if (i7 < 0) {
            f3.q(androidx.activity.g.j(i7, "Bad id: "));
        } else {
            k0VarK.v(new j0(k0VarK, i7, 1), false);
            this.a0 = -1;
        }
    }

    public Dialog P() {
        if (k0.E(3)) {
            toString();
        }
        return new Dialog(I(), this.X);
    }

    @Override // androidx.fragment.app.u
    public final a5.h e() {
        return new m(this, new o(this));
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.f1259e0) {
            return;
        }
        if (k0.E(3)) {
            toString();
        }
        O(true, true);
    }

    @Override // androidx.fragment.app.u
    public final void p(Context context) {
        super.p(context);
        this.N.d(this.f1257c0);
        this.f1260f0 = false;
    }

    @Override // androidx.fragment.app.u
    public void q(Bundle bundle) {
        super.q(bundle);
        this.S = new Handler();
        this.Z = this.f1317w == 0;
        if (bundle != null) {
            this.W = bundle.getInt("android:style", 0);
            this.X = bundle.getInt("android:theme", 0);
            this.Y = bundle.getBoolean("android:cancelable", true);
            this.Z = bundle.getBoolean("android:showsDialog", this.Z);
            this.a0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.u
    public final void t() {
        this.C = true;
        Dialog dialog = this.f1258d0;
        if (dialog != null) {
            this.f1259e0 = true;
            dialog.setOnDismissListener(null);
            this.f1258d0.dismiss();
            if (!this.f1260f0) {
                onDismiss(this.f1258d0);
            }
            this.f1258d0 = null;
            this.f1261g0 = false;
        }
    }

    @Override // androidx.fragment.app.u
    public final void u() {
        this.C = true;
        if (!this.f1260f0) {
            this.f1260f0 = true;
        }
        androidx.lifecycle.x xVar = this.N;
        xVar.getClass();
        androidx.lifecycle.x.a("removeObserver");
        androidx.lifecycle.w wVar = (androidx.lifecycle.w) xVar.b.b(this.f1257c0);
        if (wVar == null) {
            return;
        }
        wVar.d();
        wVar.c(false);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0042 A[Catch: all -> 0x004a, TryCatch #0 {all -> 0x004a, blocks: (B:12:0x0018, B:14:0x0024, B:24:0x003c, B:26:0x0042, B:29:0x004c, B:20:0x002e, B:22:0x0034, B:23:0x0039, B:30:0x0064), top: B:45:0x0018 }] */
    @Override // androidx.fragment.app.u
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.LayoutInflater v(android.os.Bundle r7) {
        /*
            r6 = this;
            android.view.LayoutInflater r7 = super.v(r7)
            boolean r0 = r6.Z
            r1 = 2
            if (r0 == 0) goto L83
            boolean r2 = r6.f1256b0
            if (r2 == 0) goto Lf
            goto L83
        Lf:
            if (r0 != 0) goto L12
            goto L6d
        L12:
            boolean r0 = r6.f1261g0
            if (r0 != 0) goto L6d
            r0 = 0
            r2 = 1
            r6.f1256b0 = r2     // Catch: java.lang.Throwable -> L4a
            android.app.Dialog r3 = r6.P()     // Catch: java.lang.Throwable -> L4a
            r6.f1258d0 = r3     // Catch: java.lang.Throwable -> L4a
            boolean r4 = r6.Z     // Catch: java.lang.Throwable -> L4a
            if (r4 == 0) goto L64
            int r4 = r6.W     // Catch: java.lang.Throwable -> L4a
            if (r4 == r2) goto L39
            if (r4 == r1) goto L39
            r5 = 3
            if (r4 == r5) goto L2e
            goto L3c
        L2e:
            android.view.Window r4 = r3.getWindow()     // Catch: java.lang.Throwable -> L4a
            if (r4 == 0) goto L39
            r5 = 24
            r4.addFlags(r5)     // Catch: java.lang.Throwable -> L4a
        L39:
            r3.requestWindowFeature(r2)     // Catch: java.lang.Throwable -> L4a
        L3c:
            android.content.Context r3 = r6.i()     // Catch: java.lang.Throwable -> L4a
            if (r3 == 0) goto L4c
            android.app.Dialog r4 = r6.f1258d0     // Catch: java.lang.Throwable -> L4a
            android.app.Activity r3 = (android.app.Activity) r3     // Catch: java.lang.Throwable -> L4a
            r4.setOwnerActivity(r3)     // Catch: java.lang.Throwable -> L4a
            goto L4c
        L4a:
            r7 = move-exception
            goto L6a
        L4c:
            android.app.Dialog r3 = r6.f1258d0     // Catch: java.lang.Throwable -> L4a
            boolean r4 = r6.Y     // Catch: java.lang.Throwable -> L4a
            r3.setCancelable(r4)     // Catch: java.lang.Throwable -> L4a
            android.app.Dialog r3 = r6.f1258d0     // Catch: java.lang.Throwable -> L4a
            androidx.fragment.app.k r4 = r6.U     // Catch: java.lang.Throwable -> L4a
            r3.setOnCancelListener(r4)     // Catch: java.lang.Throwable -> L4a
            android.app.Dialog r3 = r6.f1258d0     // Catch: java.lang.Throwable -> L4a
            androidx.fragment.app.l r4 = r6.V     // Catch: java.lang.Throwable -> L4a
            r3.setOnDismissListener(r4)     // Catch: java.lang.Throwable -> L4a
            r6.f1261g0 = r2     // Catch: java.lang.Throwable -> L4a
            goto L67
        L64:
            r2 = 0
            r6.f1258d0 = r2     // Catch: java.lang.Throwable -> L4a
        L67:
            r6.f1256b0 = r0
            goto L6d
        L6a:
            r6.f1256b0 = r0
            throw r7
        L6d:
            boolean r0 = androidx.fragment.app.k0.E(r1)
            if (r0 == 0) goto L76
            r6.toString()
        L76:
            android.app.Dialog r0 = r6.f1258d0
            if (r0 == 0) goto L8c
            android.content.Context r0 = r0.getContext()
            android.view.LayoutInflater r7 = r7.cloneInContext(r0)
            return r7
        L83:
            boolean r0 = androidx.fragment.app.k0.E(r1)
            if (r0 == 0) goto L8c
            r6.toString()
        L8c:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.n.v(android.os.Bundle):android.view.LayoutInflater");
    }

    @Override // androidx.fragment.app.u
    public void z(Bundle bundle) {
        Dialog dialog = this.f1258d0;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i7 = this.W;
        if (i7 != 0) {
            bundle.putInt("android:style", i7);
        }
        int i8 = this.X;
        if (i8 != 0) {
            bundle.putInt("android:theme", i8);
        }
        boolean z6 = this.Y;
        if (!z6) {
            bundle.putBoolean("android:cancelable", z6);
        }
        boolean z7 = this.Z;
        if (!z7) {
            bundle.putBoolean("android:showsDialog", z7);
        }
        int i9 = this.a0;
        if (i9 != -1) {
            bundle.putInt("android:backStackId", i9);
        }
    }
}
