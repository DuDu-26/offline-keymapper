package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class q0 implements androidx.lifecycle.h, u0.d, androidx.lifecycle.m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.lifecycle.l0 f1277a;
    public androidx.lifecycle.t b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.activity.o f1278c = null;

    public q0(androidx.lifecycle.l0 l0Var) {
        this.f1277a = l0Var;
    }

    @Override // u0.d
    public final androidx.appcompat.widget.v a() {
        f();
        return (androidx.appcompat.widget.v) this.f1278c.f362c;
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 c() {
        f();
        return this.f1277a;
    }

    @Override // androidx.lifecycle.r
    public final androidx.lifecycle.t d() {
        f();
        return this.b;
    }

    public final void e(androidx.lifecycle.l lVar) {
        this.b.d(lVar);
    }

    public final void f() {
        if (this.b == null) {
            this.b = new androidx.lifecycle.t(this);
            this.f1278c = new androidx.activity.o(this);
        }
    }
}
