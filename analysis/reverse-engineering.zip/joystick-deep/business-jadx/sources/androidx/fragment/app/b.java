package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1199a;

    public /* synthetic */ b(int i7) {
        this.f1199a = i7;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f1199a) {
            case 0:
                return new BackStackState(parcel);
            case 1:
                FragmentManager$LaunchedFragmentInfo fragmentManager$LaunchedFragmentInfo = new FragmentManager$LaunchedFragmentInfo();
                fragmentManager$LaunchedFragmentInfo.f1162a = parcel.readString();
                fragmentManager$LaunchedFragmentInfo.b = parcel.readInt();
                return fragmentManager$LaunchedFragmentInfo;
            case 2:
                FragmentManagerState fragmentManagerState = new FragmentManagerState();
                fragmentManagerState.e = null;
                fragmentManagerState.f1166f = new ArrayList();
                fragmentManagerState.f1167g = new ArrayList();
                fragmentManagerState.f1163a = parcel.createTypedArrayList(FragmentState.CREATOR);
                fragmentManagerState.b = parcel.createStringArrayList();
                fragmentManagerState.f1164c = (BackStackState[]) parcel.createTypedArray(BackStackState.CREATOR);
                fragmentManagerState.f1165d = parcel.readInt();
                fragmentManagerState.e = parcel.readString();
                fragmentManagerState.f1166f = parcel.createStringArrayList();
                fragmentManagerState.f1167g = parcel.createTypedArrayList(Bundle.CREATOR);
                fragmentManagerState.f1168h = parcel.createTypedArrayList(FragmentManager$LaunchedFragmentInfo.CREATOR);
                return fragmentManagerState;
            case 3:
                return new FragmentState(parcel);
            default:
                FragmentTabHost$SavedState fragmentTabHost$SavedState = new FragmentTabHost$SavedState(parcel);
                fragmentTabHost$SavedState.f1180a = parcel.readString();
                return fragmentTabHost$SavedState;
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i7) {
        switch (this.f1199a) {
            case 0:
                return new BackStackState[i7];
            case 1:
                return new FragmentManager$LaunchedFragmentInfo[i7];
            case 2:
                return new FragmentManagerState[i7];
            case 3:
                return new FragmentState[i7];
            default:
                return new FragmentTabHost$SavedState[i7];
        }
    }
}
