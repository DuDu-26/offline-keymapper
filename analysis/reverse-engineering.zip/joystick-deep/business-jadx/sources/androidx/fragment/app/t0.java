package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class t0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1291a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final u f1292c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f1293d;
    public final HashSet e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f1294f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1295g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final o0 f1296h;

    public t0(int i7, int i8, o0 o0Var, b0.b bVar) {
        u uVar = o0Var.f1265c;
        this.f1293d = new ArrayList();
        this.e = new HashSet();
        this.f1294f = false;
        this.f1295g = false;
        this.f1291a = i7;
        this.b = i8;
        this.f1292c = uVar;
        bVar.a(new e(4, this));
        this.f1296h = o0Var;
    }

    public final void a() {
        HashSet hashSet = this.e;
        if (this.f1294f) {
            return;
        }
        this.f1294f = true;
        if (hashSet.isEmpty()) {
            b();
            return;
        }
        ArrayList arrayList = new ArrayList(hashSet);
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            b0.b bVar = (b0.b) obj;
            synchronized (bVar) {
                try {
                    if (!bVar.f1779a) {
                        bVar.f1779a = true;
                        bVar.f1780c = true;
                        b0.a aVar = bVar.b;
                        if (aVar != null) {
                            try {
                                aVar.onCancel();
                            } catch (Throwable th) {
                                synchronized (bVar) {
                                    bVar.f1780c = false;
                                    bVar.notifyAll();
                                    throw th;
                                }
                            }
                        }
                        synchronized (bVar) {
                            bVar.f1780c = false;
                            bVar.notifyAll();
                        }
                    }
                } finally {
                }
            }
        }
    }

    public final void b() {
        if (!this.f1295g) {
            if (k0.E(2)) {
                toString();
            }
            this.f1295g = true;
            ArrayList arrayList = this.f1293d;
            int size = arrayList.size();
            int i7 = 0;
            while (i7 < size) {
                Object obj = arrayList.get(i7);
                i7++;
                ((Runnable) obj).run();
            }
        }
        this.f1296h.k();
    }

    public final void c(int i7, int i8) {
        int iD = n.e.d(i8);
        u uVar = this.f1292c;
        if (iD == 0) {
            if (this.f1291a != 1) {
                if (k0.E(2)) {
                    Objects.toString(uVar);
                }
                this.f1291a = i7;
                return;
            }
            return;
        }
        if (iD != 1) {
            if (iD != 2) {
                return;
            }
            if (k0.E(2)) {
                Objects.toString(uVar);
            }
            this.f1291a = 1;
            this.b = 3;
            return;
        }
        if (this.f1291a == 1) {
            if (k0.E(2)) {
                Objects.toString(uVar);
            }
            this.f1291a = 2;
            this.b = 2;
        }
    }

    public final void d() {
        if (this.b == 2) {
            o0 o0Var = this.f1296h;
            u uVar = o0Var.f1265c;
            View viewFindFocus = uVar.E.findFocus();
            if (viewFindFocus != null) {
                uVar.f().f1287k = viewFindFocus;
                if (k0.E(2)) {
                    viewFindFocus.toString();
                    uVar.toString();
                }
            }
            View viewJ = this.f1292c.J();
            if (viewJ.getParent() == null) {
                o0Var.b();
                viewJ.setAlpha(0.0f);
            }
            if (viewJ.getAlpha() == 0.0f && viewJ.getVisibility() == 0) {
                viewJ.setVisibility(4);
            }
            r rVar = uVar.H;
            viewJ.setAlpha(rVar == null ? 1.0f : rVar.f1286j);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Operation {");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} {mFinalState = ");
        int i7 = this.f1291a;
        sb.append(i7 != 1 ? i7 != 2 ? i7 != 3 ? i7 != 4 ? "null" : "INVISIBLE" : "GONE" : "VISIBLE" : "REMOVED");
        sb.append("} {mLifecycleImpact = ");
        int i8 = this.b;
        sb.append(i8 != 1 ? i8 != 2 ? i8 != 3 ? "null" : "REMOVING" : "ADDING" : "NONE");
        sb.append("} {mFragment = ");
        sb.append(this.f1292c);
        sb.append("}");
        return sb.toString();
    }
}
