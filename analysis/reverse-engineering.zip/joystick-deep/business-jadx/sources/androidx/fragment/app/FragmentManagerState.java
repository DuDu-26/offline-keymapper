package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
@SuppressLint({"BanParcelableUsage"})
final class FragmentManagerState implements Parcelable {
    public static final Parcelable.Creator<FragmentManagerState> CREATOR = new b(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f1163a;
    public ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public BackStackState[] f1164c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1165d;
    public String e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ArrayList f1166f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f1167g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList f1168h;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i7) {
        parcel.writeTypedList(this.f1163a);
        parcel.writeStringList(this.b);
        parcel.writeTypedArray(this.f1164c, i7);
        parcel.writeInt(this.f1165d);
        parcel.writeString(this.e);
        parcel.writeStringList(this.f1166f);
        parcel.writeTypedList(this.f1167g);
        parcel.writeTypedList(this.f1168h);
    }
}
