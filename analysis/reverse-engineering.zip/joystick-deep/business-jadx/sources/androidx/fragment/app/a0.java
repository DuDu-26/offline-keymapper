package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a0 implements LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k0 f1198a;

    public a0(k0 k0Var) {
        this.f1198a = k0Var;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0, types: [androidx.fragment.app.k0] */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12, types: [androidx.fragment.app.u] */
    /* JADX WARN: Type inference failed for: r6v14, types: [androidx.fragment.app.u] */
    /* JADX WARN: Type inference failed for: r6v16, types: [androidx.fragment.app.u] */
    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v23, types: [androidx.fragment.app.u] */
    /* JADX WARN: Type inference failed for: r6v24 */
    /* JADX WARN: Type inference failed for: r6v34 */
    /* JADX WARN: Type inference failed for: r6v35 */
    /* JADX WARN: Type inference failed for: r6v36 */
    /* JADX WARN: Type inference failed for: r6v37 */
    /* JADX WARN: Type inference failed for: r6v38 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean zIsAssignableFrom;
        MainActivity mainActivity;
        o0 o0VarF;
        ?? r62;
        View view2;
        ?? r42 = this.f1198a;
        y2.e eVar = r42.f1226c;
        if (FragmentContainerView.class.getName().equals(str)) {
            FragmentContainerView fragmentContainerView = new FragmentContainerView(context, attributeSet);
            fragmentContainerView.f1161d = true;
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o0.a.b);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(0);
            }
            String string = typedArrayObtainStyledAttributes.getString(1);
            typedArrayObtainStyledAttributes.recycle();
            int id = fragmentContainerView.getId();
            u uVarA = r42.A(id);
            if (classAttribute != null && uVarA == null) {
                if (id <= 0) {
                    f3.t(s.h.e("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ""));
                    return null;
                }
                f0 f0VarC = r42.C();
                context.getClassLoader();
                u uVarA2 = f0VarC.a(classAttribute);
                uVarA2.C = true;
                x xVar = uVarA2.f1313s;
                if ((xVar != null ? xVar.f1323a : null) != null) {
                    uVarA2.C = true;
                }
                a aVar = new a(r42);
                aVar.f1194p = true;
                uVarA2.D = fragmentContainerView;
                aVar.f(fragmentContainerView.getId(), uVarA2, string, 1);
                if (aVar.f1185g) {
                    f3.t("This transaction is already being added to the back stack");
                    return null;
                }
                aVar.f1186h = false;
                aVar.f1195q.y(aVar, true);
            }
            ArrayList arrayListK = eVar.k();
            int size = arrayListK.size();
            while (id < size) {
                Object obj = arrayListK.get(id);
                id++;
                o0 o0Var = (o0) obj;
                u uVar = o0Var.f1265c;
                if (uVar.f1317w == fragmentContainerView.getId() && (view2 = uVar.E) != null && view2.getParent() == null) {
                    uVar.D = fragmentContainerView;
                    o0Var.b();
                }
            }
            return fragmentContainerView;
        }
        if ("fragment".equals(str)) {
            String attributeValue = attributeSet.getAttributeValue(null, "class");
            TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, o0.a.f7172a);
            if (attributeValue == null) {
                attributeValue = typedArrayObtainStyledAttributes2.getString(0);
            }
            int resourceId = typedArrayObtainStyledAttributes2.getResourceId(1, -1);
            String string2 = typedArrayObtainStyledAttributes2.getString(2);
            typedArrayObtainStyledAttributes2.recycle();
            if (attributeValue != null) {
                try {
                    zIsAssignableFrom = u.class.isAssignableFrom(f0.b(context.getClassLoader(), attributeValue));
                } catch (ClassNotFoundException unused) {
                    zIsAssignableFrom = false;
                }
                if (zIsAssignableFrom) {
                    id = view != null ? view.getId() : 0;
                    if (id == -1 && resourceId == -1 && string2 == null) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                    }
                    ?? A = resourceId != -1 ? r42.A(resourceId) : 0;
                    if (A == 0 && string2 != null) {
                        ArrayList arrayList = (ArrayList) eVar.f8965c;
                        int size2 = arrayList.size() - 1;
                        while (true) {
                            if (size2 < 0) {
                                mainActivity = mainActivity;
                                Iterator it = ((HashMap) eVar.b).values().iterator();
                                while (true) {
                                    if (!it.hasNext()) {
                                        A = mainActivity;
                                        break;
                                    }
                                    o0 o0Var2 = (o0) it.next();
                                    if (o0Var2 != null) {
                                        A = o0Var2.f1265c;
                                        if (string2.equals(A.f1318x)) {
                                            break;
                                        }
                                    }
                                }
                            } else {
                                u uVar2 = (u) arrayList.get(size2);
                                mainActivity = mainActivity;
                                if (uVar2 != null && string2.equals(uVar2.f1318x)) {
                                    A = uVar2;
                                    break;
                                }
                                size2--;
                                mainActivity = mainActivity;
                            }
                        }
                    } else {
                        mainActivity = null;
                    }
                    if (A == 0 && id != -1) {
                        A = r42.A(id);
                    }
                    if (A == 0) {
                        f0 f0VarC2 = r42.C();
                        context.getClassLoader();
                        u uVarA3 = f0VarC2.a(attributeValue);
                        uVarA3.f1307m = true;
                        uVarA3.f1316v = resourceId != 0 ? resourceId : id;
                        uVarA3.f1317w = id;
                        uVarA3.f1318x = string2;
                        uVarA3.f1308n = true;
                        uVarA3.f1312r = r42;
                        x xVar2 = r42.f1237o;
                        uVarA3.f1313s = xVar2;
                        MainActivity mainActivity2 = xVar2.b;
                        uVarA3.C = true;
                        if ((xVar2 == null ? mainActivity : xVar2.f1323a) != null) {
                            uVarA3.C = true;
                        }
                        o0VarF = r42.a(uVarA3);
                        r62 = uVarA3;
                        if (k0.E(2)) {
                            uVarA3.toString();
                            Integer.toHexString(resourceId);
                            r62 = uVarA3;
                        }
                    } else {
                        if (A.f1308n) {
                            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string2 + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
                        }
                        A.f1308n = true;
                        A.f1312r = r42;
                        x xVar3 = r42.f1237o;
                        A.f1313s = xVar3;
                        MainActivity mainActivity3 = xVar3.b;
                        A.C = true;
                        if ((xVar3 == null ? mainActivity : xVar3.f1323a) != null) {
                            A.C = true;
                        }
                        o0VarF = r42.f(A);
                        r62 = A;
                        if (k0.E(2)) {
                            A.toString();
                            Integer.toHexString(resourceId);
                            r62 = A;
                        }
                    }
                    r62.D = (ViewGroup) view;
                    o0VarF.k();
                    o0VarF.j();
                    View view3 = r62.E;
                    if (view3 == null) {
                        f3.t(s.h.e("Fragment ", attributeValue, " did not create a view."));
                        return null;
                    }
                    if (resourceId != 0) {
                        view3.setId(resourceId);
                    }
                    if (r62.E.getTag() == null) {
                        r62.E.setTag(string2);
                    }
                    r62.E.addOnAttachStateChangeListener(new z(this, o0VarF));
                    return r62.E;
                }
            }
        }
        return null;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
