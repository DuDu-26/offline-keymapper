package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class z implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o0 f1329a;
    public final /* synthetic */ a0 b;

    public z(a0 a0Var, o0 o0Var) {
        this.b = a0Var;
        this.f1329a = o0Var;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        o0 o0Var = this.f1329a;
        u uVar = o0Var.f1265c;
        o0Var.k();
        j.f((ViewGroup) uVar.E.getParent(), this.b.f1198a.D()).e();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
    }
}
