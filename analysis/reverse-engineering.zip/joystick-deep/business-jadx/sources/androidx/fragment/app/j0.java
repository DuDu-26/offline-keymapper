package androidx.fragment.app;

import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j0 implements i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1222a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k0 f1223c;

    public j0(k0 k0Var, int i7, int i8) {
        this.f1223c = k0Var;
        this.f1222a = i7;
        this.b = i8;
    }

    @Override // androidx.fragment.app.i0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        k0 k0Var = this.f1223c;
        u uVar = k0Var.f1240r;
        int i7 = this.f1222a;
        if (uVar == null || i7 >= 0 || !uVar.h().L()) {
            return k0Var.M(arrayList, arrayList2, i7, this.b);
        }
        return false;
    }
}
