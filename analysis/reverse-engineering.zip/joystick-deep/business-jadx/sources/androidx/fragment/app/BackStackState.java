package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.appcompat.widget.f3;
import java.util.ArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
@SuppressLint({"BanParcelableUsage"})
final class BackStackState implements Parcelable {
    public static final Parcelable.Creator<BackStackState> CREATOR = new b(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f1145a;
    public final ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f1146c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f1147d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f1148f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1149g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f1150h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f1151i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f1152j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CharSequence f1153k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f1154l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f1155m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f1156n;

    public BackStackState(a aVar) {
        int size = aVar.f1181a.size();
        this.f1145a = new int[size * 5];
        if (!aVar.f1185g) {
            f3.t("Not on back stack");
            throw null;
        }
        this.b = new ArrayList(size);
        this.f1146c = new int[size];
        this.f1147d = new int[size];
        int i7 = 0;
        for (int i8 = 0; i8 < size; i8++) {
            p0 p0Var = (p0) aVar.f1181a.get(i8);
            int i9 = i7 + 1;
            this.f1145a[i7] = p0Var.f1270a;
            ArrayList arrayList = this.b;
            u uVar = p0Var.b;
            arrayList.add(uVar != null ? uVar.e : null);
            int[] iArr = this.f1145a;
            iArr[i9] = p0Var.f1271c;
            iArr[i7 + 2] = p0Var.f1272d;
            int i10 = i7 + 4;
            iArr[i7 + 3] = p0Var.e;
            i7 += 5;
            iArr[i10] = p0Var.f1273f;
            this.f1146c[i8] = p0Var.f1274g.ordinal();
            this.f1147d[i8] = p0Var.f1275h.ordinal();
        }
        this.e = aVar.f1184f;
        this.f1148f = aVar.f1187i;
        this.f1149g = aVar.f1197s;
        this.f1150h = aVar.f1188j;
        this.f1151i = aVar.f1189k;
        this.f1152j = aVar.f1190l;
        this.f1153k = aVar.f1191m;
        this.f1154l = aVar.f1192n;
        this.f1155m = aVar.f1193o;
        this.f1156n = aVar.f1194p;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i7) {
        parcel.writeIntArray(this.f1145a);
        parcel.writeStringList(this.b);
        parcel.writeIntArray(this.f1146c);
        parcel.writeIntArray(this.f1147d);
        parcel.writeInt(this.e);
        parcel.writeString(this.f1148f);
        parcel.writeInt(this.f1149g);
        parcel.writeInt(this.f1150h);
        TextUtils.writeToParcel(this.f1151i, parcel, 0);
        parcel.writeInt(this.f1152j);
        TextUtils.writeToParcel(this.f1153k, parcel, 0);
        parcel.writeStringList(this.f1154l);
        parcel.writeStringList(this.f1155m);
        parcel.writeInt(this.f1156n ? 1 : 0);
    }

    public BackStackState(Parcel parcel) {
        this.f1145a = parcel.createIntArray();
        this.b = parcel.createStringArrayList();
        this.f1146c = parcel.createIntArray();
        this.f1147d = parcel.createIntArray();
        this.e = parcel.readInt();
        this.f1148f = parcel.readString();
        this.f1149g = parcel.readInt();
        this.f1150h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f1151i = (CharSequence) creator.createFromParcel(parcel);
        this.f1152j = parcel.readInt();
        this.f1153k = (CharSequence) creator.createFromParcel(parcel);
        this.f1154l = parcel.createStringArrayList();
        this.f1155m = parcel.createStringArrayList();
        this.f1156n = parcel.readInt() != 0;
    }
}
