package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h extends androidx.appcompat.app.y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1216c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1217d;
    public w3.b e;

    /* JADX WARN: Removed duplicated region for block: B:17:0x0027  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00b9 A[Catch: RuntimeException -> 0x00bf, TRY_LEAVE, TryCatch #1 {RuntimeException -> 0x00bf, blocks: (B:67:0x00b3, B:69:0x00b9), top: B:80:0x00b3 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final w3.b j(android.content.Context r9) {
        /*
            Method dump skipped, instruction units count: 212
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.h.j(android.content.Context):w3.b");
    }
}
