package androidx.fragment.app;

import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1279a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1280c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1281d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1282f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f1283g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f1284h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Object f1285i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f1286j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f1287k;
}
