package androidx.fragment.app;

import androidx.appcompat.widget.f3;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.bc;
import com.umeng.analytics.pro.dd;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f1181a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1182c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1183d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1184f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1185g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1186h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f1187i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f1188j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f1189k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f1190l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public CharSequence f1191m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public ArrayList f1192n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ArrayList f1193o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f1194p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final k0 f1195q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f1196r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1197s;

    public a(k0 k0Var) {
        k0Var.C();
        x xVar = k0Var.f1237o;
        if (xVar != null) {
            xVar.b.getClassLoader();
        }
        this.f1181a = new ArrayList();
        this.f1186h = true;
        this.f1194p = false;
        this.f1197s = -1;
        this.f1195q = k0Var;
    }

    @Override // androidx.fragment.app.i0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        if (k0.E(2)) {
            toString();
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f1185g) {
            return true;
        }
        k0 k0Var = this.f1195q;
        if (k0Var.f1227d == null) {
            k0Var.f1227d = new ArrayList();
        }
        k0Var.f1227d.add(this);
        return true;
    }

    public final void b(p0 p0Var) {
        this.f1181a.add(p0Var);
        p0Var.f1271c = this.b;
        p0Var.f1272d = this.f1182c;
        p0Var.e = this.f1183d;
        p0Var.f1273f = this.e;
    }

    public final void c(int i7) {
        if (this.f1185g) {
            if (k0.E(2)) {
                toString();
            }
            ArrayList arrayList = this.f1181a;
            int size = arrayList.size();
            for (int i8 = 0; i8 < size; i8++) {
                p0 p0Var = (p0) arrayList.get(i8);
                u uVar = p0Var.b;
                if (uVar != null) {
                    uVar.f1311q += i7;
                    if (k0.E(2)) {
                        Objects.toString(p0Var.b);
                        int i9 = p0Var.b.f1311q;
                    }
                }
            }
        }
    }

    public final int d(boolean z6) {
        if (this.f1196r) {
            f3.t("commit already called");
            return 0;
        }
        if (k0.E(2)) {
            toString();
            PrintWriter printWriter = new PrintWriter(new r0());
            g("  ", printWriter, true);
            printWriter.close();
        }
        this.f1196r = true;
        boolean z7 = this.f1185g;
        k0 k0Var = this.f1195q;
        if (z7) {
            this.f1197s = k0Var.f1231i.getAndIncrement();
        } else {
            this.f1197s = -1;
        }
        k0Var.v(this, z6);
        return this.f1197s;
    }

    public final void e() {
        if (this.f1185g) {
            f3.t("This transaction is already being added to the back stack");
        } else {
            this.f1186h = false;
        }
    }

    public final void f(int i7, u uVar, String str, int i8) {
        Class<?> cls = uVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str2 = uVar.f1318x;
            if (str2 != null && !str.equals(str2)) {
                StringBuilder sb = new StringBuilder("Can't change tag of fragment ");
                sb.append(uVar);
                String str3 = uVar.f1318x;
                sb.append(": was ");
                sb.append(str3);
                sb.append(" now ");
                sb.append(str);
                throw new IllegalStateException(sb.toString());
            }
            uVar.f1318x = str;
        }
        if (i7 != 0) {
            if (i7 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + uVar + " with tag " + str + " to container view with no id");
            }
            int i9 = uVar.f1316v;
            if (i9 != 0 && i9 != i7) {
                StringBuilder sb2 = new StringBuilder("Can't change container ID of fragment ");
                sb2.append(uVar);
                int i10 = uVar.f1316v;
                sb2.append(": was ");
                sb2.append(i10);
                sb2.append(" now ");
                sb2.append(i7);
                throw new IllegalStateException(sb2.toString());
            }
            uVar.f1316v = i7;
            uVar.f1317w = i7;
        }
        b(new p0(i8, uVar));
        uVar.f1312r = this.f1195q;
    }

    public final void g(String str, PrintWriter printWriter, boolean z6) {
        String str2;
        if (z6) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f1187i);
            printWriter.print(" mIndex=");
            printWriter.print(this.f1197s);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f1196r);
            if (this.f1184f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f1184f));
            }
            if (this.b != 0 || this.f1182c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f1182c));
            }
            if (this.f1183d != 0 || this.e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f1183d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.e));
            }
            if (this.f1188j != 0 || this.f1189k != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f1188j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f1189k);
            }
            if (this.f1190l != 0 || this.f1191m != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f1190l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f1191m);
            }
        }
        ArrayList arrayList = this.f1181a;
        if (arrayList.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            p0 p0Var = (p0) arrayList.get(i7);
            switch (p0Var.f1270a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case dd.f4082h /* 7 */:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + p0Var.f1270a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i7);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(p0Var.b);
            if (z6) {
                if (p0Var.f1271c != 0 || p0Var.f1272d != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(p0Var.f1271c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(p0Var.f1272d));
                }
                if (p0Var.e != 0 || p0Var.f1273f != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(p0Var.e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(p0Var.f1273f));
                }
            }
        }
    }

    public final void h(u uVar) {
        k0 k0Var = uVar.f1312r;
        if (k0Var == null || k0Var == this.f1195q) {
            b(new p0(3, uVar));
            return;
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + uVar.toString() + " is already attached to a FragmentManager.");
    }

    public final void i(u uVar, androidx.lifecycle.m mVar) {
        k0 k0Var = uVar.f1312r;
        k0 k0Var2 = this.f1195q;
        if (k0Var != k0Var2) {
            k3.g.h(k0Var2, "Cannot setMaxLifecycle for Fragment not attached to FragmentManager ");
            return;
        }
        if (mVar == androidx.lifecycle.m.b && uVar.f1297a > -1) {
            f3.n("Cannot set maximum Lifecycle to ", mVar, " after the Fragment has been created");
            return;
        }
        if (mVar == androidx.lifecycle.m.f1358a) {
            f3.n("Cannot set maximum Lifecycle to ", mVar, ". Use remove() to remove the fragment from the FragmentManager and trigger its destruction.");
            return;
        }
        p0 p0Var = new p0();
        p0Var.f1270a = 10;
        p0Var.b = uVar;
        p0Var.f1274g = uVar.K;
        p0Var.f1275h = mVar;
        b(p0Var);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(bc.f3796d);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f1197s >= 0) {
            sb.append(" #");
            sb.append(this.f1197s);
        }
        if (this.f1187i != null) {
            sb.append(" ");
            sb.append(this.f1187i);
        }
        sb.append("}");
        return sb.toString();
    }
}
