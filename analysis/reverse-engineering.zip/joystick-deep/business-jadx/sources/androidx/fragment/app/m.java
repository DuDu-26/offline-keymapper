package androidx.fragment.app;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class m extends a5.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o f1255a;
    public final /* synthetic */ n b;

    public m(n nVar, o oVar) {
        this.b = nVar;
        this.f1255a = oVar;
    }

    @Override // a5.h
    public final View R(int i7) {
        o oVar = this.f1255a;
        if (oVar.S()) {
            return oVar.R(i7);
        }
        Dialog dialog = this.b.f1258d0;
        if (dialog != null) {
            return dialog.findViewById(i7);
        }
        return null;
    }

    @Override // a5.h
    public final boolean S() {
        return this.f1255a.S() || this.b.f1261g0;
    }
}
