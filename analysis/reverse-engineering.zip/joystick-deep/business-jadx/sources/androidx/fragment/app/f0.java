package androidx.fragment.app;

import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class f0 {
    public static final l.k b = new l.k();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k0 f1212a;

    public f0(k0 k0Var) {
        this.f1212a = k0Var;
    }

    public static Class b(ClassLoader classLoader, String str) throws ClassNotFoundException {
        l.k kVar = b;
        l.k kVar2 = (l.k) kVar.getOrDefault(classLoader, null);
        if (kVar2 == null) {
            kVar2 = new l.k();
            kVar.put(classLoader, kVar2);
        }
        Class cls = (Class) kVar2.getOrDefault(str, null);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        kVar2.put(str, cls2);
        return cls2;
    }

    public static Class c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassCastException e) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e);
        } catch (ClassNotFoundException e3) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": make sure class name exists"), e3);
        }
    }

    public final u a(String str) {
        try {
            return (u) c(this.f1212a.f1237o.b.getClassLoader(), str).getConstructor(null).newInstance(null);
        } catch (IllegalAccessException e) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e);
        } catch (InstantiationException e3) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e3);
        } catch (NoSuchMethodException e7) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e7);
        } catch (InvocationTargetException e8) {
            throw new s(s.h.e("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e8);
        }
    }
}
