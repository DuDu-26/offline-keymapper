package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class y extends AnimationSet implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f1326a;
    public final View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1327c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1328d;
    public boolean e;

    public y(Animation animation, ViewGroup viewGroup, View view) {
        super(false);
        this.e = true;
        this.f1326a = viewGroup;
        this.b = view;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public final boolean getTransformation(long j7, Transformation transformation) {
        this.e = true;
        if (this.f1327c) {
            return !this.f1328d;
        }
        if (!super.getTransformation(j7, transformation)) {
            this.f1327c = true;
            f0.u.a(this.f1326a, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z6 = this.f1327c;
        ViewGroup viewGroup = this.f1326a;
        if (z6 || !this.e) {
            viewGroup.endViewTransition(this.b);
            this.f1328d = true;
        } else {
            this.e = false;
            viewGroup.post(this);
        }
    }

    @Override // android.view.animation.Animation
    public final boolean getTransformation(long j7, Transformation transformation, float f2) {
        this.e = true;
        if (this.f1327c) {
            return !this.f1328d;
        }
        if (!super.getTransformation(j7, transformation, f2)) {
            this.f1327c = true;
            f0.u.a(this.f1326a, this);
        }
        return true;
    }
}
