package androidx.fragment.app;

import android.animation.Animator;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f1219a;
    public final ArrayList b = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f1220c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1221d = false;
    public boolean e = false;

    public j(ViewGroup viewGroup) {
        this.f1219a = viewGroup;
    }

    public static j f(ViewGroup viewGroup, e0 e0Var) {
        Object tag = viewGroup.getTag(2131296716);
        if (tag instanceof j) {
            return (j) tag;
        }
        e0Var.getClass();
        j jVar = new j(viewGroup);
        viewGroup.setTag(2131296716, jVar);
        return jVar;
    }

    public final void a(int i7, int i8, o0 o0Var) {
        synchronized (this.b) {
            try {
                b0.b bVar = new b0.b();
                t0 t0VarD = d(o0Var.f1265c);
                if (t0VarD != null) {
                    t0VarD.c(i7, i8);
                    return;
                }
                t0 t0Var = new t0(i7, i8, o0Var, bVar);
                this.b.add(t0Var);
                t0Var.f1293d.add(new s0(this, t0Var, 0));
                t0Var.f1293d.add(new s0(this, t0Var, 1));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(ArrayList arrayList, boolean z6) {
        int i7;
        int i8;
        ViewGroup viewGroup;
        int size = arrayList.size();
        boolean z7 = false;
        t0 t0Var = null;
        int i9 = 0;
        t0 t0Var2 = null;
        while (true) {
            i7 = 2;
            if (i9 >= size) {
                break;
            }
            Object obj = arrayList.get(i9);
            i9++;
            t0 t0Var3 = (t0) obj;
            int iC = androidx.activity.g.c(t0Var3.f1292c.E);
            int iD = n.e.d(t0Var3.f1291a);
            if (iD != 0) {
                if (iD != 1) {
                    if (iD == 2 || iD == 3) {
                    }
                } else if (iC != 2) {
                    t0Var2 = t0Var3;
                }
            }
            if (iC == 2 && t0Var == null) {
                t0Var = t0Var3;
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList(arrayList);
        int size2 = arrayList.size();
        int i10 = 0;
        while (i10 < size2) {
            Object obj2 = arrayList.get(i10);
            i10++;
            t0 t0Var4 = (t0) obj2;
            b0.b bVar = new b0.b();
            t0Var4.d();
            HashSet hashSet = t0Var4.e;
            hashSet.add(bVar);
            h hVar = new h(t0Var4, bVar);
            hVar.f1217d = z7;
            hVar.f1216c = z6;
            arrayList2.add(hVar);
            b0.b bVar2 = new b0.b();
            t0Var4.d();
            hashSet.add(bVar2);
            boolean z8 = (!z6 ? t0Var4 == t0Var2 : t0Var4 == t0Var) ? z7 : true;
            i iVar = new i(t0Var4, bVar2);
            int i11 = t0Var4.f1291a;
            u uVar = t0Var4.f1292c;
            if (i11 == 2) {
                if (z6) {
                    uVar.getClass();
                } else {
                    uVar.getClass();
                }
                if (z6) {
                    uVar.getClass();
                } else {
                    uVar.getClass();
                }
            } else if (z6) {
                uVar.getClass();
            } else {
                uVar.getClass();
            }
            if (z8) {
                if (z6) {
                    uVar.getClass();
                } else {
                    uVar.getClass();
                }
            }
            arrayList3.add(iVar);
            t0Var4.f1293d.add(new c(this, arrayList4, t0Var4));
            z7 = false;
        }
        HashMap map = new HashMap();
        int size3 = arrayList3.size();
        int i12 = 0;
        while (i12 < size3) {
            Object obj3 = arrayList3.get(i12);
            i12++;
            t0 t0Var5 = (t0) ((i) obj3).f559a;
            androidx.activity.g.c(t0Var5.f1292c.E);
            int i13 = t0Var5.f1291a;
        }
        int size4 = arrayList3.size();
        int i14 = 0;
        while (i14 < size4) {
            Object obj4 = arrayList3.get(i14);
            i14++;
            i iVar2 = (i) obj4;
            map.put((t0) iVar2.f559a, Boolean.FALSE);
            iVar2.d();
        }
        boolean zContainsValue = map.containsValue(Boolean.TRUE);
        ViewGroup viewGroup2 = this.f1219a;
        Context context = viewGroup2.getContext();
        ArrayList arrayList5 = new ArrayList();
        int size5 = arrayList2.size();
        boolean z9 = false;
        int i15 = 0;
        while (i15 < size5) {
            Object obj5 = arrayList2.get(i15);
            i15++;
            h hVar2 = (h) obj5;
            t0 t0Var6 = (t0) hVar2.f559a;
            int iC2 = androidx.activity.g.c(t0Var6.f1292c.E);
            int i16 = t0Var6.f1291a;
            if (iC2 == i16 || !(iC2 == i7 || i16 == i7)) {
                viewGroup = viewGroup2;
                i8 = i7;
                hVar2.d();
                viewGroup2 = viewGroup;
                i7 = i8;
            } else {
                w3.b bVarJ = hVar2.j(context);
                if (bVarJ == null) {
                    hVar2.d();
                } else {
                    Animator animator = (Animator) bVarJ.f8545c;
                    if (animator == null) {
                        arrayList5.add(hVar2);
                    } else {
                        t0 t0Var7 = (t0) hVar2.f559a;
                        u uVar2 = t0Var7.f1292c;
                        i8 = i7;
                        if (Boolean.TRUE.equals(map.get(t0Var7))) {
                            if (k0.E(i8)) {
                                Objects.toString(uVar2);
                            }
                            hVar2.d();
                            viewGroup = viewGroup2;
                            viewGroup2 = viewGroup;
                            i7 = i8;
                        } else {
                            boolean z10 = t0Var7.f1291a == 3;
                            if (z10) {
                                arrayList4.remove(t0Var7);
                            }
                            View view = uVar2.E;
                            viewGroup2.startViewTransition(view);
                            ViewGroup viewGroup3 = viewGroup2;
                            animator.addListener(new d(viewGroup3, view, z10, t0Var7, hVar2));
                            animator.setTarget(view);
                            animator.start();
                            ((b0.b) hVar2.b).a(new e(0, animator));
                            viewGroup2 = viewGroup3;
                            i7 = i8;
                            z9 = true;
                        }
                    }
                }
                viewGroup = viewGroup2;
                i8 = i7;
                viewGroup2 = viewGroup;
                i7 = i8;
            }
        }
        ViewGroup viewGroup4 = viewGroup2;
        int i17 = i7;
        int size6 = arrayList5.size();
        int i18 = 0;
        while (i18 < size6) {
            Object obj6 = arrayList5.get(i18);
            i18++;
            h hVar3 = (h) obj6;
            t0 t0Var8 = (t0) hVar3.f559a;
            u uVar3 = t0Var8.f1292c;
            if (zContainsValue) {
                if (k0.E(i17)) {
                    Objects.toString(uVar3);
                }
                hVar3.d();
            } else if (z9) {
                if (k0.E(i17)) {
                    Objects.toString(uVar3);
                }
                hVar3.d();
            } else {
                View view2 = uVar3.E;
                w3.b bVarJ2 = hVar3.j(context);
                bVarJ2.getClass();
                Animation animation = (Animation) bVarJ2.b;
                animation.getClass();
                if (t0Var8.f1291a != 1) {
                    view2.startAnimation(animation);
                    hVar3.d();
                } else {
                    viewGroup4.startViewTransition(view2);
                    y yVar = new y(animation, viewGroup4, view2);
                    yVar.setAnimationListener(new g(view2, viewGroup4, hVar3));
                    view2.startAnimation(yVar);
                }
                ((b0.b) hVar3.b).a(new y2.e(view2, viewGroup4, hVar3));
            }
        }
        int size7 = arrayList4.size();
        int i19 = 0;
        while (i19 < size7) {
            Object obj7 = arrayList4.get(i19);
            i19++;
            t0 t0Var9 = (t0) obj7;
            androidx.activity.g.a(t0Var9.f1292c.E, t0Var9.f1291a);
        }
        arrayList4.clear();
    }

    public final void c() {
        if (this.e) {
            return;
        }
        ViewGroup viewGroup = this.f1219a;
        WeakHashMap weakHashMap = f0.s0.f5582a;
        if (!f0.e0.b(viewGroup)) {
            e();
            this.f1221d = false;
            return;
        }
        synchronized (this.b) {
            try {
                if (!this.b.isEmpty()) {
                    ArrayList arrayList = new ArrayList(this.f1220c);
                    this.f1220c.clear();
                    int size = arrayList.size();
                    int i7 = 0;
                    while (i7 < size) {
                        Object obj = arrayList.get(i7);
                        i7++;
                        t0 t0Var = (t0) obj;
                        if (k0.E(2)) {
                            Objects.toString(t0Var);
                        }
                        t0Var.a();
                        if (!t0Var.f1295g) {
                            this.f1220c.add(t0Var);
                        }
                    }
                    g();
                    ArrayList arrayList2 = new ArrayList(this.b);
                    this.b.clear();
                    this.f1220c.addAll(arrayList2);
                    int size2 = arrayList2.size();
                    int i8 = 0;
                    while (i8 < size2) {
                        Object obj2 = arrayList2.get(i8);
                        i8++;
                        ((t0) obj2).d();
                    }
                    b(arrayList2, this.f1221d);
                    this.f1221d = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final t0 d(u uVar) {
        ArrayList arrayList = this.b;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            t0 t0Var = (t0) obj;
            if (t0Var.f1292c.equals(uVar) && !t0Var.f1294f) {
                return t0Var;
            }
        }
        return null;
    }

    public final void e() {
        ViewGroup viewGroup = this.f1219a;
        WeakHashMap weakHashMap = f0.s0.f5582a;
        boolean zB = f0.e0.b(viewGroup);
        synchronized (this.b) {
            try {
                g();
                ArrayList arrayList = this.b;
                int size = arrayList.size();
                int i7 = 0;
                int i8 = 0;
                while (i8 < size) {
                    Object obj = arrayList.get(i8);
                    i8++;
                    ((t0) obj).d();
                }
                ArrayList arrayList2 = new ArrayList(this.f1220c);
                int size2 = arrayList2.size();
                int i9 = 0;
                while (i9 < size2) {
                    Object obj2 = arrayList2.get(i9);
                    i9++;
                    t0 t0Var = (t0) obj2;
                    if (k0.E(2)) {
                        if (!zB) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("Container ");
                            sb.append(this.f1219a);
                            sb.append(" is not attached to window. ");
                        }
                        Objects.toString(t0Var);
                    }
                    t0Var.a();
                }
                ArrayList arrayList3 = new ArrayList(this.b);
                int size3 = arrayList3.size();
                while (i7 < size3) {
                    Object obj3 = arrayList3.get(i7);
                    i7++;
                    t0 t0Var2 = (t0) obj3;
                    if (k0.E(2)) {
                        if (!zB) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Container ");
                            sb2.append(this.f1219a);
                            sb2.append(" is not attached to window. ");
                        }
                        Objects.toString(t0Var2);
                    }
                    t0Var2.a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void g() {
        ArrayList arrayList = this.b;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            t0 t0Var = (t0) obj;
            if (t0Var.b == 2) {
                t0Var.c(androidx.activity.g.b(t0Var.f1292c.J().getVisibility()), 1);
            }
        }
    }
}
