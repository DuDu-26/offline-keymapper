package androidx.fragment.app;

import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import com.umeng.analytics.pro.bc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class u implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.r, androidx.lifecycle.m0, androidx.lifecycle.h, u0.d {
    public static final Object R = new Object();
    public boolean A;
    public boolean C;
    public ViewGroup D;
    public View E;
    public boolean F;
    public r H;
    public boolean I;
    public boolean J;
    public q0 M;
    public Bundle b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public SparseArray f1298c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Bundle f1299d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Bundle f1300f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public u f1301g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1303i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1305k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1306l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1307m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1308n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1309o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f1310p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f1311q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public k0 f1312r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public x f1313s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public u f1315u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f1316v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f1317w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f1318x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f1319y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1320z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1297a = -1;
    public String e = UUID.randomUUID().toString();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f1302h = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Boolean f1304j = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public k0 f1314t = new k0();
    public boolean B = true;
    public boolean G = true;
    public androidx.lifecycle.m K = androidx.lifecycle.m.e;
    public final androidx.lifecycle.x N = new androidx.lifecycle.x();
    public final AtomicInteger P = new AtomicInteger();
    public final ArrayList Q = new ArrayList();
    public androidx.lifecycle.t L = new androidx.lifecycle.t(this);
    public androidx.activity.o O = new androidx.activity.o(this);

    public void A() {
        this.C = true;
    }

    public void B() {
        this.C = true;
    }

    public void C(View view) {
    }

    public void D(Bundle bundle) {
        this.C = true;
    }

    public void E(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f1314t.K();
        this.f1310p = true;
        this.M = new q0(c());
        View viewR = r(layoutInflater, viewGroup, bundle);
        this.E = viewR;
        q0 q0Var = this.M;
        if (viewR == null) {
            if (q0Var.b == null) {
                this.M = null;
                return;
            } else {
                f3.t("Called getViewLifecycleOwner() but onCreateView() returned null");
                return;
            }
        }
        q0Var.f();
        View view = this.E;
        q0 q0Var2 = this.M;
        view.getClass();
        view.setTag(2131296809, q0Var2);
        View view2 = this.E;
        q0 q0Var3 = this.M;
        view2.getClass();
        view2.setTag(2131296812, q0Var3);
        View view3 = this.E;
        q0 q0Var4 = this.M;
        view3.getClass();
        view3.setTag(2131296811, q0Var4);
        this.N.e(this.M);
    }

    public final q F(a5.h hVar, androidx.activity.result.a aVar) {
        e eVar = new e(2, this);
        if (this.f1297a > 1) {
            f3.t(androidx.activity.g.m("Fragment ", this, " is attempting to registerForActivityResult after being created. Fragments must call registerForActivityResult() before they are created (i.e. initialization, onAttach(), or onCreate())."));
            return null;
        }
        AtomicReference atomicReference = new AtomicReference();
        p pVar = new p(this, eVar, atomicReference, hVar, aVar);
        if (this.f1297a >= 0) {
            pVar.a();
        } else {
            this.Q.add(pVar);
        }
        return new q(atomicReference);
    }

    public final void G(String[] strArr) {
        if (this.f1313s == null) {
            f3.t(androidx.activity.g.m("Fragment ", this, " not attached to Activity"));
            return;
        }
        k0 k0VarK = k();
        if (k0VarK.f1245w == null) {
            k0VarK.f1237o.getClass();
            return;
        }
        String str = this.e;
        FragmentManager$LaunchedFragmentInfo fragmentManager$LaunchedFragmentInfo = new FragmentManager$LaunchedFragmentInfo();
        fragmentManager$LaunchedFragmentInfo.f1162a = str;
        fragmentManager$LaunchedFragmentInfo.b = 100;
        k0VarK.f1246x.addLast(fragmentManager$LaunchedFragmentInfo);
        k0VarK.f1245w.a(strArr);
    }

    public final androidx.appcompat.app.k H() {
        androidx.appcompat.app.k kVarG = g();
        if (kVarG != null) {
            return kVarG;
        }
        f3.t(androidx.activity.g.m("Fragment ", this, " not attached to an activity."));
        return null;
    }

    public final Context I() {
        Context contextI = i();
        if (contextI != null) {
            return contextI;
        }
        f3.t(androidx.activity.g.m("Fragment ", this, " not attached to a context."));
        return null;
    }

    public final View J() {
        View view = this.E;
        if (view != null) {
            return view;
        }
        f3.t(androidx.activity.g.m("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
        return null;
    }

    public final void K(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.f1314t.P(parcelable);
        k0 k0Var = this.f1314t;
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(1);
    }

    public final void L(int i7, int i8, int i9, int i10) {
        if (this.H == null && i7 == 0 && i8 == 0 && i9 == 0 && i10 == 0) {
            return;
        }
        f().b = i7;
        f().f1280c = i8;
        f().f1281d = i9;
        f().e = i10;
    }

    public final void M(Bundle bundle) {
        k0 k0Var = this.f1312r;
        if (k0Var != null) {
            if (k0Var == null ? false : k0Var.I()) {
                f3.t("Fragment already added and state has been saved");
                return;
            }
        }
        this.f1300f = bundle;
    }

    public final void N(Intent intent) {
        x xVar = this.f1313s;
        if (xVar != null) {
            androidx.core.content.a.b(xVar.b, intent, null);
        } else {
            f3.t(androidx.activity.g.m("Fragment ", this, " not attached to Activity"));
        }
    }

    @Override // u0.d
    public final androidx.appcompat.widget.v a() {
        return (androidx.appcompat.widget.v) this.O.f362c;
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 c() {
        if (this.f1312r == null) {
            f3.t("Can't access ViewModels from detached fragment");
            return null;
        }
        if (j() == 1) {
            f3.t("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
            return null;
        }
        HashMap map = this.f1312r.G.e;
        androidx.lifecycle.l0 l0Var = (androidx.lifecycle.l0) map.get(this.e);
        if (l0Var != null) {
            return l0Var;
        }
        androidx.lifecycle.l0 l0Var2 = new androidx.lifecycle.l0();
        map.put(this.e, l0Var2);
        return l0Var2;
    }

    @Override // androidx.lifecycle.r
    public final androidx.lifecycle.t d() {
        return this.L;
    }

    public a5.h e() {
        return new o(this);
    }

    public final r f() {
        if (this.H == null) {
            r rVar = new r();
            Object obj = R;
            rVar.f1283g = obj;
            rVar.f1284h = obj;
            rVar.f1285i = obj;
            rVar.f1286j = 1.0f;
            rVar.f1287k = null;
            this.H = rVar;
        }
        return this.H;
    }

    public final androidx.appcompat.app.k g() {
        x xVar = this.f1313s;
        if (xVar == null) {
            return null;
        }
        return xVar.f1323a;
    }

    public final k0 h() {
        if (this.f1313s != null) {
            return this.f1314t;
        }
        f3.t(androidx.activity.g.m("Fragment ", this, " has not been attached yet."));
        return null;
    }

    public final Context i() {
        x xVar = this.f1313s;
        if (xVar == null) {
            return null;
        }
        return xVar.b;
    }

    public final int j() {
        androidx.lifecycle.m mVar = this.K;
        return (mVar == androidx.lifecycle.m.b || this.f1315u == null) ? mVar.ordinal() : Math.min(mVar.ordinal(), this.f1315u.j());
    }

    public final k0 k() {
        k0 k0Var = this.f1312r;
        if (k0Var != null) {
            return k0Var;
        }
        f3.t(androidx.activity.g.m("Fragment ", this, " not associated with a fragment manager."));
        return null;
    }

    public final Resources l() {
        return I().getResources();
    }

    public final String m(int i7) {
        return l().getString(i7);
    }

    public final String n(int i7, Object... objArr) {
        return l().getString(i7, objArr);
    }

    public final boolean o() {
        return this.f1313s != null && this.f1305k;
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        this.C = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        H().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        this.C = true;
    }

    public void p(Context context) {
        this.C = true;
        x xVar = this.f1313s;
        if ((xVar == null ? null : xVar.f1323a) != null) {
            this.C = true;
        }
    }

    public void q(Bundle bundle) {
        this.C = true;
        K(bundle);
        k0 k0Var = this.f1314t;
        if (k0Var.f1236n >= 1) {
            return;
        }
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(1);
    }

    public View r(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    public void s() {
        this.C = true;
    }

    public void t() {
        this.C = true;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(bc.f3796d);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} (");
        sb.append(this.e);
        if (this.f1316v != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f1316v));
        }
        if (this.f1318x != null) {
            sb.append(" tag=");
            sb.append(this.f1318x);
        }
        sb.append(")");
        return sb.toString();
    }

    public void u() {
        this.C = true;
    }

    public LayoutInflater v(Bundle bundle) {
        x xVar = this.f1313s;
        if (xVar == null) {
            f3.t("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
            return null;
        }
        MainActivity mainActivity = xVar.e;
        LayoutInflater layoutInflaterCloneInContext = mainActivity.getLayoutInflater().cloneInContext(mainActivity);
        layoutInflaterCloneInContext.setFactory2(this.f1314t.f1228f);
        return layoutInflaterCloneInContext;
    }

    public void w() {
        this.C = true;
    }

    public void x(int i7, String[] strArr, int[] iArr) {
    }

    public void y() {
        this.C = true;
    }

    public void z(Bundle bundle) {
    }
}
