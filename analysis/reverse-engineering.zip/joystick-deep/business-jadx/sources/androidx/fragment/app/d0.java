package androidx.fragment.app;

import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1207a = false;
    public final CopyOnWriteArrayList b = new CopyOnWriteArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.activity.w f1208c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k0 f1209d;

    public d0(k0 k0Var) {
        this.f1209d = k0Var;
    }
}
