package androidx.fragment.app;

import android.os.Handler;
import android.view.View;
import android.view.Window;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class x extends a5.h implements androidx.lifecycle.m0, androidx.lifecycle.r, m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MainActivity f1323a;
    public final MainActivity b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Handler f1324c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k0 f1325d;
    public final /* synthetic */ MainActivity e;

    public x(MainActivity mainActivity) {
        this.e = mainActivity;
        Handler handler = new Handler();
        this.f1325d = new k0();
        this.f1323a = mainActivity;
        this.b = mainActivity;
        this.f1324c = handler;
    }

    @Override // a5.h
    public final View R(int i7) {
        return this.e.findViewById(i7);
    }

    @Override // a5.h
    public final boolean S() {
        Window window = this.e.getWindow();
        return (window == null || window.peekDecorView() == null) ? false : true;
    }

    @Override // androidx.fragment.app.m0
    public final void b() {
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 c() {
        return this.e.c();
    }

    @Override // androidx.lifecycle.r
    public final androidx.lifecycle.t d() {
        return this.e.f504q;
    }
}
