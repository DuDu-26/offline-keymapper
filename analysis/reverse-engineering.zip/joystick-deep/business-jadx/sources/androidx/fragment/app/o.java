package androidx.fragment.app;

import android.view.View;
import androidx.appcompat.widget.f3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o extends a5.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ u f1263a;

    public o(u uVar) {
        this.f1263a = uVar;
    }

    @Override // a5.h
    public final View R(int i7) {
        u uVar = this.f1263a;
        View view = uVar.E;
        if (view != null) {
            return view.findViewById(i7);
        }
        f3.t(androidx.activity.g.m("Fragment ", uVar, " does not have a view"));
        return null;
    }

    @Override // a5.h
    public final boolean S() {
        return this.f1263a.E != null;
    }
}
