package androidx.fragment.app;

import android.content.Intent;
import androidx.activity.result.ActivityResult;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c0 implements androidx.activity.result.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1203a;
    public final /* synthetic */ k0 b;

    public /* synthetic */ c0(k0 k0Var, int i7) {
        this.f1203a = i7;
        this.b = k0Var;
    }

    @Override // androidx.activity.result.a
    public final void c(Object obj) {
        switch (this.f1203a) {
            case 0:
                ActivityResult activityResult = (ActivityResult) obj;
                k0 k0Var = this.b;
                FragmentManager$LaunchedFragmentInfo fragmentManager$LaunchedFragmentInfo = (FragmentManager$LaunchedFragmentInfo) k0Var.f1246x.pollFirst();
                if (fragmentManager$LaunchedFragmentInfo != null) {
                    u uVarJ = k0Var.f1226c.j(fragmentManager$LaunchedFragmentInfo.f1162a);
                    if (uVarJ != null) {
                        int i7 = activityResult.f366a;
                        Intent intent = activityResult.b;
                        if (k0.E(2)) {
                            uVarJ.toString();
                            Objects.toString(intent);
                        }
                        break;
                    }
                }
                break;
            case 1:
                Map map = (Map) obj;
                String[] strArr = (String[]) map.keySet().toArray(new String[0]);
                ArrayList arrayList = new ArrayList(map.values());
                int[] iArr = new int[arrayList.size()];
                for (int i8 = 0; i8 < arrayList.size(); i8++) {
                    iArr[i8] = ((Boolean) arrayList.get(i8)).booleanValue() ? 0 : -1;
                }
                k0 k0Var2 = this.b;
                FragmentManager$LaunchedFragmentInfo fragmentManager$LaunchedFragmentInfo2 = (FragmentManager$LaunchedFragmentInfo) k0Var2.f1246x.pollFirst();
                if (fragmentManager$LaunchedFragmentInfo2 != null) {
                    String str = fragmentManager$LaunchedFragmentInfo2.f1162a;
                    int i9 = fragmentManager$LaunchedFragmentInfo2.b;
                    u uVarJ2 = k0Var2.f1226c.j(str);
                    if (uVarJ2 != null) {
                        uVarJ2.x(i9, strArr, iArr);
                        break;
                    }
                }
                break;
            default:
                ActivityResult activityResult2 = (ActivityResult) obj;
                k0 k0Var3 = this.b;
                FragmentManager$LaunchedFragmentInfo fragmentManager$LaunchedFragmentInfo3 = (FragmentManager$LaunchedFragmentInfo) k0Var3.f1246x.pollFirst();
                if (fragmentManager$LaunchedFragmentInfo3 != null) {
                    u uVarJ3 = k0Var3.f1226c.j(fragmentManager$LaunchedFragmentInfo3.f1162a);
                    if (uVarJ3 != null) {
                        int i10 = activityResult2.f366a;
                        Intent intent2 = activityResult2.b;
                        if (k0.E(2)) {
                            uVarJ3.toString();
                            Objects.toString(intent2);
                        }
                        break;
                    }
                }
                break;
        }
    }
}
