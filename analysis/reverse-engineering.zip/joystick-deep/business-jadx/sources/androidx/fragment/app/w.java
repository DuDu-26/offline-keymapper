package androidx.fragment.app;

import android.os.Bundle;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class w implements a.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f1322a;

    public w(MainActivity mainActivity) {
        this.f1322a = mainActivity;
    }

    @Override // a.a
    public final void a() {
        MainActivity mainActivity = this.f1322a;
        e eVar = mainActivity.f503p;
        x xVar = (x) eVar.b;
        xVar.f1325d.b(xVar, xVar, null);
        Bundle bundleC = ((androidx.appcompat.widget.v) mainActivity.e.f362c).c("android:support:fragments");
        if (bundleC != null) {
            ((x) eVar.b).f1325d.P(bundleC.getParcelable("android:support:fragments"));
        }
    }
}
