package androidx.fragment.app;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g0 implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ u f1215a;

    public g0(u uVar) {
        this.f1215a = uVar;
    }

    @Override // androidx.fragment.app.m0
    public final void b() {
        this.f1215a.getClass();
    }
}
