package androidx.fragment.app;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.f3;
import com.efs.sdk.base.http.HttpResponse;
import com.umeng.analytics.pro.dd;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.UUID;
import java.util.WeakHashMap;
import moe.heroman.eventtest.MainActivity;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final y2.o f1264a;
    public final y2.e b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final u f1265c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1266d = false;
    public int e = -1;

    public o0(y2.o oVar, y2.e eVar, ClassLoader classLoader, f0 f0Var, FragmentState fragmentState) {
        this.f1264a = oVar;
        this.b = eVar;
        u uVarA = f0Var.a(fragmentState.f1169a);
        this.f1265c = uVarA;
        Bundle bundle = fragmentState.f1176j;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        uVarA.M(bundle);
        uVarA.e = fragmentState.b;
        uVarA.f1307m = fragmentState.f1170c;
        uVarA.f1309o = true;
        uVarA.f1316v = fragmentState.f1171d;
        uVarA.f1317w = fragmentState.e;
        uVarA.f1318x = fragmentState.f1172f;
        uVarA.A = fragmentState.f1173g;
        uVarA.f1306l = fragmentState.f1174h;
        uVarA.f1320z = fragmentState.f1175i;
        uVarA.f1319y = fragmentState.f1177k;
        uVarA.K = androidx.lifecycle.m.values()[fragmentState.f1178l];
        Bundle bundle2 = fragmentState.f1179m;
        if (bundle2 != null) {
            uVarA.b = bundle2;
        } else {
            uVarA.b = new Bundle();
        }
        if (k0.E(2)) {
            Objects.toString(uVarA);
        }
    }

    public final void a() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        Bundle bundle = uVar.b;
        uVar.f1314t.K();
        uVar.f1297a = 3;
        uVar.C = true;
        if (k0.E(3)) {
            uVar.toString();
        }
        View view = uVar.E;
        if (view != null) {
            Bundle bundle2 = uVar.b;
            SparseArray<Parcelable> sparseArray = uVar.f1298c;
            if (sparseArray != null) {
                view.restoreHierarchyState(sparseArray);
                uVar.f1298c = null;
            }
            if (uVar.E != null) {
                q0 q0Var = uVar.M;
                q0Var.f1278c.b(uVar.f1299d);
                uVar.f1299d = null;
            }
            uVar.C = false;
            uVar.D(bundle2);
            if (!uVar.C) {
                throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onViewStateRestored()"));
            }
            if (uVar.E != null) {
                uVar.M.e(androidx.lifecycle.l.ON_CREATE);
            }
        }
        uVar.b = null;
        k0 k0Var = uVar.f1314t;
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(4);
        this.f1264a.h(false);
    }

    public final void b() {
        View view;
        View view2;
        ArrayList arrayList = (ArrayList) this.b.f8965c;
        u uVar = this.f1265c;
        ViewGroup viewGroup = uVar.D;
        int iIndexOfChild = -1;
        if (viewGroup != null) {
            int iIndexOf = arrayList.indexOf(uVar);
            int i7 = iIndexOf - 1;
            while (true) {
                if (i7 < 0) {
                    while (true) {
                        iIndexOf++;
                        if (iIndexOf >= arrayList.size()) {
                            break;
                        }
                        u uVar2 = (u) arrayList.get(iIndexOf);
                        if (uVar2.D == viewGroup && (view = uVar2.E) != null) {
                            iIndexOfChild = viewGroup.indexOfChild(view);
                            break;
                        }
                    }
                } else {
                    u uVar3 = (u) arrayList.get(i7);
                    if (uVar3.D == viewGroup && (view2 = uVar3.E) != null) {
                        iIndexOfChild = viewGroup.indexOfChild(view2) + 1;
                        break;
                    }
                    i7--;
                }
            }
        }
        uVar.D.addView(uVar.E, iIndexOfChild);
    }

    public final void c() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        u uVar2 = uVar.f1301g;
        o0 o0Var = null;
        y2.e eVar = this.b;
        if (uVar2 != null) {
            o0 o0Var2 = (o0) ((HashMap) eVar.b).get(uVar2.e);
            if (o0Var2 == null) {
                StringBuilder sb = new StringBuilder("Fragment ");
                sb.append(uVar);
                u uVar3 = uVar.f1301g;
                sb.append(" declared target fragment ");
                sb.append(uVar3);
                sb.append(" that does not belong to this FragmentManager!");
                throw new IllegalStateException(sb.toString());
            }
            uVar.f1302h = uVar.f1301g.e;
            uVar.f1301g = null;
            o0Var = o0Var2;
        } else {
            String str = uVar.f1302h;
            if (str != null && (o0Var = (o0) ((HashMap) eVar.b).get(str)) == null) {
                StringBuilder sb2 = new StringBuilder("Fragment ");
                sb2.append(uVar);
                sb2.append(" declared target fragment ");
                f3.t(androidx.activity.g.o(sb2, uVar.f1302h, " that does not belong to this FragmentManager!"));
                return;
            }
        }
        if (o0Var != null) {
            o0Var.k();
        }
        k0 k0Var = uVar.f1312r;
        uVar.f1313s = k0Var.f1237o;
        uVar.f1315u = k0Var.f1239q;
        y2.o oVar = this.f1264a;
        oVar.o(false);
        ArrayList arrayList = uVar.Q;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            ((p) obj).a();
        }
        arrayList.clear();
        uVar.f1314t.b(uVar.f1313s, uVar.e(), uVar);
        uVar.f1297a = 0;
        uVar.C = false;
        uVar.p(uVar.f1313s.b);
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onAttach()"));
        }
        Iterator it = uVar.f1312r.f1235m.iterator();
        while (it.hasNext()) {
            ((m0) it.next()).b();
        }
        k0 k0Var2 = uVar.f1314t;
        k0Var2.f1248z = false;
        k0Var2.A = false;
        k0Var2.G.f1254h = false;
        k0Var2.s(0);
        oVar.i(false);
    }

    public final int d() {
        t0 t0Var;
        u uVar = this.f1265c;
        if (uVar.f1312r == null) {
            return uVar.f1297a;
        }
        int iMin = this.e;
        int iOrdinal = uVar.K.ordinal();
        int i7 = 0;
        if (iOrdinal == 1) {
            iMin = Math.min(iMin, 0);
        } else if (iOrdinal == 2) {
            iMin = Math.min(iMin, 1);
        } else if (iOrdinal == 3) {
            iMin = Math.min(iMin, 5);
        } else if (iOrdinal != 4) {
            iMin = Math.min(iMin, -1);
        }
        if (uVar.f1307m) {
            boolean z6 = uVar.f1308n;
            int i8 = this.e;
            if (z6) {
                iMin = Math.max(i8, 2);
                View view = uVar.E;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = i8 < 4 ? Math.min(iMin, uVar.f1297a) : Math.min(iMin, 1);
            }
        }
        if (!uVar.f1305k) {
            iMin = Math.min(iMin, 1);
        }
        ViewGroup viewGroup = uVar.D;
        if (viewGroup != null) {
            j jVarF = j.f(viewGroup, uVar.k().D());
            t0 t0VarD = jVarF.d(uVar);
            int i9 = t0VarD != null ? t0VarD.b : 0;
            ArrayList arrayList = jVarF.f1220c;
            int size = arrayList.size();
            while (true) {
                if (i7 >= size) {
                    t0Var = null;
                    break;
                }
                Object obj = arrayList.get(i7);
                i7++;
                t0Var = (t0) obj;
                if (t0Var.f1292c.equals(uVar) && !t0Var.f1294f) {
                    break;
                }
            }
            i7 = (t0Var == null || !(i9 == 0 || i9 == 1)) ? i9 : t0Var.b;
        }
        if (i7 == 2) {
            iMin = Math.min(iMin, 6);
        } else if (i7 == 3) {
            iMin = Math.max(iMin, 3);
        } else if (uVar.f1306l) {
            iMin = uVar.f1311q > 0 ? Math.min(iMin, 1) : Math.min(iMin, -1);
        }
        if (uVar.F && uVar.f1297a < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (k0.E(2)) {
            Objects.toString(uVar);
        }
        return iMin;
    }

    public final void e() {
        boolean zE = k0.E(3);
        final u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        boolean z6 = uVar.J;
        Bundle bundle = uVar.b;
        if (z6) {
            uVar.K(bundle);
            uVar.f1297a = 1;
            return;
        }
        y2.o oVar = this.f1264a;
        oVar.p(false);
        Bundle bundle2 = uVar.b;
        uVar.f1314t.K();
        uVar.f1297a = 1;
        uVar.C = false;
        uVar.L.a(new androidx.lifecycle.p() { // from class: androidx.fragment.app.Fragment$5
            @Override // androidx.lifecycle.p
            public final void a(androidx.lifecycle.r rVar, androidx.lifecycle.l lVar) {
                View view;
                if (lVar != androidx.lifecycle.l.ON_STOP || (view = uVar.E) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
        uVar.O.b(bundle2);
        uVar.q(bundle2);
        uVar.J = true;
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onCreate()"));
        }
        uVar.L.d(androidx.lifecycle.l.ON_CREATE);
        oVar.j(false);
    }

    public final void f() {
        String resourceName;
        u uVar = this.f1265c;
        if (uVar.f1307m) {
            return;
        }
        if (k0.E(3)) {
            Objects.toString(uVar);
        }
        LayoutInflater layoutInflaterV = uVar.v(uVar.b);
        ViewGroup viewGroup = uVar.D;
        if (viewGroup == null) {
            int i7 = uVar.f1317w;
            if (i7 == 0) {
                viewGroup = null;
            } else {
                if (i7 == -1) {
                    f3.q(androidx.activity.g.m("Cannot create fragment ", uVar, " for a container view with no id"));
                    return;
                }
                viewGroup = (ViewGroup) uVar.f1312r.f1238p.R(i7);
                if (viewGroup == null && !uVar.f1309o) {
                    try {
                        resourceName = uVar.l().getResourceName(uVar.f1317w);
                    } catch (Resources.NotFoundException unused) {
                        resourceName = "unknown";
                    }
                    throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(uVar.f1317w) + " (" + resourceName + ") for fragment " + uVar);
                }
            }
        }
        uVar.D = viewGroup;
        uVar.E(layoutInflaterV, viewGroup, uVar.b);
        View view = uVar.E;
        if (view != null) {
            view.setSaveFromParentEnabled(false);
            uVar.E.setTag(2131296480, uVar);
            if (viewGroup != null) {
                b();
            }
            if (uVar.f1319y) {
                uVar.E.setVisibility(8);
            }
            View view2 = uVar.E;
            WeakHashMap weakHashMap = f0.s0.f5582a;
            boolean zB = f0.e0.b(view2);
            View view3 = uVar.E;
            if (zB) {
                f0.f0.c(view3);
            } else {
                view3.addOnAttachStateChangeListener(new n0(view3));
            }
            uVar.C(uVar.E);
            uVar.f1314t.s(2);
            this.f1264a.u(uVar, uVar.E, false);
            int visibility = uVar.E.getVisibility();
            uVar.f().f1286j = uVar.E.getAlpha();
            if (uVar.D != null && visibility == 0) {
                View viewFindFocus = uVar.E.findFocus();
                if (viewFindFocus != null) {
                    uVar.f().f1287k = viewFindFocus;
                    if (k0.E(2)) {
                        viewFindFocus.toString();
                        Objects.toString(uVar);
                    }
                }
                uVar.E.setAlpha(0.0f);
            }
        }
        uVar.f1297a = 2;
    }

    public final void g() {
        u uVarI;
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        boolean zIsChangingConfigurations = true;
        int i7 = 0;
        boolean z6 = uVar.f1306l && uVar.f1311q <= 0;
        y2.e eVar = this.b;
        if (!z6) {
            l0 l0Var = (l0) eVar.f8966d;
            if (!((l0Var.f1250c.containsKey(uVar.e) && l0Var.f1252f) ? l0Var.f1253g : true)) {
                String str = uVar.f1302h;
                if (str != null && (uVarI = eVar.i(str)) != null && uVarI.A) {
                    uVar.f1301g = uVarI;
                }
                uVar.f1297a = 0;
                return;
            }
        }
        x xVar = uVar.f1313s;
        if (xVar != null) {
            zIsChangingConfigurations = ((l0) eVar.f8966d).f1253g;
        } else {
            MainActivity mainActivity = xVar.b;
            if (mainActivity != null) {
                zIsChangingConfigurations = true ^ mainActivity.isChangingConfigurations();
            }
        }
        if (z6 || zIsChangingConfigurations) {
            l0 l0Var2 = (l0) eVar.f8966d;
            HashMap map = l0Var2.e;
            HashMap map2 = l0Var2.f1251d;
            if (k0.E(3)) {
                Objects.toString(uVar);
            }
            l0 l0Var3 = (l0) map2.get(uVar.e);
            if (l0Var3 != null) {
                l0Var3.a();
                map2.remove(uVar.e);
            }
            androidx.lifecycle.l0 l0Var4 = (androidx.lifecycle.l0) map.get(uVar.e);
            if (l0Var4 != null) {
                l0Var4.a();
                map.remove(uVar.e);
            }
        }
        uVar.f1314t.k();
        uVar.L.d(androidx.lifecycle.l.ON_DESTROY);
        uVar.f1297a = 0;
        uVar.C = false;
        uVar.J = false;
        uVar.s();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onDestroy()"));
        }
        this.f1264a.l(false);
        ArrayList arrayListK = eVar.k();
        int size = arrayListK.size();
        while (i7 < size) {
            Object obj = arrayListK.get(i7);
            i7++;
            o0 o0Var = (o0) obj;
            if (o0Var != null) {
                u uVar2 = o0Var.f1265c;
                if (uVar.e.equals(uVar2.f1302h)) {
                    uVar2.f1301g = uVar;
                    uVar2.f1302h = null;
                }
            }
        }
        String str2 = uVar.f1302h;
        if (str2 != null) {
            uVar.f1301g = eVar.i(str2);
        }
        eVar.x(this);
    }

    public final void h() {
        r0.a aVar;
        View view;
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        ViewGroup viewGroup = uVar.D;
        if (viewGroup != null && (view = uVar.E) != null) {
            viewGroup.removeView(view);
        }
        uVar.f1314t.s(1);
        if (uVar.E != null) {
            q0 q0Var = uVar.M;
            q0Var.f();
            if (q0Var.b.f1365c.compareTo(androidx.lifecycle.m.f1359c) >= 0) {
                uVar.M.e(androidx.lifecycle.l.ON_DESTROY);
            }
        }
        uVar.f1297a = 1;
        uVar.C = false;
        uVar.t();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onDestroyView()"));
        }
        androidx.lifecycle.l0 l0VarC = uVar.c();
        l0VarC.getClass();
        q0.a aVar2 = q0.a.f7728c;
        aVar2.getClass();
        String canonicalName = r0.a.class.getCanonicalName();
        if (canonicalName != null) {
            String strConcat = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
            LinkedHashMap linkedHashMap = l0VarC.f1357a;
            androidx.lifecycle.j0 j0Var = (androidx.lifecycle.j0) linkedHashMap.get(strConcat);
            if (r0.a.class.isInstance(j0Var)) {
                j0Var.getClass();
            } else {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                linkedHashMap2.putAll((LinkedHashMap) aVar2.b);
                linkedHashMap2.put(androidx.lifecycle.k0.b, strConcat);
                try {
                    aVar = new r0.a();
                } catch (AbstractMethodError unused) {
                    aVar = new r0.a();
                }
                j0Var = aVar;
                androidx.lifecycle.j0 j0Var2 = (androidx.lifecycle.j0) linkedHashMap.put(strConcat, j0Var);
                if (j0Var2 != null) {
                    j0Var2.a();
                }
            }
            l.l lVar = ((r0.a) j0Var).f7875c;
            if (lVar.f6717c <= 0) {
                uVar.f1310p = false;
            } else {
                lVar.b[0].getClass();
                f3.b();
            }
        } else {
            f3.q("Local and anonymous classes can not be ViewModels");
        }
        this.f1264a.v(false);
        uVar.D = null;
        uVar.E = null;
        uVar.M = null;
        uVar.N.e(null);
        uVar.f1308n = false;
    }

    public final void i() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        uVar.f1297a = -1;
        uVar.C = false;
        uVar.u();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onDetach()"));
        }
        k0 k0Var = uVar.f1314t;
        if (!k0Var.B) {
            k0Var.k();
            uVar.f1314t = new k0();
        }
        this.f1264a.m(false);
        uVar.f1297a = -1;
        uVar.f1313s = null;
        uVar.f1315u = null;
        uVar.f1312r = null;
        if (!uVar.f1306l || uVar.f1311q > 0) {
            l0 l0Var = (l0) this.b.f8966d;
            if (!((l0Var.f1250c.containsKey(uVar.e) && l0Var.f1252f) ? l0Var.f1253g : true)) {
                return;
            }
        }
        if (k0.E(3)) {
            Objects.toString(uVar);
        }
        uVar.L = new androidx.lifecycle.t(uVar);
        uVar.O = new androidx.activity.o(uVar);
        uVar.e = UUID.randomUUID().toString();
        uVar.f1305k = false;
        uVar.f1306l = false;
        uVar.f1307m = false;
        uVar.f1308n = false;
        uVar.f1309o = false;
        uVar.f1311q = 0;
        uVar.f1312r = null;
        uVar.f1314t = new k0();
        uVar.f1313s = null;
        uVar.f1316v = 0;
        uVar.f1317w = 0;
        uVar.f1318x = null;
        uVar.f1319y = false;
        uVar.f1320z = false;
    }

    public final void j() {
        u uVar = this.f1265c;
        if (uVar.f1307m && uVar.f1308n && !uVar.f1310p) {
            if (k0.E(3)) {
                Objects.toString(uVar);
            }
            uVar.E(uVar.v(uVar.b), null, uVar.b);
            View view = uVar.E;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                uVar.E.setTag(2131296480, uVar);
                if (uVar.f1319y) {
                    uVar.E.setVisibility(8);
                }
                uVar.C(uVar.E);
                uVar.f1314t.s(2);
                this.f1264a.u(uVar, uVar.E, false);
                uVar.f1297a = 2;
            }
        }
    }

    public final void k() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        boolean z6 = this.f1266d;
        u uVar = this.f1265c;
        if (z6) {
            if (k0.E(2)) {
                Objects.toString(uVar);
                return;
            }
            return;
        }
        try {
            this.f1266d = true;
            while (true) {
                int iD = d();
                int i7 = uVar.f1297a;
                if (iD == i7) {
                    if (uVar.I) {
                        if (uVar.E != null && (viewGroup = uVar.D) != null) {
                            j jVarF = j.f(viewGroup, uVar.k().D());
                            if (uVar.f1319y) {
                                if (k0.E(2)) {
                                    Objects.toString(uVar);
                                }
                                jVarF.a(3, 1, this);
                            } else {
                                if (k0.E(2)) {
                                    Objects.toString(uVar);
                                }
                                jVarF.a(2, 1, this);
                            }
                        }
                        k0 k0Var = uVar.f1312r;
                        if (k0Var != null && uVar.f1305k && k0.F(uVar)) {
                            k0Var.f1247y = true;
                        }
                        uVar.I = false;
                    }
                    this.f1266d = false;
                    return;
                }
                if (iD <= i7) {
                    switch (i7 - 1) {
                        case HttpResponse.REQUEST_ERROR_DEFAULT /* -1 */:
                            i();
                            break;
                        case 0:
                            g();
                            break;
                        case 1:
                            h();
                            uVar.f1297a = 1;
                            break;
                        case 2:
                            uVar.f1308n = false;
                            uVar.f1297a = 2;
                            break;
                        case 3:
                            if (k0.E(3)) {
                                Objects.toString(uVar);
                            }
                            if (uVar.E != null && uVar.f1298c == null) {
                                p();
                            }
                            if (uVar.E != null && (viewGroup3 = uVar.D) != null) {
                                j jVarF2 = j.f(viewGroup3, uVar.k().D());
                                if (k0.E(2)) {
                                    Objects.toString(uVar);
                                }
                                jVarF2.a(1, 3, this);
                            }
                            uVar.f1297a = 3;
                            break;
                        case 4:
                            r();
                            break;
                        case 5:
                            uVar.f1297a = 5;
                            break;
                        case 6:
                            l();
                            break;
                    }
                } else {
                    switch (i7 + 1) {
                        case 0:
                            c();
                            break;
                        case 1:
                            e();
                            break;
                        case 2:
                            j();
                            f();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            if (uVar.E != null && (viewGroup2 = uVar.D) != null) {
                                j jVarF3 = j.f(viewGroup2, uVar.k().D());
                                int iB = androidx.activity.g.b(uVar.E.getVisibility());
                                if (k0.E(2)) {
                                    Objects.toString(uVar);
                                }
                                jVarF3.a(iB, 2, this);
                            }
                            uVar.f1297a = 4;
                            break;
                        case 5:
                            q();
                            break;
                        case 6:
                            uVar.f1297a = 6;
                            break;
                        case dd.f4082h /* 7 */:
                            n();
                            break;
                    }
                }
            }
        } catch (Throwable th) {
            this.f1266d = false;
            throw th;
        }
    }

    public final void l() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        uVar.f1314t.s(5);
        if (uVar.E != null) {
            uVar.M.e(androidx.lifecycle.l.ON_PAUSE);
        }
        uVar.L.d(androidx.lifecycle.l.ON_PAUSE);
        uVar.f1297a = 6;
        uVar.C = false;
        uVar.w();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onPause()"));
        }
        this.f1264a.n(false);
    }

    public final void m(ClassLoader classLoader) {
        u uVar = this.f1265c;
        Bundle bundle = uVar.b;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        uVar.f1298c = uVar.b.getSparseParcelableArray("android:view_state");
        uVar.f1299d = uVar.b.getBundle("android:view_registry_state");
        String string = uVar.b.getString("android:target_state");
        uVar.f1302h = string;
        if (string != null) {
            uVar.f1303i = uVar.b.getInt("android:target_req_state", 0);
        }
        boolean z6 = uVar.b.getBoolean("android:user_visible_hint", true);
        uVar.G = z6;
        if (z6) {
            return;
        }
        uVar.F = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void n() {
        /*
            r6 = this;
            r0 = 3
            boolean r0 = androidx.fragment.app.k0.E(r0)
            androidx.fragment.app.u r1 = r6.f1265c
            if (r0 == 0) goto Lc
            java.util.Objects.toString(r1)
        Lc:
            androidx.fragment.app.r r0 = r1.H
            r2 = 0
            if (r0 != 0) goto L13
            r0 = r2
            goto L15
        L13:
            android.view.View r0 = r0.f1287k
        L15:
            if (r0 == 0) goto L45
            android.view.View r3 = r1.E
            if (r0 != r3) goto L1c
            goto L26
        L1c:
            android.view.ViewParent r3 = r0.getParent()
        L20:
            if (r3 == 0) goto L45
            android.view.View r4 = r1.E
            if (r3 != r4) goto L40
        L26:
            r0.requestFocus()
            r3 = 2
            boolean r3 = androidx.fragment.app.k0.E(r3)
            if (r3 == 0) goto L45
            r0.toString()
            java.util.Objects.toString(r1)
            android.view.View r0 = r1.E
            android.view.View r0 = r0.findFocus()
            java.util.Objects.toString(r0)
            goto L45
        L40:
            android.view.ViewParent r3 = r3.getParent()
            goto L20
        L45:
            androidx.fragment.app.r r0 = r1.f()
            r0.f1287k = r2
            androidx.fragment.app.k0 r0 = r1.f1314t
            r0.K()
            androidx.fragment.app.k0 r0 = r1.f1314t
            r3 = 1
            r0.x(r3)
            r0 = 7
            r1.f1297a = r0
            r3 = 0
            r1.C = r3
            r1.y()
            boolean r4 = r1.C
            if (r4 == 0) goto L8e
            androidx.lifecycle.t r4 = r1.L
            androidx.lifecycle.l r5 = androidx.lifecycle.l.ON_RESUME
            r4.d(r5)
            android.view.View r4 = r1.E
            if (r4 == 0) goto L75
            androidx.fragment.app.q0 r4 = r1.M
            androidx.lifecycle.t r4 = r4.b
            r4.d(r5)
        L75:
            androidx.fragment.app.k0 r4 = r1.f1314t
            r4.f1248z = r3
            r4.A = r3
            androidx.fragment.app.l0 r5 = r4.G
            r5.f1254h = r3
            r4.s(r0)
            y2.o r0 = r6.f1264a
            r0.q(r3)
            r1.b = r2
            r1.f1298c = r2
            r1.f1299d = r2
            return
        L8e:
            androidx.fragment.app.u0 r0 = new androidx.fragment.app.u0
            java.lang.String r2 = "Fragment "
            java.lang.String r3 = " did not call through to super.onResume()"
            java.lang.String r1 = androidx.activity.g.m(r2, r1, r3)
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.o0.n():void");
    }

    public final Bundle o() {
        Bundle bundle = new Bundle();
        u uVar = this.f1265c;
        uVar.z(bundle);
        uVar.O.c(bundle);
        Parcelable parcelableQ = uVar.f1314t.Q();
        if (parcelableQ != null) {
            bundle.putParcelable("android:support:fragments", parcelableQ);
        }
        this.f1264a.r(false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (uVar.E != null) {
            p();
        }
        if (uVar.f1298c != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", uVar.f1298c);
        }
        if (uVar.f1299d != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", uVar.f1299d);
        }
        if (!uVar.G) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", uVar.G);
        }
        return bundle;
    }

    public final void p() {
        u uVar = this.f1265c;
        if (uVar.E == null) {
            return;
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        uVar.E.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            uVar.f1298c = sparseArray;
        }
        Bundle bundle = new Bundle();
        uVar.M.f1278c.c(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        uVar.f1299d = bundle;
    }

    public final void q() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        uVar.f1314t.K();
        uVar.f1314t.x(true);
        uVar.f1297a = 5;
        uVar.C = false;
        uVar.A();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onStart()"));
        }
        androidx.lifecycle.t tVar = uVar.L;
        androidx.lifecycle.l lVar = androidx.lifecycle.l.ON_START;
        tVar.d(lVar);
        if (uVar.E != null) {
            uVar.M.b.d(lVar);
        }
        k0 k0Var = uVar.f1314t;
        k0Var.f1248z = false;
        k0Var.A = false;
        k0Var.G.f1254h = false;
        k0Var.s(5);
        this.f1264a.s(false);
    }

    public final void r() {
        boolean zE = k0.E(3);
        u uVar = this.f1265c;
        if (zE) {
            Objects.toString(uVar);
        }
        k0 k0Var = uVar.f1314t;
        k0Var.A = true;
        k0Var.G.f1254h = true;
        k0Var.s(4);
        if (uVar.E != null) {
            uVar.M.e(androidx.lifecycle.l.ON_STOP);
        }
        uVar.L.d(androidx.lifecycle.l.ON_STOP);
        uVar.f1297a = 4;
        uVar.C = false;
        uVar.B();
        if (!uVar.C) {
            throw new u0(androidx.activity.g.m("Fragment ", uVar, " did not call through to super.onStop()"));
        }
        this.f1264a.t(false);
    }

    public o0(y2.o oVar, y2.e eVar, u uVar) {
        this.f1264a = oVar;
        this.b = eVar;
        this.f1265c = uVar;
    }

    public o0(y2.o oVar, y2.e eVar, u uVar, FragmentState fragmentState) {
        this.f1264a = oVar;
        this.b = eVar;
        this.f1265c = uVar;
        uVar.f1298c = null;
        uVar.f1299d = null;
        uVar.f1311q = 0;
        uVar.f1308n = false;
        uVar.f1305k = false;
        u uVar2 = uVar.f1301g;
        uVar.f1302h = uVar2 != null ? uVar2.e : null;
        uVar.f1301g = null;
        Bundle bundle = fragmentState.f1179m;
        if (bundle != null) {
            uVar.b = bundle;
        } else {
            uVar.b = new Bundle();
        }
    }
}
