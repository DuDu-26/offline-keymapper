package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f1204a;
    public final /* synthetic */ View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f1205c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ t0 f1206d;
    public final /* synthetic */ h e;

    public d(ViewGroup viewGroup, View view, boolean z6, t0 t0Var, h hVar) {
        this.f1204a = viewGroup;
        this.b = view;
        this.f1205c = z6;
        this.f1206d = t0Var;
        this.e = hVar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        ViewGroup viewGroup = this.f1204a;
        View view = this.b;
        viewGroup.endViewTransition(view);
        if (this.f1205c) {
            androidx.activity.g.a(view, this.f1206d.f1291a);
        }
        this.e.d();
    }
}
