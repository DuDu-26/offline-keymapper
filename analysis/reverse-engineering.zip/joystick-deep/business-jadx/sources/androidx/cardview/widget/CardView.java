package androidx.cardview.widget;

import a4.i0;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import e4.r0;
import j.a;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class CardView extends FrameLayout {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int[] f987f = {R.attr.colorBackground};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f988a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f989c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Rect f990d;
    public final i0 e;

    public CardView(Context context, AttributeSet attributeSet) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, 2130968738);
        Rect rect = new Rect();
        this.f989c = rect;
        this.f990d = new Rect();
        i0 i0Var = new i0(this);
        this.e = i0Var;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f6350a, 2130968738, 2131886367);
        if (typedArrayObtainStyledAttributes.hasValue(2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(f987f);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(2131099694) : getResources().getColor(2131099693));
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(5, 0.0f);
        this.f988a = typedArrayObtainStyledAttributes.getBoolean(7, false);
        this.b = typedArrayObtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        k.a aVar = new k.a(colorStateListValueOf, dimension);
        i0Var.b = aVar;
        setBackgroundDrawable(aVar);
        setClipToOutline(true);
        setElevation(dimension2);
        r0.c0(i0Var, dimension3);
    }

    public static /* synthetic */ void a(CardView cardView, int i7, int i8, int i9, int i10) {
        super.setPadding(i7, i8, i9, i10);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((k.a) this.e.b).f6504h;
    }

    public float getCardElevation() {
        return ((CardView) this.e.f124c).getElevation();
    }

    public int getContentPaddingBottom() {
        return this.f989c.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f989c.left;
    }

    public int getContentPaddingRight() {
        return this.f989c.right;
    }

    public int getContentPaddingTop() {
        return this.f989c.top;
    }

    public float getMaxCardElevation() {
        return ((k.a) this.e.b).e;
    }

    public boolean getPreventCornerOverlap() {
        return this.b;
    }

    public float getRadius() {
        return ((k.a) this.e.b).f6499a;
    }

    public boolean getUseCompatPadding() {
        return this.f988a;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i7, int i8) {
        super.onMeasure(i7, i8);
    }

    public void setCardBackgroundColor(int i7) {
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(i7);
        k.a aVar = (k.a) this.e.b;
        if (colorStateListValueOf == null) {
            aVar.getClass();
            colorStateListValueOf = ColorStateList.valueOf(0);
        }
        aVar.f6504h = colorStateListValueOf;
        aVar.b.setColor(colorStateListValueOf.getColorForState(aVar.getState(), aVar.f6504h.getDefaultColor()));
        aVar.invalidateSelf();
    }

    public void setCardElevation(float f2) {
        ((CardView) this.e.f124c).setElevation(f2);
    }

    public void setMaxCardElevation(float f2) {
        r0.c0(this.e, f2);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i7) {
        super.setMinimumHeight(i7);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i7) {
        super.setMinimumWidth(i7);
    }

    @Override // android.view.View
    public final void setPadding(int i7, int i8, int i9, int i10) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i7, int i8, int i9, int i10) {
    }

    public void setPreventCornerOverlap(boolean z6) {
        if (z6 != this.b) {
            this.b = z6;
            i0 i0Var = this.e;
            r0.c0(i0Var, ((k.a) i0Var.b).e);
        }
    }

    public void setRadius(float f2) {
        k.a aVar = (k.a) this.e.b;
        if (f2 == aVar.f6499a) {
            return;
        }
        aVar.f6499a = f2;
        aVar.b(null);
        aVar.invalidateSelf();
    }

    public void setUseCompatPadding(boolean z6) {
        if (this.f988a != z6) {
            this.f988a = z6;
            i0 i0Var = this.e;
            r0.c0(i0Var, ((k.a) i0Var.b).e);
        }
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        k.a aVar = (k.a) this.e.b;
        if (colorStateList == null) {
            aVar.getClass();
            colorStateList = ColorStateList.valueOf(0);
        }
        aVar.f6504h = colorStateList;
        aVar.b.setColor(colorStateList.getColorForState(aVar.getState(), aVar.f6504h.getDefaultColor()));
        aVar.invalidateSelf();
    }
}
