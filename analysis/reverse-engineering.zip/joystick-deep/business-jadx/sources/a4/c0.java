package a4;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c0 extends FrameLayout {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final /* synthetic */ int f52t = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WindowManager f53a;
    public final WindowManager.LayoutParams b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final LinearLayout f54c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinearLayout f55d;
    public final FrameLayout e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public FrameLayout f56f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public FrameLayout f57g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final TextView f58h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public TextView f59i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f60j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final LinearLayout f61k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final TextView f62l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final TextView f63m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final TextView f64n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final TextView f65o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public v1 f66p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public LinearLayout f67q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public FrameLayout f68r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public b0 f69s;

    public c0(Context context) {
        super(context);
        this.f60j = v.m.p.abcdstr(27);
        this.f66p = null;
        this.f67q = null;
        this.f53a = (WindowManager) context.getSystemService(v.m.p.abcdstr(28));
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, 2038, 768, -3);
        this.b = layoutParams;
        layoutParams.layoutInDisplayCutoutMode = 1;
        if (Build.VERSION.SDK_INT >= 30) {
            g0.f.f(layoutParams);
        }
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        setBackgroundColor(-268435456);
        setOnTouchListener(new b(1));
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-15066598);
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setBackgroundColor(-14013910);
        frameLayout.setPadding(e(20.0f), e(8.0f), e(20.0f), e(4.0f));
        TextView textView = new TextView(getContext());
        this.f58h = textView;
        textView.setText(getContext().getString(2131820714));
        this.f58h.setTextColor(-1);
        this.f58h.setTextSize(16.0f);
        this.f58h.setGravity(17);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        frameLayout.addView(this.f58h, layoutParams2);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        this.f61k = linearLayout2;
        linearLayout2.setOrientation(0);
        this.f61k.setGravity(16);
        this.f61k.setVisibility(8);
        TextView textViewB = b(getContext().getString(2131820642), false, new u(this, 4));
        this.f62l = textViewB;
        this.f61k.addView(textViewB);
        TextView textViewB2 = b(getContext().getString(2131820630), false, new u(this, 5));
        this.f63m = textViewB2;
        this.f61k.addView(textViewB2);
        TextView textViewB3 = b(getContext().getString(2131820648), false, new u(this, 6));
        this.f64n = textViewB3;
        this.f61k.addView(textViewB3);
        TextView textViewB4 = b(getContext().getString(2131820730), true, new u(this, 7));
        this.f65o = textViewB4;
        this.f61k.addView(textViewB4);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 8388627;
        layoutParams3.leftMargin = e(5.0f);
        frameLayout.addView(this.f61k, layoutParams3);
        FrameLayout frameLayout2 = new FrameLayout(getContext());
        frameLayout2.setClickable(true);
        frameLayout2.setFocusable(true);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackgroundBorderless});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        if (resourceId != 0) {
            frameLayout2.setBackgroundResource(resourceId);
        }
        ImageView imageView = new ImageView(getContext());
        imageView.setImageResource(2131230892);
        imageView.setColorFilter(-1);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(e(30.0f), e(30.0f));
        layoutParams4.gravity = 17;
        frameLayout2.addView(imageView, layoutParams4);
        frameLayout2.setOnClickListener(new v(this, 0));
        FrameLayout.LayoutParams layoutParams5 = new FrameLayout.LayoutParams(e(48.0f), e(48.0f));
        layoutParams5.gravity = 8388629;
        layoutParams5.rightMargin = e(5.0f);
        frameLayout.addView(frameLayout2, layoutParams5);
        linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout3 = new LinearLayout(getContext());
        linearLayout3.setOrientation(0);
        ScrollView scrollView = new ScrollView(getContext());
        scrollView.setBackgroundColor(-14342875);
        LinearLayout linearLayout4 = new LinearLayout(getContext());
        this.f54c = linearLayout4;
        linearLayout4.setOrientation(1);
        scrollView.addView(this.f54c);
        linearLayout3.addView(scrollView, new LinearLayout.LayoutParams(0, -1, 0.25f));
        View view = new View(getContext());
        view.setBackgroundColor(-12961222);
        linearLayout3.addView(view, new LinearLayout.LayoutParams(e(2.0f), -1));
        FrameLayout frameLayout3 = new FrameLayout(getContext());
        this.e = frameLayout3;
        frameLayout3.setBackgroundColor(-15066598);
        ScrollView scrollView2 = new ScrollView(getContext());
        scrollView2.setBackgroundColor(0);
        LinearLayout linearLayout5 = new LinearLayout(getContext());
        this.f55d = linearLayout5;
        linearLayout5.setOrientation(1);
        this.f55d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
        scrollView2.addView(this.f55d);
        this.e.addView(scrollView2, new FrameLayout.LayoutParams(-1, -1));
        linearLayout3.addView(this.e, new LinearLayout.LayoutParams(0, -1, 0.75f));
        linearLayout.addView(linearLayout3, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        f();
    }

    private int[] getDisplayCutoutSafeInsets() {
        DisplayCutout displayCutout;
        int[] iArr = {0, 0, 0, 0};
        WindowInsets rootWindowInsets = getRootWindowInsets();
        if (rootWindowInsets != null && (displayCutout = rootWindowInsets.getDisplayCutout()) != null) {
            iArr[0] = displayCutout.getSafeInsetLeft();
            iArr[1] = displayCutout.getSafeInsetTop();
            iArr[2] = displayCutout.getSafeInsetRight();
            iArr[3] = displayCutout.getSafeInsetBottom();
        }
        return iArr;
    }

    public static void j(TextView textView, boolean z6) {
        if (textView == null) {
            return;
        }
        textView.setEnabled(z6);
        textView.setAlpha(z6 ? 1.0f : 0.5f);
        textView.setTextColor(z6 ? -1 : -10066330);
    }

    public static void l(LinearLayout linearLayout, boolean z6) {
        int i7;
        if (linearLayout == null) {
            return;
        }
        View viewFindViewWithTag = linearLayout.findViewWithTag(v.m.p.abcdstr(29));
        View viewFindViewWithTag2 = linearLayout.findViewWithTag(v.m.p.abcdstr(30));
        if (viewFindViewWithTag != null) {
            if (z6) {
                i7 = 8;
                viewFindViewWithTag.setVisibility(i7);
            } else {
                u1 u1VarN = u1.n();
                String str = ((v1) linearLayout.getTag()).f257a;
                if (str != null) {
                    if (str.equals(u1VarN.f249f)) {
                        i7 = 0;
                    }
                    viewFindViewWithTag.setVisibility(i7);
                } else {
                    u1VarN.getClass();
                }
                i7 = 8;
                viewFindViewWithTag.setVisibility(i7);
            }
        }
        if (viewFindViewWithTag2 != null) {
            viewFindViewWithTag2.setVisibility(z6 ? 0 : 8);
        }
    }

    public final TextView a(String str, String str2) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(14.0f);
        textView.setPadding(e(15.0f), e(12.0f), e(15.0f), e(12.0f));
        textView.setClickable(true);
        textView.setFocusable(true);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        if (resourceId != 0) {
            textView.setBackgroundResource(resourceId);
        }
        textView.setOnClickListener(new f(this, textView, str2, 4));
        return textView;
    }

    public final TextView b(String str, boolean z6, Runnable runnable) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(z6 ? -1 : -10066330);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, 1);
        textView.setPadding(e(12.0f), e(8.0f), e(12.0f), e(8.0f));
        textView.setGravity(17);
        textView.setClickable(true);
        textView.setFocusable(true);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-12961222);
        gradientDrawable.setCornerRadius(e(4.0f));
        textView.setBackground(gradientDrawable);
        textView.setEnabled(z6);
        textView.setAlpha(z6 ? 1.0f : 0.5f);
        textView.setOnClickListener(new i(textView, runnable, 1));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, e(36.0f));
        layoutParams.setMargins(0, 0, e(8.0f), 0);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    public final void c(v1 v1Var, int i7) {
        String str = u1.n().f248d;
        if (str == null) {
            FloatingService.f6880k.a(String.format(getContext().getString(2131821375), v.m.p.abcdstr(31)));
        } else {
            f3.e.e().a(2, v1Var.f257a, str, i7, new y(this, 1));
        }
    }

    public final TextView d(int i7, String str) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(12.0f);
        textView.setTypeface(null, 1);
        textView.setGravity(17);
        textView.setPadding(e(16.0f), e(8.0f), e(16.0f), e(8.0f));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i7);
        gradientDrawable.setCornerRadius(e(6.0f));
        textView.setBackground(gradientDrawable);
        return textView;
    }

    public final int e(float f2) {
        return (int) (f2 * getContext().getResources().getDisplayMetrics().density);
    }

    public final void f() {
        this.f54c.removeAllViews();
        String string = getContext().getString(2131820612);
        String strAbcdstr = v.m.p.abcdstr(27);
        TextView textViewA = a(string, strAbcdstr);
        TextView textViewA2 = a(getContext().getString(2131820613), v.m.p.abcdstr(11));
        this.f54c.addView(textViewA);
        this.f54c.addView(textViewA2);
        i(textViewA, strAbcdstr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x014e  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0152  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x01b7  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x022b  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0236  */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r15v0, types: [android.view.View, android.view.ViewGroup, android.widget.LinearLayout, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v2, types: [android.view.ViewGroup, android.widget.FrameLayout] */
    /* JADX WARN: Type inference failed for: r2v14, types: [android.view.ViewGroup, android.widget.LinearLayout] */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v26, types: [android.view.View, android.view.ViewGroup, android.widget.FrameLayout] */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r5v4, types: [android.view.View, android.widget.TextView] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void g(java.lang.String r17) {
        /*
            Method dump skipped, instruction units count: 834
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c0.g(java.lang.String):void");
    }

    public final void h(View view) {
        if (view == null || view.getParent() != this) {
            return;
        }
        removeView(view);
        if (view == this.f57g) {
            this.f57g = null;
        }
    }

    public final void i(TextView textView, String str) {
        TextView textView2 = this.f59i;
        if (textView2 != null) {
            textView2.setBackgroundColor(0);
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
            typedArrayObtainStyledAttributes.recycle();
            if (resourceId != 0) {
                this.f59i.setBackgroundResource(resourceId);
            }
        }
        this.f59i = textView;
        textView.setBackgroundColor(-12961222);
        this.f60j = str;
        g(str);
    }

    public final void k(LinearLayout linearLayout) {
        h(this.f57g);
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setBackgroundColor(Integer.MIN_VALUE);
        frameLayout.setOnClickListener(new g(this, 3, frameLayout));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels / 3, -2);
        layoutParams.gravity = 17;
        frameLayout.addView(linearLayout, layoutParams);
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        this.f57g = frameLayout;
    }

    public final void m(boolean z6) {
        FrameLayout frameLayout = this.f68r;
        if (!z6) {
            if (frameLayout != null) {
                ViewParent parent = frameLayout.getParent();
                FrameLayout frameLayout2 = this.e;
                if (parent == frameLayout2) {
                    frameLayout2.removeView(this.f68r);
                    return;
                }
                return;
            }
            return;
        }
        if (frameLayout == null) {
            FrameLayout frameLayout3 = new FrameLayout(getContext());
            this.f68r = frameLayout3;
            frameLayout3.setBackgroundColor(Integer.MIN_VALUE);
            this.f68r.setClickable(true);
            ProgressBar progressBar = new ProgressBar(getContext());
            progressBar.setIndeterminate(true);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(e(48.0f), e(48.0f));
            layoutParams.gravity = 17;
            this.f68r.addView(progressBar, layoutParams);
        }
        if (this.f68r.getParent() == null) {
            this.e.addView(this.f68r, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    public final void n() {
        boolean z6 = this.f66p != null;
        j(this.f62l, z6);
        j(this.f63m, z6);
        j(this.f64n, z6);
        j(this.f65o, true);
    }

    public final void o() {
        int[] displayCutoutSafeInsets = getDisplayCutoutSafeInsets();
        int iE = e(10.0f);
        int rotation = this.f53a.getDefaultDisplay().getRotation();
        if (getResources().getConfiguration().orientation != 2) {
            this.f54c.setPadding(iE, iE, iE, iE);
            this.f55d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
            return;
        }
        if (rotation == 1) {
            this.f54c.setPadding(displayCutoutSafeInsets[0] + iE, iE, iE, iE);
            this.f55d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
            return;
        }
        LinearLayout linearLayout = this.f54c;
        if (rotation == 3) {
            linearLayout.setPadding(iE, iE, iE, iE);
            this.f55d.setPadding(e(15.0f), e(15.0f), e(15.0f) + displayCutoutSafeInsets[2], e(15.0f));
            return;
        }
        linearLayout.setPadding(iE, iE, iE, iE);
        this.f55d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        post(new u(this, 3));
    }

    public void setOnCloseListener(a0 a0Var) {
    }

    public void setOnConfigChangedListener(b0 b0Var) {
        this.f69s = b0Var;
    }
}
