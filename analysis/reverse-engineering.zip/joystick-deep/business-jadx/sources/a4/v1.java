package a4;

import org.json.JSONObject;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class v1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f257a;
    public String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f258c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f259d;
    public int e;

    public v1(JSONObject jSONObject) {
        this.f257a = jSONObject.getString(v.m.p.abcdstr(48));
        this.b = jSONObject.getString(v.m.p.abcdstr(49));
        this.f258c = jSONObject.optBoolean(v.m.p.abcdstr(50), false);
        this.f259d = jSONObject.optLong(v.m.p.abcdstr(51), System.currentTimeMillis());
        jSONObject.optLong(v.m.p.abcdstr(52), System.currentTimeMillis());
    }

    public v1(long j7, String str, String str2, boolean z6) {
        this.f257a = str;
        this.b = str2;
        this.f258c = z6;
        this.f259d = j7;
    }
}
