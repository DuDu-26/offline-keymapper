package a4;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.util.Size;
import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import moe.heroman.eventtest.App;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i1 extends View {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final /* synthetic */ int f125s = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f126a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f127c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f128d;
    public float e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public h1 f129f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final float f130g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final n4.a f131h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public z1 f132i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public z1 f133j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public float f134k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public float f135l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f136m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f137n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public z1 f138o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f139p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f140q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public long f141r;

    public i1(Context context) {
        super(context);
        this.f126a = new ArrayList();
        this.b = -1;
        this.f127c = false;
        n4.a aVar = new n4.a();
        this.f131h = aVar;
        this.f132i = null;
        this.f133j = null;
        this.f138o = null;
        this.f130g = 40.0f * getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        aVar.f7167w = new f1(0, this);
    }

    public static void a(ArrayList arrayList, float f2, float f7) {
        b(arrayList, a2.f45g, 0.93f * f2, 0.76f * f7, 0.06f * f7);
        b(arrayList, a2.f46h, f2 * 0.07f, 0.55f * f7, f7 * 0.05f);
    }

    public static void b(List list, a2 a2Var, float f2, float f7, float f8) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            if (((z1) it.next()).e == a2Var) {
                return;
            }
        }
        z1 z1Var = new z1(a2Var, f2, f7, f8);
        z1Var.f297d = App.f6858a.getString(a2Var.f48a);
        list.add(z1Var);
    }

    public static void c(ArrayList arrayList, float f2, float f7) {
        float f8 = 0.32f * f7;
        float f9 = f7 * 0.042f;
        b(arrayList, a2.e, 0.05f * f2, f8, f9);
        b(arrayList, a2.f44f, f2 * 0.14f, f8, f9);
    }

    public final void d() {
        boolean z6;
        y3.p pVar;
        int i7 = 0;
        boolean z7 = y2.l.i().d() && y3.t.r();
        ArrayList arrayListD = t3.b.g().d();
        int size = arrayListD.size();
        int i8 = 0;
        while (true) {
            if (i8 >= size) {
                z6 = true;
                break;
            }
            Object obj = arrayListD.get(i8);
            i8++;
            t3.a aVar = (t3.a) obj;
            if ((aVar instanceof y3.t) && (pVar = ((y3.t) aVar).f9126d) != null) {
                z6 = !(pVar instanceof v3.b);
                break;
            }
        }
        boolean z8 = (z6 || z7) ? false : true;
        while (true) {
            ArrayList arrayList = this.f126a;
            if (i7 >= arrayList.size()) {
                return;
            }
            z1 z1Var = (z1) arrayList.get(i7);
            if (z1Var.e == a2.b) {
                z1Var.f305m = z8;
                if (z8 && i7 == this.b) {
                    g(-1);
                }
            }
            i7++;
        }
    }

    public final void e() {
        boolean z6 = y2.l.i().d() && y3.t.r();
        ArrayList arrayList = this.f126a;
        if (z6) {
            Size sizeX = g.d.C().x();
            a(arrayList, sizeX.getWidth(), sizeX.getHeight());
        }
        for (int i7 = 0; i7 < arrayList.size(); i7++) {
            z1 z1Var = (z1) arrayList.get(i7);
            a2 a2Var = z1Var.e;
            if (a2Var == a2.f45g || a2Var == a2.f46h) {
                z1Var.f305m = !z6;
                if (!z6 && i7 == this.b) {
                    g(-1);
                }
            }
        }
    }

    public final void f() {
        boolean z6 = ((SharedPreferences) y2.l.i().f8978a).getBoolean("general_peek_enabled", false);
        boolean z7 = y2.l.i().d() && y3.t.r();
        ArrayList arrayList = this.f126a;
        if (z6 || z7) {
            Size sizeX = g.d.C().x();
            c(arrayList, sizeX.getWidth(), sizeX.getHeight());
        }
        boolean z8 = (z6 || z7) ? false : true;
        for (int i7 = 0; i7 < arrayList.size(); i7++) {
            z1 z1Var = (z1) arrayList.get(i7);
            a2 a2Var = z1Var.e;
            if (a2Var == a2.e || a2Var == a2.f44f) {
                z1Var.f305m = z8;
                if (z8 && i7 == this.b) {
                    g(-1);
                }
            }
        }
    }

    public final void g(int i7) {
        ArrayList arrayList = this.f126a;
        z1 z1Var = (i7 < 0 || i7 >= arrayList.size()) ? null : (z1) arrayList.get(i7);
        z1 z1Var2 = this.f132i;
        if (z1Var2 != null && z1Var2 != z1Var) {
            this.f132i = null;
            n4.a aVar = this.f131h;
            aVar.f7161q = false;
            aVar.f7162r = false;
            aVar.f7160p = false;
        }
        int i8 = this.b;
        if (i8 >= 0 && i8 < arrayList.size()) {
            ((z1) arrayList.get(this.b)).a(false);
        }
        this.b = i7;
        if (i7 >= 0 && i7 < arrayList.size()) {
            ((z1) arrayList.get(this.b)).a(true);
        }
        h1 h1Var = this.f129f;
        if (h1Var != null) {
            ((d0) h1Var).f76a.f113o.setEnabled(this.b >= 0);
        }
    }

    public List<z1> getNodes() {
        return new ArrayList(this.f126a);
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        ArrayList arrayList;
        z1 z1Var;
        int i7;
        super.onDraw(canvas);
        int i8 = 0;
        while (true) {
            arrayList = this.f126a;
            if (i8 >= arrayList.size()) {
                break;
            }
            z1 z1Var2 = (z1) arrayList.get(i8);
            if (!z1Var2.f305m) {
                z1Var2.a(i8 == this.b);
                canvas.drawCircle(z1Var2.f295a, z1Var2.b, z1Var2.f296c, z1Var2.f299g);
                canvas.drawCircle(z1Var2.f295a, z1Var2.b, z1Var2.f296c, z1Var2.f298f);
                canvas.drawText(z1Var2.f297d, z1Var2.f295a, z1Var2.b + 7.0f, z1Var2.f300h);
                if (z1Var2.f303k) {
                    float f2 = z1Var2.f295a;
                    float f7 = z1Var2.b;
                    float f8 = z1Var2.f296c;
                    float[] fArr = {f2, f7 - f8, f2, f7 + f8, f2 - f8, f7, f8 + f2, f7};
                    for (int i9 = 0; i9 < 8; i9 += 2) {
                        float f9 = fArr[i9];
                        float f10 = fArr[i9 + 1];
                        canvas.drawCircle(f9, f10, 12.0f, z1Var2.f301i);
                        canvas.drawCircle(f9, f10, 12.0f, z1Var2.f302j);
                    }
                }
            }
            i8++;
        }
        n4.a aVar = this.f131h;
        if (!aVar.f7161q || (z1Var = this.f132i) == null || z1Var.f305m || (i7 = this.b) < 0 || i7 >= arrayList.size()) {
            return;
        }
        Object obj = arrayList.get(this.b);
        z1 z1Var3 = this.f132i;
        if (obj == z1Var3) {
            z1Var3.getClass();
            float f11 = z1Var3.f295a;
            float f12 = z1Var3.f296c;
            float f13 = z1Var3.b;
            aVar.b(canvas, new RectF(f11 - f12, f13 - f12, f11 + f12, f13 + f12), getWidth(), getHeight());
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:6:0x0021, code lost:
    
        if (r3 != 3) goto L57;
     */
    /* JADX WARN: Removed duplicated region for block: B:128:0x0253  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouchEvent(android.view.MotionEvent r25) {
        /*
            Method dump skipped, instruction units count: 769
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.i1.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setNodes(List<z1> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        ArrayList arrayList = this.f126a;
        arrayList.clear();
        arrayList.addAll(list);
        this.b = -1;
        this.f132i = null;
        n4.a aVar = this.f131h;
        aVar.f7161q = false;
        aVar.f7162r = false;
        aVar.f7160p = false;
        f();
        e();
        d();
        invalidate();
    }

    public void setOnNodeChangeListener(g1 g1Var) {
    }

    public void setOnNodeSelectionListener(h1 h1Var) {
        this.f129f = h1Var;
    }
}
