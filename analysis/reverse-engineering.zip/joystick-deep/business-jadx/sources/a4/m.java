package a4;

import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class m implements z0, i3.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f169a;
    public final /* synthetic */ String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ t f170c;

    public /* synthetic */ m(t tVar, String str, String str2) {
        this.f170c = tVar;
        this.f169a = str;
        this.b = str2;
    }

    @Override // a4.z0, d4.j, e4.f0
    public void a(String str) {
        FloatingService.f6880k.a(this.f170c.getContext().getString(2131820631));
    }

    @Override // a4.z0, d4.j, e4.f0
    public void b() {
        this.f170c.post(new a3.f(this, this.f169a, this.b, 2));
    }

    @Override // i3.a
    public void i(int i7) {
        t tVar = this.f170c;
        tVar.f230q = false;
        tVar.i(tVar.f231r);
        tVar.f231r = null;
        if (tVar.isAttachedToWindow()) {
            if (i7 == 272) {
                FloatingService.f6880k.a(tVar.getContext().getString(2131820688));
                return;
            }
            if (i7 == 512 || i7 == 513) {
                FloatingService.f6880k.a(tVar.getContext().getString(2131820689));
                return;
            }
            i0.I().G(i7, 0, this.f169a, this.b);
            tVar.h(tVar.f223j);
            FloatingService.f6880k.a(tVar.getContext().getString(2131820677, a5.h.F(tVar.getContext(), i7)));
        }
    }

    @Override // i3.a
    public void j() {
        t tVar = this.f170c;
        tVar.f230q = false;
        tVar.i(tVar.f231r);
        tVar.f231r = null;
    }

    @Override // i3.a
    public void o(int i7, int i8) {
        t tVar = this.f170c;
        tVar.f230q = false;
        tVar.i(tVar.f231r);
        tVar.f231r = null;
        if (tVar.isAttachedToWindow()) {
            if (i7 == 272 || i8 == 272) {
                FloatingService.f6880k.a(tVar.getContext().getString(2131820688));
                return;
            }
            i0.I().G(i7, i8, this.f169a, this.b);
            tVar.h(tVar.f223j);
            FloatingService.f6880k.a(tVar.getContext().getString(2131820677, a5.h.F(tVar.getContext(), i7) + v.m.p.abcdstr(79) + a5.h.F(tVar.getContext(), i8)));
        }
    }
}
