package a4;

import android.provider.Settings;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class x0 implements a3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f269a;
    public final /* synthetic */ Object b;

    public /* synthetic */ x0(int i7, Object obj) {
        this.f269a = i7;
        this.b = obj;
    }

    @Override // a3.b
    public final void b(a3.a aVar) {
        switch (this.f269a) {
            case 0:
                long j7 = aVar.e;
                d1 d1Var = (d1) this.b;
                if (j7 != d1Var.f82g) {
                    d1Var.f82g = j7;
                    String str = d1Var.f81f;
                    if (str != null && d1Var.f80d != null) {
                        ((d1) this.b).j(str, null);
                        break;
                    }
                }
                break;
            case 1:
                long j8 = aVar.e;
                u1 u1Var = (u1) this.b;
                if (j8 != u1Var.f251h) {
                    u1Var.f251h = j8;
                    String str2 = u1Var.f249f;
                    if (str2 != null && u1Var.f248d != null) {
                        u1Var.h(str2, null);
                        break;
                    }
                }
                break;
            case 2:
                long j9 = aVar.e;
                d4.m mVar = (d4.m) this.b;
                if (j9 != mVar.f5270g) {
                    mVar.f5270g = j9;
                    String str3 = mVar.f5269f;
                    if (str3 != null && mVar.f5268d != null) {
                        mVar.h(str3, null);
                        break;
                    }
                }
                break;
            case 3:
                long j10 = aVar.e;
                e4.h0 h0Var = (e4.h0) this.b;
                if (j10 != h0Var.f5372h) {
                    h0Var.f5372h = j10;
                    String str4 = h0Var.f5370f;
                    if (str4 != null && h0Var.f5369d != null) {
                        h0Var.i(str4, null);
                        break;
                    }
                }
                break;
            case 4:
                moe.heroman.eventtest.auth.a.h();
                boolean zD = moe.heroman.eventtest.auth.a.d();
                FloatingService floatingService = (FloatingService) this.b;
                if (zD) {
                    if (floatingService.f6886h) {
                        FloatingService floatingService2 = (FloatingService) this.b;
                        k3.l lVar = floatingService2.f6885g;
                        if ((lVar == null || !lVar.e) && Settings.canDrawOverlays(floatingService2)) {
                            FloatingService floatingService3 = (FloatingService) this.b;
                            floatingService3.f6882c.removeCallbacks(floatingService3.f6883d);
                            FloatingService floatingService4 = (FloatingService) this.b;
                            floatingService4.f6882c.postDelayed(floatingService4.f6883d, 250L);
                        }
                    }
                    break;
                } else {
                    k3.l lVar2 = floatingService.f6885g;
                    if (lVar2 != null && lVar2.e) {
                        floatingService.f6882c.removeCallbacks(floatingService.f6883d);
                        ((FloatingService) this.b).f6885g.f();
                        break;
                    }
                }
                break;
            case 5:
                long j11 = aVar.e;
                h3.j1 j1Var = (h3.j1) this.b;
                if (j11 != j1Var.f6024i) {
                    j1Var.f6024i = j11;
                    String str5 = j1Var.f6021f;
                    if (str5 != null && j1Var.f6020d != null) {
                        j1Var.g(str5, null);
                        break;
                    }
                }
                break;
            default:
                long j12 = aVar.e;
                t3.b bVar = (t3.b) this.b;
                if (j12 != bVar.f8252f) {
                    bVar.f8252f = j12;
                    String str6 = bVar.e;
                    if (str6 != null) {
                        bVar.b(str6);
                        break;
                    }
                }
                break;
        }
    }
}
