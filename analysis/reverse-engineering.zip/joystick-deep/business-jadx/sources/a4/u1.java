package a4;

import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Size;
import com.umeng.commonsdk.statistics.UMErrorCode;
import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import moe.heroman.eventtest.App;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.auth.RecognitionToken;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class u1 {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static u1 f245k;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public RecognitionToken f250g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final x0 f252i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public k3.f f253j;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f248d = null;
    public final ArrayList e = new ArrayList();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public String f249f = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f251h = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SharedPreferences f246a = App.f6858a.getSharedPreferences(v.m.p.abcdstr(UMErrorCode.E_UM_BE_RAW_OVERSIZE), 0);
    public final ExecutorService b = Executors.newSingleThreadExecutor();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Handler f247c = new Handler(Looper.getMainLooper());

    public u1() {
        if (this.f252i != null) {
            return;
        }
        this.f252i = new x0(1, this);
        moe.heroman.eventtest.auth.a.h().a(this.f252i);
    }

    public static byte[] a(ArrayList arrayList) {
        i0 i0Var = new i0(1);
        i0Var.l();
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            z1 z1Var = (z1) obj;
            i0Var.e();
            i0Var.E(2, v.m.p.abcdstr(UMErrorCode.E_UM_BE_FILE_OVERSIZE));
            i0Var.E(78, z1Var.e.name());
            i0Var.D(3, Math.round(z1Var.f295a));
            i0Var.D(4, Math.round(z1Var.b));
            long jRound = Math.round(z1Var.f296c * 2.0f);
            i0Var.D(7, jRound);
            i0Var.D(8, jRound);
            i0Var.t();
        }
        i0Var.t();
        return ((ByteArrayOutputStream) i0Var.b).toByteArray();
    }

    public static String i(String str) {
        String strR = NativeAuth.r();
        return (strR == null || strR.isEmpty()) ? str : strR;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0041  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static a4.z1 j(a3.j r7) {
        /*
            r0 = 78
            r1 = 0
            java.lang.String r0 = r7.k(r0, r1)     // Catch: java.lang.Exception -> L28
            if (r0 != 0) goto La
            return r1
        La:
            a4.a2 r0 = a4.a2.valueOf(r0)     // Catch: java.lang.Exception -> L28 java.lang.IllegalArgumentException -> L52
            r2 = 3
            double r2 = r7.i(r2)     // Catch: java.lang.Exception -> L28
            float r2 = (float) r2     // Catch: java.lang.Exception -> L28
            r3 = 4
            double r3 = r7.i(r3)     // Catch: java.lang.Exception -> L28
            float r3 = (float) r3     // Catch: java.lang.Exception -> L28
            r4 = 51
            boolean r5 = r7.e(r4)     // Catch: java.lang.Exception -> L28
            if (r5 == 0) goto L2a
            double r4 = r7.i(r4)     // Catch: java.lang.Exception -> L28
            float r7 = (float) r4     // Catch: java.lang.Exception -> L28
            goto L42
        L28:
            r7 = move-exception
            goto L53
        L2a:
            r4 = 7
            boolean r5 = r7.e(r4)     // Catch: java.lang.Exception -> L28
            r6 = 1117782016(0x42a00000, float:80.0)
            if (r5 == 0) goto L41
            double r4 = r7.i(r4)     // Catch: java.lang.Exception -> L28
            float r7 = (float) r4     // Catch: java.lang.Exception -> L28
            r4 = 0
            int r4 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r4 <= 0) goto L41
            r4 = 1073741824(0x40000000, float:2.0)
            float r7 = r7 / r4
            goto L42
        L41:
            r7 = r6
        L42:
            a4.z1 r4 = new a4.z1     // Catch: java.lang.Exception -> L28
            r4.<init>(r0, r2, r3, r7)     // Catch: java.lang.Exception -> L28
            android.content.Context r7 = moe.heroman.eventtest.App.f6858a     // Catch: java.lang.Exception -> L28
            int r0 = r0.f48a     // Catch: java.lang.Exception -> L28
            java.lang.String r7 = r7.getString(r0)     // Catch: java.lang.Exception -> L28
            r4.f297d = r7     // Catch: java.lang.Exception -> L28
            return r4
        L52:
            return r1
        L53:
            r0 = 88
            java.lang.String r0 = v.m.p.abcdstr(r0)
            r2 = 115(0x73, float:1.61E-43)
            java.lang.String r2 = v.m.p.abcdstr(r2)
            android.util.Log.e(r0, r2, r7)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.u1.j(a3.j):a4.z1");
    }

    public static synchronized u1 n() {
        try {
            if (f245k == null) {
                f245k = new u1();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f245k;
    }

    public static v1 o(NativeAuth.ConfigSummary configSummary) {
        long jCurrentTimeMillis = configSummary.modifiedAt;
        if (jCurrentTimeMillis <= 0) {
            jCurrentTimeMillis = System.currentTimeMillis();
        }
        v1 v1Var = new v1(jCurrentTimeMillis, configSummary.guid, configSummary.name, configSummary.isOfficial);
        v1Var.e = configSummary.version;
        return v1Var;
    }

    public final boolean b(String str) {
        ArrayList arrayList = this.e;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            if (((v1) obj).b.equals(str)) {
                return true;
            }
        }
        return false;
    }

    public final void c(String str, t1 t1Var) {
        if (this.f248d == null) {
            this.f247c.post(new n(7, t1Var));
            return;
        }
        String string = UUID.randomUUID().toString();
        long jCurrentTimeMillis = System.currentTimeMillis();
        String str2 = this.f248d;
        ArrayList arrayList = new ArrayList();
        Size sizeX = g.d.C().x();
        float width = sizeX.getWidth();
        float height = sizeX.getHeight();
        float f2 = width / 2.0f;
        float f7 = height / 2.0f;
        float f8 = 0.13f * height;
        float f9 = (0.182f * height) + f7;
        float f10 = 0.042f * height;
        arrayList.add(new z1(a2.b, f2 - f8, f9, f10));
        arrayList.add(new z1(a2.f42c, f2, f9, f10));
        arrayList.add(new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10));
        i1.c(arrayList, width, height);
        i1.a(arrayList, width, height);
        this.b.execute(new q1(this, arrayList, string, str, str2, jCurrentTimeMillis, t1Var, 0));
    }

    public final v1 d(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = this.e;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            v1 v1Var = (v1) obj;
            if (v1Var.f257a.equals(str)) {
                return v1Var;
            }
        }
        return null;
    }

    public final String e(String str) {
        String strA = n.e.a(str, v.m.p.abcdstr(43));
        int i7 = 1;
        while (b(strA)) {
            i7++;
            strA = str + v.m.p.abcdstr(44) + i7;
        }
        return strA;
    }

    public final EnumMap f() {
        EnumMap enumMap = new EnumMap(a2.class);
        RecognitionToken recognitionToken = this.f250g;
        if (recognitionToken != null) {
            int iO0 = NativeAuth.o0(recognitionToken);
            for (int i7 = 0; i7 < iO0; i7++) {
                String strQ0 = NativeAuth.q0(recognitionToken, i7);
                if (strQ0 != null) {
                    try {
                        a2 a2VarValueOf = a2.valueOf(strQ0);
                        int[] iArrP0 = NativeAuth.p0(recognitionToken, strQ0);
                        if (iArrP0 != null && iArrP0.length >= 4) {
                            int i8 = iArrP0[2] / 2;
                            int i9 = iArrP0[3] / 2;
                            int i10 = iArrP0[0];
                            int i11 = iArrP0[1];
                            enumMap.put(a2VarValueOf, new Rect(i10 - i8, i11 - i9, i10 + i8, i11 + i9));
                        }
                    } catch (IllegalArgumentException unused) {
                    }
                }
            }
        }
        return enumMap;
    }

    public final Rect g(a2 a2Var) {
        int[] iArrP0;
        RecognitionToken recognitionToken = this.f250g;
        if (recognitionToken == null || (iArrP0 = NativeAuth.p0(recognitionToken, a2Var.name())) == null || iArrP0.length < 4) {
            return null;
        }
        int i7 = iArrP0[2] / 2;
        int i8 = iArrP0[3] / 2;
        int i9 = iArrP0[0];
        int i10 = iArrP0[1];
        return new Rect(i9 - i7, i10 - i8, i9 + i7, i10 + i8);
    }

    public final void h(String str, s1 s1Var) {
        Handler handler = this.f247c;
        if (str == null) {
            this.f249f = null;
            k();
            l();
            if (s1Var != null) {
                handler.post(new m1(s1Var, 0));
                return;
            }
            return;
        }
        this.f249f = str;
        l();
        String str2 = this.f248d;
        if (str2 != null) {
            this.b.execute(new n0((Object) this, str2, (Serializable) str, (Object) s1Var, 5));
        } else if (s1Var != null) {
            handler.post(new m1(s1Var, 1));
        }
    }

    public final void k() {
        RecognitionToken recognitionToken = this.f250g;
        if (recognitionToken != null) {
            NativeAuth.u0(recognitionToken);
            this.f250g = null;
        }
    }

    public final void l() {
        if (this.f248d == null) {
            return;
        }
        String str = v.m.p.abcdstr(89) + this.f248d;
        String str2 = this.f249f;
        SharedPreferences sharedPreferences = this.f246a;
        if (str2 != null) {
            sharedPreferences.edit().putString(str, this.f249f).apply();
        } else {
            sharedPreferences.edit().remove(str).apply();
        }
    }

    public final void m(v1 v1Var, List list, s1 s1Var) {
        String str = v1Var.f257a;
        this.b.execute(new l1(this, new ArrayList(list), str, v1Var.b, this.f248d, v1Var.f258c, v1Var.f259d, Math.max(1, v1Var.e) + 1, s1Var, 0));
    }

    public final void p(String str, q.n nVar) {
        Handler handler = this.f247c;
        if (str == null || str.isEmpty()) {
            handler.post(new a3.e(this, 15, nVar));
            return;
        }
        if (!str.equals(this.f248d)) {
            this.b.execute(new a3.f(this, str, nVar, 12));
        } else if (nVar != null) {
            handler.post(new m1(nVar, 0));
        }
    }
}
