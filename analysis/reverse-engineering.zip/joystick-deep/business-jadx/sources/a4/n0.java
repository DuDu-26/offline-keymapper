package a4;

import android.os.Handler;
import android.util.Log;
import android.util.Size;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.UMErrorCode;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import moe.heroman.eventtest.auth.MappingToken;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.auth.PatternToken;
import moe.heroman.eventtest.auth.RecognitionToken;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class n0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f175a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f176c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f177d;
    public final /* synthetic */ Object e;

    public /* synthetic */ n0(Object obj, Object obj2, String str, Object obj3, int i7) {
        this.f175a = i7;
        this.b = obj;
        this.e = obj2;
        this.f176c = str;
        this.f177d = obj3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        long jM0;
        h3.j1 j1Var;
        String str;
        ArrayList arrayList;
        switch (this.f175a) {
            case 0:
                d1 d1Var = (d1) this.b;
                String str2 = this.f176c;
                NativeAuth.ConfigSummary[] configSummaryArr = (NativeAuth.ConfigSummary[]) this.e;
                z0 z0Var = (z0) this.f177d;
                d1Var.f(new y1.e(2));
                d1Var.f80d = str2;
                d1Var.e.clear();
                d1Var.q();
                for (NativeAuth.ConfigSummary configSummary : configSummaryArr) {
                    d1Var.e.add(d1.v(configSummary));
                }
                if (d1Var.f80d == null) {
                    d1Var.f81f = null;
                } else {
                    d1Var.f81f = d1Var.f78a.getString(v.m.p.abcdstr(45) + d1Var.f80d, null);
                }
                String str3 = d1Var.f81f;
                if (str3 != null && d1Var.e(str3) == null) {
                    d1Var.f81f = null;
                    d1Var.r();
                }
                String str4 = d1Var.f81f;
                if (str4 != null) {
                    d1Var.j(str4, new w3.e(4, z0Var));
                    return;
                } else {
                    if (z0Var != null) {
                        z0Var.b();
                        return;
                    }
                    return;
                }
            case 1:
                final d1 d1Var2 = (d1) this.b;
                final String str5 = this.f176c;
                final String str6 = (String) this.e;
                final z0 z0Var2 = (z0) this.f177d;
                Handler handler = d1Var2.f79c;
                final PatternToken patternTokenC = NativeAuth.c(str5, str6);
                if (patternTokenC == null) {
                    handler.post(new o0(d1Var2, str5, str6, z0Var2, d1.m(v.m.p.abcdstr(77)), 1));
                    return;
                }
                final float fV = (float) NativeAuth.V(patternTokenC);
                final int i7 = 0;
                handler.post(new Runnable() { // from class: a4.p0
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i7) {
                            case 0:
                                d1 d1Var3 = (d1) d1Var2;
                                String str7 = str5;
                                String str8 = str6;
                                PatternToken patternToken = patternTokenC;
                                z0 z0Var3 = (z0) z0Var2;
                                float f2 = fV;
                                if (str7.equals(d1Var3.f80d) && str8.equals(d1Var3.f81f)) {
                                    d1Var3.q();
                                    d1Var3.f84i = patternToken;
                                    d1Var3.f85j = str7;
                                    d1Var3.f86k = str8;
                                    e1 e1VarE = d1Var3.e(str8);
                                    if (e1VarE != null) {
                                        e1VarE.f103f = f2;
                                        String strAbcdstr = v.m.p.abcdstr(41);
                                        e1VarE.f104g.put(strAbcdstr, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr)));
                                        String strAbcdstr2 = v.m.p.abcdstr(42);
                                        e1VarE.f104g.put(strAbcdstr2, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr2)));
                                    }
                                    if (z0Var3 != null) {
                                        z0Var3.b();
                                    }
                                } else {
                                    NativeAuth.t0(patternToken);
                                    if (z0Var3 != null) {
                                        z0Var3.b();
                                    }
                                }
                                break;
                            default:
                                d4.m mVar = (d4.m) d1Var2;
                                String str9 = str5;
                                String str10 = str6;
                                PatternToken patternToken2 = patternTokenC;
                                d4.j jVar = (d4.j) z0Var2;
                                float f7 = fV;
                                if (str9.equals(mVar.f5268d) && str10.equals(mVar.f5269f)) {
                                    mVar.n();
                                    mVar.f5272i = patternToken2;
                                    mVar.f5273j = str9;
                                    mVar.f5274k = str10;
                                    e4.x xVarD = mVar.d(str10);
                                    if (xVarD != null) {
                                        xVarD.f5483f = f7;
                                        String strAbcdstr3 = v.m.p.abcdstr(104);
                                        xVarD.a(strAbcdstr3, (float) NativeAuth.h0(patternToken2, strAbcdstr3));
                                        String strAbcdstr4 = v.m.p.abcdstr(105);
                                        xVarD.a(strAbcdstr4, (float) NativeAuth.h0(patternToken2, strAbcdstr4));
                                        String strAbcdstr5 = v.m.p.abcdstr(106);
                                        xVarD.a(strAbcdstr5, (float) NativeAuth.h0(patternToken2, strAbcdstr5));
                                        String strAbcdstr6 = v.m.p.abcdstr(107);
                                        xVarD.a(strAbcdstr6, (float) NativeAuth.h0(patternToken2, strAbcdstr6));
                                        String strAbcdstr7 = v.m.p.abcdstr(108);
                                        xVarD.a(strAbcdstr7, (float) NativeAuth.h0(patternToken2, strAbcdstr7));
                                        String strAbcdstr8 = v.m.p.abcdstr(109);
                                        xVarD.a(strAbcdstr8, (float) NativeAuth.h0(patternToken2, strAbcdstr8));
                                        String strAbcdstr9 = v.m.p.abcdstr(UMErrorCode.E_UM_BE_JSON_FAILED);
                                        xVarD.a(strAbcdstr9, (float) NativeAuth.h0(patternToken2, strAbcdstr9));
                                    }
                                    NativeAuth.g0(patternToken2);
                                    if (jVar != null) {
                                        jVar.b();
                                    }
                                } else {
                                    NativeAuth.t0(patternToken2);
                                    if (jVar != null) {
                                        jVar.b();
                                    }
                                }
                                break;
                        }
                    }
                });
                return;
            case 2:
                d1 d1Var3 = (d1) this.b;
                e1 e1Var = (e1) this.e;
                String str7 = this.f176c;
                m mVar = (m) this.f177d;
                d1Var3.e.remove(e1Var);
                if (str7.equals(d1Var3.f81f)) {
                    d1Var3.f81f = null;
                    d1Var3.q();
                    d1Var3.r();
                }
                mVar.b();
                return;
            case 3:
                u1 u1Var = (u1) this.b;
                v1 v1Var = (v1) this.e;
                String str8 = this.f176c;
                y yVar = (y) this.f177d;
                u1Var.e.remove(v1Var);
                if (str8.equals(u1Var.f249f)) {
                    u1Var.f249f = null;
                    u1Var.k();
                    u1Var.l();
                }
                yVar.b();
                return;
            case 4:
                u1 u1Var2 = (u1) this.b;
                String str9 = this.f176c;
                NativeAuth.ConfigSummary[] configSummaryArr2 = (NativeAuth.ConfigSummary[]) this.e;
                s1 s1Var = (s1) this.f177d;
                u1Var2.f248d = str9;
                ArrayList arrayList2 = u1Var2.e;
                arrayList2.clear();
                u1Var2.k();
                for (NativeAuth.ConfigSummary configSummary2 : configSummaryArr2) {
                    arrayList2.add(u1.o(configSummary2));
                }
                if (u1Var2.f248d == null) {
                    u1Var2.f249f = null;
                } else {
                    u1Var2.f249f = u1Var2.f246a.getString(v.m.p.abcdstr(89) + u1Var2.f248d, null);
                }
                String str10 = u1Var2.f249f;
                if (str10 != null && u1Var2.d(str10) == null) {
                    u1Var2.f249f = null;
                    u1Var2.l();
                }
                String str11 = u1Var2.f249f;
                if (str11 != null) {
                    u1Var2.h(str11, s1Var);
                    return;
                } else {
                    if (s1Var != null) {
                        s1Var.b();
                        return;
                    }
                    return;
                }
            case 5:
                u1 u1Var3 = (u1) this.b;
                String str12 = this.f176c;
                String str13 = (String) this.e;
                s1 s1Var2 = (s1) this.f177d;
                Handler handler2 = u1Var3.f247c;
                moe.heroman.eventtest.auth.a.h();
                RecognitionToken recognitionTokenD = NativeAuth.d(str12, str13);
                if (recognitionTokenD == null) {
                    handler2.post(new o0(u1Var3, str12, str13, s1Var2, u1.i(v.m.p.abcdstr(85)), 4));
                    return;
                } else {
                    handler2.post(new o0(u1Var3, str12, str13, recognitionTokenD, s1Var2, 5));
                    return;
                }
            case 6:
                u1 u1Var4 = (u1) this.b;
                String str14 = this.f176c;
                String str15 = (String) this.e;
                w3.e eVar = (w3.e) this.f177d;
                Handler handler3 = u1Var4.f247c;
                jM0 = NativeAuth.m0(str14, str15);
                if (jM0 == 0) {
                    handler3.post(new p1(eVar, u1.i(v.m.p.abcdstr(77)), 0));
                    return;
                }
                try {
                    byte[] bArrK = NativeAuth.k(15, jM0);
                    NativeAuth.h(jM0);
                    ArrayList arrayList3 = new ArrayList();
                    if (bArrK != null && bArrK.length != 0) {
                        try {
                            Iterator it = a5.h.W(bArrK).iterator();
                            while (it.hasNext()) {
                                z1 z1VarJ = u1.j((a3.j) it.next());
                                if (z1VarJ != null) {
                                    arrayList3.add(z1VarJ);
                                }
                            }
                        } catch (Exception e) {
                            Log.e(v.m.p.abcdstr(88), v.m.p.abcdstr(84), e);
                        }
                        break;
                    }
                    handler3.post(new a3.e(eVar, 16, arrayList3));
                    return;
                } finally {
                }
            case dd.f4082h /* 7 */:
                d4.m mVar2 = (d4.m) this.b;
                String str16 = this.f176c;
                NativeAuth.ConfigSummary[] configSummaryArr3 = (NativeAuth.ConfigSummary[]) this.e;
                d4.j jVar = (d4.j) this.f177d;
                mVar2.e(new y1.e(14));
                mVar2.f5268d = str16;
                ArrayList arrayList4 = mVar2.e;
                arrayList4.clear();
                mVar2.n();
                for (NativeAuth.ConfigSummary configSummary3 : configSummaryArr3) {
                    arrayList4.add(d4.m.u(configSummary3));
                }
                if (mVar2.f5268d == null) {
                    mVar2.f5269f = null;
                } else {
                    mVar2.f5269f = mVar2.f5266a.getString(v.m.p.abcdstr(87) + mVar2.f5268d, null);
                }
                String str17 = mVar2.f5269f;
                if (str17 != null && mVar2.d(str17) == null) {
                    mVar2.f5269f = null;
                    mVar2.o();
                }
                String str18 = mVar2.f5269f;
                if (str18 != null) {
                    mVar2.h(str18, null);
                }
                if (jVar != null) {
                    jVar.b();
                    return;
                }
                return;
            case 8:
                d4.m mVar3 = (d4.m) this.b;
                e4.x xVar = (e4.x) this.e;
                String str19 = this.f176c;
                e4.h hVar = (e4.h) this.f177d;
                mVar3.e.remove(xVar);
                if (str19.equals(mVar3.f5269f)) {
                    mVar3.f5269f = null;
                    mVar3.n();
                    mVar3.o();
                }
                hVar.b();
                return;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                final d4.m mVar4 = (d4.m) this.b;
                final String str20 = this.f176c;
                final String str21 = (String) this.e;
                final d4.j jVar2 = (d4.j) this.f177d;
                Handler handler4 = mVar4.f5267c;
                final PatternToken patternTokenC2 = NativeAuth.c(str20, str21);
                if (patternTokenC2 == null) {
                    handler4.post(new o0(mVar4, str20, str21, jVar2, d4.m.k(v.m.p.abcdstr(77)), 7));
                    return;
                }
                final float fV2 = (float) NativeAuth.V(patternTokenC2);
                final int i8 = 1;
                handler4.post(new Runnable() { // from class: a4.p0
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i8) {
                            case 0:
                                d1 d1Var32 = (d1) mVar4;
                                String str72 = str20;
                                String str82 = str21;
                                PatternToken patternToken = patternTokenC2;
                                z0 z0Var3 = (z0) jVar2;
                                float f2 = fV2;
                                if (str72.equals(d1Var32.f80d) && str82.equals(d1Var32.f81f)) {
                                    d1Var32.q();
                                    d1Var32.f84i = patternToken;
                                    d1Var32.f85j = str72;
                                    d1Var32.f86k = str82;
                                    e1 e1VarE = d1Var32.e(str82);
                                    if (e1VarE != null) {
                                        e1VarE.f103f = f2;
                                        String strAbcdstr = v.m.p.abcdstr(41);
                                        e1VarE.f104g.put(strAbcdstr, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr)));
                                        String strAbcdstr2 = v.m.p.abcdstr(42);
                                        e1VarE.f104g.put(strAbcdstr2, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr2)));
                                    }
                                    if (z0Var3 != null) {
                                        z0Var3.b();
                                    }
                                } else {
                                    NativeAuth.t0(patternToken);
                                    if (z0Var3 != null) {
                                        z0Var3.b();
                                    }
                                }
                                break;
                            default:
                                d4.m mVar5 = (d4.m) mVar4;
                                String str92 = str20;
                                String str102 = str21;
                                PatternToken patternToken2 = patternTokenC2;
                                d4.j jVar3 = (d4.j) jVar2;
                                float f7 = fV2;
                                if (str92.equals(mVar5.f5268d) && str102.equals(mVar5.f5269f)) {
                                    mVar5.n();
                                    mVar5.f5272i = patternToken2;
                                    mVar5.f5273j = str92;
                                    mVar5.f5274k = str102;
                                    e4.x xVarD = mVar5.d(str102);
                                    if (xVarD != null) {
                                        xVarD.f5483f = f7;
                                        String strAbcdstr3 = v.m.p.abcdstr(104);
                                        xVarD.a(strAbcdstr3, (float) NativeAuth.h0(patternToken2, strAbcdstr3));
                                        String strAbcdstr4 = v.m.p.abcdstr(105);
                                        xVarD.a(strAbcdstr4, (float) NativeAuth.h0(patternToken2, strAbcdstr4));
                                        String strAbcdstr5 = v.m.p.abcdstr(106);
                                        xVarD.a(strAbcdstr5, (float) NativeAuth.h0(patternToken2, strAbcdstr5));
                                        String strAbcdstr6 = v.m.p.abcdstr(107);
                                        xVarD.a(strAbcdstr6, (float) NativeAuth.h0(patternToken2, strAbcdstr6));
                                        String strAbcdstr7 = v.m.p.abcdstr(108);
                                        xVarD.a(strAbcdstr7, (float) NativeAuth.h0(patternToken2, strAbcdstr7));
                                        String strAbcdstr8 = v.m.p.abcdstr(109);
                                        xVarD.a(strAbcdstr8, (float) NativeAuth.h0(patternToken2, strAbcdstr8));
                                        String strAbcdstr9 = v.m.p.abcdstr(UMErrorCode.E_UM_BE_JSON_FAILED);
                                        xVarD.a(strAbcdstr9, (float) NativeAuth.h0(patternToken2, strAbcdstr9));
                                    }
                                    NativeAuth.g0(patternToken2);
                                    if (jVar3 != null) {
                                        jVar3.b();
                                    }
                                } else {
                                    NativeAuth.t0(patternToken2);
                                    if (jVar3 != null) {
                                        jVar3.b();
                                    }
                                }
                                break;
                        }
                    }
                });
                return;
            case 10:
                e4.h0 h0Var = (e4.h0) this.b;
                e4.i0 i0Var = (e4.i0) this.e;
                String str22 = this.f176c;
                d0.g gVar = (d0.g) this.f177d;
                h0Var.e.remove(i0Var);
                if (str22.equals(h0Var.f5370f)) {
                    h0Var.f5370f = null;
                    h0Var.l();
                    h0Var.m();
                }
                gVar.b();
                return;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                e4.h0 h0Var2 = (e4.h0) this.b;
                String str23 = this.f176c;
                NativeAuth.ConfigSummary[] configSummaryArr4 = (NativeAuth.ConfigSummary[]) this.e;
                e4.f0 f0Var = (e4.f0) this.f177d;
                h0Var2.f5369d = str23;
                ArrayList arrayList5 = h0Var2.e;
                arrayList5.clear();
                h0Var2.l();
                for (NativeAuth.ConfigSummary configSummary4 : configSummaryArr4) {
                    arrayList5.add(e4.h0.p(configSummary4));
                }
                if (h0Var2.f5369d == null) {
                    h0Var2.f5370f = null;
                } else {
                    h0Var2.f5370f = h0Var2.f5367a.getString(v.m.p.abcdstr(86) + h0Var2.f5369d, null);
                }
                String str24 = h0Var2.f5370f;
                if (str24 != null && h0Var2.e(str24) == null) {
                    h0Var2.f5370f = null;
                    h0Var2.m();
                }
                String str25 = h0Var2.f5370f;
                if (str25 != null) {
                    h0Var2.i(str25, f0Var);
                    return;
                } else {
                    if (f0Var != null) {
                        f0Var.b();
                        return;
                    }
                    return;
                }
            case 12:
                e4.h0 h0Var3 = (e4.h0) this.b;
                String str26 = this.f176c;
                String str27 = (String) this.e;
                e4.f0 f0Var2 = (e4.f0) this.f177d;
                Handler handler5 = h0Var3.f5368c;
                moe.heroman.eventtest.auth.a.h();
                RecognitionToken recognitionTokenD2 = NativeAuth.d(str26, str27);
                if (recognitionTokenD2 == null) {
                    handler5.post(new o0(h0Var3, str26, str27, f0Var2, e4.h0.j(v.m.p.abcdstr(85)), 10));
                    return;
                } else {
                    handler5.post(new o0(h0Var3, str26, str27, recognitionTokenD2, f0Var2, 11));
                    return;
                }
            case 13:
                e4.h0 h0Var4 = (e4.h0) this.b;
                String str28 = this.f176c;
                String str29 = (String) this.e;
                w3.e eVar2 = (w3.e) this.f177d;
                Handler handler6 = h0Var4.f5368c;
                jM0 = NativeAuth.m0(str28, str29);
                if (jM0 == 0) {
                    handler6.post(new p1(eVar2, e4.h0.j(v.m.p.abcdstr(77)), 1));
                    return;
                }
                try {
                    byte[] bArrK2 = NativeAuth.k(15, jM0);
                    NativeAuth.h(jM0);
                    ArrayList arrayList6 = new ArrayList();
                    if (bArrK2 != null && bArrK2.length != 0) {
                        try {
                            Iterator it2 = a5.h.W(bArrK2).iterator();
                            while (it2.hasNext()) {
                                e4.m0 m0VarK = e4.h0.k((a3.j) it2.next());
                                if (m0VarK != null) {
                                    arrayList6.add(m0VarK);
                                }
                            }
                        } catch (Exception e3) {
                            Log.e(v.m.p.abcdstr(83), v.m.p.abcdstr(84), e3);
                        }
                        break;
                    }
                    handler6.post(new a3.e(eVar2, 29, arrayList6));
                    return;
                } finally {
                }
            case 14:
                h3.j1 j1Var2 = (h3.j1) this.b;
                h3.c cVar = (h3.c) this.e;
                String str30 = this.f176c;
                h3.o oVar = (h3.o) this.f177d;
                j1Var2.e.remove(cVar);
                if (str30.equals(j1Var2.f6021f)) {
                    j1Var2.f6021f = null;
                    j1Var2.k();
                    String str31 = j1Var2.f6021f;
                    if (str31 != null) {
                        j1Var2.e(str31);
                    }
                    j1Var2.f6021f = null;
                    j1Var2.k();
                    j1Var2.j();
                    w3.b.r().o(null);
                }
                oVar.b();
                return;
            case 15:
                h3.j1 j1Var3 = (h3.j1) this.b;
                String str32 = this.f176c;
                NativeAuth.ConfigSummary[] configSummaryArr5 = (NativeAuth.ConfigSummary[]) this.e;
                h3.h1 h1Var = (h3.h1) this.f177d;
                j1Var3.f6020d = str32;
                ArrayList arrayList7 = j1Var3.e;
                arrayList7.clear();
                for (NativeAuth.ConfigSummary configSummary5 : configSummaryArr5) {
                    arrayList7.add(h3.j1.n(configSummary5));
                }
                if (j1Var3.f6020d == null) {
                    j1Var3.f6021f = null;
                } else {
                    j1Var3.f6021f = j1Var3.f6018a.getString(v.m.p.abcdstr(82) + j1Var3.f6020d, null);
                }
                String str33 = j1Var3.f6021f;
                if (str33 != null && j1Var3.e(str33) == null) {
                    j1Var3.f6021f = null;
                    j1Var3.k();
                }
                arrayList7.size();
                String str34 = j1Var3.f6021f;
                if (str34 != null) {
                    j1Var3.g(str34, null);
                } else {
                    j1Var3.j();
                    w3.b.r().o(null);
                }
                h1Var.b();
                return;
            default:
                h3.j1 j1Var4 = (h3.j1) this.b;
                String str35 = this.f176c;
                String str36 = (String) this.e;
                y0 y0Var = (y0) this.f177d;
                Handler handler7 = j1Var4.f6019c;
                moe.heroman.eventtest.auth.a.h();
                MappingToken mappingTokenB = NativeAuth.b(str35, str36);
                if (mappingTokenB == null) {
                    handler7.post(new e4.e0(y0Var, 10, h3.j1.i(v.m.p.abcdstr(77))));
                    return;
                }
                Size sizeT = g.d.C().t();
                int width = sizeT.getWidth();
                int height = sizeT.getHeight();
                HashSet hashSet = null;
                if (str35 != null && str36 != null) {
                    long jA = NativeAuth.A(str35, str36);
                    String strAbcdstr = v.m.p.abcdstr(13);
                    if (jA == 0) {
                        Log.e(strAbcdstr, v.m.p.abcdstr(80).concat(str36));
                        arrayList = null;
                        j1Var = j1Var4;
                        str = str36;
                    } else {
                        try {
                            byte[] bArrW0 = NativeAuth.w0(jA);
                            int iG = NativeAuth.g(9, jA);
                            int iG2 = NativeAuth.g(10, jA);
                            NativeAuth.h(jA);
                            ArrayList arrayList8 = new ArrayList();
                            if (bArrW0 == null || bArrW0.length == 0) {
                                j1Var = j1Var4;
                                str = str36;
                            } else {
                                try {
                                    int[] iArrM = NativeAuth.m(bArrW0, str35);
                                    List listW = a5.h.W(bArrW0);
                                    if (iArrM != null) {
                                        hashSet = new HashSet();
                                        j1Var = j1Var4;
                                        try {
                                            str = str36;
                                            int i9 = 0;
                                            for (int length = iArrM.length; i9 < length; length = length) {
                                                try {
                                                    hashSet.add(Integer.valueOf(iArrM[i9]));
                                                    i9++;
                                                } catch (Exception e7) {
                                                    e = e7;
                                                    Log.e(strAbcdstr, v.m.p.abcdstr(81), e);
                                                    e4.r0.Z(arrayList8, iG, iG2, width, height);
                                                    arrayList8.size();
                                                    arrayList = arrayList8;
                                                    handler7.post(new w0(j1Var, str35, str, mappingTokenB, y0Var, arrayList));
                                                    return;
                                                }
                                            }
                                        } catch (Exception e8) {
                                            e = e8;
                                            str = str36;
                                            Log.e(strAbcdstr, v.m.p.abcdstr(81), e);
                                        }
                                    } else {
                                        j1Var = j1Var4;
                                        str = str36;
                                    }
                                    for (int i10 = 0; i10 < listW.size(); i10++) {
                                        if (hashSet == null || hashSet.contains(Integer.valueOf(i10))) {
                                            a3.j jVar3 = (a3.j) listW.get(i10);
                                            h3.j1.d(jVar3, str35);
                                            j3.k kVarB = j3.p.d().b(jVar3);
                                            if (kVarB != null) {
                                                arrayList8.add(kVarB);
                                            }
                                        }
                                    }
                                } catch (Exception e9) {
                                    e = e9;
                                    j1Var = j1Var4;
                                }
                            }
                            e4.r0.Z(arrayList8, iG, iG2, width, height);
                            arrayList8.size();
                            arrayList = arrayList8;
                        } catch (Throwable th) {
                            NativeAuth.h(jA);
                            throw th;
                        }
                    }
                    break;
                } else {
                    j1Var = j1Var4;
                    str = str36;
                    arrayList = null;
                }
                handler7.post(new w0(j1Var, str35, str, mappingTokenB, y0Var, arrayList));
                return;
        }
    }

    public /* synthetic */ n0(Object obj, String str, Serializable serializable, Object obj2, int i7) {
        this.f175a = i7;
        this.b = obj;
        this.f176c = str;
        this.e = serializable;
        this.f177d = obj2;
    }
}
