package a4;

import android.view.View;
import android.view.ViewParent;
import android.widget.FrameLayout;
import moe.heroman.eventtest.App;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class v implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f254a;
    public final /* synthetic */ c0 b;

    public /* synthetic */ v(c0 c0Var, int i7) {
        this.f254a = i7;
        this.b = c0Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f254a) {
            case 0:
                c0 c0Var = this.b;
                FrameLayout frameLayout = c0Var.f56f;
                if (frameLayout != null) {
                    ViewParent parent = frameLayout.getParent();
                    FrameLayout frameLayout2 = c0Var.e;
                    if (parent == frameLayout2) {
                        frameLayout2.removeView(c0Var.f56f);
                        c0Var.f56f = null;
                    }
                }
                k3.t.e().q(k3.o.f6605t);
                break;
            case 1:
                c0 c0Var2 = this.b;
                c0Var2.m(true);
                u1 u1VarN = u1.n();
                y yVar = new y(c0Var2, 2);
                u1VarN.getClass();
                u1VarN.c(u1VarN.e(App.f6858a.getString(2131820713)), yVar);
                break;
            case 2:
                c0 c0Var3 = this.b;
                c0Var3.h(c0Var3.f57g);
                break;
            case 3:
                c0 c0Var4 = this.b;
                c0Var4.h(c0Var4.f57g);
                break;
            case 4:
                c0 c0Var5 = this.b;
                c0Var5.h(c0Var5.f57g);
                break;
            case 5:
                c0 c0Var6 = this.b;
                c0Var6.h(c0Var6.f57g);
                break;
            default:
                c0 c0Var7 = this.b;
                c0Var7.h(c0Var7.f57g);
                break;
        }
    }
}
