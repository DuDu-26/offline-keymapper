package a4;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class t extends FrameLayout {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final /* synthetic */ int f215x = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WindowManager f216a;
    public final WindowManager.LayoutParams b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final LinearLayout f217c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinearLayout f218d;
    public final FrameLayout e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public FrameLayout f219f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public FrameLayout f220g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final TextView f221h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public TextView f222i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f223j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final LinearLayout f224k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final TextView f225l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final TextView f226m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final TextView f227n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final TextView f228o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final TextView f229p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f230q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public FrameLayout f231r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public e1 f232s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public LinearLayout f233t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public FrameLayout f234u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public r f235v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public s f236w;

    public t(Context context) {
        super(context);
        this.f223j = v.m.p.abcdstr(27);
        this.f230q = false;
        this.f232s = null;
        this.f233t = null;
        this.f216a = (WindowManager) context.getSystemService(v.m.p.abcdstr(28));
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, 2038, 768, -3);
        this.b = layoutParams;
        layoutParams.layoutInDisplayCutoutMode = 1;
        if (Build.VERSION.SDK_INT >= 30) {
            g0.f.f(layoutParams);
        }
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        setBackgroundColor(-268435456);
        setOnTouchListener(new b(0));
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-15066598);
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setBackgroundColor(-14013910);
        frameLayout.setPadding(e(20.0f), e(8.0f), e(20.0f), e(4.0f));
        TextView textView = new TextView(getContext());
        this.f221h = textView;
        textView.setText(getContext().getString(2131820707));
        this.f221h.setTextColor(-1);
        this.f221h.setTextSize(16.0f);
        this.f221h.setGravity(17);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        frameLayout.addView(this.f221h, layoutParams2);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        this.f224k = linearLayout2;
        linearLayout2.setOrientation(0);
        this.f224k.setGravity(16);
        this.f224k.setVisibility(8);
        TextView textViewB = b(getContext().getString(2131820642), false, new c(this, 0));
        this.f225l = textViewB;
        this.f224k.addView(textViewB);
        TextView textViewB2 = b(getContext().getString(2131820630), false, new c(this, 1));
        this.f226m = textViewB2;
        this.f224k.addView(textViewB2);
        TextView textViewB3 = b(getContext().getString(2131820648), false, new c(this, 2));
        this.f227n = textViewB3;
        this.f224k.addView(textViewB3);
        TextView textViewB4 = b(getContext().getString(2131820684), false, new c(this, 3));
        this.f229p = textViewB4;
        this.f224k.addView(textViewB4);
        TextView textViewB5 = b(getContext().getString(2131820730), true, new c(this, 4));
        this.f228o = textViewB5;
        this.f224k.addView(textViewB5);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 8388627;
        layoutParams3.leftMargin = e(5.0f);
        frameLayout.addView(this.f224k, layoutParams3);
        FrameLayout frameLayout2 = new FrameLayout(getContext());
        frameLayout2.setClickable(true);
        frameLayout2.setFocusable(true);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackgroundBorderless});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        if (resourceId != 0) {
            frameLayout2.setBackgroundResource(resourceId);
        }
        ImageView imageView = new ImageView(getContext());
        imageView.setImageResource(2131230892);
        imageView.setColorFilter(-1);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(e(30.0f), e(30.0f));
        layoutParams4.gravity = 17;
        frameLayout2.addView(imageView, layoutParams4);
        frameLayout2.setOnClickListener(new d(this, 0));
        FrameLayout.LayoutParams layoutParams5 = new FrameLayout.LayoutParams(e(48.0f), e(48.0f));
        layoutParams5.gravity = 8388629;
        layoutParams5.rightMargin = e(5.0f);
        frameLayout.addView(frameLayout2, layoutParams5);
        linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout3 = new LinearLayout(getContext());
        linearLayout3.setOrientation(0);
        ScrollView scrollView = new ScrollView(getContext());
        scrollView.setBackgroundColor(-14342875);
        LinearLayout linearLayout4 = new LinearLayout(getContext());
        this.f217c = linearLayout4;
        linearLayout4.setOrientation(1);
        scrollView.addView(this.f217c);
        linearLayout3.addView(scrollView, new LinearLayout.LayoutParams(0, -1, 0.25f));
        View view = new View(getContext());
        view.setBackgroundColor(-12961222);
        linearLayout3.addView(view, new LinearLayout.LayoutParams(e(2.0f), -1));
        FrameLayout frameLayout3 = new FrameLayout(getContext());
        this.e = frameLayout3;
        frameLayout3.setBackgroundColor(-15066598);
        ScrollView scrollView2 = new ScrollView(getContext());
        scrollView2.setBackgroundColor(0);
        LinearLayout linearLayout5 = new LinearLayout(getContext());
        this.f218d = linearLayout5;
        linearLayout5.setOrientation(1);
        this.f218d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
        scrollView2.addView(this.f218d);
        this.e.addView(scrollView2, new FrameLayout.LayoutParams(-1, -1));
        linearLayout3.addView(this.e, new LinearLayout.LayoutParams(0, -1, 0.75f));
        linearLayout.addView(linearLayout3, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        g();
    }

    private int[] getDisplayCutoutSafeInsets() {
        DisplayCutout displayCutout;
        int[] iArr = {0, 0, 0, 0};
        WindowInsets rootWindowInsets = getRootWindowInsets();
        if (rootWindowInsets != null && (displayCutout = rootWindowInsets.getDisplayCutout()) != null) {
            iArr[0] = displayCutout.getSafeInsetLeft();
            iArr[1] = displayCutout.getSafeInsetTop();
            iArr[2] = displayCutout.getSafeInsetRight();
            iArr[3] = displayCutout.getSafeInsetBottom();
        }
        return iArr;
    }

    public static void k(TextView textView, boolean z6) {
        if (textView == null) {
            return;
        }
        textView.setEnabled(z6);
        textView.setAlpha(z6 ? 1.0f : 0.5f);
        textView.setTextColor(z6 ? -1 : -10066330);
    }

    public static void m(LinearLayout linearLayout, boolean z6) {
        int i7;
        if (linearLayout == null) {
            return;
        }
        View viewFindViewWithTag = linearLayout.findViewWithTag(v.m.p.abcdstr(29));
        View viewFindViewWithTag2 = linearLayout.findViewWithTag(v.m.p.abcdstr(30));
        if (viewFindViewWithTag != null) {
            if (z6) {
                i7 = 8;
                viewFindViewWithTag.setVisibility(i7);
            } else {
                d1 d1VarU = d1.u();
                String str = ((e1) linearLayout.getTag()).f100a;
                if (str != null) {
                    if (str.equals(d1VarU.f81f)) {
                        i7 = 0;
                    }
                    viewFindViewWithTag.setVisibility(i7);
                } else {
                    d1VarU.getClass();
                }
                i7 = 8;
                viewFindViewWithTag.setVisibility(i7);
            }
        }
        if (viewFindViewWithTag2 != null) {
            viewFindViewWithTag2.setVisibility(z6 ? 0 : 8);
        }
    }

    public final TextView a(String str, String str2) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(14.0f);
        textView.setPadding(e(15.0f), e(12.0f), e(15.0f), e(12.0f));
        textView.setClickable(true);
        textView.setFocusable(true);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        if (resourceId != 0) {
            textView.setBackgroundResource(resourceId);
        }
        textView.setOnClickListener(new f(this, textView, str2, 1));
        return textView;
    }

    public final TextView b(String str, boolean z6, Runnable runnable) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(z6 ? -1 : -10066330);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, 1);
        textView.setPadding(e(12.0f), e(8.0f), e(12.0f), e(8.0f));
        textView.setGravity(17);
        textView.setClickable(true);
        textView.setFocusable(true);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-12961222);
        gradientDrawable.setCornerRadius(e(4.0f));
        textView.setBackground(gradientDrawable);
        textView.setEnabled(z6);
        textView.setAlpha(z6 ? 1.0f : 0.5f);
        textView.setOnClickListener(new i(textView, runnable, 0));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, e(36.0f));
        layoutParams.setMargins(0, 0, e(8.0f), 0);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    public final void c(e1 e1Var, int i7) {
        String str = d1.u().f80d;
        if (str == null) {
            FloatingService.f6880k.a(String.format(getContext().getString(2131821375), v.m.p.abcdstr(31)));
        } else {
            f3.e.e().a(3, e1Var.f100a, str, i7, new o(this, 0));
        }
    }

    public final TextView d(int i7, String str) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(12.0f);
        textView.setTypeface(null, 1);
        textView.setGravity(17);
        textView.setPadding(e(16.0f), e(8.0f), e(16.0f), e(8.0f));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i7);
        gradientDrawable.setCornerRadius(e(6.0f));
        textView.setBackground(gradientDrawable);
        return textView;
    }

    public final int e(float f2) {
        return (int) (f2 * getContext().getResources().getDisplayMetrics().density);
    }

    public final String f(int[] iArr) {
        StringBuilder sb = new StringBuilder();
        for (int i7 = 0; i7 < iArr.length; i7++) {
            if (i7 > 0) {
                sb.append(v.m.p.abcdstr(79));
            }
            sb.append(a5.h.F(getContext(), iArr[i7]));
        }
        return sb.toString();
    }

    public final void g() {
        this.f217c.removeAllViews();
        String string = getContext().getString(2131820612);
        String strAbcdstr = v.m.p.abcdstr(27);
        TextView textViewA = a(string, strAbcdstr);
        TextView textViewA2 = a(getContext().getString(2131820613), v.m.p.abcdstr(11));
        this.f217c.addView(textViewA);
        this.f217c.addView(textViewA2);
        j(textViewA, strAbcdstr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x014e  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0152  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x019f  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0227  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0229  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x029c  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x02a7  */
    /* JADX WARN: Type inference failed for: r12v1, types: [android.view.View, android.view.ViewGroup, android.widget.LinearLayout] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r1v2, types: [android.view.ViewGroup, android.widget.FrameLayout] */
    /* JADX WARN: Type inference failed for: r2v13, types: [android.view.ViewGroup, android.widget.LinearLayout] */
    /* JADX WARN: Type inference failed for: r2v21 */
    /* JADX WARN: Type inference failed for: r2v25, types: [android.view.View, android.view.ViewGroup, android.widget.FrameLayout] */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r7v5, types: [android.view.View, android.widget.TextView] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void h(java.lang.String r17) {
        /*
            Method dump skipped, instruction units count: 948
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.t.h(java.lang.String):void");
    }

    public final void i(View view) {
        if (view == null || view.getParent() != this) {
            return;
        }
        removeView(view);
        if (view == this.f220g) {
            this.f220g = null;
        }
    }

    public final void j(TextView textView, String str) {
        TextView textView2 = this.f222i;
        if (textView2 != null) {
            textView2.setBackgroundColor(0);
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
            typedArrayObtainStyledAttributes.recycle();
            if (resourceId != 0) {
                this.f222i.setBackgroundResource(resourceId);
            }
        }
        this.f222i = textView;
        textView.setBackgroundColor(-12961222);
        this.f223j = str;
        h(str);
    }

    public final void l(LinearLayout linearLayout) {
        if (this.f230q) {
            i3.e.b();
        }
        i(this.f220g);
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setBackgroundColor(Integer.MIN_VALUE);
        frameLayout.setOnClickListener(new g(this, 1, frameLayout));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels / 3, -2);
        layoutParams.gravity = 17;
        frameLayout.addView(linearLayout, layoutParams);
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        this.f220g = frameLayout;
    }

    public final void n(boolean z6) {
        FrameLayout frameLayout = this.f234u;
        if (!z6) {
            if (frameLayout != null) {
                ViewParent parent = frameLayout.getParent();
                FrameLayout frameLayout2 = this.e;
                if (parent == frameLayout2) {
                    frameLayout2.removeView(this.f234u);
                    return;
                }
                return;
            }
            return;
        }
        if (frameLayout == null) {
            FrameLayout frameLayout3 = new FrameLayout(getContext());
            this.f234u = frameLayout3;
            frameLayout3.setBackgroundColor(Integer.MIN_VALUE);
            this.f234u.setClickable(true);
            ProgressBar progressBar = new ProgressBar(getContext());
            progressBar.setIndeterminate(true);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(e(48.0f), e(48.0f));
            layoutParams.gravity = 17;
            this.f234u.addView(progressBar, layoutParams);
        }
        if (this.f234u.getParent() == null) {
            this.e.addView(this.f234u, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    public final void o() {
        boolean z6 = this.f232s != null;
        k(this.f225l, z6);
        k(this.f226m, z6);
        k(this.f227n, z6);
        k(this.f229p, z6);
        k(this.f228o, true);
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        post(new c(this, 8));
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f230q) {
            i3.e.b();
            this.f230q = false;
        }
    }

    public final void p() {
        int[] displayCutoutSafeInsets = getDisplayCutoutSafeInsets();
        int iE = e(10.0f);
        int rotation = this.f216a.getDefaultDisplay().getRotation();
        if (getResources().getConfiguration().orientation != 2) {
            this.f217c.setPadding(iE, iE, iE, iE);
            this.f218d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
            return;
        }
        if (rotation == 1) {
            this.f217c.setPadding(displayCutoutSafeInsets[0] + iE, iE, iE, iE);
            this.f218d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
            return;
        }
        LinearLayout linearLayout = this.f217c;
        if (rotation == 3) {
            linearLayout.setPadding(iE, iE, iE, iE);
            this.f218d.setPadding(e(15.0f), e(15.0f), e(15.0f) + displayCutoutSafeInsets[2], e(15.0f));
            return;
        }
        linearLayout.setPadding(iE, iE, iE, iE);
        this.f218d.setPadding(e(15.0f), e(15.0f), e(15.0f), e(15.0f));
    }

    public void setOnCloseListener(q qVar) {
    }

    public void setOnConfigChangedListener(r rVar) {
        this.f235v = rVar;
    }

    public void setOnConfigRenamedListener(s sVar) {
        this.f236w = sVar;
    }
}
