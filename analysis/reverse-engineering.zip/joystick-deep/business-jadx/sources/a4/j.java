package a4;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.widget.EditText;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class j implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f142a;
    public final /* synthetic */ Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ EditText f143c;

    public /* synthetic */ j(Context context, EditText editText, int i7) {
        this.f142a = i7;
        this.b = context;
        this.f143c = editText;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ClipData primaryClip;
        CharSequence text;
        ClipData primaryClip2;
        CharSequence text2;
        ClipData primaryClip3;
        CharSequence text3;
        ClipData primaryClip4;
        CharSequence text4;
        ClipData primaryClip5;
        CharSequence text5;
        switch (this.f142a) {
            case 0:
                ClipboardManager clipboardManager = (ClipboardManager) this.b.getSystemService(v.m.p.abcdstr(25));
                if (clipboardManager != null && clipboardManager.hasPrimaryClip() && (primaryClip = clipboardManager.getPrimaryClip()) != null && primaryClip.getItemCount() > 0 && (text = primaryClip.getItemAt(0).getText()) != null) {
                    EditText editText = this.f143c;
                    editText.setText(text);
                    editText.setSelection(text.length());
                    break;
                }
                break;
            case 1:
                ClipboardManager clipboardManager2 = (ClipboardManager) this.b.getSystemService(v.m.p.abcdstr(25));
                if (clipboardManager2 != null && clipboardManager2.hasPrimaryClip() && (primaryClip2 = clipboardManager2.getPrimaryClip()) != null && primaryClip2.getItemCount() > 0 && (text2 = primaryClip2.getItemAt(0).getText()) != null) {
                    EditText editText2 = this.f143c;
                    editText2.setText(text2);
                    editText2.setSelection(text2.length());
                    break;
                }
                break;
            case 2:
                ClipboardManager clipboardManager3 = (ClipboardManager) this.b.getSystemService(v.m.p.abcdstr(25));
                if (clipboardManager3 != null && clipboardManager3.hasPrimaryClip() && (primaryClip3 = clipboardManager3.getPrimaryClip()) != null && primaryClip3.getItemCount() > 0 && (text3 = primaryClip3.getItemAt(0).getText()) != null) {
                    EditText editText3 = this.f143c;
                    editText3.setText(text3);
                    editText3.setSelection(text3.length());
                    break;
                }
                break;
            case 3:
                ClipboardManager clipboardManager4 = (ClipboardManager) this.b.getSystemService(v.m.p.abcdstr(25));
                if (clipboardManager4 != null && clipboardManager4.hasPrimaryClip() && (primaryClip4 = clipboardManager4.getPrimaryClip()) != null && primaryClip4.getItemCount() > 0 && (text4 = primaryClip4.getItemAt(0).getText()) != null) {
                    EditText editText4 = this.f143c;
                    editText4.setText(text4);
                    editText4.setSelection(text4.length());
                    break;
                }
                break;
            default:
                ClipboardManager clipboardManager5 = (ClipboardManager) this.b.getSystemService(v.m.p.abcdstr(25));
                if (clipboardManager5 != null && clipboardManager5.hasPrimaryClip() && (primaryClip5 = clipboardManager5.getPrimaryClip()) != null && primaryClip5.getItemCount() > 0 && (text5 = primaryClip5.getItemAt(0).getText()) != null) {
                    EditText editText5 = this.f143c;
                    editText5.setText(text5);
                    editText5.setSelection(text5.length());
                    break;
                }
                break;
        }
    }
}
