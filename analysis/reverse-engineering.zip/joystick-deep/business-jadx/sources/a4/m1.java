package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class m1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f173a;
    public final /* synthetic */ s1 b;

    public /* synthetic */ m1(s1 s1Var, int i7) {
        this.f173a = i7;
        this.b = s1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f173a) {
            case 0:
                this.b.b();
                break;
            default:
                this.b.a(v.m.p.abcdstr(31));
                break;
        }
    }
}
