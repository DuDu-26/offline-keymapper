package a4;

import java.util.HashMap;
import org.json.JSONObject;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public class e1 {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final String[] f99h = {v.m.p.abcdstr(41), v.m.p.abcdstr(42)};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f100a;
    public String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f101c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f102d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f103f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public HashMap f104g;

    public e1(JSONObject jSONObject) {
        this.f103f = 1.0f;
        this.f100a = jSONObject.getString(v.m.p.abcdstr(48));
        this.b = jSONObject.getString(v.m.p.abcdstr(49));
        this.f101c = jSONObject.optBoolean(v.m.p.abcdstr(50), false);
        this.f102d = jSONObject.optLong(v.m.p.abcdstr(51), System.currentTimeMillis());
        jSONObject.optLong(v.m.p.abcdstr(52), System.currentTimeMillis());
        this.f103f = (float) jSONObject.optDouble(v.m.p.abcdstr(53), 1.0d);
        this.f104g = new HashMap();
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject(v.m.p.abcdstr(54));
        for (int i7 = 0; i7 < 2; i7++) {
            String str = f99h[i7];
            this.f104g.put(str, Float.valueOf(jSONObjectOptJSONObject != null ? (float) jSONObjectOptJSONObject.optDouble(str, 1.0d) : 1.0f));
        }
    }
}
