package a4;

import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class x implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f268a;
    public final /* synthetic */ y b;

    public /* synthetic */ x(y yVar, int i7) {
        this.f268a = i7;
        this.b = yVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f268a) {
            case 0:
                c0 c0Var = this.b.b;
                c0Var.g(c0Var.f60j);
                p3.x.t().p();
                FloatingService.f6880k.a(c0Var.getContext().getString(2131820634));
                break;
            case 1:
                this.b.a(v.m.p.abcdstr(31));
                break;
            default:
                this.b.a(v.m.p.abcdstr(71));
                break;
        }
    }
}
