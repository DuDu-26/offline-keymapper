package a4;

import android.os.Handler;
import java.util.ArrayList;
import java.util.List;
import moe.heroman.eventtest.auth.MappingToken;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class w0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f262a;
    public final /* synthetic */ String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f263c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f264d;
    public final /* synthetic */ Object e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f265f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f266g;

    public /* synthetic */ w0(h3.j1 j1Var, String str, String str2, MappingToken mappingToken, y0 y0Var, ArrayList arrayList) {
        this.f262a = 4;
        this.e = j1Var;
        this.b = str;
        this.f263c = str2;
        this.f264d = mappingToken;
        this.f265f = y0Var;
        this.f266g = arrayList;
    }

    @Override // java.lang.Runnable
    public final void run() {
        long jU;
        long jM0;
        switch (this.f262a) {
            case 0:
                d1 d1Var = (d1) this.e;
                String str = this.b;
                String str2 = this.f263c;
                final o oVar = (o) this.f265f;
                String str3 = (String) this.f264d;
                e1 e1Var = (e1) this.f266g;
                Handler handler = d1Var.f79c;
                jU = NativeAuth.U(str, str2);
                if (jU == 0) {
                    final String strM = d1.m(v.m.p.abcdstr(77));
                    final int i7 = 0;
                    handler.post(new Runnable() { // from class: a4.v0
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i7) {
                                case 0:
                                    oVar.a(strM);
                                    break;
                                default:
                                    oVar.a(strM);
                                    break;
                            }
                        }
                    });
                    return;
                }
                try {
                    int i8 = NativeAuth.i(jU, str3, System.currentTimeMillis());
                    if (i8 != 0) {
                        break;
                    }
                    if (i8 == 0) {
                        handler.post(new a3.f(e1Var, str3, oVar, 5));
                        return;
                    }
                    final String strM2 = d1.m(v.m.p.abcdstr(116));
                    final int i9 = 1;
                    handler.post(new Runnable() { // from class: a4.v0
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i9) {
                                case 0:
                                    oVar.a(strM2);
                                    break;
                                default:
                                    oVar.a(strM2);
                                    break;
                            }
                        }
                    });
                    return;
                } finally {
                }
            case 1:
                u1 u1Var = (u1) this.e;
                String str4 = this.b;
                String str5 = this.f263c;
                final y yVar = (y) this.f265f;
                String str6 = (String) this.f264d;
                v1 v1Var = (v1) this.f266g;
                Handler handler2 = u1Var.f247c;
                jM0 = NativeAuth.m0(str4, str5);
                if (jM0 == 0) {
                    final String strI = u1.i(v.m.p.abcdstr(77));
                    final int i10 = 0;
                    handler2.post(new Runnable() { // from class: a4.k1
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i10) {
                                case 0:
                                    yVar.a(strI);
                                    break;
                                default:
                                    yVar.a(strI);
                                    break;
                            }
                        }
                    });
                    return;
                }
                try {
                    int i11 = NativeAuth.i(jM0, str6, System.currentTimeMillis());
                    if (i11 != 0) {
                        break;
                    }
                    if (i11 == 0) {
                        handler2.post(new a3.f(v1Var, str6, yVar, 9));
                        return;
                    }
                    final String strI2 = u1.i(v.m.p.abcdstr(116));
                    final int i12 = 1;
                    handler2.post(new Runnable() { // from class: a4.k1
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i12) {
                                case 0:
                                    yVar.a(strI2);
                                    break;
                                default:
                                    yVar.a(strI2);
                                    break;
                            }
                        }
                    });
                    return;
                } finally {
                }
            case 2:
                d4.m mVar = (d4.m) this.e;
                String str7 = this.b;
                String str8 = this.f263c;
                final e4.h hVar = (e4.h) this.f265f;
                String str9 = (String) this.f264d;
                e4.x xVar = (e4.x) this.f266g;
                Handler handler3 = mVar.f5267c;
                jU = NativeAuth.U(str7, str8);
                if (jU == 0) {
                    final String strK = d4.m.k(v.m.p.abcdstr(77));
                    final int i13 = 0;
                    handler3.post(new Runnable() { // from class: d4.g
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i13) {
                                case 0:
                                    hVar.a(strK);
                                    break;
                                default:
                                    hVar.a(strK);
                                    break;
                            }
                        }
                    });
                    return;
                }
                try {
                    int i14 = NativeAuth.i(jU, str9, System.currentTimeMillis());
                    if (i14 != 0) {
                        break;
                    }
                    if (i14 == 0) {
                        handler3.post(new a3.f(xVar, str9, hVar, 15));
                        return;
                    }
                    final String strK2 = d4.m.k(v.m.p.abcdstr(116));
                    final int i15 = 1;
                    handler3.post(new Runnable() { // from class: d4.g
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i15) {
                                case 0:
                                    hVar.a(strK2);
                                    break;
                                default:
                                    hVar.a(strK2);
                                    break;
                            }
                        }
                    });
                    return;
                } finally {
                }
            case 3:
                e4.h0 h0Var = (e4.h0) this.e;
                String str10 = this.b;
                String str11 = this.f263c;
                final e4.p pVar = (e4.p) this.f265f;
                String str12 = (String) this.f264d;
                e4.i0 i0Var = (e4.i0) this.f266g;
                Handler handler4 = h0Var.f5368c;
                jM0 = NativeAuth.m0(str10, str11);
                if (jM0 == 0) {
                    final String strJ = e4.h0.j(v.m.p.abcdstr(77));
                    final int i16 = 0;
                    handler4.post(new Runnable() { // from class: e4.b0
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i16) {
                                case 0:
                                    pVar.a(strJ);
                                    break;
                                default:
                                    pVar.a(strJ);
                                    break;
                            }
                        }
                    });
                    return;
                }
                try {
                    int i17 = NativeAuth.i(jM0, str12, System.currentTimeMillis());
                    if (i17 != 0) {
                        break;
                    }
                    if (i17 == 0) {
                        handler4.post(new a3.f(i0Var, str12, pVar, 20));
                        return;
                    }
                    final String strJ2 = e4.h0.j(v.m.p.abcdstr(116));
                    final int i18 = 1;
                    handler4.post(new Runnable() { // from class: e4.b0
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i18) {
                                case 0:
                                    pVar.a(strJ2);
                                    break;
                                default:
                                    pVar.a(strJ2);
                                    break;
                            }
                        }
                    });
                    return;
                } finally {
                }
            case 4:
                h3.j1 j1Var = (h3.j1) this.e;
                String str13 = this.b;
                String str14 = this.f263c;
                MappingToken mappingToken = (MappingToken) this.f264d;
                y0 y0Var = (y0) this.f265f;
                List list = (List) this.f266g;
                if (!str13.equals(j1Var.f6020d) || !str14.equals(j1Var.f6021f)) {
                    NativeAuth.s0(mappingToken);
                    y0Var.a(v.m.p.abcdstr(117));
                    return;
                } else {
                    j1Var.j();
                    j1Var.f6022g = mappingToken;
                    j1Var.f6023h = list;
                    y0Var.b();
                    return;
                }
            default:
                h3.j1 j1Var2 = (h3.j1) this.e;
                String str15 = this.b;
                String str16 = this.f263c;
                final h3.o oVar2 = (h3.o) this.f265f;
                String str17 = (String) this.f264d;
                h3.c cVar = (h3.c) this.f266g;
                Handler handler5 = j1Var2.f6019c;
                long jA = NativeAuth.A(str15, str16);
                if (jA == 0) {
                    final String strI3 = h3.j1.i(v.m.p.abcdstr(77));
                    final int i19 = 0;
                    handler5.post(new Runnable() { // from class: h3.f1
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i19) {
                                case 0:
                                    oVar2.a(strI3);
                                    break;
                                default:
                                    oVar2.a(strI3);
                                    break;
                            }
                        }
                    });
                    return;
                }
                try {
                    int i20 = NativeAuth.i(jA, str17, System.currentTimeMillis());
                    if (i20 != 0) {
                        NativeAuth.h(jA);
                        break;
                    }
                    if (i20 == 0) {
                        handler5.post(new a3.f(cVar, str17, oVar2, 29));
                        return;
                    }
                    final String strI4 = h3.j1.i(v.m.p.abcdstr(116));
                    final int i21 = 1;
                    handler5.post(new Runnable() { // from class: h3.f1
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i21) {
                                case 0:
                                    oVar2.a(strI4);
                                    break;
                                default:
                                    oVar2.a(strI4);
                                    break;
                            }
                        }
                    });
                    return;
                } catch (Throwable th) {
                    NativeAuth.h(jA);
                    throw th;
                }
        }
    }

    public /* synthetic */ w0(Object obj, String str, String str2, Object obj2, String str3, Object obj3, int i7) {
        this.f262a = i7;
        this.e = obj;
        this.b = str;
        this.f263c = str2;
        this.f265f = obj2;
        this.f264d = str3;
        this.f266g = obj3;
    }
}
