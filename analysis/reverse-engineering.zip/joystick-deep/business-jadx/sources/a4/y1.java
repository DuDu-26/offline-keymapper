package a4;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class y1 extends View {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final int f274r = Color.argb(230, 40, 40, 40);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final int f275s = Color.argb(255, 70, 70, 75);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final int f276t = Color.argb(255, 76, 175, 80);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final int f277u = Color.argb(255, 50, 50, 55);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final int f278v = Color.argb(100, 255, 255, 255);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f279a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f280c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f281d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f282f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final RectF f283g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final RectF f284h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final RectF f285i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final RectF f286j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Paint f287k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Paint f288l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final GradientDrawable f289m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public x1 f290n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Handler f291o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final w1 f292p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f293q;

    public y1(Context context) {
        super(context);
        this.f279a = false;
        this.f293q = 0;
        this.f283g = new RectF();
        this.f284h = new RectF();
        this.f285i = new RectF();
        this.f286j = new RectF();
        this.f291o = new Handler(Looper.getMainLooper());
        this.f292p = new w1(0, this);
        this.b = a(100);
        this.f280c = a(70);
        this.f281d = a(28);
        a(4);
        this.e = a(12);
        this.f282f = a(6);
        GradientDrawable gradientDrawable = new GradientDrawable();
        this.f289m = gradientDrawable;
        gradientDrawable.setColor(f274r);
        GradientDrawable gradientDrawable2 = this.f289m;
        float f2 = this.e;
        gradientDrawable2.setCornerRadii(new float[]{0.0f, 0.0f, 0.0f, 0.0f, f2, f2, f2, f2});
        Paint paint = new Paint(1);
        this.f287k = paint;
        Paint.Style style = Paint.Style.FILL;
        paint.setStyle(style);
        Paint paint2 = new Paint(1);
        this.f288l = paint2;
        paint2.setStyle(style);
        setElevation(25.0f);
    }

    public final int a(int i7) {
        return Math.round(TypedValue.applyDimension(1, i7, getResources().getDisplayMetrics()));
    }

    public final void b(Canvas canvas, RectF rectF, int i7) {
        this.f287k.setColor(!this.f279a ? f277u : this.f293q == i7 ? f276t : f275s);
        canvas.drawRoundRect(rectF, a(6), a(6), this.f287k);
        this.f288l.setColor(this.f279a ? -1 : f278v);
        float fCenterX = rectF.centerX();
        float fCenterY = rectF.centerY();
        float f2 = this.f281d * 0.35f;
        Path path = new Path();
        int iD = n.e.d(i7);
        if (iD == 0) {
            path.moveTo(fCenterX, fCenterY - f2);
            float f7 = (0.5f * f2) + fCenterY;
            path.lineTo(fCenterX - f2, f7);
            path.lineTo(fCenterX + f2, f7);
            path.close();
        } else if (iD == 1) {
            path.moveTo(fCenterX, fCenterY + f2);
            float f8 = fCenterY - (0.5f * f2);
            path.lineTo(fCenterX - f2, f8);
            path.lineTo(fCenterX + f2, f8);
            path.close();
        } else if (iD == 2) {
            path.moveTo(fCenterX - f2, fCenterY);
            float f9 = (0.5f * f2) + fCenterX;
            path.lineTo(f9, fCenterY - f2);
            path.lineTo(f9, fCenterY + f2);
            path.close();
        } else if (iD == 3) {
            path.moveTo(fCenterX + f2, fCenterY);
            float f10 = fCenterX - (0.5f * f2);
            path.lineTo(f10, fCenterY - f2);
            path.lineTo(f10, fCenterY + f2);
            path.close();
        }
        canvas.drawPath(path, this.f288l);
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f289m.draw(canvas);
        b(canvas, this.f283g, 1);
        b(canvas, this.f284h, 2);
        b(canvas, this.f285i, 3);
        b(canvas, this.f286j, 4);
    }

    @Override // android.view.View
    public final void onMeasure(int i7, int i8) {
        setMeasuredDimension(this.b, this.f280c);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i7, int i8, int i9, int i10) {
        super.onSizeChanged(i7, i8, i9, i10);
        this.f289m.setBounds(0, 0, i7, i8);
        int width = getWidth() / 2;
        int height = getHeight() / 2;
        float f2 = width;
        int i11 = this.f281d;
        float f7 = i11 / 2.0f;
        int i12 = this.f282f;
        this.f283g.set(f2 - f7, i12, f7 + f2, i12 + i11);
        int height2 = getHeight() - this.f282f;
        this.f284h.set(f2 - (this.f281d / 2.0f), height2 - r1, (this.f281d / 2.0f) + f2, getHeight() - this.f282f);
        int i13 = this.f282f;
        float f8 = height;
        float f9 = this.f281d / 2.0f;
        this.f285i.set(i13, f8 - f9, i13 + r8, f9 + f8);
        int width2 = getWidth() - this.f282f;
        this.f286j.set(width2 - r7, f8 - (this.f281d / 2.0f), getWidth() - this.f282f, (this.f281d / 2.0f) + f8);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        float x4 = motionEvent.getX();
        float y6 = motionEvent.getY();
        int action = motionEvent.getAction();
        w1 w1Var = this.f292p;
        Handler handler = this.f291o;
        if (action != 0) {
            if (action == 1 || action == 3) {
                handler.removeCallbacks(w1Var);
                this.f293q = 0;
                invalidate();
                return true;
            }
        } else if (this.f279a) {
            if (this.f283g.contains(x4, y6)) {
                this.f293q = 1;
            } else if (this.f284h.contains(x4, y6)) {
                this.f293q = 2;
            } else if (this.f285i.contains(x4, y6)) {
                this.f293q = 3;
            } else if (this.f286j.contains(x4, y6)) {
                this.f293q = 4;
            }
            int i7 = this.f293q;
            if (i7 != 0) {
                x1 x1Var = this.f290n;
                if (x1Var != null) {
                    ((d0) x1Var).a(i7);
                }
                handler.postDelayed(w1Var, 400L);
            }
            invalidate();
            return true;
        }
        return true;
    }

    @Override // android.view.View
    public void setEnabled(boolean z6) {
        if (this.f279a != z6) {
            this.f279a = z6;
            invalidate();
        }
    }

    public void setOnDirectionListener(x1 x1Var) {
        this.f290n = x1Var;
    }
}
