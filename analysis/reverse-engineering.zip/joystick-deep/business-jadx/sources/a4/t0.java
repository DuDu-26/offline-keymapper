package a4;

import android.os.Handler;
import java.util.HashMap;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class t0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f237a = 1;
    public final /* synthetic */ d1 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f238c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f239d;
    public final /* synthetic */ long e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ HashMap f240f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ String f241g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ a1 f242h;

    public /* synthetic */ t0(d1 d1Var, String str, String str2, long j7, HashMap map, String str3, a1 a1Var) {
        this.b = d1Var;
        this.f238c = str;
        this.f239d = str2;
        this.e = j7;
        this.f240f = map;
        this.f241g = str3;
        this.f242h = a1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f237a) {
            case 0:
                d1 d1Var = this.b;
                String str = this.f238c;
                HashMap map = this.f240f;
                a1 a1Var = this.f242h;
                String str2 = this.f239d;
                String str3 = this.f241g;
                long j7 = this.e;
                Handler handler = d1Var.f79c;
                byte[] bArrO = d1.o(new z3.a());
                byte[] bArrI = bArrO != null ? d1.i(1.0f) : null;
                byte[] bArrT = bArrI != null ? d1.t(map) : null;
                if (bArrO == null || bArrI == null || bArrT == null) {
                    handler.post(new s0(a1Var, 1));
                } else if (NativeAuth.K(bArrO, bArrI, bArrT, str2, str3, str, false, j7, j7, j7, 1) == 0) {
                    handler.post(new t0(d1Var, str2, str3, j7, map, str, a1Var));
                } else {
                    handler.post(new a3.e(a1Var, 11, d1.m(v.m.p.abcdstr(78))));
                }
                break;
            default:
                d1 d1Var2 = this.b;
                String str4 = this.f238c;
                String str5 = this.f239d;
                long j8 = this.e;
                HashMap map2 = this.f240f;
                String str6 = this.f241g;
                a1 a1Var2 = this.f242h;
                e1 e1Var = new e1();
                e1Var.f100a = str4;
                e1Var.b = str5;
                e1Var.f101c = false;
                e1Var.f102d = j8;
                e1Var.f103f = 1.0f;
                e1Var.f104g = new HashMap(map2);
                e1Var.e = 1;
                if (str6.equals(d1Var2.f80d)) {
                    d1Var2.e.add(e1Var);
                }
                a1Var2.h(e1Var);
                break;
        }
    }

    public /* synthetic */ t0(d1 d1Var, String str, HashMap map, a1 a1Var, String str2, String str3, long j7) {
        this.b = d1Var;
        this.f238c = str;
        this.f240f = map;
        this.f242h = a1Var;
        this.f239d = str2;
        this.f241g = str3;
        this.e = j7;
    }
}
