package a4;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Process;
import android.util.Log;
import com.umeng.analytics.pro.dd;
import moe.heroman.eventtest.common.IpcRing;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class o1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f185a;

    public /* synthetic */ o1(int i7) {
        this.f185a = i7;
    }

    private final void a() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        IpcRing ipcRing;
        switch (this.f185a) {
            case 0:
                Log.e(v.m.p.abcdstr(103), v.m.p.abcdstr(102));
                return;
            case 1:
                Log.e(v.m.p.abcdstr(101), v.m.p.abcdstr(102));
                return;
            case 2:
                return;
            case 3:
                p3.x.t().q();
                return;
            case 4:
                q3.i.i();
                return;
            case 5:
                String strAbcdstr = v.m.p.abcdstr(100);
                Process.setThreadPriority(-20);
                y2.b bVarB = y2.b.b();
                synchronized (bVarB) {
                    ipcRing = bVarB.f8952d;
                }
                if (ipcRing == null) {
                    Log.e(strAbcdstr, "incoming ring is null");
                    return;
                }
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        int iS = ipcRing.s();
                        int iU = ipcRing.u();
                        if (iU < 0) {
                            Log.e(strAbcdstr, "Negative payload length " + iU + ", protocol desync");
                            return;
                        }
                        byte[] bArr = new byte[iU];
                        ipcRing.t(iU, bArr);
                        if (iS == 2) {
                            c3.a[] aVarArrU = a5.h.u(bArr);
                            if (aVarArrU.length > 0) {
                                y2.j jVarA = y2.j.a();
                                ((Handler) jVarA.f8974a).post(new p3.s(jVarA, 4, aVarArrU));
                            }
                        } else {
                            c3.a[] aVarArrT = iS == 1 ? a5.h.t(bArr) : iS == 3 ? a5.h.v(bArr) : iS == 4 ? a5.h.w(bArr) : null;
                            if (aVarArrT != null && aVarArrT.length > 0) {
                                y2.o oVarE = y2.o.E();
                                ((Handler) oVarE.b).post(new p3.s(oVarE, 3, aVarArrT));
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                }
                return;
            case 6:
                try {
                    y2.l.a(false);
                    return;
                } catch (Exception e3) {
                    Log.e("PointerLocation", v.m.p.abcdstr(99), e3);
                    return;
                }
            case dd.f4082h /* 7 */:
                try {
                    y2.o.B();
                    return;
                } catch (Exception e7) {
                    Log.e("ResolutionTool", v.m.p.abcdstr(98), e7);
                    return;
                }
            default:
                y2.l lVarI = y2.l.i();
                try {
                    SharedPreferences sharedPreferences = (SharedPreferences) lVarI.f8978a;
                    SharedPreferences sharedPreferences2 = (SharedPreferences) lVarI.f8978a;
                    int i7 = sharedPreferences.getInt(v.m.p.abcdstr("96"), 0);
                    int i8 = sharedPreferences2.getInt("resolution_height", 0);
                    int i9 = sharedPreferences2.getInt("resolution_density", 0);
                    if (sharedPreferences2.getBoolean("resolution_auto_apply", false) && i7 > 0 && i8 > 0) {
                        y2.o.c(i7, i8, i9);
                    } else if (sharedPreferences2.getBoolean("resolution_active", false)) {
                        y2.o.B();
                    }
                    return;
                } catch (Exception e8) {
                    Log.e("ResolutionTool", v.m.p.abcdstr(97), e8);
                    return;
                }
        }
    }

    public /* synthetic */ o1(int i7, Object obj) {
        this.f185a = i7;
    }
}
