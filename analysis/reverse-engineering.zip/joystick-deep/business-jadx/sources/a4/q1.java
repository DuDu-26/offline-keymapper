package a4;

import android.os.Handler;
import java.util.ArrayList;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class q1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f197a;
    public final /* synthetic */ ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f198c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f199d;
    public final /* synthetic */ String e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ long f200f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f201g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f202h;

    public /* synthetic */ q1(Object obj, ArrayList arrayList, String str, String str2, String str3, long j7, Object obj2, int i7) {
        this.f197a = i7;
        this.f201g = obj;
        this.b = arrayList;
        this.f198c = str;
        this.f199d = str2;
        this.e = str3;
        this.f200f = j7;
        this.f202h = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f197a) {
            case 0:
                u1 u1Var = (u1) this.f201g;
                t1 t1Var = (t1) this.f202h;
                Handler handler = u1Var.f247c;
                byte[] bArrA = u1.a(this.b);
                String str = this.f198c;
                String str2 = this.f199d;
                String str3 = this.e;
                long j7 = this.f200f;
                if (NativeAuth.k0(bArrA, str, str2, str3, false, j7, j7, j7, 1) == 0) {
                    handler.post(new r1(u1Var, str, str2, j7, str3, t1Var, 0));
                } else {
                    handler.post(new a3.e(t1Var, 17, u1.i(v.m.p.abcdstr(78))));
                }
                break;
            default:
                e4.h0 h0Var = (e4.h0) this.f201g;
                e4.g0 g0Var = (e4.g0) this.f202h;
                Handler handler2 = h0Var.f5368c;
                byte[] bArrA2 = e4.h0.a(this.b);
                String str4 = this.f198c;
                String str5 = this.f199d;
                String str6 = this.e;
                long j8 = this.f200f;
                if (NativeAuth.k0(bArrA2, str4, str5, str6, false, j8, j8, j8, 1) == 0) {
                    handler2.post(new r1(h0Var, str4, str5, j8, str6, g0Var, 1));
                } else {
                    handler2.post(new e4.e0(g0Var, 0, e4.h0.j(v.m.p.abcdstr(78))));
                }
                break;
        }
    }
}
