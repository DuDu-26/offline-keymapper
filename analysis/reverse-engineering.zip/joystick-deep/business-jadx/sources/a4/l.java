package a4;

import java.util.function.BooleanSupplier;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class l implements BooleanSupplier {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f157a;
    public final /* synthetic */ Object b;

    public /* synthetic */ l(int i7, Object obj) {
        this.f157a = i7;
        this.b = obj;
    }

    @Override // java.util.function.BooleanSupplier
    public final boolean getAsBoolean() {
        switch (this.f157a) {
            case 0:
                return ((t) this.b).getParent() != null;
            case 1:
                return ((c0) this.b).getParent() != null;
            case 2:
                return ((b4.q0) this.b).b.f1975g;
            case 3:
                return ((e4.k) this.b).getParent() != null;
            case 4:
                return ((e4.s) this.b).getParent() != null;
            case 5:
                return ((j3.b) this.b).f6364m;
            default:
                return ((j3.t) this.b).f6460p;
        }
    }
}
