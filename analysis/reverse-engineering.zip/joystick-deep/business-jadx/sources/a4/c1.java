package a4;

import java.util.HashMap;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class c1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f70a;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f71c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f72d;
    public final long e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final float f73f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final HashMap f74g;

    public /* synthetic */ c1(String str, String str2, String str3, boolean z6, long j7, int i7, float f2, HashMap map) {
        this.f70a = str;
        this.b = str2;
        this.f71c = str3;
        this.f72d = z6;
        this.e = j7;
        this.f73f = f2;
        this.f74g = map;
    }
}
