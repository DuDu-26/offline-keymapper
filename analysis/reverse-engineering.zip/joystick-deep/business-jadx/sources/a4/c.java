package a4;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.umeng.analytics.pro.dd;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f51a;
    public final /* synthetic */ t b;

    public /* synthetic */ c(t tVar, int i7) {
        this.f51a = i7;
        this.b = tVar;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f51a) {
            case 0:
                t tVar = this.b;
                e1 e1Var = tVar.f232s;
                if (e1Var != null) {
                    LinearLayout linearLayout = new LinearLayout(tVar.getContext());
                    linearLayout.setOrientation(1);
                    GradientDrawable gradientDrawableH = androidx.activity.g.h(linearLayout, tVar.e(20.0f), tVar.e(16.0f), tVar.e(20.0f), tVar.e(16.0f));
                    gradientDrawableH.setColor(-14013910);
                    gradientDrawableH.setCornerRadius(tVar.e(8.0f));
                    linearLayout.setBackground(gradientDrawableH);
                    TextView textView = new TextView(tVar.getContext());
                    textView.setText(tVar.getContext().getString(2131820644));
                    textView.setTextColor(-1);
                    textView.setTextSize(16.0f);
                    textView.setPadding(0, 0, 0, tVar.e(12.0f));
                    linearLayout.addView(textView);
                    EditText editText = new EditText(tVar.getContext());
                    editText.setText(e1Var.b);
                    editText.setTextColor(-1);
                    editText.setHintTextColor(-7829368);
                    editText.setBackgroundColor(-15066598);
                    editText.setPadding(tVar.e(8.0f), tVar.e(8.0f), tVar.e(8.0f), tVar.e(8.0f));
                    editText.setFocusableInTouchMode(true);
                    linearLayout.addView(editText);
                    LinearLayout linearLayout2 = new LinearLayout(tVar.getContext());
                    linearLayout2.setOrientation(0);
                    linearLayout2.setGravity(8388613);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                    layoutParams.topMargin = tVar.e(12.0f);
                    TextView textView2 = new TextView(tVar.getContext());
                    textView2.setText(tVar.getContext().getString(2131820610));
                    textView2.setTextColor(-7829368);
                    textView2.setTextSize(14.0f);
                    textView2.setPadding(tVar.e(12.0f), tVar.e(8.0f), tVar.e(12.0f), tVar.e(8.0f));
                    textView2.setClickable(true);
                    textView2.setOnClickListener(new d(tVar, 2));
                    linearLayout2.addView(textView2);
                    TextView textView3 = new TextView(tVar.getContext());
                    textView3.setText(tVar.getContext().getString(2131820649));
                    textView3.setTextColor(-11751600);
                    textView3.setTextSize(14.0f);
                    textView3.setPadding(tVar.e(12.0f), tVar.e(8.0f), tVar.e(12.0f), tVar.e(8.0f));
                    textView3.setClickable(true);
                    textView3.setOnClickListener(new f(tVar, editText, e1Var, 0));
                    linearLayout2.addView(textView3);
                    linearLayout.addView(linearLayout2, layoutParams);
                    tVar.l(linearLayout);
                    editText.postDelayed(new a3.e(tVar, 3, editText), 200L);
                }
                break;
            case 1:
                final t tVar2 = this.b;
                final e1 e1Var2 = tVar2.f232s;
                if (e1Var2 != null) {
                    LinearLayout linearLayout3 = new LinearLayout(tVar2.getContext());
                    linearLayout3.setOrientation(1);
                    GradientDrawable gradientDrawableH2 = androidx.activity.g.h(linearLayout3, tVar2.e(20.0f), tVar2.e(16.0f), tVar2.e(20.0f), tVar2.e(16.0f));
                    gradientDrawableH2.setColor(-14013910);
                    gradientDrawableH2.setCornerRadius(tVar2.e(8.0f));
                    linearLayout3.setBackground(gradientDrawableH2);
                    TextView textView4 = new TextView(tVar2.getContext());
                    textView4.setText(tVar2.getContext().getString(2131820633));
                    textView4.setTextColor(-1);
                    textView4.setTextSize(16.0f);
                    textView4.setPadding(0, 0, 0, tVar2.e(8.0f));
                    linearLayout3.addView(textView4);
                    TextView textView5 = new TextView(tVar2.getContext());
                    textView5.setText(String.format(tVar2.getContext().getString(2131820632), e1Var2.b));
                    textView5.setTextColor(-3355444);
                    textView5.setTextSize(14.0f);
                    textView5.setPadding(0, 0, 0, tVar2.e(16.0f));
                    linearLayout3.addView(textView5);
                    LinearLayout linearLayout4 = new LinearLayout(tVar2.getContext());
                    linearLayout4.setOrientation(0);
                    linearLayout4.setGravity(8388613);
                    TextView textView6 = new TextView(tVar2.getContext());
                    textView6.setText(tVar2.getContext().getString(2131820610));
                    textView6.setTextColor(-7829368);
                    textView6.setTextSize(14.0f);
                    textView6.setPadding(tVar2.e(12.0f), tVar2.e(8.0f), tVar2.e(12.0f), tVar2.e(8.0f));
                    textView6.setClickable(true);
                    textView6.setOnClickListener(new d(tVar2, 1));
                    linearLayout4.addView(textView6);
                    TextView textView7 = new TextView(tVar2.getContext());
                    textView7.setText(tVar2.getContext().getString(2131820630));
                    textView7.setTextColor(-769226);
                    textView7.setTextSize(14.0f);
                    textView7.setPadding(tVar2.e(12.0f), tVar2.e(8.0f), tVar2.e(12.0f), tVar2.e(8.0f));
                    textView7.setClickable(true);
                    final int i7 = 0;
                    textView7.setOnClickListener(new View.OnClickListener() { // from class: a4.e
                        /* JADX WARN: Type inference fix 'apply assigned field type' failed
                        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
                        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
                        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
                        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
                         */
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            switch (i7) {
                                case 0:
                                    t tVar3 = tVar2;
                                    String str = e1Var2.f100a;
                                    String str2 = d1.u().f80d;
                                    d1 d1VarU = d1.u();
                                    final m mVar = new m(tVar3, str2, str);
                                    if (d1VarU.f80d == null) {
                                        Handler handler = d1VarU.f79c;
                                        final int i8 = 0;
                                        handler.post(new Runnable() { // from class: a4.u0
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i8) {
                                                    case 0:
                                                        mVar.a(v.m.p.abcdstr(31));
                                                        break;
                                                    default:
                                                        mVar.a(v.m.p.abcdstr(71));
                                                        break;
                                                }
                                            }
                                        });
                                    } else {
                                        e1 e1VarE = d1VarU.e(str);
                                        if (e1VarE == null) {
                                            Handler handler2 = d1VarU.f79c;
                                            final int i9 = 1;
                                            handler2.post(new Runnable() { // from class: a4.u0
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i9) {
                                                        case 0:
                                                            mVar.a(v.m.p.abcdstr(31));
                                                            break;
                                                        default:
                                                            mVar.a(v.m.p.abcdstr(71));
                                                            break;
                                                    }
                                                }
                                            });
                                        } else {
                                            d1VarU.b.execute(new o0(d1VarU, d1VarU.f80d, str, mVar, e1VarE, 2));
                                        }
                                    }
                                    tVar3.i(tVar3.f220g);
                                    break;
                                case 1:
                                    t tVar4 = tVar2;
                                    e1 e1Var3 = e1Var2;
                                    tVar4.i(tVar4.f220g);
                                    if (!tVar4.f230q) {
                                        String str3 = e1Var3.f100a;
                                        String str4 = d1.u().f80d;
                                        if (str4 != null) {
                                            tVar4.f230q = true;
                                            String str5 = e1Var3.b;
                                            Context context = tVar4.getContext();
                                            LinearLayout linearLayout5 = new LinearLayout(context);
                                            linearLayout5.setOrientation(1);
                                            linearLayout5.setPadding(tVar4.e(18.0f), tVar4.e(16.0f), tVar4.e(18.0f), tVar4.e(16.0f));
                                            linearLayout5.setClickable(true);
                                            GradientDrawable gradientDrawable = new GradientDrawable();
                                            gradientDrawable.setColor(-14013910);
                                            gradientDrawable.setCornerRadius(tVar4.e(12.0f));
                                            linearLayout5.setBackground(gradientDrawable);
                                            TextView textView8 = new TextView(context);
                                            textView8.setText(context.getString(2131820679));
                                            textView8.setTextColor(-1);
                                            textView8.setTextSize(15.0f);
                                            textView8.setTypeface(null, 1);
                                            textView8.setGravity(17);
                                            linearLayout5.addView(textView8);
                                            TextView textView9 = new TextView(context);
                                            textView9.setText(str5);
                                            textView9.setTextColor(-11549705);
                                            textView9.setTextSize(12.0f);
                                            textView9.setGravity(17);
                                            textView9.setPadding(0, tVar4.e(4.0f), 0, 0);
                                            linearLayout5.addView(textView9);
                                            TextView textView10 = new TextView(context);
                                            textView10.setText(context.getString(2131820678));
                                            textView10.setTextColor(-4473925);
                                            textView10.setTextSize(13.0f);
                                            textView10.setLineSpacing(tVar4.e(3.0f), 1.0f);
                                            textView10.setPadding(0, tVar4.e(12.0f), 0, tVar4.e(14.0f));
                                            linearLayout5.addView(textView10);
                                            TextView textViewD = tVar4.d(-10066330, context.getString(2131820610));
                                            textViewD.setOnClickListener(new d(tVar4, 6));
                                            linearLayout5.addView(textViewD, new LinearLayout.LayoutParams(-1, -2));
                                            tVar4.l(linearLayout5);
                                            FrameLayout frameLayout = tVar4.f220g;
                                            tVar4.f231r = frameLayout;
                                            if (frameLayout != null) {
                                                frameLayout.setOnClickListener(new g(tVar4, 2, frameLayout));
                                            }
                                            i3.e.a(new m(tVar4, str4, str3), true);
                                            break;
                                        }
                                    }
                                    break;
                                default:
                                    t tVar5 = tVar2;
                                    e1 e1Var4 = e1Var2;
                                    tVar5.i(tVar5.f220g);
                                    tVar5.c(e1Var4, 0);
                                    break;
                            }
                        }
                    });
                    linearLayout4.addView(textView7);
                    linearLayout3.addView(linearLayout4);
                    tVar2.l(linearLayout3);
                }
                break;
            case 2:
                final t tVar3 = this.b;
                final e1 e1Var3 = tVar3.f232s;
                if (e1Var3 != null) {
                    Context context = tVar3.getContext();
                    LinearLayout linearLayout5 = new LinearLayout(context);
                    linearLayout5.setOrientation(1);
                    linearLayout5.setBackgroundColor(-14013910);
                    linearLayout5.setPadding(tVar3.e(14.0f), tVar3.e(14.0f), tVar3.e(14.0f), tVar3.e(14.0f));
                    TextView textView8 = new TextView(context);
                    textView8.setText(2131821380);
                    textView8.setTextColor(-1);
                    textView8.setTextSize(15.0f);
                    textView8.setTypeface(null, 1);
                    textView8.setPadding(0, 0, 0, tVar3.e(12.0f));
                    linearLayout5.addView(textView8);
                    linearLayout5.addView(new f3.g(context, new h(tVar3, 0, e1Var3)));
                    View view = new View(context);
                    view.setLayoutParams(new LinearLayout.LayoutParams(-1, tVar3.e(6.0f)));
                    linearLayout5.addView(view);
                    String string = context.getString(2131821378);
                    String string2 = context.getString(2131821379);
                    final int i8 = 2;
                    View.OnClickListener onClickListener = new View.OnClickListener() { // from class: a4.e
                        /* JADX WARN: Type inference fix 'apply assigned field type' failed
                        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
                        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
                        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
                        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
                         */
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view2) {
                            switch (i8) {
                                case 0:
                                    t tVar32 = tVar3;
                                    String str = e1Var3.f100a;
                                    String str2 = d1.u().f80d;
                                    d1 d1VarU = d1.u();
                                    final m mVar = new m(tVar32, str2, str);
                                    if (d1VarU.f80d == null) {
                                        Handler handler = d1VarU.f79c;
                                        final int i82 = 0;
                                        handler.post(new Runnable() { // from class: a4.u0
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i82) {
                                                    case 0:
                                                        mVar.a(v.m.p.abcdstr(31));
                                                        break;
                                                    default:
                                                        mVar.a(v.m.p.abcdstr(71));
                                                        break;
                                                }
                                            }
                                        });
                                    } else {
                                        e1 e1VarE = d1VarU.e(str);
                                        if (e1VarE == null) {
                                            Handler handler2 = d1VarU.f79c;
                                            final int i9 = 1;
                                            handler2.post(new Runnable() { // from class: a4.u0
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i9) {
                                                        case 0:
                                                            mVar.a(v.m.p.abcdstr(31));
                                                            break;
                                                        default:
                                                            mVar.a(v.m.p.abcdstr(71));
                                                            break;
                                                    }
                                                }
                                            });
                                        } else {
                                            d1VarU.b.execute(new o0(d1VarU, d1VarU.f80d, str, mVar, e1VarE, 2));
                                        }
                                    }
                                    tVar32.i(tVar32.f220g);
                                    break;
                                case 1:
                                    t tVar4 = tVar3;
                                    e1 e1Var32 = e1Var3;
                                    tVar4.i(tVar4.f220g);
                                    if (!tVar4.f230q) {
                                        String str3 = e1Var32.f100a;
                                        String str4 = d1.u().f80d;
                                        if (str4 != null) {
                                            tVar4.f230q = true;
                                            String str5 = e1Var32.b;
                                            Context context2 = tVar4.getContext();
                                            LinearLayout linearLayout52 = new LinearLayout(context2);
                                            linearLayout52.setOrientation(1);
                                            linearLayout52.setPadding(tVar4.e(18.0f), tVar4.e(16.0f), tVar4.e(18.0f), tVar4.e(16.0f));
                                            linearLayout52.setClickable(true);
                                            GradientDrawable gradientDrawable = new GradientDrawable();
                                            gradientDrawable.setColor(-14013910);
                                            gradientDrawable.setCornerRadius(tVar4.e(12.0f));
                                            linearLayout52.setBackground(gradientDrawable);
                                            TextView textView82 = new TextView(context2);
                                            textView82.setText(context2.getString(2131820679));
                                            textView82.setTextColor(-1);
                                            textView82.setTextSize(15.0f);
                                            textView82.setTypeface(null, 1);
                                            textView82.setGravity(17);
                                            linearLayout52.addView(textView82);
                                            TextView textView9 = new TextView(context2);
                                            textView9.setText(str5);
                                            textView9.setTextColor(-11549705);
                                            textView9.setTextSize(12.0f);
                                            textView9.setGravity(17);
                                            textView9.setPadding(0, tVar4.e(4.0f), 0, 0);
                                            linearLayout52.addView(textView9);
                                            TextView textView10 = new TextView(context2);
                                            textView10.setText(context2.getString(2131820678));
                                            textView10.setTextColor(-4473925);
                                            textView10.setTextSize(13.0f);
                                            textView10.setLineSpacing(tVar4.e(3.0f), 1.0f);
                                            textView10.setPadding(0, tVar4.e(12.0f), 0, tVar4.e(14.0f));
                                            linearLayout52.addView(textView10);
                                            TextView textViewD = tVar4.d(-10066330, context2.getString(2131820610));
                                            textViewD.setOnClickListener(new d(tVar4, 6));
                                            linearLayout52.addView(textViewD, new LinearLayout.LayoutParams(-1, -2));
                                            tVar4.l(linearLayout52);
                                            FrameLayout frameLayout = tVar4.f220g;
                                            tVar4.f231r = frameLayout;
                                            if (frameLayout != null) {
                                                frameLayout.setOnClickListener(new g(tVar4, 2, frameLayout));
                                            }
                                            i3.e.a(new m(tVar4, str4, str3), true);
                                            break;
                                        }
                                    }
                                    break;
                                default:
                                    t tVar5 = tVar3;
                                    e1 e1Var4 = e1Var3;
                                    tVar5.i(tVar5.f220g);
                                    tVar5.c(e1Var4, 0);
                                    break;
                            }
                        }
                    };
                    Context context2 = tVar3.getContext();
                    LinearLayout linearLayout6 = new LinearLayout(context2);
                    linearLayout6.setOrientation(1);
                    GradientDrawable gradientDrawableH3 = androidx.activity.g.h(linearLayout6, tVar3.e(10.0f), tVar3.e(10.0f), tVar3.e(10.0f), tVar3.e(10.0f));
                    gradientDrawableH3.setColor(-12961222);
                    gradientDrawableH3.setCornerRadius(tVar3.e(6.0f));
                    linearLayout6.setBackground(gradientDrawableH3);
                    linearLayout6.setOnClickListener(onClickListener);
                    TextView textView9 = new TextView(context2);
                    textView9.setText(string);
                    textView9.setTextColor(-1);
                    textView9.setTextSize(14.0f);
                    textView9.setTypeface(null, 1);
                    linearLayout6.addView(textView9);
                    TextView textView10 = new TextView(context2);
                    textView10.setText(string2);
                    textView10.setTextColor(-5592406);
                    textView10.setTextSize(11.0f);
                    textView10.setPadding(0, tVar3.e(2.0f), 0, 0);
                    linearLayout6.addView(textView10);
                    linearLayout5.addView(linearLayout6);
                    View view2 = new View(context);
                    view2.setLayoutParams(new LinearLayout.LayoutParams(-1, tVar3.e(10.0f)));
                    linearLayout5.addView(view2);
                    TextView textView11 = new TextView(context);
                    textView11.setText(2131820610);
                    textView11.setTextColor(-5592406);
                    textView11.setTextSize(13.0f);
                    textView11.setGravity(17);
                    textView11.setPadding(tVar3.e(12.0f), tVar3.e(12.0f), tVar3.e(12.0f), tVar3.e(12.0f));
                    textView11.setOnClickListener(new d(tVar3, 4));
                    linearLayout5.addView(textView11);
                    tVar3.l(linearLayout5);
                }
                break;
            case 3:
                final t tVar4 = this.b;
                final e1 e1Var4 = tVar4.f232s;
                if (e1Var4 != null) {
                    Context context3 = tVar4.getContext();
                    String str = e1Var4.f100a;
                    int[] iArrU = i0.I().u(d1.u().f80d, str);
                    LinearLayout linearLayout7 = new LinearLayout(context3);
                    linearLayout7.setOrientation(1);
                    GradientDrawable gradientDrawableH4 = androidx.activity.g.h(linearLayout7, tVar4.e(18.0f), tVar4.e(16.0f), tVar4.e(18.0f), tVar4.e(16.0f));
                    gradientDrawableH4.setColor(-14013910);
                    gradientDrawableH4.setCornerRadius(tVar4.e(12.0f));
                    linearLayout7.setBackground(gradientDrawableH4);
                    TextView textView12 = new TextView(context3);
                    textView12.setText(context3.getString(2131820686));
                    textView12.setTextColor(-1);
                    textView12.setTextSize(15.0f);
                    textView12.setTypeface(null, 1);
                    textView12.setGravity(17);
                    linearLayout7.addView(textView12);
                    TextView textView13 = new TextView(context3);
                    textView13.setText(context3.getString(2131820682, iArrU != null ? tVar4.f(iArrU) : context3.getString(2131820687)));
                    textView13.setTextColor(-4473925);
                    textView13.setTextSize(13.0f);
                    textView13.setGravity(17);
                    textView13.setPadding(0, tVar4.e(10.0f), 0, tVar4.e(14.0f));
                    linearLayout7.addView(textView13);
                    TextView textViewD = tVar4.d(-15108398, context3.getString(2131820691));
                    final int i9 = 1;
                    textViewD.setOnClickListener(new View.OnClickListener() { // from class: a4.e
                        /* JADX WARN: Type inference fix 'apply assigned field type' failed
                        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
                        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
                        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
                        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
                        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
                         */
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view22) {
                            switch (i9) {
                                case 0:
                                    t tVar32 = tVar4;
                                    String str2 = e1Var4.f100a;
                                    String str22 = d1.u().f80d;
                                    d1 d1VarU = d1.u();
                                    final m mVar = new m(tVar32, str22, str2);
                                    if (d1VarU.f80d == null) {
                                        Handler handler = d1VarU.f79c;
                                        final int i82 = 0;
                                        handler.post(new Runnable() { // from class: a4.u0
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i82) {
                                                    case 0:
                                                        mVar.a(v.m.p.abcdstr(31));
                                                        break;
                                                    default:
                                                        mVar.a(v.m.p.abcdstr(71));
                                                        break;
                                                }
                                            }
                                        });
                                    } else {
                                        e1 e1VarE = d1VarU.e(str2);
                                        if (e1VarE == null) {
                                            Handler handler2 = d1VarU.f79c;
                                            final int i92 = 1;
                                            handler2.post(new Runnable() { // from class: a4.u0
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i92) {
                                                        case 0:
                                                            mVar.a(v.m.p.abcdstr(31));
                                                            break;
                                                        default:
                                                            mVar.a(v.m.p.abcdstr(71));
                                                            break;
                                                    }
                                                }
                                            });
                                        } else {
                                            d1VarU.b.execute(new o0(d1VarU, d1VarU.f80d, str2, mVar, e1VarE, 2));
                                        }
                                    }
                                    tVar32.i(tVar32.f220g);
                                    break;
                                case 1:
                                    t tVar42 = tVar4;
                                    e1 e1Var32 = e1Var4;
                                    tVar42.i(tVar42.f220g);
                                    if (!tVar42.f230q) {
                                        String str3 = e1Var32.f100a;
                                        String str4 = d1.u().f80d;
                                        if (str4 != null) {
                                            tVar42.f230q = true;
                                            String str5 = e1Var32.b;
                                            Context context22 = tVar42.getContext();
                                            LinearLayout linearLayout52 = new LinearLayout(context22);
                                            linearLayout52.setOrientation(1);
                                            linearLayout52.setPadding(tVar42.e(18.0f), tVar42.e(16.0f), tVar42.e(18.0f), tVar42.e(16.0f));
                                            linearLayout52.setClickable(true);
                                            GradientDrawable gradientDrawable = new GradientDrawable();
                                            gradientDrawable.setColor(-14013910);
                                            gradientDrawable.setCornerRadius(tVar42.e(12.0f));
                                            linearLayout52.setBackground(gradientDrawable);
                                            TextView textView82 = new TextView(context22);
                                            textView82.setText(context22.getString(2131820679));
                                            textView82.setTextColor(-1);
                                            textView82.setTextSize(15.0f);
                                            textView82.setTypeface(null, 1);
                                            textView82.setGravity(17);
                                            linearLayout52.addView(textView82);
                                            TextView textView92 = new TextView(context22);
                                            textView92.setText(str5);
                                            textView92.setTextColor(-11549705);
                                            textView92.setTextSize(12.0f);
                                            textView92.setGravity(17);
                                            textView92.setPadding(0, tVar42.e(4.0f), 0, 0);
                                            linearLayout52.addView(textView92);
                                            TextView textView102 = new TextView(context22);
                                            textView102.setText(context22.getString(2131820678));
                                            textView102.setTextColor(-4473925);
                                            textView102.setTextSize(13.0f);
                                            textView102.setLineSpacing(tVar42.e(3.0f), 1.0f);
                                            textView102.setPadding(0, tVar42.e(12.0f), 0, tVar42.e(14.0f));
                                            linearLayout52.addView(textView102);
                                            TextView textViewD2 = tVar42.d(-10066330, context22.getString(2131820610));
                                            textViewD2.setOnClickListener(new d(tVar42, 6));
                                            linearLayout52.addView(textViewD2, new LinearLayout.LayoutParams(-1, -2));
                                            tVar42.l(linearLayout52);
                                            FrameLayout frameLayout = tVar42.f220g;
                                            tVar42.f231r = frameLayout;
                                            if (frameLayout != null) {
                                                frameLayout.setOnClickListener(new g(tVar42, 2, frameLayout));
                                            }
                                            i3.e.a(new m(tVar42, str4, str3), true);
                                            break;
                                        }
                                    }
                                    break;
                                default:
                                    t tVar5 = tVar4;
                                    e1 e1Var42 = e1Var4;
                                    tVar5.i(tVar5.f220g);
                                    tVar5.c(e1Var42, 0);
                                    break;
                            }
                        }
                    });
                    linearLayout7.addView(textViewD, new LinearLayout.LayoutParams(-1, -2));
                    if (iArrU != null) {
                        TextView textViewD2 = tVar4.d(-7652806, context3.getString(2131820680));
                        textViewD2.setOnClickListener(new g(tVar4, 0, str));
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                        layoutParams2.topMargin = tVar4.e(8.0f);
                        linearLayout7.addView(textViewD2, layoutParams2);
                    }
                    tVar4.l(linearLayout7);
                }
                break;
            case 4:
                t tVar5 = this.b;
                Context context4 = tVar5.getContext();
                int iE = tVar5.e(14.0f);
                int iE2 = tVar5.e(10.0f);
                LinearLayout linearLayout8 = new LinearLayout(context4);
                linearLayout8.setOrientation(1);
                GradientDrawable gradientDrawableH5 = androidx.activity.g.h(linearLayout8, iE, iE, iE, iE);
                gradientDrawableH5.setColor(Color.parseColor(v.m.p.abcdstr(32)));
                gradientDrawableH5.setCornerRadius(iE2);
                linearLayout8.setBackground(gradientDrawableH5);
                TextView textView14 = new TextView(context4);
                textView14.setText(2131820735);
                textView14.setTextColor(-1);
                textView14.setTextSize(2, 15.0f);
                textView14.setTypeface(null, 1);
                textView14.setPadding(0, 0, 0, tVar5.e(12.0f));
                linearLayout8.addView(textView14);
                EditText editText2 = new EditText(context4);
                editText2.setHint(2131820732);
                String strAbcdstr = v.m.p.abcdstr(33);
                editText2.setHintTextColor(Color.parseColor(strAbcdstr));
                editText2.setTextColor(-1);
                editText2.setTextSize(2, 14.0f);
                editText2.setSingleLine(true);
                editText2.setPadding(tVar5.e(10.0f), tVar5.e(10.0f), tVar5.e(10.0f), tVar5.e(10.0f));
                editText2.setFocusable(true);
                editText2.setFocusableInTouchMode(true);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(v.m.p.abcdstr(34)));
                gradientDrawable.setCornerRadius(tVar5.e(6.0f));
                editText2.setBackground(gradientDrawable);
                linearLayout8.addView(editText2);
                LinearLayout linearLayout9 = new LinearLayout(context4);
                linearLayout9.setOrientation(0);
                linearLayout9.setGravity(17);
                linearLayout9.setPadding(0, tVar5.e(12.0f), 0, 0);
                TextView textViewD3 = tVar5.d(Color.parseColor(v.m.p.abcdstr(35)), context4.getString(2131820965));
                textViewD3.setOnClickListener(new j(context4, editText2, 0));
                linearLayout9.addView(textViewD3);
                View view3 = new View(context4);
                view3.setLayoutParams(new LinearLayout.LayoutParams(tVar5.e(10.0f), 1));
                linearLayout9.addView(view3);
                TextView textViewD4 = tVar5.d(Color.parseColor(v.m.p.abcdstr(36)), context4.getString(2131820730));
                textViewD4.setOnClickListener(new k(tVar5, editText2, context4, textViewD4, 0));
                linearLayout9.addView(textViewD4);
                View view4 = new View(context4);
                view4.setLayoutParams(new LinearLayout.LayoutParams(tVar5.e(10.0f), 1));
                linearLayout9.addView(view4);
                TextView textViewD5 = tVar5.d(Color.parseColor(strAbcdstr), context4.getString(2131820610));
                textViewD5.setOnClickListener(new d(tVar5, 5));
                linearLayout9.addView(textViewD5);
                linearLayout8.addView(linearLayout9);
                tVar5.l(linearLayout8);
                break;
            case 5:
                t tVar6 = this.b;
                e4.r0.g(tVar6.f216a, tVar6, tVar6.b);
                break;
            case 6:
                t tVar7 = this.b;
                if (tVar7.getParent() != null) {
                    e4.r0.V(tVar7.f216a, tVar7);
                }
                break;
            case dd.f4082h /* 7 */:
                t tVar8 = this.b;
                tVar8.p();
                tVar8.requestLayout();
                break;
            default:
                t tVar9 = this.b;
                tVar9.p();
                tVar9.requestLayout();
                tVar9.invalidate();
                break;
        }
    }
}
