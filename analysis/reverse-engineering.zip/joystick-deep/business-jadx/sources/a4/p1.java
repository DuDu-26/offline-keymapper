package a4;

import com.umeng.commonsdk.statistics.UMErrorCode;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class p1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f192a;
    public final /* synthetic */ String b;

    public /* synthetic */ p1(String str) {
        this.f192a = 2;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String strAbcdstr;
        String strAbcdstr2;
        switch (this.f192a) {
            case 0:
                strAbcdstr = v.m.p.abcdstr(103);
                strAbcdstr2 = v.m.p.abcdstr(UMErrorCode.E_UM_BE_CREATE_FAILED);
                break;
            case 1:
                strAbcdstr = v.m.p.abcdstr(101);
                strAbcdstr2 = v.m.p.abcdstr(UMErrorCode.E_UM_BE_CREATE_FAILED);
                break;
            default:
                FloatingService floatingService = FloatingService.f6880k;
                if (floatingService != null) {
                    floatingService.a(this.b);
                    return;
                }
                return;
        }
        androidx.activity.g.w(strAbcdstr2, this.b, strAbcdstr);
    }

    public /* synthetic */ p1(Object obj, String str, int i7) {
        this.f192a = i7;
        this.b = str;
    }
}
