package a4;

import android.content.SharedPreferences;
import android.widget.CompoundButton;
import com.google.android.material.chip.Chip;
import com.umeng.analytics.pro.dd;
import java.util.function.Consumer;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class e0 implements CompoundButton.OnCheckedChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f98a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e0(int i7, Object obj) {
        this.f98a = i7;
        this.b = obj;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z6) {
        switch (this.f98a) {
            case 0:
                g0 g0Var = (g0) this.b;
                s.h.f((SharedPreferences) y2.l.i().f8978a, v.m.p.abcdstr(47), z6);
                i1 i1Var = g0Var.f111m;
                if (i1Var != null) {
                    i1Var.f();
                    i1Var.invalidate();
                }
                break;
            case 1:
                e4.v vVar = (e4.v) this.b;
                s.h.f((SharedPreferences) y2.l.i().f8978a, v.m.p.abcdstr(46), z6);
                e4.l0 l0Var = vVar.f5452m;
                if (l0Var != null) {
                    l0Var.a();
                    l0Var.invalidate();
                }
                if (y2.l.i().d()) {
                    p3.x.t().p();
                }
                break;
            case 2:
                CompoundButton.OnCheckedChangeListener onCheckedChangeListener = ((Chip) this.b).f3152i;
                if (onCheckedChangeListener != null) {
                    onCheckedChangeListener.onCheckedChanged(compoundButton, z6);
                }
                break;
            case 3:
                ((m3.f) this.b).c(z6);
                break;
            case 4:
                n3.c cVar = (n3.c) this.b;
                cVar.f6959a.f6364m = z6;
                cVar.f6963g.setVisibility(z6 ? 0 : 8);
                cVar.f();
                break;
            case 5:
                n3.f0 f0Var = (n3.f0) this.b;
                int i7 = f0Var.f6993a;
                n3.h0 h0Var = f0Var.b;
                switch (i7) {
                    case 3:
                        j3.q qVar = h0Var.f7000a;
                        qVar.f6429n = z6;
                        g.d dVar = h0Var.b;
                        if (dVar != null) {
                            dVar.e(qVar);
                        }
                        break;
                    default:
                        j3.q qVar2 = h0Var.f7000a;
                        qVar2.f6430o = z6;
                        g.d dVar2 = h0Var.b;
                        if (dVar2 != null) {
                            dVar2.e(qVar2);
                        }
                        break;
                }
                break;
            case 6:
                n3.l0 l0Var2 = (n3.l0) this.b;
                l0Var2.f7049n.setVisibility(z6 ? 0 : 8);
                j3.r rVar = l0Var2.f7038a;
                rVar.f6442v = z6;
                g.d dVar3 = l0Var2.b;
                if (dVar3 != null) {
                    dVar3.e(rVar);
                }
                break;
            case dd.f4082h /* 7 */:
                n3.m0 m0Var = (n3.m0) this.b;
                int i8 = m0Var.f7056a;
                com.google.android.material.textfield.w wVar = m0Var.b;
                switch (i8) {
                    case 1:
                        ((j3.s) wVar.f3582d).f6449m = z6;
                        wVar.f();
                        break;
                    default:
                        ((j3.s) wVar.f3582d).f6450n = z6;
                        wVar.f();
                        break;
                }
                break;
            case 8:
                com.google.android.material.textfield.w wVar2 = (com.google.android.material.textfield.w) this.b;
                ((j3.s) wVar2.f3582d).f6453q = z6;
                wVar2.f();
                break;
            default:
                ((Consumer) this.b).accept(Boolean.valueOf(z6));
                break;
        }
    }
}
