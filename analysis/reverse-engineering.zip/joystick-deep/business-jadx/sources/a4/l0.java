package a4;

import android.os.Handler;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class l0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f158a = 0;
    public final /* synthetic */ d1 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f159c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f160d;
    public final /* synthetic */ b1 e;

    public /* synthetic */ l0(d1 d1Var, String str, String str2, b1 b1Var) {
        this.b = d1Var;
        this.f159c = str;
        this.f160d = str2;
        this.e = b1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f158a) {
            case 0:
                d1 d1Var = this.b;
                Handler handler = d1Var.f79c;
                String str = this.f159c;
                String str2 = this.f160d;
                b1 b1Var = this.e;
                long jU = NativeAuth.U(str, str2);
                if (jU == 0) {
                    handler.post(new l0(d1Var, str, str2, d1.m(v.m.p.abcdstr(77)), b1Var));
                    return;
                }
                try {
                    byte[] bArrK = NativeAuth.k(16, jU);
                    byte[] bArr = bArrK == null ? null : bArrK;
                    if (bArrK == null || bArr != null) {
                        handler.post(new o0(d1Var, str, str2, b1Var, d1.n(bArr), 0));
                    } else {
                        handler.post(new l0(d1Var, str, str2, "Permission denied", b1Var));
                    }
                    return;
                } finally {
                    NativeAuth.h(jU);
                }
            default:
                d1 d1Var2 = this.b;
                String str3 = this.f159c;
                String str4 = this.f160d;
                b1 b1Var2 = this.e;
                if (str3.equals(d1Var2.f80d) && str4.equals(d1Var2.f81f)) {
                    b1Var2.c();
                    return;
                }
                return;
        }
    }

    public /* synthetic */ l0(d1 d1Var, String str, String str2, String str3, b1 b1Var) {
        this.b = d1Var;
        this.f159c = str;
        this.f160d = str2;
        this.e = b1Var;
    }
}
