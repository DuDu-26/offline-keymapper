package a4;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d2 extends LinearLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public c2 f93a;
    public ImageView b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public GradientDrawable f94c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f95d;

    public final void a(LinearLayout linearLayout, int i7) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.rightMargin = i7;
        addView(linearLayout, layoutParams);
    }

    public final LinearLayout b(Context context, int i7, String str) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setPadding(c(4), c(4), c(4), c(4));
        linearLayout.setGravity(1);
        int iC = c(28);
        ImageView imageView = new ImageView(context);
        imageView.setImageResource(i7);
        imageView.setColorFilter(androidx.core.content.c.a(context, 2131099745));
        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(iC, iC));
        TextView textView = new TextView(context);
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(11.0f);
        textView.setPadding(0, c(3), 0, 0);
        linearLayout.addView(imageView);
        linearLayout.addView(textView, new LinearLayout.LayoutParams(-2, -2));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        if (resourceId != 0) {
            linearLayout.setBackgroundResource(resourceId);
        }
        return linearLayout;
    }

    public final int c(int i7) {
        return Math.round(TypedValue.applyDimension(1, i7, getResources().getDisplayMetrics()));
    }

    public final void d(boolean z6) {
        GradientDrawable gradientDrawable = this.f94c;
        if (gradientDrawable != null) {
            int i7 = this.f95d;
            if (z6) {
                gradientDrawable.setCornerRadii(new float[]{i7, i7, i7, i7, 0.0f, 0.0f, 0.0f, 0.0f});
            } else {
                gradientDrawable.setCornerRadius(i7);
            }
        }
    }

    public void setDPadExpanded(boolean z6) {
        ImageView imageView = this.b;
        if (imageView != null) {
            imageView.setImageResource(z6 ? 2131230889 : 2131230886);
        }
        d(z6);
    }

    public void setOnToolbarClickListener(c2 c2Var) {
        this.f93a = c2Var;
    }
}
