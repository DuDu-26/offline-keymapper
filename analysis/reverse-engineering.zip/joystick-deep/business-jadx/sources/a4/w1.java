package a4;

import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class w1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f267a;
    public final /* synthetic */ Object b;

    public /* synthetic */ w1(int i7, Object obj) {
        this.f267a = i7;
        this.b = obj;
    }

    private final void a() {
        s4.a aVarB;
        long jNanoTime;
        s4.a aVarB2;
        s4.d dVar = (s4.d) this.b;
        synchronized (dVar) {
            dVar.f8209g++;
            aVarB = dVar.b();
        }
        if (aVarB == null) {
            return;
        }
        Thread threadCurrentThread = Thread.currentThread();
        String name = threadCurrentThread.getName();
        while (true) {
            try {
                threadCurrentThread.setName(aVarB.f8195a);
                Logger logger = ((s4.d) this.b).b;
                s4.c cVar = aVarB.f8196c;
                cVar.getClass();
                boolean zIsLoggable = logger.isLoggable(Level.FINE);
                if (zIsLoggable) {
                    jNanoTime = System.nanoTime();
                    m4.f.a(logger, aVarB, cVar, "starting");
                } else {
                    jNanoTime = -1;
                }
                try {
                    long jA = aVarB.a();
                    if (zIsLoggable) {
                        m4.f.a(logger, aVarB, cVar, "finished run in " + m4.f.j(System.nanoTime() - jNanoTime));
                    }
                    s4.d dVar2 = (s4.d) this.b;
                    synchronized (dVar2) {
                        s4.d.a(dVar2, aVarB, jA, true);
                        aVarB2 = dVar2.b();
                    }
                    if (aVarB2 == null) {
                        return;
                    } else {
                        aVarB = aVarB2;
                    }
                } catch (Throwable th) {
                    if (zIsLoggable) {
                        m4.f.a(logger, aVarB, cVar, "failed a run in " + m4.f.j(System.nanoTime() - jNanoTime));
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                try {
                    s4.d dVar3 = (s4.d) this.b;
                    synchronized (dVar3) {
                        s4.d.a(dVar3, aVarB, -1L, false);
                        if (!(th2 instanceof InterruptedException)) {
                            throw th2;
                        }
                        Thread.currentThread().interrupt();
                        return;
                    }
                } finally {
                    threadCurrentThread.setName(name);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:218:0x05a6  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instruction units count: 1954
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.w1.run():void");
    }
}
