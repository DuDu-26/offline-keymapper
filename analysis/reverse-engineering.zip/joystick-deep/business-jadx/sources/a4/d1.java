package a4;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import moe.heroman.eventtest.App;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.auth.PatternToken;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class d1 {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static d1 f77r;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final x0 f83h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public PatternToken f84i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f85j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public String f86k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public k3.f f87l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public volatile y3.j f88m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public z3.a f89n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public String f90o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public String f91p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f92q;
    public final ArrayList e = new ArrayList();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public String f81f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f82g = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SharedPreferences f78a = App.f6858a.getSharedPreferences(v.m.p.abcdstr(37), 0);
    public final ExecutorService b = Executors.newSingleThreadExecutor();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Handler f79c = new Handler(Looper.getMainLooper());

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile String f80d = null;

    public d1() {
        if (this.f83h != null) {
            return;
        }
        this.f83h = new x0(0, this);
        moe.heroman.eventtest.auth.a.h().a(this.f83h);
    }

    public static byte[] i(float f2) {
        i0 i0Var = new i0(1);
        i0Var.m();
        i0Var.w(85);
        i0.J(i0Var.n(), f2);
        i0Var.p();
        i0Var.t();
        return ((ByteArrayOutputStream) i0Var.b).toByteArray();
    }

    public static String m(String str) {
        String strR = NativeAuth.r();
        return (strR == null || strR.isEmpty()) ? str : strR;
    }

    public static z3.a n(byte[] bArr) {
        if (bArr == null || bArr.length == 0) {
            return new z3.a();
        }
        try {
            a3.j jVarV = a5.h.V(bArr);
            if (jVarV == null || jVarV.f27a != 5) {
                jVarV = null;
            }
            if (jVarV == null) {
                return new z3.a();
            }
            a3.j jVarF = jVarV.f("general");
            if (jVarF == null) {
                LinkedHashMap linkedHashMap = jVarV.f31g;
                Iterator it = (linkedHashMap != null ? linkedHashMap.keySet() : Collections.EMPTY_SET).iterator();
                if (it.hasNext()) {
                    jVarF = jVarV.f((String) it.next());
                }
            }
            return jVarF == null ? new z3.a() : z3.a.d(jVarF);
        } catch (Exception e) {
            Log.e(v.m.p.abcdstr(38), v.m.p.abcdstr(39), e);
            return new z3.a();
        }
    }

    public static byte[] o(z3.a aVar) {
        try {
            i0 i0Var = new i0(1);
            i0Var.m();
            i0Var.h("general");
            aVar.m(i0Var);
            i0Var.t();
            i0Var.t();
            return ((ByteArrayOutputStream) i0Var.b).toByteArray();
        } catch (Exception e) {
            Log.e(v.m.p.abcdstr(38), v.m.p.abcdstr(40), e);
            return new byte[0];
        }
    }

    public static byte[] t(HashMap map) {
        i0 i0Var = new i0(1);
        i0Var.m();
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            i0Var.C((String) ((Map.Entry) it.next()).getKey(), ((Float) r1.getValue()).floatValue());
        }
        i0Var.t();
        return ((ByteArrayOutputStream) i0Var.b).toByteArray();
    }

    public static synchronized d1 u() {
        try {
            if (f77r == null) {
                f77r = new d1();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f77r;
    }

    public static e1 v(NativeAuth.ConfigSummary configSummary) {
        long jCurrentTimeMillis = configSummary.modifiedAt;
        if (jCurrentTimeMillis <= 0) {
            jCurrentTimeMillis = System.currentTimeMillis();
        }
        String str = configSummary.guid;
        String str2 = configSummary.name;
        boolean z6 = configSummary.isOfficial;
        e1 e1Var = new e1();
        e1Var.f100a = str;
        e1Var.b = str2;
        e1Var.f101c = z6;
        e1Var.f102d = jCurrentTimeMillis;
        e1Var.f103f = 1.0f;
        HashMap map = new HashMap();
        for (int i7 = 0; i7 < 2; i7++) {
            map.put(e1.f99h[i7], Float.valueOf(1.0f));
        }
        e1Var.f104g = map;
        e1Var.e = configSummary.version;
        return e1Var;
    }

    public final boolean a(z3.a aVar) {
        e1 e1VarE;
        if (this.f81f == null || this.f80d == null || !x(this.f80d, this.f81f) || (e1VarE = e(this.f81f)) == null) {
            return false;
        }
        byte[] bArrI = i(e1VarE.f103f);
        byte[] bArrT = t(new HashMap(e1VarE.f104g));
        if (bArrI == null || bArrT == null || NativeAuth.d0(this.f84i, bArrI, bArrT) != 0) {
            return false;
        }
        l(aVar);
        return true;
    }

    public final void b(String str, String str2) {
        if (this.f81f == null || this.f80d == null || !x(this.f80d, this.f81f)) {
            return;
        }
        NativeAuth.G(this.f84i, str, str2);
    }

    public final boolean c(String str) {
        ArrayList arrayList = this.e;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            if (((e1) obj).b.equals(str)) {
                return true;
            }
        }
        return false;
    }

    public final void d(String str, a1 a1Var) {
        if (this.f80d == null) {
            this.f79c.post(new s0(a1Var, 0));
            return;
        }
        String string = UUID.randomUUID().toString();
        long jCurrentTimeMillis = System.currentTimeMillis();
        String str2 = this.f80d;
        HashMap map = new HashMap();
        Float fValueOf = Float.valueOf(1.0f);
        map.put(v.m.p.abcdstr(41), fValueOf);
        map.put(v.m.p.abcdstr(42), fValueOf);
        this.b.execute(new t0(this, str2, map, a1Var, string, str, jCurrentTimeMillis));
    }

    public final e1 e(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = this.e;
        int size = arrayList.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            e1 e1Var = (e1) obj;
            if (e1Var.f100a.equals(str)) {
                return e1Var;
            }
        }
        return null;
    }

    public final void f(z0 z0Var) {
        if (!this.f92q || this.f89n == null) {
            this.f79c.post(new k0(z0Var, 0));
            return;
        }
        if (!Objects.equals(this.f90o, this.f80d) || !Objects.equals(this.f91p, this.f81f)) {
            this.f89n = null;
            this.f90o = null;
            this.f91p = null;
            this.f92q = false;
            this.f79c.post(new k0(z0Var, 0));
            return;
        }
        z3.a aVarC = this.f89n.c();
        this.f89n = null;
        this.f90o = null;
        this.f91p = null;
        this.f92q = false;
        s(aVarC, z0Var);
    }

    public final String g(String str) {
        String strA = n.e.a(str, v.m.p.abcdstr(43));
        int i7 = 1;
        while (c(strA)) {
            i7++;
            strA = str + v.m.p.abcdstr(44) + i7;
        }
        return strA;
    }

    public final boolean h() {
        return (this.f84i == null || this.f81f == null) ? false : true;
    }

    public final void j(String str, z0 z0Var) {
        if (this.f92q) {
            f(new y1.e(2));
        }
        if (str == null) {
            this.f81f = null;
            q();
            r();
            if (z0Var != null) {
                this.f79c.post(new k0(z0Var, 0));
                return;
            }
            return;
        }
        this.f81f = str;
        r();
        if (this.f80d != null) {
            this.b.execute(new n0((Object) this, this.f80d, (Serializable) str, (Object) z0Var, 1));
        } else if (z0Var != null) {
            this.f79c.post(new k0(z0Var, 4));
        }
    }

    public final void k(b1 b1Var) {
        String str = this.f81f;
        String str2 = this.f80d;
        if (str == null || str2 == null) {
            this.f79c.post(new n(4, b1Var));
            return;
        }
        z3.a aVarP = p(str2, str);
        if (aVarP != null) {
            this.f79c.post(new o0(this, str2, str, b1Var, aVarP, 0));
        } else {
            this.b.execute(new l0(this, str2, str, b1Var));
        }
    }

    public final void l(z3.a aVar) {
        this.f89n = aVar;
        this.f90o = this.f80d;
        this.f91p = this.f81f;
        this.f92q = true;
    }

    public final z3.a p(String str, String str2) {
        if (this.f92q && this.f89n != null && Objects.equals(str, this.f90o) && Objects.equals(str2, this.f91p)) {
            return this.f89n.c();
        }
        return null;
    }

    public final void q() {
        PatternToken patternToken = this.f84i;
        if (patternToken != null) {
            NativeAuth.t0(patternToken);
            this.f84i = null;
        }
        this.f85j = null;
        this.f86k = null;
    }

    public final void r() {
        if (this.f80d == null) {
            return;
        }
        String str = v.m.p.abcdstr(45) + this.f80d;
        String str2 = this.f81f;
        SharedPreferences sharedPreferences = this.f78a;
        if (str2 != null) {
            sharedPreferences.edit().putString(str, this.f81f).apply();
        } else {
            sharedPreferences.edit().remove(str).apply();
        }
    }

    public final void s(z3.a aVar, z0 z0Var) {
        if (this.f81f == null) {
            this.f79c.post(new k0(z0Var, 1));
            return;
        }
        if (this.f80d == null) {
            this.f79c.post(new k0(z0Var, 2));
            return;
        }
        e1 e1VarE = e(this.f81f);
        if (e1VarE == null) {
            this.f79c.post(new k0(z0Var, 3));
            return;
        }
        y3.j jVar = this.f88m;
        if (jVar != null) {
            HashMap mapT = jVar.f9093a.t(this.f80d, this.f81f);
            if (mapT != null) {
                aVar.f9202i = mapT;
            }
        }
        String str = this.f80d;
        String str2 = e1VarE.f100a;
        String str3 = e1VarE.b;
        boolean z6 = e1VarE.f101c;
        long j7 = e1VarE.f102d;
        int i7 = e1VarE.e;
        c1 c1Var = new c1(str, str2, str3, z6, j7, i7, e1VarE.f103f, new HashMap(new HashMap(e1VarE.f104g)));
        if (!z6) {
            this.b.execute(new q0(this, c1Var, aVar.c(), z0Var, Math.max(1, i7) + 1, 0));
        } else if (str.equals(this.f80d)) {
            d(g(str3), new y0(this, c1Var, z0Var, aVar.c(), 0));
        } else {
            this.f79c.post(new k0(z0Var, 5));
        }
    }

    public final void w(String str, y3.q qVar) {
        if (str == null || str.isEmpty()) {
            this.f79c.post(new a3.e(this, 9, qVar));
        } else if (!str.equals(this.f80d)) {
            this.b.execute(new a3.f(this, str, qVar, 4));
        } else if (qVar != null) {
            this.f79c.post(new k0(qVar, 0));
        }
    }

    public final boolean x(String str, String str2) {
        return this.f84i != null && Objects.equals(this.f85j, str) && Objects.equals(this.f86k, str2);
    }
}
