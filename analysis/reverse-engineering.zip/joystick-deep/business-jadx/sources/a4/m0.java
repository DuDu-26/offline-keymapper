package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class m0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f171a;
    public final /* synthetic */ z0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f172c;

    public /* synthetic */ m0(z0 z0Var, String str, int i7) {
        this.f171a = i7;
        this.b = z0Var;
        this.f172c = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f171a) {
            case 0:
                z0 z0Var = this.b;
                if (z0Var != null) {
                    z0Var.a(this.f172c);
                }
                break;
            default:
                this.b.a(this.f172c);
                break;
        }
    }
}
