package a4;

import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Handler;
import android.text.Editable;
import android.text.Selection;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import androidx.appcompat.widget.f3;
import androidx.cardview.widget.CardView;
import com.umeng.analytics.pro.bc;
import com.umeng.analytics.pro.dd;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import moe.heroman.eventtest.App;
import moe.heroman.eventtest.floatingservice.FloatingService;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i0 implements z0, d4.j, e4.f0, i3.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static i0 f122d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f123a;
    public Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f124c;

    public i0(int i7) {
        this.f123a = i7;
        int i8 = 0;
        switch (i7) {
            case 1:
                this.b = new ByteArrayOutputStream(bc.e);
                this.f124c = new ArrayDeque();
                break;
            case 10:
                this.b = new byte[]{48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};
                byte[] bArr = new byte[bc.f3796d];
                this.f124c = bArr;
                for (int i9 = 0; i9 < 128; i9++) {
                    bArr[i9] = -1;
                }
                while (true) {
                    byte[] bArr2 = (byte[]) this.b;
                    if (i8 >= bArr2.length) {
                        bArr[65] = bArr[97];
                        bArr[66] = bArr[98];
                        bArr[67] = bArr[99];
                        bArr[68] = bArr[100];
                        bArr[69] = bArr[101];
                        bArr[70] = bArr[102];
                    } else {
                        bArr[bArr2[i8]] = (byte) i8;
                        i8++;
                    }
                    break;
                }
                break;
            case 12:
                break;
            default:
                this.f124c = new HashMap();
                this.b = App.f6858a.getSharedPreferences(v.m.p.abcdstr(60), 0);
                break;
        }
    }

    public static synchronized i0 I() {
        try {
            if (f122d == null) {
                f122d = new i0(0);
            }
        } catch (Throwable th) {
            throw th;
        }
        return f122d;
    }

    public static void J(ByteArrayOutputStream byteArrayOutputStream, double d3) {
        byteArrayOutputStream.write(3);
        long jDoubleToLongBits = Double.doubleToLongBits(d3);
        for (int i7 = 7; i7 >= 0; i7--) {
            byteArrayOutputStream.write((int) ((jDoubleToLongBits >> (i7 * 8)) & 255));
        }
    }

    public static void K(ByteArrayOutputStream byteArrayOutputStream, long j7) {
        byteArrayOutputStream.write(2);
        M(byteArrayOutputStream, (j7 >> 63) ^ (j7 << 1));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [int] */
    /* JADX WARN: Type inference failed for: r3v3 */
    /* JADX WARN: Type inference failed for: r7v0, types: [java.io.ByteArrayOutputStream] */
    public static void L(ByteArrayOutputStream byteArrayOutputStream, a3.j jVar) {
        int i7 = jVar.f27a;
        switch (i7) {
            case 0:
                byteArrayOutputStream.write(0);
                break;
            case 1:
                ?? r32 = i7 == 1 ? jVar.f29d : 0;
                byteArrayOutputStream.write(1);
                byteArrayOutputStream.write(r32);
                break;
            case 2:
                K(byteArrayOutputStream, jVar.c(0L));
                break;
            case 3:
                J(byteArrayOutputStream, jVar.b(0.0d));
                break;
            case 4:
                String str = i7 == 4 ? jVar.e : "";
                byteArrayOutputStream.write(4);
                byte[] bytes = (str != null ? str : "").getBytes(StandardCharsets.UTF_8);
                M(byteArrayOutputStream, bytes.length);
                byteArrayOutputStream.write(bytes, 0, bytes.length);
                break;
            case 5:
                byteArrayOutputStream.write(5);
                HashMap map = jVar.f30f;
                int size = map != null ? map.size() : 0;
                M(byteArrayOutputStream, size + (jVar.f31g != null ? r4.size() : 0));
                HashMap map2 = jVar.f30f;
                if (map2 != null) {
                    for (Map.Entry entry : map2.entrySet()) {
                        M(byteArrayOutputStream, ((Integer) entry.getKey()).intValue());
                        L(byteArrayOutputStream, (a3.j) entry.getValue());
                    }
                }
                LinkedHashMap linkedHashMap = jVar.f31g;
                if (linkedHashMap != null) {
                    for (Map.Entry entry2 : linkedHashMap.entrySet()) {
                        M(byteArrayOutputStream, 0L);
                        byte[] bytes2 = ((String) entry2.getKey()).getBytes(StandardCharsets.UTF_8);
                        M(byteArrayOutputStream, bytes2.length);
                        byteArrayOutputStream.write(bytes2, 0, bytes2.length);
                        L(byteArrayOutputStream, (a3.j) entry2.getValue());
                    }
                }
                break;
            case 6:
                byteArrayOutputStream.write(6);
                List list = jVar.f32h;
                if (list == null) {
                    list = Collections.EMPTY_LIST;
                }
                M(byteArrayOutputStream, list.size());
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    L(byteArrayOutputStream, (a3.j) it.next());
                }
                break;
            default:
                byteArrayOutputStream.write(0);
                break;
        }
    }

    public static void M(ByteArrayOutputStream byteArrayOutputStream, long j7) {
        while (((-128) & j7) != 0) {
            byteArrayOutputStream.write((int) ((j7 & 127) | 128));
            j7 >>>= 7;
        }
        byteArrayOutputStream.write((int) (j7 & 127));
    }

    public static boolean s(Editable editable, KeyEvent keyEvent, boolean z6) {
        androidx.emoji2.text.u[] uVarArr;
        if (KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState())) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart == selectionEnd && (uVarArr = (androidx.emoji2.text.u[]) editable.getSpans(selectionStart, selectionEnd, androidx.emoji2.text.u.class)) != null && uVarArr.length > 0) {
                for (androidx.emoji2.text.u uVar : uVarArr) {
                    int spanStart = editable.getSpanStart(uVar);
                    int spanEnd = editable.getSpanEnd(uVar);
                    if ((z6 && spanStart == selectionStart) || ((!z6 && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                        editable.delete(spanStart, spanEnd);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void A(String str, ArrayList arrayList) {
        JSONArray jSONArray = new JSONArray();
        try {
            int size = arrayList.size();
            int i7 = 0;
            while (i7 < size) {
                Object obj = arrayList.get(i7);
                i7++;
                h0 h0Var = (h0) obj;
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("p", h0Var.f118a);
                jSONObject.put("c", h0Var.b);
                jSONObject.put("g", h0Var.f119c);
                jSONArray.put(jSONObject);
            }
            ((SharedPreferences) this.b).edit().putString(s.h.d(v.m.p.abcdstr(61), str), jSONArray.toString()).apply();
        } catch (Exception unused) {
        }
    }

    public void B(int i7, boolean z6) {
        w(i7);
        ByteArrayOutputStream byteArrayOutputStreamN = n();
        byteArrayOutputStreamN.write(1);
        byteArrayOutputStreamN.write(z6 ? 1 : 0);
        p();
    }

    public void C(String str, double d3) {
        ByteArrayOutputStream byteArrayOutputStreamN = n();
        M(byteArrayOutputStreamN, 0L);
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        M(byteArrayOutputStreamN, bytes.length);
        byteArrayOutputStreamN.write(bytes, 0, bytes.length);
        J(n(), d3);
        p();
    }

    public void D(int i7, long j7) {
        w(i7);
        K(n(), j7);
        p();
    }

    public void E(int i7, String str) {
        w(i7);
        ByteArrayOutputStream byteArrayOutputStreamN = n();
        byteArrayOutputStreamN.write(4);
        if (str == null) {
            str = "";
        }
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        M(byteArrayOutputStreamN, bytes.length);
        byteArrayOutputStreamN.write(bytes, 0, bytes.length);
        p();
    }

    public synchronized h0 F(String str, HashSet hashSet) {
        if (str != null && hashSet != null) {
            if (!hashSet.isEmpty()) {
                List<h0> listX = x(str);
                if (hashSet.size() >= 2) {
                    for (h0 h0Var : listX) {
                        if (!h0Var.a() && hashSet.contains(Integer.valueOf(h0Var.f118a)) && hashSet.contains(Integer.valueOf(h0Var.b))) {
                            return h0Var;
                        }
                    }
                }
                for (h0 h0Var2 : listX) {
                    if (h0Var2.a() && hashSet.contains(Integer.valueOf(h0Var2.f118a))) {
                        return h0Var2;
                    }
                }
                return null;
            }
        }
        return null;
    }

    public synchronized void G(int i7, int i8, String str, String str2) {
        int iMin;
        int i9;
        if (str == null || str2 == null || i7 <= 0 || i8 < 0 || i7 == i8) {
            return;
        }
        if (i8 > 0) {
            try {
                iMin = Math.min(i7, i8);
            } catch (Throwable th) {
                throw th;
            }
        } else {
            iMin = i7;
        }
        int iMax = i8 > 0 ? Math.max(i7, i8) : 0;
        List<h0> listX = x(str);
        ArrayList arrayList = new ArrayList();
        for (h0 h0Var : listX) {
            if (!h0Var.f119c.equals(str2) && (h0Var.f118a != iMin || h0Var.b != iMax)) {
                if (iMax != 0 || h0Var.a() || (h0Var.f118a != iMin && h0Var.b != iMin)) {
                    if (iMax <= 0 || !h0Var.a() || ((i9 = h0Var.f118a) != iMin && i9 != iMax)) {
                        arrayList.add(h0Var);
                    }
                }
            }
        }
        arrayList.add(new h0(str2, iMin, iMax));
        ((HashMap) this.f124c).put(str, arrayList);
        A(str, arrayList);
    }

    public void H(int i7, int i8, int i9, int i10) {
        CardView cardView = (CardView) this.f124c;
        cardView.f990d.set(i7, i8, i9, i10);
        Rect rect = cardView.f989c;
        CardView.a(cardView, i7 + rect.left, i8 + rect.top, i9 + rect.right, i10 + rect.bottom);
    }

    @Override // a4.z0, d4.j, e4.f0
    public void a(String str) {
        switch (this.f123a) {
            case 2:
                ((z0) ((y0) this.f124c).f272c).a(str);
                break;
            case 6:
                ((d4.j) ((y0) this.f124c).f272c).a(str);
                break;
            case dd.f4082h /* 7 */:
                e4.s sVar = (e4.s) this.f124c;
                e4.s.k(sVar.f5447p, false);
                sVar.f5447p = null;
                e4.s.i(sVar.getContext().getString(2131820636) + v.m.p.abcdstr(62) + str);
                sVar.m();
                break;
            case 14:
                ((f4.d) this.b).run();
                break;
            default:
                FloatingService.f6880k.a(((y3.t) this.f124c).f8245a.getString(2131820692));
                break;
        }
    }

    @Override // a4.z0, d4.j, e4.f0
    public void b() {
        h3.l1 l1Var;
        switch (this.f123a) {
            case 2:
                y0 y0Var = (y0) this.f124c;
                d1 d1Var = (d1) y0Var.e;
                String str = ((c1) y0Var.b).f71c;
                String str2 = ((e1) this.b).b;
                if (d1Var.f87l != null) {
                    d1Var.f79c.post(new a3.f(d1Var, str, str2, 3));
                }
                ((z0) y0Var.f272c).b();
                break;
            case 6:
                y0 y0Var2 = (y0) this.f124c;
                d4.m mVar = (d4.m) y0Var2.e;
                String str3 = ((c1) y0Var2.b).f71c;
                String str4 = ((e4.x) this.b).b;
                if (mVar.f5275l != null) {
                    mVar.f5267c.post(new a3.f(mVar, str3, str4, 16));
                }
                ((d4.j) y0Var2.f272c).b();
                break;
            case dd.f4082h /* 7 */:
                e4.s sVar = (e4.s) this.f124c;
                sVar.f5447p = null;
                e4.i0 i0Var = (e4.i0) this.b;
                sVar.f5446o = i0Var;
                e4.r rVar = sVar.f5449r;
                if (rVar != null) {
                    ((h) rVar).b();
                }
                k3.t.e().c(k3.m.f6583a);
                sVar.e(sVar.f5440i);
                sVar.f5446o = i0Var;
                sVar.m();
                break;
            case 14:
                ((y3.l) this.f124c).b.h();
                ((f4.d) this.b).run();
                break;
            default:
                y3.t tVar = (y3.t) this.f124c;
                y3.p pVar = tVar.f9126d;
                if (pVar != null) {
                    pVar.h();
                }
                y3.t.o(tVar);
                FloatingService floatingService = FloatingService.f6880k;
                if (floatingService != null) {
                    k3.l lVar = floatingService.f6885g;
                    if (lVar != null && (l1Var = lVar.f6573q) != null) {
                        l1Var.postInvalidate();
                    }
                    floatingService.a(tVar.f8245a.getString(2131820693, (String) this.b));
                }
                break;
        }
    }

    public void c() {
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(false));
    }

    public void d(double d3) {
        J(n(), d3);
        p();
    }

    public void e() {
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(true));
    }

    public void f(int i7) {
        w(i7);
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(false));
    }

    public void g(String str) {
        ByteArrayOutputStream byteArrayOutputStreamN = n();
        M(byteArrayOutputStreamN, 0L);
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        M(byteArrayOutputStreamN, bytes.length);
        byteArrayOutputStreamN.write(bytes, 0, bytes.length);
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(false));
    }

    public void h(String str) {
        ByteArrayOutputStream byteArrayOutputStreamN = n();
        M(byteArrayOutputStreamN, 0L);
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        M(byteArrayOutputStreamN, bytes.length);
        byteArrayOutputStreamN.write(bytes, 0, bytes.length);
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(true));
    }

    @Override // i3.a
    public void i(int i7) {
        int i8;
        n3.c cVar = (n3.c) this.f124c;
        Button button = (Button) this.b;
        j3.b bVar = cVar.f6959a;
        if (i7 != bVar.f6413d && ((i8 = bVar.f6368q) <= 0 || i7 != i8)) {
            bVar.f6367p = i7;
            cVar.e(button);
            cVar.f();
        } else {
            FloatingService floatingService = FloatingService.f6880k;
            if (floatingService != null) {
                floatingService.a(cVar.getContext().getString(2131821344));
            }
            cVar.e(button);
        }
    }

    @Override // i3.a
    public void j() {
        ((n3.c) this.f124c).e((Button) this.b);
    }

    public void k(int i7) {
        w(i7);
        p();
        ((ArrayDeque) this.f124c).push(new a3.k(true));
    }

    public void l() {
        ((ArrayDeque) this.f124c).push(new a3.k(false));
    }

    public void m() {
        ((ArrayDeque) this.f124c).push(new a3.k(true));
    }

    public ByteArrayOutputStream n() {
        return ((a3.k) ((ArrayDeque) this.f124c).peek()).b;
    }

    @Override // i3.a
    public void o(int i7, int i8) {
        n3.c cVar = (n3.c) this.f124c;
        FloatingService floatingService = FloatingService.f6880k;
        if (floatingService != null) {
            floatingService.a(cVar.getContext().getString(2131821345));
        }
        cVar.e((Button) this.b);
    }

    public void p() {
        ((a3.k) ((ArrayDeque) this.f124c).peek()).f34c++;
    }

    public synchronized void q(String str, String str2) {
        if (str == null || str2 == null) {
            return;
        }
        try {
            List<h0> listX = x(str);
            ArrayList arrayList = new ArrayList();
            boolean z6 = false;
            for (h0 h0Var : listX) {
                if (h0Var.f119c.equals(str2)) {
                    z6 = true;
                } else {
                    arrayList.add(h0Var);
                }
            }
            if (z6) {
                ((HashMap) this.f124c).put(str, arrayList);
                A(str, arrayList);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public byte[] r(int i7, String str) throws IOException {
        String strAbcdstr;
        byte[] bArr = (byte[]) this.f124c;
        if (i7 >= 0) {
            int i8 = 1;
            if (1 <= str.length() - i7) {
                if ((i7 & 1) == 0) {
                    int i9 = i7 >>> 1;
                    byte[] bArr2 = new byte[i9];
                    for (int i10 = 0; i10 < i9; i10++) {
                        int i11 = i8 + 1;
                        byte b = bArr[str.charAt(i8)];
                        i8 += 2;
                        int i12 = bArr[str.charAt(i11)] | (b << 4);
                        if (i12 >= 0) {
                            bArr2[i10] = (byte) i12;
                        } else {
                            strAbcdstr = v.m.p.abcdstr(63);
                        }
                    }
                    return bArr2;
                }
                strAbcdstr = v.m.p.abcdstr(64);
                f3.v(strAbcdstr);
                return null;
            }
        }
        throw new IndexOutOfBoundsException(v.m.p.abcdstr(65));
    }

    public void t() {
        ArrayDeque arrayDeque = (ArrayDeque) this.f124c;
        a3.k kVar = (a3.k) arrayDeque.pop();
        ByteArrayOutputStream byteArrayOutputStream = arrayDeque.isEmpty() ? (ByteArrayOutputStream) this.b : ((a3.k) arrayDeque.peek()).b;
        byteArrayOutputStream.write(kVar.f33a ? 5 : 6);
        M(byteArrayOutputStream, kVar.f34c);
        byte[] byteArray = kVar.b.toByteArray();
        byteArrayOutputStream.write(byteArray, 0, byteArray.length);
    }

    public String toString() {
        switch (this.f123a) {
            case 8:
                return v.m.p.abcdstr(66) + ((x.c) this.b) + v.m.p.abcdstr(67) + ((x.c) this.f124c) + v.m.p.abcdstr(68);
            default:
                return super.toString();
        }
    }

    public synchronized int[] u(String str, String str2) {
        if (str == null || str2 == null) {
            return null;
        }
        try {
            for (h0 h0Var : x(str)) {
                if (str2.equals(h0Var.f119c)) {
                    boolean zA = h0Var.a();
                    int i7 = h0Var.f118a;
                    return zA ? new int[]{i7} : new int[]{i7, h0Var.b};
                }
            }
            return null;
        } catch (Throwable th) {
            throw th;
        }
    }

    public boolean v(CharSequence charSequence, int i7, int i8, androidx.emoji2.text.n nVar) {
        if (nVar.f1127c == 0) {
            androidx.emoji2.text.c cVar = (androidx.emoji2.text.c) this.f124c;
            m0.a aVarB = nVar.b();
            int iA = aVarB.a(8);
            if (iA != 0) {
                ((ByteBuffer) aVarB.f5600d).getShort(iA + aVarB.f5598a);
            }
            cVar.getClass();
            ThreadLocal threadLocal = androidx.emoji2.text.c.b;
            if (threadLocal.get() == null) {
                threadLocal.set(new StringBuilder());
            }
            StringBuilder sb = (StringBuilder) threadLocal.get();
            sb.setLength(0);
            while (i7 < i8) {
                sb.append(charSequence.charAt(i7));
                i7++;
            }
            TextPaint textPaint = cVar.f1107a;
            String string = sb.toString();
            int i9 = x.e.f8675a;
            nVar.f1127c = x.d.a(textPaint, string) ? 2 : 1;
        }
        return nVar.f1127c == 2;
    }

    public void w(int i7) {
        M(n(), i7);
    }

    public List x(String str) {
        HashMap map = (HashMap) this.f124c;
        List list = (List) map.get(str);
        if (list != null) {
            return list;
        }
        ArrayList arrayList = new ArrayList();
        String string = ((SharedPreferences) this.b).getString(v.m.p.abcdstr(61) + str, null);
        if (string != null) {
            try {
                JSONArray jSONArray = new JSONArray(string);
                for (int i7 = 0; i7 < jSONArray.length(); i7++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i7);
                    int iOptInt = jSONObject.optInt("p", -1);
                    int iOptInt2 = jSONObject.optInt("c", -1);
                    String strOptString = jSONObject.optString("g", null);
                    if (iOptInt > 0 && iOptInt2 >= 0 && iOptInt2 != iOptInt && strOptString != null && !strOptString.isEmpty()) {
                        arrayList.add(iOptInt2 > 0 ? new h0(strOptString, Math.min(iOptInt, iOptInt2), Math.max(iOptInt, iOptInt2)) : new h0(strOptString, iOptInt, 0));
                    }
                }
            } catch (Exception unused) {
            }
        }
        map.put(str, arrayList);
        return arrayList;
    }

    public void y(c0.g gVar) {
        Handler handler = (Handler) this.f124c;
        g.d dVar = (g.d) this.b;
        int i7 = gVar.b;
        if (i7 == 0) {
            handler.post(new androidx.fragment.app.c(dVar, 1, gVar.f2111a));
        } else {
            handler.post(new androidx.emoji2.text.h(dVar, i7, 2));
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:144:0x020f, code lost:
    
        continue;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0116 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x010f A[Catch: IOException -> 0x0097, XmlPullParserException -> 0x009a, TryCatch #2 {IOException -> 0x0097, XmlPullParserException -> 0x009a, blocks: (B:19:0x0068, B:96:0x020f, B:27:0x007a, B:28:0x0088, B:30:0x008d, B:37:0x009d, B:45:0x00b7, B:40:0x00a6, B:43:0x00af, B:46:0x00c5, B:50:0x00d4, B:52:0x00dc, B:53:0x00e6, B:62:0x010f, B:63:0x0116, B:64:0x012e, B:56:0x00ef, B:58:0x00f7, B:59:0x0105, B:65:0x012f, B:67:0x0137, B:68:0x0145, B:71:0x014f, B:72:0x015a, B:73:0x0172, B:74:0x0173, B:77:0x017d, B:78:0x0188, B:79:0x01a0, B:80:0x01a1, B:82:0x01a9, B:83:0x01b2, B:86:0x01bc, B:87:0x01c6, B:88:0x01de, B:89:0x01df, B:92:0x01e9, B:93:0x01f3, B:94:0x020b, B:95:0x020c), top: B:104:0x0068 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void z(android.content.Context r10, android.content.res.XmlResourceParser r11) {
        /*
            Method dump skipped, instruction units count: 614
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.i0.z(android.content.Context, android.content.res.XmlResourceParser):void");
    }

    public /* synthetic */ i0(Object obj, Object obj2, int i7, boolean z6) {
        this.f123a = i7;
        this.b = obj;
        this.f124c = obj2;
    }

    public /* synthetic */ i0(Object obj, int i7, Object obj2) {
        this.f123a = i7;
        this.f124c = obj;
        this.b = obj2;
    }

    public i0(y0 y0Var, y1.e eVar, androidx.emoji2.text.c cVar) {
        this.f123a = 3;
        this.b = y0Var;
        this.f124c = cVar;
    }

    public i0(ArrayList arrayList, ArrayList arrayList2) {
        this.f123a = 13;
        int size = arrayList.size();
        this.b = new int[size];
        this.f124c = new float[size];
        for (int i7 = 0; i7 < size; i7++) {
            ((int[]) this.b)[i7] = ((Integer) arrayList.get(i7)).intValue();
            ((float[]) this.f124c)[i7] = ((Float) arrayList2.get(i7)).floatValue();
        }
    }

    public i0(int i7, int i8) {
        this.f123a = 13;
        this.b = new int[]{i7, i8};
        this.f124c = new float[]{0.0f, 1.0f};
    }

    public i0(int i7, int i8, int i9) {
        this.f123a = 13;
        this.b = new int[]{i7, i8, i9};
        this.f124c = new float[]{0.0f, 0.5f, 1.0f};
    }

    public i0(androidx.viewpager2.adapter.d dVar, androidx.fragment.app.u uVar, FrameLayout frameLayout) {
        this.f123a = 4;
        this.b = uVar;
        this.f124c = frameLayout;
    }

    public i0(CardView cardView) {
        this.f123a = 9;
        this.f124c = cardView;
    }
}
