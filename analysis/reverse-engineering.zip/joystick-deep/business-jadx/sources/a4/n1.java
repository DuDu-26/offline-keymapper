package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class n1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f178a;
    public final /* synthetic */ s1 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f179c;

    public /* synthetic */ n1(s1 s1Var, String str, int i7) {
        this.f178a = i7;
        this.b = s1Var;
        this.f179c = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f178a) {
            case 0:
                s1 s1Var = this.b;
                if (s1Var != null) {
                    s1Var.a(this.f179c);
                }
                break;
            default:
                this.b.a(this.f179c);
                break;
        }
    }
}
