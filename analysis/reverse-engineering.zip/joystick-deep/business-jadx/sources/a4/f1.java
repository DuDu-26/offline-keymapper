package a4;

import android.net.Uri;
import com.efs.sdk.memleaksdk.monitor.internal.h4;
import com.umeng.analytics.pro.dd;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import moe.heroman.eventtest.adbhelper.AdbClient;
import moe.heroman.eventtest.adbhelper.AdbKey;
import moe.heroman.eventtest.adbhelper.AdbPairingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class f1 implements e4.j, g0.d, p2.l, m3.e, h3.l0, AdbClient.ShellOutputListener, l4.b, androidx.lifecycle.y, n3.a1, androidx.activity.result.a, p4.p, p2.p, com.google.android.material.navigation.j, u3.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f108a;
    public final /* synthetic */ Object b;

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ f1(p2.a aVar) {
        this.f108a = 18;
        this.b = (q2.d) aVar;
    }

    @Override // l4.b
    public int a(AdbKey adbKey) {
        y2.o oVar = (y2.o) this.b;
        oVar.getClass();
        int iB = e4.r0.B();
        if (iB > 0) {
            return iB;
        }
        ((l4.g) oVar.b).a(v.m.p.abcdstr(55));
        return -1;
    }

    @Override // n3.a1
    public void b() {
        n3.v0 v0Var = (n3.v0) this.b;
        j3.t tVar = v0Var.f7108a;
        ArrayList arrayList = new ArrayList(v0Var.e);
        tVar.getClass();
        tVar.f6461q = new ArrayList(arrayList);
        v0Var.j();
    }

    @Override // androidx.activity.result.a
    public void c(Object obj) {
        o3.u uVar = (o3.u) this.b;
        Uri uri = (Uri) obj;
        if (uri != null) {
            m4.g.f6856a.execute(new l4.a(uVar, v.m.p.getOrigApplicationContext(uVar.I().getApplicationContext()), uri, 3));
        }
    }

    @Override // p4.p
    public p4.q create(p4.d dVar) {
        return (p4.q) this.b;
    }

    @Override // u3.a
    public void d(int i7, q3.b bVar) {
        ((p3.f) this.b).c(i7, bVar);
    }

    @Override // androidx.lifecycle.y
    public void e(Object obj) {
        AdbPairingService.b((AdbPairingService) this.b, (Integer) obj);
    }

    public void f(float f2) {
        switch (this.f108a) {
            case 0:
                i1 i1Var = (i1) this.b;
                z1 z1Var = i1Var.f132i;
                if (z1Var != null) {
                    z1Var.f296c = Math.max(f2 / 2.0f, 25.0f);
                    i1Var.invalidate();
                    break;
                }
                break;
            default:
                e4.l0 l0Var = (e4.l0) this.b;
                e4.m0 m0Var = l0Var.f5400f;
                if (m0Var != null) {
                    m0Var.e(f2);
                    l0Var.e(l0Var.f5400f);
                    l0Var.invalidate();
                    break;
                }
                break;
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [p2.a, q2.d] */
    @Override // p2.l
    public Object invoke(Object obj) {
        switch (this.f108a) {
            case dd.f4082h /* 7 */:
                return obj == ((h2.a) this.b) ? v.m.p.abcdstr(56) : String.valueOf(obj);
            case 18:
                ?? r02 = (q2.d) this.b;
                obj.getClass();
                return r02.invoke();
            case 19:
                h4 h4Var = (h4) this.b;
                h2.s sVar = (h2.s) obj;
                sVar.getClass();
                Boolean bool = (Boolean) h4Var.invoke(Integer.valueOf(sVar.f5910a), sVar.b);
                bool.getClass();
                return bool;
            default:
                return ((w2.f) this.b).b(((Integer) obj).intValue());
        }
    }

    @Override // moe.heroman.eventtest.adbhelper.AdbClient.ShellOutputListener
    public void onData(byte[] bArr) {
        try {
            ((ByteArrayOutputStream) this.b).write(bArr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public /* synthetic */ f1(int i7, Object obj) {
        this.f108a = i7;
        this.b = obj;
    }

    @Override // p2.p
    public Object invoke(Object obj, Object obj2) {
        int iF0 = w2.g.f0((CharSequence) obj, (char[]) this.b, ((Integer) obj2).intValue(), false);
        if (iF0 < 0) {
            return null;
        }
        return new g2.b(Integer.valueOf(iF0), 1);
    }
}
