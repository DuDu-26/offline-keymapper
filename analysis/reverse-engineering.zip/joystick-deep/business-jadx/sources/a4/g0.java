package a4;

import java.io.Serializable;
import java.util.List;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class g0 extends h3.b {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public i1 f111m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public d2 f112n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public y1 f113o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f114p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public f0 f115q;

    public i1 getCanvasView() {
        return this.f111m;
    }

    public List<z1> getNodes() {
        i1 i1Var = this.f111m;
        if (i1Var != null) {
            return i1Var.getNodes();
        }
        return null;
    }

    public final int k(int i7) {
        return Math.round(i7 * getResources().getDisplayMetrics().density);
    }

    public final boolean l() {
        FloatingService floatingService;
        String str;
        i1 i1Var = this.f111m;
        boolean z6 = false;
        if (i1Var != null) {
            i1Var.f126a.clear();
            i1Var.b = -1;
            i1Var.f132i = null;
            n4.a aVar = i1Var.f131h;
            aVar.f7161q = false;
            aVar.f7162r = false;
            aVar.f7160p = false;
            i1Var.invalidate();
            u1 u1VarN = u1.n();
            if (u1VarN.f250g != null && (str = u1VarN.f249f) != null) {
                w3.e eVar = new w3.e(5, i1Var);
                String str2 = u1VarN.f248d;
                if (str2 != null) {
                    u1VarN.b.execute(new n0((Object) u1VarN, str2, (Serializable) str, (Object) eVar, 6));
                } else {
                    u1VarN.f247c.post(new o1(0, eVar));
                }
                z6 = true;
            }
            if (!z6 && (floatingService = FloatingService.f6880k) != null) {
                floatingService.a(getContext().getString(2131821034));
            }
        }
        return z6;
    }

    public void setOnToolbarActionListener(f0 f0Var) {
        this.f115q = f0Var;
    }
}
