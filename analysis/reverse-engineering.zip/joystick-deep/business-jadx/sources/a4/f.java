package a4;

import android.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.UMErrorCode;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.util.ArrayList;
import java.util.HashSet;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class f implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f105a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f106c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f107d;

    public /* synthetic */ f(o3.d0 d0Var, EditText editText, Context context, AlertDialog alertDialog) {
        this.f105a = 14;
        this.f106c = editText;
        this.b = context;
        this.f107d = alertDialog;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        h3.u uVar;
        h3.m0 m0Var;
        ArrayList arrayList;
        int iIndexOf;
        switch (this.f105a) {
            case 0:
                t tVar = (t) this.b;
                EditText editText = (EditText) this.f106c;
                e1 e1Var = (e1) this.f107d;
                String strTrim = editText.getText().toString().trim();
                if (strTrim.isEmpty() || strTrim.equals(e1Var.b)) {
                    tVar.i(tVar.f220g);
                } else if (d1.u().c(strTrim)) {
                    FloatingService.f6880k.a(tVar.getContext().getString(2131820637));
                } else {
                    d1 d1VarU = d1.u();
                    String str = e1Var.f100a;
                    o oVar = new o(tVar, 2);
                    if (d1VarU.f80d == null) {
                        d1VarU.f79c.post(new p(oVar, 1));
                    } else {
                        e1 e1VarE = d1VarU.e(str);
                        if (e1VarE == null || e1VarE.f101c) {
                            d1VarU.f79c.post(new p(oVar, 2));
                        } else {
                            d1VarU.b.execute(new w0(d1VarU, d1VarU.f80d, str, oVar, strTrim, e1VarE, 0));
                        }
                    }
                }
                break;
            case 1:
                ((t) this.b).j((TextView) this.f106c, (String) this.f107d);
                break;
            case 2:
                t tVar2 = (t) this.b;
                e1 e1Var2 = (e1) this.f107d;
                String str2 = e1Var2.f100a;
                LinearLayout linearLayout = (LinearLayout) this.f106c;
                if (tVar2.f233t == null) {
                    e1 e1Var3 = tVar2.f232s;
                    if (e1Var3 == null || !e1Var3.f100a.equals(str2)) {
                        tVar2.f233t = linearLayout;
                        t.m(linearLayout, true);
                        t.k(tVar2.f225l, false);
                        t.k(tVar2.f226m, false);
                        t.k(tVar2.f227n, false);
                        d1.u().j(str2, new w3.b(tVar2, 1, e1Var2));
                    }
                    break;
                }
                break;
            case 3:
                c0 c0Var = (c0) this.b;
                v1 v1Var = (v1) this.f106c;
                String str3 = v1Var.f257a;
                LinearLayout linearLayout2 = (LinearLayout) this.f107d;
                if (c0Var.f67q == null) {
                    v1 v1Var2 = c0Var.f66p;
                    if (v1Var2 == null || !v1Var2.f257a.equals(str3)) {
                        c0Var.f67q = linearLayout2;
                        c0.l(linearLayout2, true);
                        c0.j(c0Var.f62l, false);
                        c0.j(c0Var.f63m, false);
                        c0.j(c0Var.f64n, false);
                        u1.n().h(str3, new y2.o(c0Var, 1, v1Var));
                    }
                    break;
                }
                break;
            case 4:
                ((c0) this.b).i((TextView) this.f106c, (String) this.f107d);
                break;
            case 5:
                c0 c0Var2 = (c0) this.b;
                EditText editText2 = (EditText) this.f106c;
                v1 v1Var3 = (v1) this.f107d;
                String strTrim2 = editText2.getText().toString().trim();
                if (strTrim2.isEmpty() || strTrim2.equals(v1Var3.b)) {
                    c0Var2.h(c0Var2.f57g);
                } else if (u1.n().b(strTrim2)) {
                    FloatingService.f6880k.a(c0Var2.getContext().getString(2131820637));
                } else {
                    u1 u1VarN = u1.n();
                    String str4 = v1Var3.f257a;
                    y yVar = new y(c0Var2, 3);
                    Handler handler = u1VarN.f247c;
                    if (u1VarN.f248d == null) {
                        handler.post(new z(yVar, 1));
                    } else {
                        v1 v1VarD = u1VarN.d(str4);
                        if (v1VarD == null || v1VarD.f258c) {
                            handler.post(new z(yVar, 2));
                        } else {
                            u1VarN.b.execute(new w0(u1VarN, u1VarN.f248d, str4, yVar, strTrim2, v1VarD, 1));
                        }
                    }
                }
                break;
            case 6:
                e4.k kVar = (e4.k) this.b;
                e4.x xVar = (e4.x) this.f106c;
                String str5 = xVar.f5480a;
                LinearLayout linearLayout3 = (LinearLayout) this.f107d;
                if (kVar.f5392p == null) {
                    e4.x xVar2 = kVar.f5391o;
                    if (xVar2 == null || !xVar2.f5480a.equals(str5)) {
                        kVar.f5392p = linearLayout3;
                        e4.k.k(linearLayout3, true);
                        e4.k.h(kVar.f5387k, false);
                        e4.k.h(kVar.f5388l, false);
                        e4.k.h(kVar.f5389m, false);
                        d4.m.t().h(str5, new y2.o(kVar, 6, xVar));
                    }
                    break;
                }
                break;
            case dd.f4082h /* 7 */:
                e4.k kVar2 = (e4.k) this.b;
                EditText editText3 = (EditText) this.f106c;
                e4.x xVar3 = (e4.x) this.f107d;
                String strTrim3 = editText3.getText().toString().trim();
                if (strTrim3.isEmpty() || strTrim3.equals(xVar3.b)) {
                    kVar2.g(kVar2.f5395s);
                } else if (d4.m.t().b(strTrim3)) {
                    e4.k.i(kVar2.getContext().getString(2131820637));
                } else {
                    d4.m mVarT = d4.m.t();
                    String str6 = xVar3.f5480a;
                    final e4.h hVar = new e4.h(kVar2, 0);
                    Handler handler2 = mVarT.f5267c;
                    if (mVarT.f5268d == null) {
                        final int i7 = 0;
                        handler2.post(new Runnable() { // from class: d4.i
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i7) {
                                    case 0:
                                        hVar.a(v.m.p.abcdstr(31));
                                        break;
                                    default:
                                        hVar.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                                        break;
                                }
                            }
                        });
                    } else {
                        e4.x xVarD = mVarT.d(str6);
                        if (xVarD == null || xVarD.f5481c) {
                            final int i8 = 1;
                            handler2.post(new Runnable() { // from class: d4.i
                                @Override // java.lang.Runnable
                                public final void run() {
                                    switch (i8) {
                                        case 0:
                                            hVar.a(v.m.p.abcdstr(31));
                                            break;
                                        default:
                                            hVar.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                                            break;
                                    }
                                }
                            });
                        } else {
                            mVarT.b.execute(new w0(mVarT, mVarT.f5268d, str6, hVar, strTrim3, xVarD, 2));
                        }
                    }
                }
                break;
            case 8:
                e4.s sVar = (e4.s) this.b;
                e4.i0 i0Var = (e4.i0) this.f106c;
                String str7 = i0Var.f5375a;
                LinearLayout linearLayout4 = (LinearLayout) this.f107d;
                if (sVar.f5447p == null) {
                    e4.i0 i0Var2 = sVar.f5446o;
                    if (i0Var2 == null || !i0Var2.f5375a.equals(str7)) {
                        sVar.f5447p = linearLayout4;
                        e4.s.k(linearLayout4, true);
                        e4.s.h(sVar.f5442k, false);
                        e4.s.h(sVar.f5443l, false);
                        e4.s.h(sVar.f5444m, false);
                        e4.h0.o().i(str7, new i0(sVar, 7, i0Var));
                    }
                    break;
                }
                break;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                e4.s sVar2 = (e4.s) this.b;
                EditText editText4 = (EditText) this.f106c;
                e4.i0 i0Var3 = (e4.i0) this.f107d;
                String strTrim4 = editText4.getText().toString().trim();
                if (strTrim4.isEmpty() || strTrim4.equals(i0Var3.b)) {
                    sVar2.g(sVar2.f5450s);
                } else if (e4.h0.o().b(strTrim4)) {
                    e4.s.i(sVar2.getContext().getString(2131820637));
                } else {
                    e4.h0 h0VarO = e4.h0.o();
                    String str8 = i0Var3.f5375a;
                    final e4.p pVar = new e4.p(sVar2, 0);
                    Handler handler3 = h0VarO.f5368c;
                    if (h0VarO.f5369d == null) {
                        final int i9 = 0;
                        handler3.post(new Runnable() { // from class: e4.a0
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i9) {
                                    case 0:
                                        pVar.a(v.m.p.abcdstr(31));
                                        break;
                                    default:
                                        pVar.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                                        break;
                                }
                            }
                        });
                    } else {
                        e4.i0 i0VarE = h0VarO.e(str8);
                        if (i0VarE == null || i0VarE.f5376c) {
                            final int i10 = 1;
                            handler3.post(new Runnable() { // from class: e4.a0
                                @Override // java.lang.Runnable
                                public final void run() {
                                    switch (i10) {
                                        case 0:
                                            pVar.a(v.m.p.abcdstr(31));
                                            break;
                                        default:
                                            pVar.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                                            break;
                                    }
                                }
                            });
                        } else {
                            h0VarO.b.execute(new w0(h0VarO, h0VarO.f5369d, str8, pVar, strTrim4, i0VarE, 3));
                        }
                    }
                }
                break;
            case 10:
                h3.r rVar = (h3.r) this.b;
                h3.c cVar = (h3.c) this.f106c;
                String str9 = cVar.f5934a;
                LinearLayout linearLayout5 = (LinearLayout) this.f107d;
                if (rVar.f6109q == null) {
                    h3.c cVar2 = rVar.f6108p;
                    if (cVar2 == null || !cVar2.f5934a.equals(str9)) {
                        rVar.f6109q = linearLayout5;
                        h3.r.m(linearLayout5, true);
                        h3.r.j(rVar.f6104l, false);
                        h3.r.j(rVar.f6105m, false);
                        h3.r.j(rVar.f6106n, false);
                        h3.j1.m().g(str9, new w3.b(rVar, 8, cVar));
                    }
                    break;
                }
                break;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                h3.r rVar2 = (h3.r) this.b;
                EditText editText5 = (EditText) this.f106c;
                h3.c cVar3 = (h3.c) this.f107d;
                String strTrim5 = editText5.getText().toString().trim();
                if (strTrim5.isEmpty() || strTrim5.equals(cVar3.b)) {
                    rVar2.i(rVar2.f6112t);
                } else if (h3.j1.m().b(strTrim5)) {
                    h3.r.k(rVar2.getContext().getString(2131820637));
                } else {
                    h3.j1 j1VarM = h3.j1.m();
                    String str10 = cVar3.f5934a;
                    final h3.o oVar2 = new h3.o(rVar2, 0);
                    Handler handler4 = j1VarM.f6019c;
                    if (j1VarM.f6020d == null) {
                        final int i11 = 0;
                        handler4.post(new Runnable() { // from class: h3.d1
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i11) {
                                    case 0:
                                        oVar2.a(v.m.p.abcdstr(31));
                                        break;
                                    case 1:
                                        oVar2.a(v.m.p.abcdstr(71));
                                        break;
                                    default:
                                        oVar2.a(v.m.p.abcdstr(4982));
                                        break;
                                }
                            }
                        });
                    } else {
                        h3.c cVarE = j1VarM.e(str10);
                        if (cVarE == null) {
                            final int i12 = 1;
                            handler4.post(new Runnable() { // from class: h3.d1
                                @Override // java.lang.Runnable
                                public final void run() {
                                    switch (i12) {
                                        case 0:
                                            oVar2.a(v.m.p.abcdstr(31));
                                            break;
                                        case 1:
                                            oVar2.a(v.m.p.abcdstr(71));
                                            break;
                                        default:
                                            oVar2.a(v.m.p.abcdstr(4982));
                                            break;
                                    }
                                }
                            });
                        } else {
                            ArrayList arrayList2 = j1VarM.e;
                            int size = arrayList2.size();
                            int i13 = 0;
                            while (i13 < size) {
                                Object obj = arrayList2.get(i13);
                                i13++;
                                h3.c cVar4 = (h3.c) obj;
                                if (!cVar4.f5934a.equals(str10) && cVar4.b.equalsIgnoreCase(strTrim5)) {
                                    final int i14 = 2;
                                    handler4.post(new Runnable() { // from class: h3.d1
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i14) {
                                                case 0:
                                                    oVar2.a(v.m.p.abcdstr(31));
                                                    break;
                                                case 1:
                                                    oVar2.a(v.m.p.abcdstr(71));
                                                    break;
                                                default:
                                                    oVar2.a(v.m.p.abcdstr(4982));
                                                    break;
                                            }
                                        }
                                    });
                                    break;
                                }
                            }
                            j1VarM.b.execute(new w0(j1VarM, j1VarM.f6020d, str10, oVar2, strTrim5, cVarE, 5));
                        }
                    }
                }
                break;
            case 12:
                h3.y yVar2 = (h3.y) this.b;
                j3.o oVar3 = (j3.o) this.f106c;
                TextView textView = (TextView) this.f107d;
                String str11 = oVar3.f6421a;
                if (!str11.equals(yVar2.f6151l)) {
                    if ((v.m.p.abcdstr(57).equals(str11) || v.m.p.abcdstr(58).equals(str11)) && (uVar = yVar2.f6153n) != null) {
                        j3.k kVar3 = yVar2.f6146g;
                        h3.o0 o0Var = ((k3.f) uVar).f6553a.f6569m;
                        if (o0Var != null) {
                            for (j3.k kVar4 : o0Var.getNodes()) {
                                if (kVar4 != kVar3 && str11.equals(kVar4.g())) {
                                    if (yVar2.f6154o != null) {
                                        String strC = j3.p.d().c(yVar2.getContext(), str11);
                                        ((k3.f) yVar2.f6154o).f6553a.l(yVar2.getContext().getString(2131820961, strC));
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    j3.k kVarA = j3.p.d().a(str11);
                    if (kVarA != 0) {
                        kVarA.n(yVar2.f6145f.f6412c);
                        int i15 = yVar2.f6145f.f6413d;
                        if (i15 > 0) {
                            kVarA.p(i15);
                        }
                        Object obj2 = yVar2.f6145f;
                        if ((obj2 instanceof j3.a) && (kVarA instanceof j3.a)) {
                            ((j3.a) kVarA).c(((j3.a) obj2).b());
                        }
                        yVar2.f6145f = kVarA;
                        yVar2.f6151l = str11;
                        h3.w wVar = yVar2.f6148i;
                        if (wVar != null) {
                            j3.k kVar5 = yVar2.f6146g;
                            h3.o0 o0Var2 = ((k3.f) wVar).f6553a.f6569m;
                            if (o0Var2 != null && (iIndexOf = (arrayList = (m0Var = o0Var2.f6070n).f6042a).indexOf(kVar5)) != -1) {
                                arrayList.set(iIndexOf, kVarA);
                                if (m0Var.b == kVar5) {
                                    m0Var.b = kVarA;
                                }
                                m0Var.invalidate();
                            }
                            yVar2.f6146g = yVar2.f6145f;
                        }
                        j3.j jVar = yVar2.f6147h;
                        if (jVar != null) {
                            jVar.e(yVar2.f6145f);
                        }
                        yVar2.a();
                        TextView textView2 = yVar2.f6152m;
                        if (textView2 != null) {
                            textView2.setBackgroundColor(0);
                            TypedArray typedArrayObtainStyledAttributes = yVar2.getContext().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
                            int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
                            typedArrayObtainStyledAttributes.recycle();
                            if (resourceId != 0) {
                                yVar2.f6152m.setBackgroundResource(resourceId);
                            }
                        }
                        yVar2.f6152m = textView;
                        textView.setBackgroundColor(-12961222);
                        break;
                    }
                }
                break;
            case 13:
                o3.d dVar = (o3.d) this.b;
                o3.b bVar = (o3.b) this.f106c;
                ImageButton imageButton = ((o3.c) this.f107d).f7188w;
                HashSet hashSet = dVar.f7191c.V;
                String str12 = bVar.b;
                if (hashSet.contains(str12)) {
                    hashSet.remove(str12);
                    dVar.k(imageButton, false);
                } else {
                    hashSet.add(str12);
                    dVar.k(imageButton, true);
                }
                break;
            default:
                EditText editText6 = (EditText) this.f106c;
                Context context = (Context) this.b;
                AlertDialog alertDialog = (AlertDialog) this.f107d;
                String strTrim6 = editText6.getText().toString().trim();
                if (strTrim6.isEmpty()) {
                    Toast.makeText(context, 2131820786, 0).show();
                } else {
                    Context origApplicationContext = v.m.p.getOrigApplicationContext(context.getApplicationContext());
                    moe.heroman.eventtest.auth.a aVarH = moe.heroman.eventtest.auth.a.h();
                    aVarH.b.execute(new a3.f(aVarH, strTrim6, new androidx.emoji2.text.l(origApplicationContext, 1), 1));
                    alertDialog.dismiss();
                }
                break;
        }
    }

    public /* synthetic */ f(Object obj, Object obj2, Object obj3, int i7) {
        this.f105a = i7;
        this.b = obj;
        this.f106c = obj2;
        this.f107d = obj3;
    }

    public /* synthetic */ f(t tVar, e1 e1Var, LinearLayout linearLayout) {
        this.f105a = 2;
        this.b = tVar;
        this.f107d = e1Var;
        this.f106c = linearLayout;
    }
}
