package a4;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class u implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f243a;
    public final /* synthetic */ c0 b;

    public /* synthetic */ u(c0 c0Var, int i7) {
        this.f243a = i7;
        this.b = c0Var;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f243a) {
            case 0:
                c0 c0Var = this.b;
                e4.r0.g(c0Var.f53a, c0Var, c0Var.b);
                break;
            case 1:
                c0 c0Var2 = this.b;
                if (c0Var2.getParent() != null) {
                    e4.r0.V(c0Var2.f53a, c0Var2);
                }
                break;
            case 2:
                c0 c0Var3 = this.b;
                c0Var3.o();
                c0Var3.requestLayout();
                break;
            case 3:
                c0 c0Var4 = this.b;
                c0Var4.o();
                c0Var4.requestLayout();
                c0Var4.invalidate();
                break;
            case 4:
                c0 c0Var5 = this.b;
                v1 v1Var = c0Var5.f66p;
                if (v1Var != null) {
                    LinearLayout linearLayout = new LinearLayout(c0Var5.getContext());
                    linearLayout.setOrientation(1);
                    GradientDrawable gradientDrawableH = androidx.activity.g.h(linearLayout, c0Var5.e(20.0f), c0Var5.e(16.0f), c0Var5.e(20.0f), c0Var5.e(16.0f));
                    gradientDrawableH.setColor(-14013910);
                    gradientDrawableH.setCornerRadius(c0Var5.e(8.0f));
                    linearLayout.setBackground(gradientDrawableH);
                    TextView textView = new TextView(c0Var5.getContext());
                    textView.setText(c0Var5.getContext().getString(2131820644));
                    textView.setTextColor(-1);
                    textView.setTextSize(16.0f);
                    textView.setPadding(0, 0, 0, c0Var5.e(12.0f));
                    linearLayout.addView(textView);
                    EditText editText = new EditText(c0Var5.getContext());
                    editText.setText(v1Var.b);
                    editText.setTextColor(-1);
                    editText.setHintTextColor(-7829368);
                    editText.setBackgroundColor(-15066598);
                    editText.setPadding(c0Var5.e(8.0f), c0Var5.e(8.0f), c0Var5.e(8.0f), c0Var5.e(8.0f));
                    editText.setFocusableInTouchMode(true);
                    linearLayout.addView(editText);
                    LinearLayout linearLayout2 = new LinearLayout(c0Var5.getContext());
                    linearLayout2.setOrientation(0);
                    linearLayout2.setGravity(8388613);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                    layoutParams.topMargin = c0Var5.e(12.0f);
                    TextView textView2 = new TextView(c0Var5.getContext());
                    textView2.setText(c0Var5.getContext().getString(2131820610));
                    textView2.setTextColor(-7829368);
                    textView2.setTextSize(14.0f);
                    textView2.setPadding(c0Var5.e(12.0f), c0Var5.e(8.0f), c0Var5.e(12.0f), c0Var5.e(8.0f));
                    textView2.setClickable(true);
                    textView2.setOnClickListener(new v(c0Var5, 3));
                    linearLayout2.addView(textView2);
                    TextView textView3 = new TextView(c0Var5.getContext());
                    textView3.setText(c0Var5.getContext().getString(2131820649));
                    textView3.setTextColor(-11751600);
                    textView3.setTextSize(14.0f);
                    textView3.setPadding(c0Var5.e(12.0f), c0Var5.e(8.0f), c0Var5.e(12.0f), c0Var5.e(8.0f));
                    textView3.setClickable(true);
                    textView3.setOnClickListener(new f(c0Var5, editText, v1Var, 5));
                    linearLayout2.addView(textView3);
                    linearLayout.addView(linearLayout2, layoutParams);
                    c0Var5.k(linearLayout);
                    editText.postDelayed(new a3.e(c0Var5, 6, editText), 200L);
                }
                break;
            case 5:
                final c0 c0Var6 = this.b;
                final v1 v1Var2 = c0Var6.f66p;
                if (v1Var2 != null) {
                    LinearLayout linearLayout3 = new LinearLayout(c0Var6.getContext());
                    linearLayout3.setOrientation(1);
                    GradientDrawable gradientDrawableH2 = androidx.activity.g.h(linearLayout3, c0Var6.e(20.0f), c0Var6.e(16.0f), c0Var6.e(20.0f), c0Var6.e(16.0f));
                    gradientDrawableH2.setColor(-14013910);
                    gradientDrawableH2.setCornerRadius(c0Var6.e(8.0f));
                    linearLayout3.setBackground(gradientDrawableH2);
                    TextView textView4 = new TextView(c0Var6.getContext());
                    textView4.setText(c0Var6.getContext().getString(2131820633));
                    textView4.setTextColor(-1);
                    textView4.setTextSize(16.0f);
                    textView4.setPadding(0, 0, 0, c0Var6.e(8.0f));
                    linearLayout3.addView(textView4);
                    TextView textView5 = new TextView(c0Var6.getContext());
                    textView5.setText(String.format(c0Var6.getContext().getString(2131820632), v1Var2.b));
                    textView5.setTextColor(-3355444);
                    textView5.setTextSize(14.0f);
                    textView5.setPadding(0, 0, 0, c0Var6.e(16.0f));
                    linearLayout3.addView(textView5);
                    LinearLayout linearLayout4 = new LinearLayout(c0Var6.getContext());
                    linearLayout4.setOrientation(0);
                    linearLayout4.setGravity(8388613);
                    TextView textView6 = new TextView(c0Var6.getContext());
                    textView6.setText(c0Var6.getContext().getString(2131820610));
                    textView6.setTextColor(-7829368);
                    textView6.setTextSize(14.0f);
                    textView6.setPadding(c0Var6.e(12.0f), c0Var6.e(8.0f), c0Var6.e(12.0f), c0Var6.e(8.0f));
                    textView6.setClickable(true);
                    textView6.setOnClickListener(new v(c0Var6, 2));
                    linearLayout4.addView(textView6);
                    TextView textView7 = new TextView(c0Var6.getContext());
                    textView7.setText(c0Var6.getContext().getString(2131820630));
                    textView7.setTextColor(-769226);
                    textView7.setTextSize(14.0f);
                    textView7.setPadding(c0Var6.e(12.0f), c0Var6.e(8.0f), c0Var6.e(12.0f), c0Var6.e(8.0f));
                    textView7.setClickable(true);
                    final int i7 = 0;
                    textView7.setOnClickListener(new View.OnClickListener() { // from class: a4.w
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            switch (i7) {
                                case 0:
                                    u1 u1VarN = u1.n();
                                    String str = v1Var2.f257a;
                                    c0 c0Var7 = c0Var6;
                                    y yVar = new y(c0Var7, 0);
                                    Handler handler = u1VarN.f247c;
                                    if (u1VarN.f248d == null) {
                                        handler.post(new x(yVar, 1));
                                    } else {
                                        v1 v1VarD = u1VarN.d(str);
                                        if (v1VarD == null) {
                                            handler.post(new x(yVar, 2));
                                        } else {
                                            u1VarN.b.execute(new o0(u1VarN, u1VarN.f248d, str, yVar, v1VarD, 3));
                                        }
                                    }
                                    c0Var7.h(c0Var7.f57g);
                                    break;
                                default:
                                    c0 c0Var8 = c0Var6;
                                    c0Var8.h(c0Var8.f57g);
                                    c0Var8.c(v1Var2, 0);
                                    break;
                            }
                        }
                    });
                    linearLayout4.addView(textView7);
                    linearLayout3.addView(linearLayout4);
                    c0Var6.k(linearLayout3);
                }
                break;
            case 6:
                final c0 c0Var7 = this.b;
                final v1 v1Var3 = c0Var7.f66p;
                if (v1Var3 != null) {
                    Context context = c0Var7.getContext();
                    LinearLayout linearLayout5 = new LinearLayout(context);
                    linearLayout5.setOrientation(1);
                    linearLayout5.setBackgroundColor(-14013910);
                    linearLayout5.setPadding(c0Var7.e(14.0f), c0Var7.e(14.0f), c0Var7.e(14.0f), c0Var7.e(14.0f));
                    TextView textView8 = new TextView(context);
                    textView8.setText(2131821380);
                    textView8.setTextColor(-1);
                    textView8.setTextSize(15.0f);
                    textView8.setTypeface(null, 1);
                    textView8.setPadding(0, 0, 0, c0Var7.e(12.0f));
                    linearLayout5.addView(textView8);
                    linearLayout5.addView(new f3.g(context, new h(c0Var7, 1, v1Var3)));
                    View view = new View(context);
                    view.setLayoutParams(new LinearLayout.LayoutParams(-1, c0Var7.e(6.0f)));
                    linearLayout5.addView(view);
                    String string = context.getString(2131821378);
                    String string2 = context.getString(2131821379);
                    final int i8 = 1;
                    View.OnClickListener onClickListener = new View.OnClickListener() { // from class: a4.w
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view2) {
                            switch (i8) {
                                case 0:
                                    u1 u1VarN = u1.n();
                                    String str = v1Var3.f257a;
                                    c0 c0Var72 = c0Var7;
                                    y yVar = new y(c0Var72, 0);
                                    Handler handler = u1VarN.f247c;
                                    if (u1VarN.f248d == null) {
                                        handler.post(new x(yVar, 1));
                                    } else {
                                        v1 v1VarD = u1VarN.d(str);
                                        if (v1VarD == null) {
                                            handler.post(new x(yVar, 2));
                                        } else {
                                            u1VarN.b.execute(new o0(u1VarN, u1VarN.f248d, str, yVar, v1VarD, 3));
                                        }
                                    }
                                    c0Var72.h(c0Var72.f57g);
                                    break;
                                default:
                                    c0 c0Var8 = c0Var7;
                                    c0Var8.h(c0Var8.f57g);
                                    c0Var8.c(v1Var3, 0);
                                    break;
                            }
                        }
                    };
                    Context context2 = c0Var7.getContext();
                    LinearLayout linearLayout6 = new LinearLayout(context2);
                    linearLayout6.setOrientation(1);
                    GradientDrawable gradientDrawableH3 = androidx.activity.g.h(linearLayout6, c0Var7.e(10.0f), c0Var7.e(10.0f), c0Var7.e(10.0f), c0Var7.e(10.0f));
                    gradientDrawableH3.setColor(-12961222);
                    gradientDrawableH3.setCornerRadius(c0Var7.e(6.0f));
                    linearLayout6.setBackground(gradientDrawableH3);
                    linearLayout6.setOnClickListener(onClickListener);
                    TextView textView9 = new TextView(context2);
                    textView9.setText(string);
                    textView9.setTextColor(-1);
                    textView9.setTextSize(14.0f);
                    textView9.setTypeface(null, 1);
                    linearLayout6.addView(textView9);
                    TextView textView10 = new TextView(context2);
                    textView10.setText(string2);
                    textView10.setTextColor(-5592406);
                    textView10.setTextSize(11.0f);
                    textView10.setPadding(0, c0Var7.e(2.0f), 0, 0);
                    linearLayout6.addView(textView10);
                    linearLayout5.addView(linearLayout6);
                    View view2 = new View(context);
                    view2.setLayoutParams(new LinearLayout.LayoutParams(-1, c0Var7.e(10.0f)));
                    linearLayout5.addView(view2);
                    TextView textView11 = new TextView(context);
                    textView11.setText(2131820610);
                    textView11.setTextColor(-5592406);
                    textView11.setTextSize(13.0f);
                    textView11.setGravity(17);
                    textView11.setPadding(c0Var7.e(12.0f), c0Var7.e(12.0f), c0Var7.e(12.0f), c0Var7.e(12.0f));
                    textView11.setOnClickListener(new v(c0Var7, 4));
                    linearLayout5.addView(textView11);
                    c0Var7.k(linearLayout5);
                }
                break;
            default:
                c0 c0Var8 = this.b;
                Context context3 = c0Var8.getContext();
                int iE = c0Var8.e(14.0f);
                int iE2 = c0Var8.e(10.0f);
                LinearLayout linearLayout7 = new LinearLayout(context3);
                linearLayout7.setOrientation(1);
                GradientDrawable gradientDrawableH4 = androidx.activity.g.h(linearLayout7, iE, iE, iE, iE);
                gradientDrawableH4.setColor(Color.parseColor(v.m.p.abcdstr(32)));
                gradientDrawableH4.setCornerRadius(iE2);
                linearLayout7.setBackground(gradientDrawableH4);
                TextView textView12 = new TextView(context3);
                textView12.setText(2131820735);
                textView12.setTextColor(-1);
                textView12.setTextSize(2, 15.0f);
                textView12.setTypeface(null, 1);
                textView12.setPadding(0, 0, 0, c0Var8.e(12.0f));
                linearLayout7.addView(textView12);
                EditText editText2 = new EditText(context3);
                editText2.setHint(2131820732);
                String strAbcdstr = v.m.p.abcdstr(33);
                editText2.setHintTextColor(Color.parseColor(strAbcdstr));
                editText2.setTextColor(-1);
                editText2.setTextSize(2, 14.0f);
                editText2.setSingleLine(true);
                editText2.setPadding(c0Var8.e(10.0f), c0Var8.e(10.0f), c0Var8.e(10.0f), c0Var8.e(10.0f));
                editText2.setFocusable(true);
                editText2.setFocusableInTouchMode(true);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(v.m.p.abcdstr(34)));
                gradientDrawable.setCornerRadius(c0Var8.e(6.0f));
                editText2.setBackground(gradientDrawable);
                linearLayout7.addView(editText2);
                LinearLayout linearLayout8 = new LinearLayout(context3);
                linearLayout8.setOrientation(0);
                linearLayout8.setGravity(17);
                linearLayout8.setPadding(0, c0Var8.e(12.0f), 0, 0);
                TextView textViewD = c0Var8.d(Color.parseColor(v.m.p.abcdstr(35)), context3.getString(2131820965));
                textViewD.setOnClickListener(new j(context3, editText2, 1));
                linearLayout8.addView(textViewD);
                View view3 = new View(context3);
                view3.setLayoutParams(new LinearLayout.LayoutParams(c0Var8.e(10.0f), 1));
                linearLayout8.addView(view3);
                TextView textViewD2 = c0Var8.d(Color.parseColor(v.m.p.abcdstr(36)), context3.getString(2131820730));
                textViewD2.setOnClickListener(new k(c0Var8, editText2, context3, textViewD2, 1));
                linearLayout8.addView(textViewD2);
                View view4 = new View(context3);
                view4.setLayoutParams(new LinearLayout.LayoutParams(c0Var8.e(10.0f), 1));
                linearLayout8.addView(view4);
                TextView textViewD3 = c0Var8.d(Color.parseColor(strAbcdstr), context3.getString(2131820610));
                textViewD3.setOnClickListener(new v(c0Var8, 5));
                linearLayout8.addView(textViewD3);
                linearLayout7.addView(linearLayout8);
                c0Var8.k(linearLayout7);
                break;
        }
    }
}
