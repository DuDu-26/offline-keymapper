package a4;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class k implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f151a;
    public final /* synthetic */ EditText b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Context f152c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ TextView f153d;
    public final /* synthetic */ FrameLayout e;

    public /* synthetic */ k(FrameLayout frameLayout, EditText editText, Context context, TextView textView, int i7) {
        this.f151a = i7;
        this.e = frameLayout;
        this.b = editText;
        this.f152c = context;
        this.f153d = textView;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f151a) {
            case 0:
                t tVar = (t) this.e;
                String strTrim = this.b.getText().toString().trim();
                boolean zIsEmpty = strTrim.isEmpty();
                Context context = this.f152c;
                if (!zIsEmpty) {
                    f3.e.e().getClass();
                    if (!f3.e.c(strTrim)) {
                        String string = context.getString(2131820733);
                        FloatingService floatingService = FloatingService.f6880k;
                        if (floatingService != null) {
                            floatingService.a(string);
                        }
                    } else {
                        TextView textView = this.f153d;
                        textView.setEnabled(false);
                        textView.setText(v.m.p.abcdstr(76));
                        f3.e.e().b(strTrim, new y2.e(tVar, context, textView, 1));
                    }
                } else {
                    String string2 = context.getString(2131820733);
                    FloatingService floatingService2 = FloatingService.f6880k;
                    if (floatingService2 != null) {
                        floatingService2.a(string2);
                    }
                }
                break;
            case 1:
                c0 c0Var = (c0) this.e;
                String strTrim2 = this.b.getText().toString().trim();
                boolean zIsEmpty2 = strTrim2.isEmpty();
                Context context2 = this.f152c;
                if (!zIsEmpty2) {
                    f3.e.e().getClass();
                    if (!f3.e.c(strTrim2)) {
                        String string3 = context2.getString(2131820733);
                        FloatingService floatingService3 = FloatingService.f6880k;
                        if (floatingService3 != null) {
                            floatingService3.a(string3);
                        }
                    } else {
                        TextView textView2 = this.f153d;
                        textView2.setEnabled(false);
                        textView2.setText(v.m.p.abcdstr(76));
                        f3.e.e().b(strTrim2, new y2.e(c0Var, context2, textView2, 2));
                    }
                } else {
                    String string4 = context2.getString(2131820733);
                    FloatingService floatingService4 = FloatingService.f6880k;
                    if (floatingService4 != null) {
                        floatingService4.a(string4);
                    }
                }
                break;
            case 2:
                e4.k kVar = (e4.k) this.e;
                String strTrim3 = this.b.getText().toString().trim();
                boolean zIsEmpty3 = strTrim3.isEmpty();
                Context context3 = this.f152c;
                if (!zIsEmpty3) {
                    f3.e.e().getClass();
                    if (!f3.e.c(strTrim3)) {
                        e4.k.i(context3.getString(2131820733));
                    } else {
                        TextView textView3 = this.f153d;
                        textView3.setEnabled(false);
                        textView3.setText(v.m.p.abcdstr(76));
                        f3.e.e().b(strTrim3, new y2.e(kVar, context3, textView3, 9));
                    }
                } else {
                    e4.k.i(context3.getString(2131820733));
                }
                break;
            case 3:
                e4.s sVar = (e4.s) this.e;
                String strTrim4 = this.b.getText().toString().trim();
                boolean zIsEmpty4 = strTrim4.isEmpty();
                Context context4 = this.f152c;
                if (!zIsEmpty4) {
                    f3.e.e().getClass();
                    if (!f3.e.c(strTrim4)) {
                        e4.s.i(context4.getString(2131820733));
                    } else {
                        TextView textView4 = this.f153d;
                        textView4.setEnabled(false);
                        textView4.setText(v.m.p.abcdstr(76));
                        f3.e.e().b(strTrim4, new y2.e(sVar, context4, textView4, 10));
                    }
                } else {
                    e4.s.i(context4.getString(2131820733));
                }
                break;
            default:
                h3.r rVar = (h3.r) this.e;
                String strTrim5 = this.b.getText().toString().trim();
                boolean zIsEmpty5 = strTrim5.isEmpty();
                Context context5 = this.f152c;
                if (!zIsEmpty5) {
                    f3.e.e().getClass();
                    if (!f3.e.c(strTrim5)) {
                        h3.r.k(context5.getString(2131820733));
                    } else {
                        TextView textView5 = this.f153d;
                        textView5.setEnabled(false);
                        textView5.setText(v.m.p.abcdstr(76));
                        f3.e.e().b(strTrim5, new y2.e(rVar, context5, textView5, 11));
                    }
                } else {
                    h3.r.k(context5.getString(2131820733));
                }
                break;
        }
    }
}
