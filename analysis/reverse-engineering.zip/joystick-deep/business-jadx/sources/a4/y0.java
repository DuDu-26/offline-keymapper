package a4;

import android.R;
import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;
import android.util.SparseArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.widget.f3;
import androidx.viewpager2.widget.ViewPager2;
import com.efs.sdk.base.Constants;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class y0 implements a1, d4.k, f5.u, h3.h1, l3.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f271a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f272c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f273d;
    public final Object e;

    public y0(Typeface typeface, m0.b bVar) {
        int i7;
        int i8;
        int i9;
        int i10;
        this.f271a = 1;
        this.e = typeface;
        this.b = bVar;
        this.f273d = new androidx.emoji2.text.r(1024);
        int iA = bVar.a(6);
        if (iA != 0) {
            int i11 = iA + bVar.f5598a;
            i7 = ((ByteBuffer) bVar.f5600d).getInt(((ByteBuffer) bVar.f5600d).getInt(i11) + i11);
        } else {
            i7 = 0;
        }
        this.f272c = new char[i7 * 2];
        int iA2 = bVar.a(6);
        if (iA2 != 0) {
            int i12 = iA2 + bVar.f5598a;
            i8 = ((ByteBuffer) bVar.f5600d).getInt(((ByteBuffer) bVar.f5600d).getInt(i12) + i12);
        } else {
            i8 = 0;
        }
        for (int i13 = 0; i13 < i8; i13++) {
            androidx.emoji2.text.n nVar = new androidx.emoji2.text.n(this, i13);
            m0.a aVarB = nVar.b();
            int iA3 = aVarB.a(4);
            Character.toChars(iA3 != 0 ? ((ByteBuffer) aVarB.f5600d).getInt(iA3 + aVarB.f5598a) : 0, (char[]) this.f272c, i13 * 2);
            m0.a aVarB2 = nVar.b();
            int iA4 = aVarB2.a(16);
            if (iA4 != 0) {
                int i14 = iA4 + aVarB2.f5598a;
                i9 = ((ByteBuffer) aVarB2.f5600d).getInt(((ByteBuffer) aVarB2.f5600d).getInt(i14) + i14);
            } else {
                i9 = 0;
            }
            a5.h.f(v.m.p.abcdstr(134), i9 > 0);
            androidx.emoji2.text.r rVar = (androidx.emoji2.text.r) this.f273d;
            m0.a aVarB3 = nVar.b();
            int iA5 = aVarB3.a(16);
            if (iA5 != 0) {
                int i15 = iA5 + aVarB3.f5598a;
                i10 = ((ByteBuffer) aVarB3.f5600d).getInt(((ByteBuffer) aVarB3.f5600d).getInt(i15) + i15);
            } else {
                i10 = 0;
            }
            rVar.a(nVar, 0, i10 - 1);
        }
    }

    @Override // a4.a1, a4.z0, d4.j, e4.f0
    public void a(String str) {
        switch (this.f271a) {
            case 0:
                ((z0) this.f272c).a(str);
                break;
            case 3:
                ((d4.j) this.f272c).a(str);
                break;
            default:
                h3.j1 j1Var = (h3.j1) this.e;
                String str2 = (String) this.f273d;
                if (str2 != null && str2.equals(j1Var.f6020d) && ((String) this.b).equals(j1Var.f6021f)) {
                    Log.e(v.m.p.abcdstr(13), v.m.p.abcdstr(135) + str);
                    j1Var.j();
                    w3.b.r().o(null);
                }
                h3.h1 h1Var = (h3.h1) this.f272c;
                if (h1Var != null) {
                    h1Var.a(str);
                }
                break;
        }
    }

    @Override // h3.h1
    public void b() {
        w3.b.r().o(((h3.j1) this.e).f6022g);
        h3.h1 h1Var = (h3.h1) this.f272c;
        if (h1Var != null) {
            h1Var.b();
        }
    }

    @Override // l3.c
    public void c() {
        ((Runnable) this.b).run();
    }

    @Override // l3.c
    public void d() {
        ((Runnable) this.f272c).run();
    }

    @Override // l3.c
    public void destroy() {
        ((Runnable) this.e).run();
    }

    @Override // f5.u
    public f5.t e() {
        return (g5.c) this.e;
    }

    @Override // f5.u
    public f5.v f() {
        return (g5.d) this.f273d;
    }

    @Override // d4.k
    public void g(e4.x xVar) {
        c1 c1Var = (c1) this.b;
        HashMap map = c1Var.f74g;
        String str = c1Var.f70a;
        d4.m mVar = (d4.m) this.e;
        if (!str.equals(mVar.f5268d) || !c1Var.b.equals(mVar.f5269f)) {
            ((d4.j) this.f272c).a(v.m.p.abcdstr(136));
            return;
        }
        xVar.f5483f = c1Var.f73f;
        for (Map.Entry entry : map.entrySet()) {
            String str2 = (String) entry.getKey();
            Float f2 = (Float) entry.getValue();
            f2.getClass();
            xVar.f5484g.put(str2, f2);
        }
        mVar.f5269f = xVar.f5480a;
        mVar.o();
        mVar.b.execute(new q0(mVar, new c1(c1Var.f70a, xVar.f5480a, xVar.b, false, xVar.f5482d, 1, c1Var.f73f, new HashMap(map)), (d4.a) this.f273d, new i0(this, 6, xVar), Math.max(1, 1) + 1, 2));
    }

    @Override // a4.a1
    public void h(e1 e1Var) {
        if (!((c1) this.b).f70a.equals(((d1) this.e).f80d) || !((c1) this.b).b.equals(((d1) this.e).f81f)) {
            ((z0) this.f272c).a(v.m.p.abcdstr(136));
            return;
        }
        c1 c1Var = (c1) this.b;
        e1Var.f103f = c1Var.f73f;
        for (Map.Entry entry : c1Var.f74g.entrySet()) {
            String str = (String) entry.getKey();
            Float f2 = (Float) entry.getValue();
            f2.getClass();
            e1Var.f104g.put(str, f2);
        }
        d1 d1Var = (d1) this.e;
        d1Var.f81f = e1Var.f100a;
        d1Var.r();
        c1 c1Var2 = (c1) this.b;
        c1 c1Var3 = new c1(c1Var2.f70a, e1Var.f100a, e1Var.b, false, e1Var.f102d, 1, c1Var2.f73f, new HashMap(((c1) this.b).f74g));
        d1 d1Var2 = (d1) this.e;
        z3.a aVar = (z3.a) this.f273d;
        i0 i0Var = new i0(this, 2, e1Var);
        d1Var2.b.execute(new q0(d1Var2, c1Var3, aVar.c(), i0Var, Math.max(1, 1) + 1, 0));
    }

    public void i(Object obj, ArrayList arrayList, HashSet hashSet) {
        if (arrayList.contains(obj)) {
            return;
        }
        if (hashSet.contains(obj)) {
            f3.i(v.m.p.abcdstr(137));
            return;
        }
        hashSet.add(obj);
        ArrayList arrayList2 = (ArrayList) ((l.k) this.f272c).getOrDefault(obj, null);
        if (arrayList2 != null) {
            int size = arrayList2.size();
            for (int i7 = 0; i7 < size; i7++) {
                i(arrayList2.get(i7), arrayList, hashSet);
            }
        }
        hashSet.remove(obj);
        arrayList.add(obj);
    }

    @Override // l3.c
    public boolean isVisible() {
        return ((BooleanSupplier) this.f273d).getAsBoolean();
    }

    public f.f j(f.a aVar) {
        ArrayList arrayList = (ArrayList) this.f273d;
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            f.f fVar = (f.f) arrayList.get(i7);
            if (fVar != null && fVar.b == aVar) {
                return fVar;
            }
        }
        f.f fVar2 = new f.f((Context) this.f272c, aVar);
        arrayList.add(fVar2);
        return fVar2;
    }

    public boolean k(f.a aVar, MenuItem menuItem) {
        return ((ActionMode.Callback) this.b).onActionItemClicked(j(aVar), new g.s((Context) this.f272c, (z.a) menuItem));
    }

    public boolean l(f.a aVar, Menu menu) {
        ActionMode.Callback callback = (ActionMode.Callback) this.b;
        f.f fVarJ = j(aVar);
        l.k kVar = (l.k) this.e;
        Menu b0Var = (Menu) kVar.getOrDefault(menu, null);
        if (b0Var == null) {
            b0Var = new g.b0((Context) this.f272c, (g.l) menu);
            kVar.put(menu, b0Var);
        }
        return callback.onCreateActionMode(fVarJ, b0Var);
    }

    public void m() {
        int iA;
        androidx.viewpager2.widget.k kVar = (androidx.viewpager2.widget.k) this.f272c;
        androidx.viewpager2.widget.k kVar2 = (androidx.viewpager2.widget.k) this.b;
        ViewPager2 viewPager2 = (ViewPager2) this.e;
        int i7 = R.id.accessibilityActionPageLeft;
        f0.s0.g(viewPager2, R.id.accessibilityActionPageLeft);
        f0.s0.e(viewPager2, 0);
        f0.s0.g(viewPager2, R.id.accessibilityActionPageRight);
        f0.s0.e(viewPager2, 0);
        f0.s0.g(viewPager2, R.id.accessibilityActionPageUp);
        f0.s0.e(viewPager2, 0);
        f0.s0.g(viewPager2, R.id.accessibilityActionPageDown);
        f0.s0.e(viewPager2, 0);
        if (viewPager2.getAdapter() == null || (iA = viewPager2.getAdapter().a()) == 0 || !viewPager2.f1756r) {
            return;
        }
        if (viewPager2.getOrientation() != 0) {
            if (viewPager2.f1743d < iA - 1) {
                f0.s0.h(viewPager2, new g0.h(R.id.accessibilityActionPageDown), kVar2);
            }
            if (viewPager2.f1743d > 0) {
                f0.s0.h(viewPager2, new g0.h(R.id.accessibilityActionPageUp), kVar);
                return;
            }
            return;
        }
        boolean z6 = viewPager2.f1745g.E() == 1;
        int i8 = z6 ? 16908360 : 16908361;
        if (z6) {
            i7 = 16908361;
        }
        if (viewPager2.f1743d < iA - 1) {
            f0.s0.h(viewPager2, new g0.h(i8), kVar2);
        }
        if (viewPager2.f1743d > 0) {
            f0.s0.h(viewPager2, new g0.h(i7), kVar);
        }
    }

    public String toString() {
        switch (this.f271a) {
            case 5:
                String string = ((Socket) this.b).toString();
                string.getClass();
                return string;
            default:
                return super.toString();
        }
    }

    public y0(Socket socket) {
        this.f271a = 5;
        this.b = socket;
        this.f272c = new AtomicInteger();
        this.f273d = new g5.d(this);
        this.e = new g5.c(this);
    }

    public y0(int i7) {
        this.f271a = i7;
        switch (i7) {
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                this.b = new l.b();
                this.f272c = new SparseArray();
                this.f273d = new l.e();
                this.e = new l.b();
                break;
            default:
                this.b = new e0.c(10);
                this.f272c = new l.k();
                this.f273d = new ArrayList();
                this.e = new HashSet();
                break;
        }
    }

    public y0(Runnable runnable, Runnable runnable2, BooleanSupplier booleanSupplier) {
        this.f271a = 7;
        this.b = runnable;
        this.f272c = runnable2;
        this.f273d = booleanSupplier;
        this.e = runnable2;
    }

    public /* synthetic */ y0(Object obj, Object obj2, Object obj3, Object obj4, int i7) {
        this.f271a = i7;
        this.e = obj;
        this.b = obj2;
        this.f272c = obj3;
        this.f273d = obj4;
    }

    public y0(Context context, ActionMode.Callback callback) {
        this.f271a = 4;
        this.f272c = context;
        this.b = callback;
        this.f273d = new ArrayList();
        this.e = new l.k();
    }

    public y0(ViewPager2 viewPager2) {
        this.f271a = 2;
        this.e = viewPager2;
        this.b = new androidx.viewpager2.widget.k(this, 0);
        this.f272c = new androidx.viewpager2.widget.k(this, 1);
    }
}
