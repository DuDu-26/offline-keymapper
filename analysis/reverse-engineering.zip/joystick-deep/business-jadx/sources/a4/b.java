package a4;

import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class b implements View.OnTouchListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f49a;

    public /* synthetic */ b(int i7) {
        this.f49a = i7;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        switch (this.f49a) {
            case 0:
                int i7 = t.f215x;
                break;
            case 1:
                int i8 = c0.f52t;
                break;
            case 2:
                int i9 = e4.k.f5378t;
                break;
            case 3:
                int i10 = e4.s.f5433t;
                break;
            case 4:
                int i11 = h3.r.f6094u;
                break;
            case 5:
                int i12 = h3.y.f6141p;
                break;
            case 6:
                int i13 = h3.d0.f5941k;
                break;
            default:
                int i14 = h3.j0.f6008k;
                break;
        }
        return true;
    }
}
