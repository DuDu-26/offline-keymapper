package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public enum a2 {
    b(2131820697),
    f42c(2131820702),
    f43d(2131820703),
    e(2131820700),
    f44f(2131820701),
    f45g(2131820698),
    f46h(2131820699);


    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f48a;

    a2(int i7) {
        this.f48a = i7;
    }
}
