package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f118a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f119c;

    public h0(String str, int i7, int i8) {
        this.f118a = i7;
        this.b = i8;
        this.f119c = str;
    }

    public final boolean a() {
        return this.b <= 0;
    }
}
