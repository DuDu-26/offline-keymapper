package a4;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class y implements s1, f3.d, t1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f270a;
    public final /* synthetic */ c0 b;

    public /* synthetic */ y(c0 c0Var, int i7) {
        this.f270a = i7;
        this.b = c0Var;
    }

    @Override // a4.s1, f3.d, a4.a1, a4.z0, d4.j, e4.f0
    public final void a(String str) {
        switch (this.f270a) {
            case 0:
                FloatingService.f6880k.a(this.b.getContext().getString(2131820631));
                break;
            case 1:
                FloatingService.f6880k.a(String.format(this.b.getContext().getString(2131821375), str));
                break;
            case 2:
                n nVar = new n(3, this);
                c0 c0Var = this.b;
                c0Var.post(nVar);
                FloatingService.f6880k.a(c0Var.getContext().getString(2131820627));
                break;
            default:
                FloatingService.f6880k.a(this.b.getContext().getString(2131820643));
                break;
        }
    }

    @Override // a4.s1
    public void b() {
        switch (this.f270a) {
            case 0:
                this.b.post(new x(this, 0));
                break;
            default:
                this.b.post(new z(this, 0));
                break;
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // f3.d
    public void e(String str, String str2) {
        c0 c0Var = this.b;
        Context context = c0Var.getContext();
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-14013910);
        linearLayout.setPadding(c0Var.e(14.0f), c0Var.e(14.0f), c0Var.e(14.0f), c0Var.e(14.0f));
        TextView textView = new TextView(context);
        textView.setText(2131821374);
        textView.setTextColor(-1);
        textView.setTextSize(15.0f);
        textView.setTypeface(null, 1);
        textView.setPadding(0, 0, 0, c0Var.e(6.0f));
        linearLayout.addView(textView);
        TextView textView2 = new TextView(context);
        textView2.setText(str2);
        textView2.setTextColor(-5592406);
        textView2.setTextSize(12.0f);
        textView2.setPadding(0, 0, 0, c0Var.e(12.0f));
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(context);
        textView3.setText(str);
        textView3.setTextColor(-11751600);
        textView3.setTextSize(14.0f);
        textView3.setTypeface(Typeface.MONOSPACE, 1);
        textView3.setGravity(17);
        textView3.setPadding(c0Var.e(10.0f), c0Var.e(10.0f), c0Var.e(10.0f), c0Var.e(10.0f));
        textView3.setTextIsSelectable(true);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-15066598);
        gradientDrawable.setCornerRadius(c0Var.e(6.0f));
        textView3.setBackground(gradientDrawable);
        linearLayout.addView(textView3);
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        linearLayout2.setPadding(0, c0Var.e(12.0f), 0, 0);
        TextView textViewD = c0Var.d(-11751600, context.getString(2131820650));
        textViewD.setOnClickListener(new a(context, str, 1));
        linearLayout2.addView(textViewD);
        View view = new View(context);
        view.setLayoutParams(new LinearLayout.LayoutParams(c0Var.e(10.0f), 1));
        linearLayout2.addView(view);
        TextView textViewD2 = c0Var.d(-10066330, context.getString(2131820621));
        textViewD2.setOnClickListener(new v(c0Var, 6));
        linearLayout2.addView(textViewD2);
        linearLayout.addView(linearLayout2);
        c0Var.k(linearLayout);
    }

    @Override // a4.t1
    public void f(v1 v1Var) {
        this.b.post(new a3.e(this, 8, v1Var));
    }
}
