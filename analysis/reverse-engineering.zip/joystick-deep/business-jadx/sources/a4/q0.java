package a4;

import android.os.Handler;
import com.umeng.commonsdk.statistics.UMErrorCode;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.auth.PatternToken;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class q0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f193a;
    public final /* synthetic */ int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f194c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f195d;
    public final /* synthetic */ Object e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f196f;

    public /* synthetic */ q0(Object obj, Object obj2, Object obj3, Object obj4, int i7, int i8) {
        this.f193a = i8;
        this.f194c = obj;
        this.f195d = obj2;
        this.e = obj3;
        this.f196f = obj4;
        this.b = i7;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f193a) {
            case 0:
                final d1 d1Var = (d1) this.f194c;
                final c1 c1Var = (c1) this.f195d;
                z3.a aVar = (z3.a) this.e;
                final z0 z0Var = (z0) this.f196f;
                Handler handler = d1Var.f79c;
                byte[] bArrO = d1.o(aVar);
                final byte[] bArrI = bArrO != null ? d1.i(c1Var.f73f) : null;
                final byte[] bArrT = bArrI != null ? d1.t(c1Var.f74g) : null;
                if (bArrO == null || bArrI == null || bArrT == null) {
                    handler.post(new k0(z0Var, 6));
                } else {
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    String str = c1Var.b;
                    String str2 = c1Var.f71c;
                    String str3 = c1Var.f70a;
                    boolean z6 = c1Var.f72d;
                    long j7 = c1Var.e;
                    final int i7 = this.b;
                    if (NativeAuth.K(bArrO, bArrI, bArrT, str, str2, str3, z6, j7, jCurrentTimeMillis, jCurrentTimeMillis, i7) == 0) {
                        final PatternToken patternTokenC = NativeAuth.c(c1Var.f70a, c1Var.b);
                        final int i8 = 0;
                        handler.post(new Runnable() { // from class: a4.r0
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i8) {
                                    case 0:
                                        d1 d1Var2 = (d1) d1Var;
                                        c1 c1Var2 = (c1) c1Var;
                                        int i9 = i7;
                                        PatternToken patternToken = patternTokenC;
                                        byte[] bArr = bArrI;
                                        byte[] bArr2 = bArrT;
                                        z0 z0Var2 = (z0) z0Var;
                                        if (c1Var2.f70a.equals(d1Var2.f80d) && c1Var2.b.equals(d1Var2.f81f)) {
                                            e1 e1VarE = d1Var2.e(c1Var2.b);
                                            if (e1VarE != null) {
                                                System.currentTimeMillis();
                                                e1VarE.e = i9;
                                            }
                                            if (patternToken != null) {
                                                d1Var2.q();
                                                d1Var2.f84i = patternToken;
                                                d1Var2.f85j = c1Var2.f70a;
                                                d1Var2.f86k = c1Var2.b;
                                                if (e1VarE != null) {
                                                    e1VarE.f103f = (float) NativeAuth.V(patternToken);
                                                    String strAbcdstr = v.m.p.abcdstr(41);
                                                    e1VarE.f104g.put(strAbcdstr, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr)));
                                                    String strAbcdstr2 = v.m.p.abcdstr(42);
                                                    e1VarE.f104g.put(strAbcdstr2, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr2)));
                                                }
                                            } else if (d1Var2.x(c1Var2.f70a, c1Var2.b)) {
                                                NativeAuth.d0(d1Var2.f84i, bArr, bArr2);
                                            }
                                        } else if (patternToken != null) {
                                            NativeAuth.t0(patternToken);
                                        }
                                        z0Var2.b();
                                        break;
                                    default:
                                        d4.m mVar = (d4.m) d1Var;
                                        c1 c1Var3 = (c1) c1Var;
                                        int i10 = i7;
                                        PatternToken patternToken2 = patternTokenC;
                                        byte[] bArr3 = bArrI;
                                        byte[] bArr4 = bArrT;
                                        d4.j jVar = (d4.j) z0Var;
                                        String str4 = c1Var3.f70a;
                                        String str5 = c1Var3.b;
                                        if (str4.equals(mVar.f5268d) && str5.equals(mVar.f5269f)) {
                                            e4.x xVarD = mVar.d(str5);
                                            if (xVarD != null) {
                                                System.currentTimeMillis();
                                                xVarD.e = i10;
                                            }
                                            if (patternToken2 != null) {
                                                mVar.n();
                                                mVar.f5272i = patternToken2;
                                                mVar.f5273j = str4;
                                                mVar.f5274k = str5;
                                                if (xVarD != null) {
                                                    xVarD.f5483f = (float) NativeAuth.V(patternToken2);
                                                    String[] strArr = {v.m.p.abcdstr(104), v.m.p.abcdstr(105), v.m.p.abcdstr(106), v.m.p.abcdstr(107), v.m.p.abcdstr(108), v.m.p.abcdstr(109), v.m.p.abcdstr(UMErrorCode.E_UM_BE_JSON_FAILED)};
                                                    for (int i11 = 0; i11 < 7; i11++) {
                                                        String str6 = strArr[i11];
                                                        xVarD.a(str6, (float) NativeAuth.h0(patternToken2, str6));
                                                    }
                                                }
                                            } else if (mVar.w(str4, str5)) {
                                                NativeAuth.d0(mVar.f5272i, bArr3, bArr4);
                                            }
                                        } else if (patternToken2 != null) {
                                            NativeAuth.t0(patternToken2);
                                        }
                                        jVar.b();
                                        break;
                                }
                            }
                        });
                    } else {
                        handler.post(new m0(z0Var, d1.m(v.m.p.abcdstr(78)), 1));
                    }
                }
                break;
            case 1:
                u1 u1Var = (u1) this.f194c;
                String str4 = (String) this.f195d;
                String str5 = (String) this.e;
                s1 s1Var = (s1) this.f196f;
                if (str4.equals(u1Var.f248d) && str5.equals(u1Var.f249f)) {
                    v1 v1VarD = u1Var.d(str5);
                    if (v1VarD != null) {
                        System.currentTimeMillis();
                        v1VarD.e = this.b;
                    }
                    u1Var.h(str5, s1Var);
                } else {
                    s1Var.b();
                }
                break;
            case 2:
                final d4.m mVar = (d4.m) this.f194c;
                final c1 c1Var2 = (c1) this.f195d;
                d4.a aVar2 = (d4.a) this.e;
                final d4.j jVar = (d4.j) this.f196f;
                Handler handler2 = mVar.f5267c;
                byte[] bArrM = d4.m.m(aVar2);
                final byte[] bArrG = bArrM != null ? d4.m.g(c1Var2.f73f) : null;
                final byte[] bArrS = bArrG != null ? d4.m.s(c1Var2.f74g) : null;
                if (bArrM == null || bArrG == null || bArrS == null) {
                    handler2.post(new d4.b(jVar, 6));
                } else {
                    long jCurrentTimeMillis2 = System.currentTimeMillis();
                    String str6 = c1Var2.b;
                    String str7 = c1Var2.f71c;
                    String str8 = c1Var2.f70a;
                    boolean z7 = c1Var2.f72d;
                    long j8 = c1Var2.e;
                    final int i9 = this.b;
                    if (NativeAuth.K(bArrM, bArrG, bArrS, str6, str7, str8, z7, j8, jCurrentTimeMillis2, jCurrentTimeMillis2, i9) == 0) {
                        final PatternToken patternTokenC2 = NativeAuth.c(c1Var2.f70a, c1Var2.b);
                        final int i10 = 1;
                        handler2.post(new Runnable() { // from class: a4.r0
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i10) {
                                    case 0:
                                        d1 d1Var2 = (d1) mVar;
                                        c1 c1Var22 = (c1) c1Var2;
                                        int i92 = i9;
                                        PatternToken patternToken = patternTokenC2;
                                        byte[] bArr = bArrG;
                                        byte[] bArr2 = bArrS;
                                        z0 z0Var2 = (z0) jVar;
                                        if (c1Var22.f70a.equals(d1Var2.f80d) && c1Var22.b.equals(d1Var2.f81f)) {
                                            e1 e1VarE = d1Var2.e(c1Var22.b);
                                            if (e1VarE != null) {
                                                System.currentTimeMillis();
                                                e1VarE.e = i92;
                                            }
                                            if (patternToken != null) {
                                                d1Var2.q();
                                                d1Var2.f84i = patternToken;
                                                d1Var2.f85j = c1Var22.f70a;
                                                d1Var2.f86k = c1Var22.b;
                                                if (e1VarE != null) {
                                                    e1VarE.f103f = (float) NativeAuth.V(patternToken);
                                                    String strAbcdstr = v.m.p.abcdstr(41);
                                                    e1VarE.f104g.put(strAbcdstr, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr)));
                                                    String strAbcdstr2 = v.m.p.abcdstr(42);
                                                    e1VarE.f104g.put(strAbcdstr2, Float.valueOf((float) NativeAuth.h0(patternToken, strAbcdstr2)));
                                                }
                                            } else if (d1Var2.x(c1Var22.f70a, c1Var22.b)) {
                                                NativeAuth.d0(d1Var2.f84i, bArr, bArr2);
                                            }
                                        } else if (patternToken != null) {
                                            NativeAuth.t0(patternToken);
                                        }
                                        z0Var2.b();
                                        break;
                                    default:
                                        d4.m mVar2 = (d4.m) mVar;
                                        c1 c1Var3 = (c1) c1Var2;
                                        int i102 = i9;
                                        PatternToken patternToken2 = patternTokenC2;
                                        byte[] bArr3 = bArrG;
                                        byte[] bArr4 = bArrS;
                                        d4.j jVar2 = (d4.j) jVar;
                                        String str42 = c1Var3.f70a;
                                        String str52 = c1Var3.b;
                                        if (str42.equals(mVar2.f5268d) && str52.equals(mVar2.f5269f)) {
                                            e4.x xVarD = mVar2.d(str52);
                                            if (xVarD != null) {
                                                System.currentTimeMillis();
                                                xVarD.e = i102;
                                            }
                                            if (patternToken2 != null) {
                                                mVar2.n();
                                                mVar2.f5272i = patternToken2;
                                                mVar2.f5273j = str42;
                                                mVar2.f5274k = str52;
                                                if (xVarD != null) {
                                                    xVarD.f5483f = (float) NativeAuth.V(patternToken2);
                                                    String[] strArr = {v.m.p.abcdstr(104), v.m.p.abcdstr(105), v.m.p.abcdstr(106), v.m.p.abcdstr(107), v.m.p.abcdstr(108), v.m.p.abcdstr(109), v.m.p.abcdstr(UMErrorCode.E_UM_BE_JSON_FAILED)};
                                                    for (int i11 = 0; i11 < 7; i11++) {
                                                        String str62 = strArr[i11];
                                                        xVarD.a(str62, (float) NativeAuth.h0(patternToken2, str62));
                                                    }
                                                }
                                            } else if (mVar2.w(str42, str52)) {
                                                NativeAuth.d0(mVar2.f5272i, bArr3, bArr4);
                                            }
                                        } else if (patternToken2 != null) {
                                            NativeAuth.t0(patternToken2);
                                        }
                                        jVar2.b();
                                        break;
                                }
                            }
                        });
                    } else {
                        handler2.post(new d4.c(jVar, d4.m.k(v.m.p.abcdstr(78)), 1));
                    }
                }
                break;
            default:
                e4.h0 h0Var = (e4.h0) this.f194c;
                String str9 = (String) this.f195d;
                String str10 = (String) this.e;
                e4.f0 f0Var = (e4.f0) this.f196f;
                if (str9.equals(h0Var.f5369d) && str10.equals(h0Var.f5370f)) {
                    e4.i0 i0VarE = h0Var.e(str10);
                    if (i0VarE != null) {
                        System.currentTimeMillis();
                        i0VarE.e = this.b;
                    }
                    h0Var.i(str10, f0Var);
                } else {
                    f0Var.b();
                }
                break;
        }
    }

    public /* synthetic */ q0(Object obj, String str, String str2, int i7, Object obj2, int i8) {
        this.f193a = i8;
        this.f194c = obj;
        this.f195d = str;
        this.e = str2;
        this.b = i7;
        this.f196f = obj2;
    }
}
