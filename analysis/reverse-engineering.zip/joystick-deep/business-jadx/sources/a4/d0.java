package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class d0 implements x1, h1, b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g0 f76a;

    public /* synthetic */ d0(g0 g0Var) {
        this.f76a = g0Var;
    }

    public void a(int i7) {
        float f2;
        a2 a2Var;
        i1 i1Var = this.f76a.f111m;
        int i8 = i1Var.b;
        if (i8 < 0) {
            return;
        }
        z1 z1Var = (z1) i1Var.f126a.get(i8);
        int iD = n.e.d(i7);
        float f7 = -1.0f;
        float f8 = 0.0f;
        if (iD != 0) {
            f2 = 1.0f;
            if (iD != 1) {
                if (iD == 2) {
                    f2 = 0.0f;
                } else if (iD != 3) {
                    f7 = 0.0f;
                    f2 = 0.0f;
                } else {
                    f7 = 1.0f;
                    f2 = 0.0f;
                }
            }
            float f9 = z1Var.f295a + f7;
            float f10 = z1Var.b + f2;
            int width = i1Var.getWidth();
            int height = i1Var.getHeight();
            a2Var = z1Var.e;
            if (a2Var != a2.f45g && a2Var != a2.f46h && a2Var != a2.e && a2Var != a2.f44f) {
                f8 = z1Var.f296c;
            }
            float fMax = Math.max(f8, Math.min(width - f8, f9));
            float fMax2 = Math.max(f8, Math.min(height - f8, f10));
            z1Var.f295a = fMax;
            z1Var.b = fMax2;
            i1Var.invalidate();
        }
        f2 = -1.0f;
        f7 = 0.0f;
        float f92 = z1Var.f295a + f7;
        float f102 = z1Var.b + f2;
        int width2 = i1Var.getWidth();
        int height2 = i1Var.getHeight();
        a2Var = z1Var.e;
        if (a2Var != a2.f45g) {
            f8 = z1Var.f296c;
        }
        float fMax3 = Math.max(f8, Math.min(width2 - f8, f92));
        float fMax22 = Math.max(f8, Math.min(height2 - f8, f102));
        z1Var.f295a = fMax3;
        z1Var.b = fMax22;
        i1Var.invalidate();
    }
}
