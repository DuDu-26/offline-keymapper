package a4;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Size;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class h implements e4.r, u3.a, h3.g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f116a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f117c;

    public /* synthetic */ h(Object obj, int i7, Object obj2) {
        this.f116a = i7;
        this.b = obj;
        this.f117c = obj2;
    }

    @Override // h3.g0
    public void a(boolean z6) {
        k3.l lVar = (k3.l) this.b;
        h3.z zVar = (h3.z) this.f117c;
        k3.t tVar = lVar.f6560c;
        k3.o oVar = k3.o.f6602q;
        tVar.m(oVar);
        tVar.q(oVar);
        lVar.f6582z = null;
        zVar.a(z6);
    }

    public void b() {
        b4.j jVar = (b4.j) this.b;
        e4.v vVar = (e4.v) this.f117c;
        if (vVar != null && vVar.getRecognitionView() != null) {
            vVar.getRecognitionView().d();
        }
        b4.q0 q0Var = ((b4.i) jVar.b).b.f1898d;
        if (q0Var != null) {
            q0Var.t();
        }
        p3.x.t().p();
    }

    public void c(androidx.appcompat.widget.b0 b0Var) {
        Point point = (Point) this.b;
        Rect rect = (Rect) this.f117c;
        p3.a0 a0VarI = p3.a0.i();
        if (!a0VarI.f7383m) {
            ((Point) b0Var.f714c).set(point.x, point.y);
            ((Rect) b0Var.f715d).set(rect);
            b0Var.b = 3;
            return;
        }
        Size sizeT = g.d.C().t();
        h3.x0 x0Var = a0VarI.f7376f;
        int pointerX = x0Var != null ? x0Var.getPointerX() : -1;
        h3.x0 x0Var2 = a0VarI.f7376f;
        int pointerY = x0Var2 != null ? x0Var2.getPointerY() : -1;
        if (pointerX < 0) {
            pointerX = sizeT.getWidth() / 2;
        }
        if (pointerY < 0) {
            pointerY = sizeT.getHeight() / 2;
        }
        ((Point) b0Var.f714c).set(pointerX - 3, pointerY - 3);
        ((Rect) b0Var.f715d).set(0, 0, sizeT.getWidth(), sizeT.getHeight());
        b0Var.b = 0;
    }

    @Override // u3.a
    public void d(int i7, q3.b bVar) {
        switch (this.f116a) {
            case 5:
                ((p3.f) this.f117c).e(i7, ((f4.a) this.b).f5629m, bVar);
                break;
            default:
                ((p3.f) this.f117c).e(i7, ((x3.b) this.b).f8777n, bVar);
                break;
        }
    }
}
