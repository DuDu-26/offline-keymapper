package a4;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class r1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f209a;
    public final /* synthetic */ String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f210c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ long f211d;
    public final /* synthetic */ String e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f212f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f213g;

    public /* synthetic */ r1(int i7, int i8, long j7, h3.i1 i1Var, h3.j1 j1Var, String str, String str2, String str3) {
        this.f209a = 2;
        this.f212f = j1Var;
        this.b = str;
        this.f210c = str2;
        this.f211d = j7;
        this.e = str3;
        this.f213g = i1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f209a) {
            case 0:
                u1 u1Var = (u1) this.f212f;
                t1 t1Var = (t1) this.f213g;
                v1 v1Var = new v1(this.f211d, this.b, this.f210c, false);
                v1Var.e = 1;
                if (this.e.equals(u1Var.f248d)) {
                    u1Var.e.add(v1Var);
                }
                t1Var.f(v1Var);
                break;
            case 1:
                e4.h0 h0Var = (e4.h0) this.f212f;
                e4.g0 g0Var = (e4.g0) this.f213g;
                e4.i0 i0Var = new e4.i0(this.f211d, this.b, this.f210c, false);
                i0Var.e = 1;
                if (this.e.equals(h0Var.f5369d)) {
                    h0Var.e.add(i0Var);
                }
                g0Var.c(i0Var);
                break;
            default:
                h3.j1 j1Var = (h3.j1) this.f212f;
                h3.i1 i1Var = (h3.i1) this.f213g;
                h3.c cVar = new h3.c();
                cVar.f5934a = this.b;
                cVar.b = this.f210c;
                cVar.f5935c = false;
                cVar.f5936d = this.f211d;
                cVar.e = 1;
                if (this.e.equals(j1Var.f6020d)) {
                    j1Var.e.add(cVar);
                }
                i1Var.d(cVar);
                break;
        }
    }

    public /* synthetic */ r1(Object obj, String str, String str2, long j7, String str3, Object obj2, int i7) {
        this.f209a = i7;
        this.f212f = obj;
        this.b = str;
        this.f210c = str2;
        this.f211d = j7;
        this.e = str3;
        this.f213g = obj2;
    }
}
