package a4;

import android.view.View;
import android.widget.TextView;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class i implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f120a;
    public final /* synthetic */ TextView b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Runnable f121c;

    public /* synthetic */ i(TextView textView, Runnable runnable, int i7) {
        this.f120a = i7;
        this.b = textView;
        this.f121c = runnable;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f120a) {
            case 0:
                if (this.b.isEnabled()) {
                    this.f121c.run();
                }
                break;
            case 1:
                if (this.b.isEnabled()) {
                    this.f121c.run();
                }
                break;
            case 2:
                if (this.b.isEnabled()) {
                    this.f121c.run();
                }
                break;
            case 3:
                if (this.b.isEnabled()) {
                    this.f121c.run();
                }
                break;
            default:
                if (this.b.isEnabled()) {
                    this.f121c.run();
                }
                break;
        }
    }
}
