package a4;

import android.graphics.Paint;
import android.graphics.PointF;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class z1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f295a;
    public float b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f296c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f297d;
    public final a2 e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Paint f298f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Paint f299g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Paint f300h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Paint f301i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Paint f302j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f303k = false;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f304l = false;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f305m = false;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f306n;

    public z1(a2 a2Var, float f2, float f7, float f8) {
        new PointF();
        this.f306n = 0;
        this.e = a2Var;
        this.f297d = "";
        this.f295a = f2;
        this.b = f7;
        this.f296c = f8;
        Paint paint = new Paint(1);
        this.f298f = paint;
        Paint.Style style = Paint.Style.STROKE;
        paint.setStyle(style);
        paint.setStrokeWidth(2.0f);
        paint.setColor(-1773873620);
        Paint paint2 = new Paint(1);
        this.f299g = paint2;
        Paint.Style style2 = Paint.Style.FILL;
        paint2.setStyle(style2);
        paint2.setColor(2013265920);
        Paint paint3 = new Paint(1);
        this.f300h = paint3;
        paint3.setColor(-1);
        paint3.setTextSize(20.0f);
        paint3.setTextAlign(Paint.Align.CENTER);
        Paint paint4 = new Paint(1);
        this.f301i = paint4;
        paint4.setStyle(style2);
        paint4.setColor(-1);
        Paint paint5 = new Paint(1);
        this.f302j = paint5;
        paint5.setStyle(style);
        paint5.setStrokeWidth(2.0f);
        paint5.setColor(-16777216);
    }

    public final void a(boolean z6) {
        this.f303k = z6;
        Paint paint = this.f298f;
        if (z6) {
            paint.setColor(-935012820);
            paint.setStrokeWidth(4.0f);
        } else {
            paint.setColor(-1773873620);
            paint.setStrokeWidth(2.0f);
        }
    }
}
