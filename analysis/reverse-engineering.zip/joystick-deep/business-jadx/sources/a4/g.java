package a4;

import a4.y0;
import android.R;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.widget.f3;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class g implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f109a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f110c;

    public /* synthetic */ g(Object obj, int i7, Object obj2) {
        this.f109a = i7;
        this.b = obj;
        this.f110c = obj2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        b4.q qVar;
        y3.t tVar;
        g.d dVar;
        switch (this.f109a) {
            case 0:
                t tVar2 = (t) this.b;
                i0.I().q(d1.u().f80d, (String) this.f110c);
                tVar2.i(tVar2.f220g);
                tVar2.h(tVar2.f223j);
                break;
            case 1:
                ((t) this.b).i((FrameLayout) this.f110c);
                break;
            case 2:
                ((t) this.b).i((View) this.f110c);
                i3.e.b();
                break;
            case 3:
                ((c0) this.b).h((FrameLayout) this.f110c);
                break;
            case 4:
                ((e4.k) this.b).g((FrameLayout) this.f110c);
                break;
            case 5:
                ((e4.s) this.b).g((FrameLayout) this.f110c);
                break;
            case 6:
                f3.g gVar = (f3.g) this.b;
                h hVar = (h) this.f110c;
                int i7 = gVar.f5626f;
                switch (hVar.f116a) {
                    case 0:
                        t tVar3 = (t) hVar.b;
                        e1 e1Var = (e1) hVar.f117c;
                        tVar3.i(tVar3.f220g);
                        tVar3.c(e1Var, i7);
                        break;
                    case 1:
                        c0 c0Var = (c0) hVar.b;
                        v1 v1Var = (v1) hVar.f117c;
                        c0Var.h(c0Var.f57g);
                        c0Var.c(v1Var, i7);
                        break;
                    case 2:
                    default:
                        h3.r rVar = (h3.r) hVar.b;
                        h3.c cVar = (h3.c) hVar.f117c;
                        rVar.i(rVar.f6112t);
                        rVar.f(cVar, i7);
                        break;
                    case 3:
                        e4.k kVar = (e4.k) hVar.b;
                        e4.x xVar = (e4.x) hVar.f117c;
                        kVar.g(kVar.f5395s);
                        kVar.c(xVar, i7);
                        break;
                    case 4:
                        e4.s sVar = (e4.s) hVar.b;
                        e4.i0 i0Var = (e4.i0) hVar.f117c;
                        sVar.g(sVar.f5450s);
                        sVar.c(i0Var, i7);
                        break;
                }
                break;
            case dd.f4082h /* 7 */:
                ((h3.r) this.b).i((FrameLayout) this.f110c);
                break;
            case 8:
                h3.w0 w0Var = (h3.w0) this.b;
                b4.j jVar = (b4.j) this.f110c;
                u3.d dVar2 = w0Var.f6128o;
                if (dVar2 != null) {
                    switch (jVar.f1845a) {
                        case 0:
                            moe.heroman.eventtest.auth.a.h();
                            b4.q qVar2 = ((b4.i) jVar.b).b;
                            if (moe.heroman.eventtest.auth.a.e(qVar2.f8246c)) {
                                k3.j jVar2 = (k3.j) dVar2;
                                jVar2.b.f6560c.m(k3.o.b);
                                k3.l lVar = jVar2.b;
                                if (((e4.v) jVar.f1846c) == null) {
                                    FloatingService floatingService = lVar.f6559a;
                                    e4.v vVar = new e4.v(floatingService);
                                    vVar.f5455p = true;
                                    vVar.setDraggable(false);
                                    FrameLayout frameLayout = new FrameLayout(floatingService);
                                    e4.l0 l0Var = new e4.l0(floatingService);
                                    vVar.f5452m = l0Var;
                                    ViewGroup.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
                                    j0 j0Var = new j0(floatingService, 1);
                                    final e4.p0 p0Var = new e4.p0(floatingService);
                                    p0Var.setOrientation(0);
                                    p0Var.setElevation(25.0f);
                                    int iC = p0Var.c(6);
                                    int iC2 = p0Var.c(4);
                                    p0Var.setPadding(iC, iC2, iC, iC2);
                                    GradientDrawable gradientDrawable = new GradientDrawable();
                                    int iA = androidx.core.content.c.a(p0Var.getContext(), 2131099747);
                                    gradientDrawable.setColor(Color.argb(230, Color.red(iA), Color.green(iA), Color.blue(iA)));
                                    gradientDrawable.setCornerRadius(p0Var.c(12));
                                    p0Var.setBackground(gradientDrawable);
                                    int iC3 = p0Var.c(6);
                                    LinearLayout linearLayoutB = p0Var.b(floatingService, 2131230933, p0Var.getResources().getString(2131821025));
                                    final int i8 = 0;
                                    linearLayoutB.setOnClickListener(new View.OnClickListener() { // from class: e4.n0
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view2) {
                                            u uVar;
                                            u uVar2;
                                            u uVar3;
                                            String str;
                                            switch (i8) {
                                                case 0:
                                                    o0 o0Var = p0Var.f5430a;
                                                    if (o0Var != null && (uVar = ((v) ((w3.e) o0Var).b).f5456q) != null) {
                                                        w3.b bVar = (w3.b) uVar;
                                                        b4.j jVar3 = (b4.j) bVar.f8545c;
                                                        u3.d dVar3 = (u3.d) bVar.b;
                                                        v vVar2 = (v) jVar3.f1846c;
                                                        s sVar2 = new s(((k3.j) dVar3).b.f6559a);
                                                        sVar2.setOnConfigChangedListener(new a4.h(jVar3, 2, vVar2));
                                                        sVar2.setOnCloseListener(new f3(8));
                                                        k3.t tVarE = k3.t.e();
                                                        EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                        y0 y0Var = new y0(new l(sVar2, 1), new l(sVar2, 2), new a4.l(4, sVar2));
                                                        k3.o oVar = k3.o.f6603r;
                                                        tVarE.l(new l3.a(oVar, enumSetOf, y0Var));
                                                        k3.t.e().n(oVar);
                                                        sVar2.post(new l(sVar2, 3));
                                                        break;
                                                    }
                                                    break;
                                                case 1:
                                                    o0 o0Var2 = p0Var.f5430a;
                                                    if (o0Var2 != null && (uVar2 = ((v) ((w3.e) o0Var2).b).f5456q) != null) {
                                                        w3.b bVar2 = (w3.b) uVar2;
                                                        b4.j.b((b4.j) bVar2.f8545c, (u3.d) bVar2.b);
                                                        break;
                                                    }
                                                    break;
                                                case 2:
                                                    o0 o0Var3 = p0Var.f5430a;
                                                    if (o0Var3 != null) {
                                                        v vVar3 = (v) ((w3.e) o0Var3).b;
                                                        l0 l0Var2 = vVar3.f5452m;
                                                        if (l0Var2 != null) {
                                                            l0Var2.f5397a.clear();
                                                            Size sizeX = g.d.C().x();
                                                            float width = sizeX.getWidth();
                                                            float height = sizeX.getHeight();
                                                            float f2 = width / 2.0f;
                                                            float f7 = height / 2.0f;
                                                            float f8 = 0.182f * height;
                                                            float f9 = f7 - f8;
                                                            float f10 = 0.042f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5457d, f2, f9, f10));
                                                            if (!y2.l.i().d()) {
                                                                l0Var2.f5397a.add(l0Var2.c(w.e, (height * 0.13f) + f2, f9, f10));
                                                            }
                                                            float f11 = f7 + f8;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5458f, f2 - (0.13f * height), f11, f10));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5459g, f2, f11, f10));
                                                            float f12 = f2 - f8;
                                                            float f13 = 0.078f * height;
                                                            float f14 = f7 - f13;
                                                            float f15 = 0.063f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5460h, f12, f14, f15));
                                                            float f16 = (0.016f * height) + f7;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5461i, f12, f16, f15));
                                                            float f17 = f2 - f13;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5462j, f17, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5463k, f17, f16, f15));
                                                            float f18 = (0.026f * height) + f2;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5464l, f18, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5465m, f18, f16, f15));
                                                            float f19 = (0.104f * height) + f7;
                                                            float f20 = 0.125f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5466n, f2 - (0.146f * height), f19, f20));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5467o, (0.021f * height) + f2, f19, f20));
                                                            float f21 = 0.11f * width;
                                                            float f22 = 0.052f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5468p, f21, f11, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5469q, f21, f11 + f15, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5470r, f21, (f15 * 2.0f) + f11, f22));
                                                            boolean zD = y2.l.i().d();
                                                            ArrayList arrayList = l0Var2.f5397a;
                                                            if (zD) {
                                                                r0.h(arrayList, width, height);
                                                            } else {
                                                                r0.i(arrayList, width, height);
                                                            }
                                                            l0Var2.a();
                                                            l0Var2.b = null;
                                                            l0Var2.f5400f = null;
                                                            n4.a aVar = l0Var2.e;
                                                            aVar.f7161q = false;
                                                            aVar.f7162r = false;
                                                            aVar.f7160p = false;
                                                            l0Var2.invalidate();
                                                        }
                                                        u uVar4 = vVar3.f5456q;
                                                        if (uVar4 != null) {
                                                            b4.j jVar4 = (b4.j) ((w3.b) uVar4).f8545c;
                                                            v vVar4 = (v) jVar4.f1846c;
                                                            if (vVar4 != null && vVar4.getRecognitionView() != null) {
                                                                ((v) jVar4.f1846c).getRecognitionView().d();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case 3:
                                                    o0 o0Var4 = p0Var.f5430a;
                                                    if (o0Var4 != null && (uVar3 = ((v) ((w3.e) o0Var4).b).f5456q) != null) {
                                                        w3.b bVar3 = (w3.b) uVar3;
                                                        b4.j jVar5 = (b4.j) bVar3.f8545c;
                                                        v vVar5 = (v) jVar5.f1846c;
                                                        if (vVar5 == null || vVar5.getRecognitionView() == null) {
                                                            b4.j.b(jVar5, (u3.d) bVar3.b);
                                                        } else {
                                                            List<m0> nodes = ((v) jVar5.f1846c).getRecognitionView().getNodes();
                                                            h0 h0VarO = h0.o();
                                                            final w3.e eVar = new w3.e(13, bVar3);
                                                            Handler handler = h0VarO.f5368c;
                                                            if (h0VarO.f5369d == null || (str = h0VarO.f5370f) == null) {
                                                                final int i9 = 1;
                                                                handler.post(new Runnable() { // from class: e4.y
                                                                    @Override // java.lang.Runnable
                                                                    public final void run() {
                                                                        switch (i9) {
                                                                            case 0:
                                                                                eVar.a(v.m.p.abcdstr(31));
                                                                                break;
                                                                            case 1:
                                                                                eVar.a(v.m.p.abcdstr(72));
                                                                                break;
                                                                            default:
                                                                                eVar.a(v.m.p.abcdstr(71));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                i0 i0VarE = h0VarO.e(str);
                                                                if (i0VarE == null) {
                                                                    final int i10 = 2;
                                                                    handler.post(new Runnable() { // from class: e4.y
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i10) {
                                                                                case 0:
                                                                                    eVar.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    eVar.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    eVar.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else if (!i0VarE.f5376c) {
                                                                    h0VarO.n(str, nodes, eVar);
                                                                } else {
                                                                    String str2 = h0VarO.f5369d;
                                                                    String str3 = i0VarE.f5375a;
                                                                    if (str2 != null) {
                                                                        h0VarO.c(h0VarO.f(i0VarE.b), new q6.c(h0VarO, str2, str3, eVar, new ArrayList(nodes), i0VarE, 4));
                                                                    } else {
                                                                        final int i11 = 0;
                                                                        handler.post(new Runnable() { // from class: e4.y
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i11) {
                                                                                    case 0:
                                                                                        eVar.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        eVar.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        eVar.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                default:
                                                    o0 o0Var5 = p0Var.f5430a;
                                                    if (o0Var5 != null) {
                                                        v vVar6 = (v) ((w3.e) o0Var5).b;
                                                        boolean z6 = vVar6.f5455p;
                                                        vVar6.f5455p = !z6;
                                                        vVar6.f5454o.setVisibility(!z6 ? 0 : 8);
                                                        vVar6.f5453n.setDPadExpanded(vVar6.f5455p);
                                                    }
                                                    break;
                                            }
                                        }
                                    });
                                    p0Var.a(linearLayoutB, iC3);
                                    LinearLayout linearLayoutB2 = p0Var.b(floatingService, 2131230892, p0Var.getResources().getString(2131820610));
                                    final int i9 = 1;
                                    linearLayoutB2.setOnClickListener(new View.OnClickListener() { // from class: e4.n0
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view2) {
                                            u uVar;
                                            u uVar2;
                                            u uVar3;
                                            String str;
                                            switch (i9) {
                                                case 0:
                                                    o0 o0Var = p0Var.f5430a;
                                                    if (o0Var != null && (uVar = ((v) ((w3.e) o0Var).b).f5456q) != null) {
                                                        w3.b bVar = (w3.b) uVar;
                                                        b4.j jVar3 = (b4.j) bVar.f8545c;
                                                        u3.d dVar3 = (u3.d) bVar.b;
                                                        v vVar2 = (v) jVar3.f1846c;
                                                        s sVar2 = new s(((k3.j) dVar3).b.f6559a);
                                                        sVar2.setOnConfigChangedListener(new a4.h(jVar3, 2, vVar2));
                                                        sVar2.setOnCloseListener(new f3(8));
                                                        k3.t tVarE = k3.t.e();
                                                        EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                        y0 y0Var = new y0(new l(sVar2, 1), new l(sVar2, 2), new a4.l(4, sVar2));
                                                        k3.o oVar = k3.o.f6603r;
                                                        tVarE.l(new l3.a(oVar, enumSetOf, y0Var));
                                                        k3.t.e().n(oVar);
                                                        sVar2.post(new l(sVar2, 3));
                                                        break;
                                                    }
                                                    break;
                                                case 1:
                                                    o0 o0Var2 = p0Var.f5430a;
                                                    if (o0Var2 != null && (uVar2 = ((v) ((w3.e) o0Var2).b).f5456q) != null) {
                                                        w3.b bVar2 = (w3.b) uVar2;
                                                        b4.j.b((b4.j) bVar2.f8545c, (u3.d) bVar2.b);
                                                        break;
                                                    }
                                                    break;
                                                case 2:
                                                    o0 o0Var3 = p0Var.f5430a;
                                                    if (o0Var3 != null) {
                                                        v vVar3 = (v) ((w3.e) o0Var3).b;
                                                        l0 l0Var2 = vVar3.f5452m;
                                                        if (l0Var2 != null) {
                                                            l0Var2.f5397a.clear();
                                                            Size sizeX = g.d.C().x();
                                                            float width = sizeX.getWidth();
                                                            float height = sizeX.getHeight();
                                                            float f2 = width / 2.0f;
                                                            float f7 = height / 2.0f;
                                                            float f8 = 0.182f * height;
                                                            float f9 = f7 - f8;
                                                            float f10 = 0.042f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5457d, f2, f9, f10));
                                                            if (!y2.l.i().d()) {
                                                                l0Var2.f5397a.add(l0Var2.c(w.e, (height * 0.13f) + f2, f9, f10));
                                                            }
                                                            float f11 = f7 + f8;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5458f, f2 - (0.13f * height), f11, f10));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5459g, f2, f11, f10));
                                                            float f12 = f2 - f8;
                                                            float f13 = 0.078f * height;
                                                            float f14 = f7 - f13;
                                                            float f15 = 0.063f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5460h, f12, f14, f15));
                                                            float f16 = (0.016f * height) + f7;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5461i, f12, f16, f15));
                                                            float f17 = f2 - f13;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5462j, f17, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5463k, f17, f16, f15));
                                                            float f18 = (0.026f * height) + f2;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5464l, f18, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5465m, f18, f16, f15));
                                                            float f19 = (0.104f * height) + f7;
                                                            float f20 = 0.125f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5466n, f2 - (0.146f * height), f19, f20));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5467o, (0.021f * height) + f2, f19, f20));
                                                            float f21 = 0.11f * width;
                                                            float f22 = 0.052f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5468p, f21, f11, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5469q, f21, f11 + f15, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5470r, f21, (f15 * 2.0f) + f11, f22));
                                                            boolean zD = y2.l.i().d();
                                                            ArrayList arrayList = l0Var2.f5397a;
                                                            if (zD) {
                                                                r0.h(arrayList, width, height);
                                                            } else {
                                                                r0.i(arrayList, width, height);
                                                            }
                                                            l0Var2.a();
                                                            l0Var2.b = null;
                                                            l0Var2.f5400f = null;
                                                            n4.a aVar = l0Var2.e;
                                                            aVar.f7161q = false;
                                                            aVar.f7162r = false;
                                                            aVar.f7160p = false;
                                                            l0Var2.invalidate();
                                                        }
                                                        u uVar4 = vVar3.f5456q;
                                                        if (uVar4 != null) {
                                                            b4.j jVar4 = (b4.j) ((w3.b) uVar4).f8545c;
                                                            v vVar4 = (v) jVar4.f1846c;
                                                            if (vVar4 != null && vVar4.getRecognitionView() != null) {
                                                                ((v) jVar4.f1846c).getRecognitionView().d();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case 3:
                                                    o0 o0Var4 = p0Var.f5430a;
                                                    if (o0Var4 != null && (uVar3 = ((v) ((w3.e) o0Var4).b).f5456q) != null) {
                                                        w3.b bVar3 = (w3.b) uVar3;
                                                        b4.j jVar5 = (b4.j) bVar3.f8545c;
                                                        v vVar5 = (v) jVar5.f1846c;
                                                        if (vVar5 == null || vVar5.getRecognitionView() == null) {
                                                            b4.j.b(jVar5, (u3.d) bVar3.b);
                                                        } else {
                                                            List<m0> nodes = ((v) jVar5.f1846c).getRecognitionView().getNodes();
                                                            h0 h0VarO = h0.o();
                                                            final w3.e eVar = new w3.e(13, bVar3);
                                                            Handler handler = h0VarO.f5368c;
                                                            if (h0VarO.f5369d == null || (str = h0VarO.f5370f) == null) {
                                                                final int i92 = 1;
                                                                handler.post(new Runnable() { // from class: e4.y
                                                                    @Override // java.lang.Runnable
                                                                    public final void run() {
                                                                        switch (i92) {
                                                                            case 0:
                                                                                eVar.a(v.m.p.abcdstr(31));
                                                                                break;
                                                                            case 1:
                                                                                eVar.a(v.m.p.abcdstr(72));
                                                                                break;
                                                                            default:
                                                                                eVar.a(v.m.p.abcdstr(71));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                i0 i0VarE = h0VarO.e(str);
                                                                if (i0VarE == null) {
                                                                    final int i10 = 2;
                                                                    handler.post(new Runnable() { // from class: e4.y
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i10) {
                                                                                case 0:
                                                                                    eVar.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    eVar.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    eVar.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else if (!i0VarE.f5376c) {
                                                                    h0VarO.n(str, nodes, eVar);
                                                                } else {
                                                                    String str2 = h0VarO.f5369d;
                                                                    String str3 = i0VarE.f5375a;
                                                                    if (str2 != null) {
                                                                        h0VarO.c(h0VarO.f(i0VarE.b), new q6.c(h0VarO, str2, str3, eVar, new ArrayList(nodes), i0VarE, 4));
                                                                    } else {
                                                                        final int i11 = 0;
                                                                        handler.post(new Runnable() { // from class: e4.y
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i11) {
                                                                                    case 0:
                                                                                        eVar.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        eVar.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        eVar.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                default:
                                                    o0 o0Var5 = p0Var.f5430a;
                                                    if (o0Var5 != null) {
                                                        v vVar6 = (v) ((w3.e) o0Var5).b;
                                                        boolean z6 = vVar6.f5455p;
                                                        vVar6.f5455p = !z6;
                                                        vVar6.f5454o.setVisibility(!z6 ? 0 : 8);
                                                        vVar6.f5453n.setDPadExpanded(vVar6.f5455p);
                                                    }
                                                    break;
                                            }
                                        }
                                    });
                                    p0Var.a(linearLayoutB2, iC3);
                                    LinearLayout linearLayoutB3 = p0Var.b(floatingService, 2131230928, p0Var.getResources().getString(2131821064));
                                    final int i10 = 2;
                                    linearLayoutB3.setOnClickListener(new View.OnClickListener() { // from class: e4.n0
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view2) {
                                            u uVar;
                                            u uVar2;
                                            u uVar3;
                                            String str;
                                            switch (i10) {
                                                case 0:
                                                    o0 o0Var = p0Var.f5430a;
                                                    if (o0Var != null && (uVar = ((v) ((w3.e) o0Var).b).f5456q) != null) {
                                                        w3.b bVar = (w3.b) uVar;
                                                        b4.j jVar3 = (b4.j) bVar.f8545c;
                                                        u3.d dVar3 = (u3.d) bVar.b;
                                                        v vVar2 = (v) jVar3.f1846c;
                                                        s sVar2 = new s(((k3.j) dVar3).b.f6559a);
                                                        sVar2.setOnConfigChangedListener(new a4.h(jVar3, 2, vVar2));
                                                        sVar2.setOnCloseListener(new f3(8));
                                                        k3.t tVarE = k3.t.e();
                                                        EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                        y0 y0Var = new y0(new l(sVar2, 1), new l(sVar2, 2), new a4.l(4, sVar2));
                                                        k3.o oVar = k3.o.f6603r;
                                                        tVarE.l(new l3.a(oVar, enumSetOf, y0Var));
                                                        k3.t.e().n(oVar);
                                                        sVar2.post(new l(sVar2, 3));
                                                        break;
                                                    }
                                                    break;
                                                case 1:
                                                    o0 o0Var2 = p0Var.f5430a;
                                                    if (o0Var2 != null && (uVar2 = ((v) ((w3.e) o0Var2).b).f5456q) != null) {
                                                        w3.b bVar2 = (w3.b) uVar2;
                                                        b4.j.b((b4.j) bVar2.f8545c, (u3.d) bVar2.b);
                                                        break;
                                                    }
                                                    break;
                                                case 2:
                                                    o0 o0Var3 = p0Var.f5430a;
                                                    if (o0Var3 != null) {
                                                        v vVar3 = (v) ((w3.e) o0Var3).b;
                                                        l0 l0Var2 = vVar3.f5452m;
                                                        if (l0Var2 != null) {
                                                            l0Var2.f5397a.clear();
                                                            Size sizeX = g.d.C().x();
                                                            float width = sizeX.getWidth();
                                                            float height = sizeX.getHeight();
                                                            float f2 = width / 2.0f;
                                                            float f7 = height / 2.0f;
                                                            float f8 = 0.182f * height;
                                                            float f9 = f7 - f8;
                                                            float f10 = 0.042f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5457d, f2, f9, f10));
                                                            if (!y2.l.i().d()) {
                                                                l0Var2.f5397a.add(l0Var2.c(w.e, (height * 0.13f) + f2, f9, f10));
                                                            }
                                                            float f11 = f7 + f8;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5458f, f2 - (0.13f * height), f11, f10));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5459g, f2, f11, f10));
                                                            float f12 = f2 - f8;
                                                            float f13 = 0.078f * height;
                                                            float f14 = f7 - f13;
                                                            float f15 = 0.063f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5460h, f12, f14, f15));
                                                            float f16 = (0.016f * height) + f7;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5461i, f12, f16, f15));
                                                            float f17 = f2 - f13;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5462j, f17, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5463k, f17, f16, f15));
                                                            float f18 = (0.026f * height) + f2;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5464l, f18, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5465m, f18, f16, f15));
                                                            float f19 = (0.104f * height) + f7;
                                                            float f20 = 0.125f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5466n, f2 - (0.146f * height), f19, f20));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5467o, (0.021f * height) + f2, f19, f20));
                                                            float f21 = 0.11f * width;
                                                            float f22 = 0.052f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5468p, f21, f11, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5469q, f21, f11 + f15, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5470r, f21, (f15 * 2.0f) + f11, f22));
                                                            boolean zD = y2.l.i().d();
                                                            ArrayList arrayList = l0Var2.f5397a;
                                                            if (zD) {
                                                                r0.h(arrayList, width, height);
                                                            } else {
                                                                r0.i(arrayList, width, height);
                                                            }
                                                            l0Var2.a();
                                                            l0Var2.b = null;
                                                            l0Var2.f5400f = null;
                                                            n4.a aVar = l0Var2.e;
                                                            aVar.f7161q = false;
                                                            aVar.f7162r = false;
                                                            aVar.f7160p = false;
                                                            l0Var2.invalidate();
                                                        }
                                                        u uVar4 = vVar3.f5456q;
                                                        if (uVar4 != null) {
                                                            b4.j jVar4 = (b4.j) ((w3.b) uVar4).f8545c;
                                                            v vVar4 = (v) jVar4.f1846c;
                                                            if (vVar4 != null && vVar4.getRecognitionView() != null) {
                                                                ((v) jVar4.f1846c).getRecognitionView().d();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case 3:
                                                    o0 o0Var4 = p0Var.f5430a;
                                                    if (o0Var4 != null && (uVar3 = ((v) ((w3.e) o0Var4).b).f5456q) != null) {
                                                        w3.b bVar3 = (w3.b) uVar3;
                                                        b4.j jVar5 = (b4.j) bVar3.f8545c;
                                                        v vVar5 = (v) jVar5.f1846c;
                                                        if (vVar5 == null || vVar5.getRecognitionView() == null) {
                                                            b4.j.b(jVar5, (u3.d) bVar3.b);
                                                        } else {
                                                            List<m0> nodes = ((v) jVar5.f1846c).getRecognitionView().getNodes();
                                                            h0 h0VarO = h0.o();
                                                            final w3.e eVar = new w3.e(13, bVar3);
                                                            Handler handler = h0VarO.f5368c;
                                                            if (h0VarO.f5369d == null || (str = h0VarO.f5370f) == null) {
                                                                final int i92 = 1;
                                                                handler.post(new Runnable() { // from class: e4.y
                                                                    @Override // java.lang.Runnable
                                                                    public final void run() {
                                                                        switch (i92) {
                                                                            case 0:
                                                                                eVar.a(v.m.p.abcdstr(31));
                                                                                break;
                                                                            case 1:
                                                                                eVar.a(v.m.p.abcdstr(72));
                                                                                break;
                                                                            default:
                                                                                eVar.a(v.m.p.abcdstr(71));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                i0 i0VarE = h0VarO.e(str);
                                                                if (i0VarE == null) {
                                                                    final int i102 = 2;
                                                                    handler.post(new Runnable() { // from class: e4.y
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i102) {
                                                                                case 0:
                                                                                    eVar.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    eVar.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    eVar.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else if (!i0VarE.f5376c) {
                                                                    h0VarO.n(str, nodes, eVar);
                                                                } else {
                                                                    String str2 = h0VarO.f5369d;
                                                                    String str3 = i0VarE.f5375a;
                                                                    if (str2 != null) {
                                                                        h0VarO.c(h0VarO.f(i0VarE.b), new q6.c(h0VarO, str2, str3, eVar, new ArrayList(nodes), i0VarE, 4));
                                                                    } else {
                                                                        final int i11 = 0;
                                                                        handler.post(new Runnable() { // from class: e4.y
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i11) {
                                                                                    case 0:
                                                                                        eVar.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        eVar.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        eVar.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                default:
                                                    o0 o0Var5 = p0Var.f5430a;
                                                    if (o0Var5 != null) {
                                                        v vVar6 = (v) ((w3.e) o0Var5).b;
                                                        boolean z6 = vVar6.f5455p;
                                                        vVar6.f5455p = !z6;
                                                        vVar6.f5454o.setVisibility(!z6 ? 0 : 8);
                                                        vVar6.f5453n.setDPadExpanded(vVar6.f5455p);
                                                    }
                                                    break;
                                            }
                                        }
                                    });
                                    p0Var.a(linearLayoutB3, iC3);
                                    LinearLayout linearLayoutB4 = p0Var.b(floatingService, 2131230929, p0Var.getResources().getString(2131821114));
                                    final int i11 = 3;
                                    linearLayoutB4.setOnClickListener(new View.OnClickListener() { // from class: e4.n0
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view2) {
                                            u uVar;
                                            u uVar2;
                                            u uVar3;
                                            String str;
                                            switch (i11) {
                                                case 0:
                                                    o0 o0Var = p0Var.f5430a;
                                                    if (o0Var != null && (uVar = ((v) ((w3.e) o0Var).b).f5456q) != null) {
                                                        w3.b bVar = (w3.b) uVar;
                                                        b4.j jVar3 = (b4.j) bVar.f8545c;
                                                        u3.d dVar3 = (u3.d) bVar.b;
                                                        v vVar2 = (v) jVar3.f1846c;
                                                        s sVar2 = new s(((k3.j) dVar3).b.f6559a);
                                                        sVar2.setOnConfigChangedListener(new a4.h(jVar3, 2, vVar2));
                                                        sVar2.setOnCloseListener(new f3(8));
                                                        k3.t tVarE = k3.t.e();
                                                        EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                        y0 y0Var = new y0(new l(sVar2, 1), new l(sVar2, 2), new a4.l(4, sVar2));
                                                        k3.o oVar = k3.o.f6603r;
                                                        tVarE.l(new l3.a(oVar, enumSetOf, y0Var));
                                                        k3.t.e().n(oVar);
                                                        sVar2.post(new l(sVar2, 3));
                                                        break;
                                                    }
                                                    break;
                                                case 1:
                                                    o0 o0Var2 = p0Var.f5430a;
                                                    if (o0Var2 != null && (uVar2 = ((v) ((w3.e) o0Var2).b).f5456q) != null) {
                                                        w3.b bVar2 = (w3.b) uVar2;
                                                        b4.j.b((b4.j) bVar2.f8545c, (u3.d) bVar2.b);
                                                        break;
                                                    }
                                                    break;
                                                case 2:
                                                    o0 o0Var3 = p0Var.f5430a;
                                                    if (o0Var3 != null) {
                                                        v vVar3 = (v) ((w3.e) o0Var3).b;
                                                        l0 l0Var2 = vVar3.f5452m;
                                                        if (l0Var2 != null) {
                                                            l0Var2.f5397a.clear();
                                                            Size sizeX = g.d.C().x();
                                                            float width = sizeX.getWidth();
                                                            float height = sizeX.getHeight();
                                                            float f2 = width / 2.0f;
                                                            float f7 = height / 2.0f;
                                                            float f8 = 0.182f * height;
                                                            float f9 = f7 - f8;
                                                            float f10 = 0.042f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5457d, f2, f9, f10));
                                                            if (!y2.l.i().d()) {
                                                                l0Var2.f5397a.add(l0Var2.c(w.e, (height * 0.13f) + f2, f9, f10));
                                                            }
                                                            float f11 = f7 + f8;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5458f, f2 - (0.13f * height), f11, f10));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5459g, f2, f11, f10));
                                                            float f12 = f2 - f8;
                                                            float f13 = 0.078f * height;
                                                            float f14 = f7 - f13;
                                                            float f15 = 0.063f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5460h, f12, f14, f15));
                                                            float f16 = (0.016f * height) + f7;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5461i, f12, f16, f15));
                                                            float f17 = f2 - f13;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5462j, f17, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5463k, f17, f16, f15));
                                                            float f18 = (0.026f * height) + f2;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5464l, f18, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5465m, f18, f16, f15));
                                                            float f19 = (0.104f * height) + f7;
                                                            float f20 = 0.125f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5466n, f2 - (0.146f * height), f19, f20));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5467o, (0.021f * height) + f2, f19, f20));
                                                            float f21 = 0.11f * width;
                                                            float f22 = 0.052f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5468p, f21, f11, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5469q, f21, f11 + f15, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5470r, f21, (f15 * 2.0f) + f11, f22));
                                                            boolean zD = y2.l.i().d();
                                                            ArrayList arrayList = l0Var2.f5397a;
                                                            if (zD) {
                                                                r0.h(arrayList, width, height);
                                                            } else {
                                                                r0.i(arrayList, width, height);
                                                            }
                                                            l0Var2.a();
                                                            l0Var2.b = null;
                                                            l0Var2.f5400f = null;
                                                            n4.a aVar = l0Var2.e;
                                                            aVar.f7161q = false;
                                                            aVar.f7162r = false;
                                                            aVar.f7160p = false;
                                                            l0Var2.invalidate();
                                                        }
                                                        u uVar4 = vVar3.f5456q;
                                                        if (uVar4 != null) {
                                                            b4.j jVar4 = (b4.j) ((w3.b) uVar4).f8545c;
                                                            v vVar4 = (v) jVar4.f1846c;
                                                            if (vVar4 != null && vVar4.getRecognitionView() != null) {
                                                                ((v) jVar4.f1846c).getRecognitionView().d();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case 3:
                                                    o0 o0Var4 = p0Var.f5430a;
                                                    if (o0Var4 != null && (uVar3 = ((v) ((w3.e) o0Var4).b).f5456q) != null) {
                                                        w3.b bVar3 = (w3.b) uVar3;
                                                        b4.j jVar5 = (b4.j) bVar3.f8545c;
                                                        v vVar5 = (v) jVar5.f1846c;
                                                        if (vVar5 == null || vVar5.getRecognitionView() == null) {
                                                            b4.j.b(jVar5, (u3.d) bVar3.b);
                                                        } else {
                                                            List<m0> nodes = ((v) jVar5.f1846c).getRecognitionView().getNodes();
                                                            h0 h0VarO = h0.o();
                                                            final w3.e eVar = new w3.e(13, bVar3);
                                                            Handler handler = h0VarO.f5368c;
                                                            if (h0VarO.f5369d == null || (str = h0VarO.f5370f) == null) {
                                                                final int i92 = 1;
                                                                handler.post(new Runnable() { // from class: e4.y
                                                                    @Override // java.lang.Runnable
                                                                    public final void run() {
                                                                        switch (i92) {
                                                                            case 0:
                                                                                eVar.a(v.m.p.abcdstr(31));
                                                                                break;
                                                                            case 1:
                                                                                eVar.a(v.m.p.abcdstr(72));
                                                                                break;
                                                                            default:
                                                                                eVar.a(v.m.p.abcdstr(71));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                i0 i0VarE = h0VarO.e(str);
                                                                if (i0VarE == null) {
                                                                    final int i102 = 2;
                                                                    handler.post(new Runnable() { // from class: e4.y
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i102) {
                                                                                case 0:
                                                                                    eVar.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    eVar.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    eVar.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else if (!i0VarE.f5376c) {
                                                                    h0VarO.n(str, nodes, eVar);
                                                                } else {
                                                                    String str2 = h0VarO.f5369d;
                                                                    String str3 = i0VarE.f5375a;
                                                                    if (str2 != null) {
                                                                        h0VarO.c(h0VarO.f(i0VarE.b), new q6.c(h0VarO, str2, str3, eVar, new ArrayList(nodes), i0VarE, 4));
                                                                    } else {
                                                                        final int i112 = 0;
                                                                        handler.post(new Runnable() { // from class: e4.y
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i112) {
                                                                                    case 0:
                                                                                        eVar.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        eVar.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        eVar.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                default:
                                                    o0 o0Var5 = p0Var.f5430a;
                                                    if (o0Var5 != null) {
                                                        v vVar6 = (v) ((w3.e) o0Var5).b;
                                                        boolean z6 = vVar6.f5455p;
                                                        vVar6.f5455p = !z6;
                                                        vVar6.f5454o.setVisibility(!z6 ? 0 : 8);
                                                        vVar6.f5453n.setDPadExpanded(vVar6.f5455p);
                                                    }
                                                    break;
                                            }
                                        }
                                    });
                                    p0Var.a(linearLayoutB4, iC3);
                                    String string = p0Var.getResources().getString(2131821027);
                                    LinearLayout linearLayout = new LinearLayout(floatingService);
                                    linearLayout.setOrientation(1);
                                    linearLayout.setClickable(true);
                                    linearLayout.setFocusable(true);
                                    qVar = qVar2;
                                    linearLayout.setPadding(p0Var.c(4), p0Var.c(4), p0Var.c(4), p0Var.c(4));
                                    linearLayout.setGravity(1);
                                    int iC4 = p0Var.c(28);
                                    ImageView imageView = new ImageView(floatingService);
                                    p0Var.b = imageView;
                                    imageView.setImageResource(2131230889);
                                    p0Var.b.setColorFilter(androidx.core.content.c.a(floatingService, 2131099745));
                                    p0Var.b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                                    p0Var.b.setLayoutParams(new LinearLayout.LayoutParams(iC4, iC4));
                                    TextView textView = new TextView(floatingService);
                                    textView.setText(string);
                                    textView.setTextColor(-1);
                                    textView.setTextSize(11.0f);
                                    textView.setPadding(0, p0Var.c(3), 0, 0);
                                    linearLayout.addView(p0Var.b);
                                    linearLayout.addView(textView, new LinearLayout.LayoutParams(-2, -2));
                                    TypedArray typedArrayObtainStyledAttributes = floatingService.obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
                                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
                                    typedArrayObtainStyledAttributes.recycle();
                                    if (resourceId != 0) {
                                        linearLayout.setBackgroundResource(resourceId);
                                    }
                                    final int i12 = 4;
                                    linearLayout.setOnClickListener(new View.OnClickListener() { // from class: e4.n0
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view2) {
                                            u uVar;
                                            u uVar2;
                                            u uVar3;
                                            String str;
                                            switch (i12) {
                                                case 0:
                                                    o0 o0Var = p0Var.f5430a;
                                                    if (o0Var != null && (uVar = ((v) ((w3.e) o0Var).b).f5456q) != null) {
                                                        w3.b bVar = (w3.b) uVar;
                                                        b4.j jVar3 = (b4.j) bVar.f8545c;
                                                        u3.d dVar3 = (u3.d) bVar.b;
                                                        v vVar2 = (v) jVar3.f1846c;
                                                        s sVar2 = new s(((k3.j) dVar3).b.f6559a);
                                                        sVar2.setOnConfigChangedListener(new a4.h(jVar3, 2, vVar2));
                                                        sVar2.setOnCloseListener(new f3(8));
                                                        k3.t tVarE = k3.t.e();
                                                        EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                        y0 y0Var = new y0(new l(sVar2, 1), new l(sVar2, 2), new a4.l(4, sVar2));
                                                        k3.o oVar = k3.o.f6603r;
                                                        tVarE.l(new l3.a(oVar, enumSetOf, y0Var));
                                                        k3.t.e().n(oVar);
                                                        sVar2.post(new l(sVar2, 3));
                                                        break;
                                                    }
                                                    break;
                                                case 1:
                                                    o0 o0Var2 = p0Var.f5430a;
                                                    if (o0Var2 != null && (uVar2 = ((v) ((w3.e) o0Var2).b).f5456q) != null) {
                                                        w3.b bVar2 = (w3.b) uVar2;
                                                        b4.j.b((b4.j) bVar2.f8545c, (u3.d) bVar2.b);
                                                        break;
                                                    }
                                                    break;
                                                case 2:
                                                    o0 o0Var3 = p0Var.f5430a;
                                                    if (o0Var3 != null) {
                                                        v vVar3 = (v) ((w3.e) o0Var3).b;
                                                        l0 l0Var2 = vVar3.f5452m;
                                                        if (l0Var2 != null) {
                                                            l0Var2.f5397a.clear();
                                                            Size sizeX = g.d.C().x();
                                                            float width = sizeX.getWidth();
                                                            float height = sizeX.getHeight();
                                                            float f2 = width / 2.0f;
                                                            float f7 = height / 2.0f;
                                                            float f8 = 0.182f * height;
                                                            float f9 = f7 - f8;
                                                            float f10 = 0.042f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5457d, f2, f9, f10));
                                                            if (!y2.l.i().d()) {
                                                                l0Var2.f5397a.add(l0Var2.c(w.e, (height * 0.13f) + f2, f9, f10));
                                                            }
                                                            float f11 = f7 + f8;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5458f, f2 - (0.13f * height), f11, f10));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5459g, f2, f11, f10));
                                                            float f12 = f2 - f8;
                                                            float f13 = 0.078f * height;
                                                            float f14 = f7 - f13;
                                                            float f15 = 0.063f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5460h, f12, f14, f15));
                                                            float f16 = (0.016f * height) + f7;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5461i, f12, f16, f15));
                                                            float f17 = f2 - f13;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5462j, f17, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5463k, f17, f16, f15));
                                                            float f18 = (0.026f * height) + f2;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5464l, f18, f14, f15));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5465m, f18, f16, f15));
                                                            float f19 = (0.104f * height) + f7;
                                                            float f20 = 0.125f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5466n, f2 - (0.146f * height), f19, f20));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5467o, (0.021f * height) + f2, f19, f20));
                                                            float f21 = 0.11f * width;
                                                            float f22 = 0.052f * height;
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5468p, f21, f11, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5469q, f21, f11 + f15, f22));
                                                            l0Var2.f5397a.add(l0Var2.c(w.f5470r, f21, (f15 * 2.0f) + f11, f22));
                                                            boolean zD = y2.l.i().d();
                                                            ArrayList arrayList = l0Var2.f5397a;
                                                            if (zD) {
                                                                r0.h(arrayList, width, height);
                                                            } else {
                                                                r0.i(arrayList, width, height);
                                                            }
                                                            l0Var2.a();
                                                            l0Var2.b = null;
                                                            l0Var2.f5400f = null;
                                                            n4.a aVar = l0Var2.e;
                                                            aVar.f7161q = false;
                                                            aVar.f7162r = false;
                                                            aVar.f7160p = false;
                                                            l0Var2.invalidate();
                                                        }
                                                        u uVar4 = vVar3.f5456q;
                                                        if (uVar4 != null) {
                                                            b4.j jVar4 = (b4.j) ((w3.b) uVar4).f8545c;
                                                            v vVar4 = (v) jVar4.f1846c;
                                                            if (vVar4 != null && vVar4.getRecognitionView() != null) {
                                                                ((v) jVar4.f1846c).getRecognitionView().d();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case 3:
                                                    o0 o0Var4 = p0Var.f5430a;
                                                    if (o0Var4 != null && (uVar3 = ((v) ((w3.e) o0Var4).b).f5456q) != null) {
                                                        w3.b bVar3 = (w3.b) uVar3;
                                                        b4.j jVar5 = (b4.j) bVar3.f8545c;
                                                        v vVar5 = (v) jVar5.f1846c;
                                                        if (vVar5 == null || vVar5.getRecognitionView() == null) {
                                                            b4.j.b(jVar5, (u3.d) bVar3.b);
                                                        } else {
                                                            List<m0> nodes = ((v) jVar5.f1846c).getRecognitionView().getNodes();
                                                            h0 h0VarO = h0.o();
                                                            final w3.e eVar = new w3.e(13, bVar3);
                                                            Handler handler = h0VarO.f5368c;
                                                            if (h0VarO.f5369d == null || (str = h0VarO.f5370f) == null) {
                                                                final int i92 = 1;
                                                                handler.post(new Runnable() { // from class: e4.y
                                                                    @Override // java.lang.Runnable
                                                                    public final void run() {
                                                                        switch (i92) {
                                                                            case 0:
                                                                                eVar.a(v.m.p.abcdstr(31));
                                                                                break;
                                                                            case 1:
                                                                                eVar.a(v.m.p.abcdstr(72));
                                                                                break;
                                                                            default:
                                                                                eVar.a(v.m.p.abcdstr(71));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                i0 i0VarE = h0VarO.e(str);
                                                                if (i0VarE == null) {
                                                                    final int i102 = 2;
                                                                    handler.post(new Runnable() { // from class: e4.y
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i102) {
                                                                                case 0:
                                                                                    eVar.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    eVar.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    eVar.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else if (!i0VarE.f5376c) {
                                                                    h0VarO.n(str, nodes, eVar);
                                                                } else {
                                                                    String str2 = h0VarO.f5369d;
                                                                    String str3 = i0VarE.f5375a;
                                                                    if (str2 != null) {
                                                                        h0VarO.c(h0VarO.f(i0VarE.b), new q6.c(h0VarO, str2, str3, eVar, new ArrayList(nodes), i0VarE, 4));
                                                                    } else {
                                                                        final int i112 = 0;
                                                                        handler.post(new Runnable() { // from class: e4.y
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i112) {
                                                                                    case 0:
                                                                                        eVar.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        eVar.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        eVar.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                default:
                                                    o0 o0Var5 = p0Var.f5430a;
                                                    if (o0Var5 != null) {
                                                        v vVar6 = (v) ((w3.e) o0Var5).b;
                                                        boolean z6 = vVar6.f5455p;
                                                        vVar6.f5455p = !z6;
                                                        vVar6.f5454o.setVisibility(!z6 ? 0 : 8);
                                                        vVar6.f5453n.setDPadExpanded(vVar6.f5455p);
                                                    }
                                                    break;
                                            }
                                        }
                                    });
                                    p0Var.a(linearLayout, 0);
                                    vVar.f5453n = p0Var;
                                    p0Var.setOnToolbarClickListener(new w3.e(23, vVar));
                                    e4.c cVar2 = new e4.c(floatingService);
                                    vVar.f5454o = cVar2;
                                    cVar2.setOnDirectionListener(new e4.t(vVar));
                                    l0Var.setOnNodeSelectionListener(new e4.t(vVar));
                                    LinearLayout linearLayout2 = new LinearLayout(floatingService);
                                    linearLayout2.setOrientation(1);
                                    linearLayout2.setElevation(25.0f);
                                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                                    int iA2 = androidx.core.content.c.a(floatingService, 2131099747);
                                    gradientDrawable2.setColor(Color.argb(230, Color.red(iA2), Color.green(iA2), Color.blue(iA2)));
                                    gradientDrawable2.setCornerRadius(vVar.k(12));
                                    linearLayout2.setBackground(gradientDrawable2);
                                    p0Var.setBackground(null);
                                    linearLayout2.addView(p0Var, new LinearLayout.LayoutParams(-2, -2));
                                    LinearLayout linearLayout3 = new LinearLayout(floatingService);
                                    linearLayout3.setOrientation(0);
                                    linearLayout3.setGravity(16);
                                    linearLayout3.setPadding(vVar.k(10), vVar.k(2), vVar.k(6), vVar.k(2));
                                    TextView textView2 = new TextView(floatingService);
                                    textView2.setText(2131821303);
                                    textView2.setTextColor(-1);
                                    textView2.setTextSize(12.0f);
                                    textView2.setMaxLines(1);
                                    Switch r13 = new Switch(floatingService);
                                    r13.setChecked(((SharedPreferences) y2.l.i().f8978a).getBoolean(v.m.p.abcdstr(46), false));
                                    r13.setOnCheckedChangeListener(new e0(1, vVar));
                                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                                    layoutParams2.rightMargin = vVar.k(8);
                                    linearLayout3.addView(textView2, layoutParams2);
                                    linearLayout3.addView(r13, new LinearLayout.LayoutParams(-2, -2));
                                    linearLayout2.addView(linearLayout3, new LinearLayout.LayoutParams(-1, -2));
                                    j0Var.addView(linearLayout2, new LinearLayout.LayoutParams(-2, -2));
                                    j0Var.addView(cVar2, new LinearLayout.LayoutParams(-2, -2));
                                    FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
                                    layoutParams3.gravity = 49;
                                    frameLayout.addView(l0Var, layoutParams);
                                    frameLayout.addView(j0Var, layoutParams3);
                                    vVar.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
                                    jVar.f1846c = vVar;
                                    WindowManager.LayoutParams layoutParams4 = new WindowManager.LayoutParams(-1, -1, 2038, 808, -3);
                                    layoutParams4.layoutInDisplayCutoutMode = 1;
                                    if (Build.VERSION.SDK_INT >= 30) {
                                        g0.f.f(layoutParams4);
                                    }
                                    layoutParams4.gravity = 8388659;
                                    layoutParams4.x = 0;
                                    layoutParams4.y = 0;
                                    ((e4.v) jVar.f1846c).setLayoutParams(layoutParams4);
                                    ((e4.v) jVar.f1846c).setWindowManager(lVar.b);
                                    ((e4.v) jVar.f1846c).setOnToolbarActionListener(new w3.b(jVar, 4, jVar2));
                                } else {
                                    qVar = qVar2;
                                }
                                e4.v vVar2 = (e4.v) jVar.f1846c;
                                if (vVar2 != null && vVar2.getRecognitionView() != null && !((e4.v) jVar.f1846c).getRecognitionView().d()) {
                                    FloatingService.f6880k.a(qVar.f8245a.getString(2131820638));
                                }
                                k3.t tVar4 = lVar.f6560c;
                                k3.o oVar = k3.o.f6607v;
                                if (tVar4.f(oVar) == null) {
                                    tVar4.l(new l3.a(oVar, EnumSet.of(k3.n.f6586a, k3.n.b), (e4.v) jVar.f1846c));
                                }
                                tVar4.n(oVar);
                                break;
                            }
                            break;
                        case 1:
                            moe.heroman.eventtest.auth.a.h();
                            if (moe.heroman.eventtest.auth.a.f(((b4.i) jVar.b).b.f8246c)) {
                                k3.j jVar3 = (k3.j) dVar2;
                                jVar3.b.f6560c.m(k3.o.b);
                                if (((e4.k) jVar.f1846c) == null) {
                                    jVar.f1846c = new e4.k(jVar3.b.f6559a);
                                }
                                ((e4.k) jVar.f1846c).setOnConfigChangedListener(new f1(2, jVar));
                                ((e4.k) jVar.f1846c).setOnCloseListener(new f3(9));
                                e4.k kVar2 = (e4.k) jVar.f1846c;
                                kVar2.getClass();
                                k3.t tVarE = k3.t.e();
                                k3.o oVar2 = k3.o.f6604s;
                                tVarE.l(new l3.a(oVar2, EnumSet.of(k3.n.f6586a, k3.n.b), new y0(new e4.d(kVar2, 2), new e4.d(kVar2, 3), new l(3, kVar2))));
                                k3.t.e().n(oVar2);
                                kVar2.e(kVar2.f5385i);
                                kVar2.post(new e4.d(kVar2, 4));
                                break;
                            }
                            break;
                        case 2:
                            moe.heroman.eventtest.auth.a.h();
                            y3.t tVar5 = ((y3.q) jVar.b).f9123a;
                            if (moe.heroman.eventtest.auth.a.f(tVar5.f8246c)) {
                                if (!y2.l.i().c()) {
                                    FloatingService.f6880k.a(tVar5.f8245a.getString(2131820716));
                                } else {
                                    k3.j jVar4 = (k3.j) dVar2;
                                    jVar4.b.f6560c.m(k3.o.b);
                                    if (((t) jVar.f1846c) == null) {
                                        jVar.f1846c = new t(jVar4.b.f6559a);
                                    }
                                    ((t) jVar.f1846c).setOnConfigChangedListener(new y3.r(jVar));
                                    ((t) jVar.f1846c).setOnConfigRenamedListener(new y3.r(jVar));
                                    ((t) jVar.f1846c).setOnCloseListener(new k3.g(24));
                                    t tVar6 = (t) jVar.f1846c;
                                    tVar6.getClass();
                                    k3.t tVarE2 = k3.t.e();
                                    k3.o oVar3 = k3.o.f6606u;
                                    tVarE2.l(new l3.a(oVar3, EnumSet.of(k3.n.f6586a, k3.n.b), new y0(new c(tVar6, 5), new c(tVar6, 6), new l(0, tVar6))));
                                    try {
                                        k3.t.e().n(oVar3);
                                        tVar6.g();
                                        tVar6.post(new c(tVar6, 7));
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        return;
                                    }
                                }
                                break;
                            }
                            break;
                        default:
                            moe.heroman.eventtest.auth.a.h();
                            y3.t tVar7 = ((y3.q) jVar.b).f9123a;
                            if (moe.heroman.eventtest.auth.a.e(tVar7.f8246c)) {
                                if (!((SharedPreferences) y2.l.i().f8978a).getBoolean(v.m.p.abcdstr(59), false)) {
                                    FloatingService.f6880k.a(tVar7.f8245a.getString(2131820715));
                                } else {
                                    k3.j jVar5 = (k3.j) dVar2;
                                    jVar5.b.f6560c.m(k3.o.b);
                                    k3.l lVar2 = jVar5.b;
                                    if (((g0) jVar.f1846c) == null) {
                                        FloatingService floatingService2 = lVar2.f6559a;
                                        g0 g0Var = new g0(floatingService2);
                                        g0Var.f114p = true;
                                        g0Var.setDraggable(false);
                                        FrameLayout frameLayout2 = new FrameLayout(floatingService2);
                                        i1 i1Var = new i1(floatingService2);
                                        g0Var.f111m = i1Var;
                                        ViewGroup.LayoutParams layoutParams5 = new FrameLayout.LayoutParams(-1, -1);
                                        j0 j0Var2 = new j0(floatingService2, 0);
                                        final d2 d2Var = new d2(floatingService2);
                                        d2Var.setOrientation(0);
                                        d2Var.setElevation(25.0f);
                                        int iC5 = d2Var.c(6);
                                        int iC6 = d2Var.c(4);
                                        d2Var.setPadding(iC5, iC6, iC5, iC6);
                                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                                        d2Var.f94c = gradientDrawable3;
                                        int iA3 = androidx.core.content.c.a(d2Var.getContext(), 2131099747);
                                        gradientDrawable3.setColor(Color.argb(230, Color.red(iA3), Color.green(iA3), Color.blue(iA3)));
                                        d2Var.f95d = d2Var.c(12);
                                        d2Var.d(true);
                                        d2Var.setBackground(gradientDrawable3);
                                        int iC7 = d2Var.c(6);
                                        LinearLayout linearLayoutB5 = d2Var.b(floatingService2, 2131230933, d2Var.getResources().getString(2131821025));
                                        final int i13 = 0;
                                        linearLayoutB5.setOnClickListener(new View.OnClickListener() { // from class: a4.b2
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                f0 f0Var;
                                                f0 f0Var2;
                                                g0 g0Var2;
                                                f0 f0Var3;
                                                String str;
                                                switch (i13) {
                                                    case 0:
                                                        c2 c2Var = d2Var.f93a;
                                                        if (c2Var != null && (f0Var = ((g0) ((w3.e) c2Var).b).f115q) != null) {
                                                            y2.o oVar4 = (y2.o) f0Var;
                                                            b4.j jVar6 = (b4.j) oVar4.f8985c;
                                                            u3.d dVar3 = (u3.d) oVar4.b;
                                                            g0 g0Var3 = (g0) jVar6.f1846c;
                                                            c0 c0Var2 = new c0(((k3.j) dVar3).b.f6559a);
                                                            c0Var2.setOnConfigChangedListener(new d0(g0Var3));
                                                            c0Var2.setOnCloseListener(new k3.g(25));
                                                            k3.t tVarE3 = k3.t.e();
                                                            EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                            y0 y0Var = new y0(new u(c0Var2, 0), new u(c0Var2, 1), new l(1, c0Var2));
                                                            k3.o oVar5 = k3.o.f6605t;
                                                            tVarE3.l(new l3.a(oVar5, enumSetOf, y0Var));
                                                            try {
                                                                k3.t.e().n(oVar5);
                                                                c0Var2.f();
                                                                c0Var2.post(new u(c0Var2, 2));
                                                            } catch (Exception e3) {
                                                                e3.printStackTrace();
                                                                return;
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    case 1:
                                                        c2 c2Var2 = d2Var.f93a;
                                                        if (c2Var2 != null && (f0Var2 = ((g0) ((w3.e) c2Var2).b).f115q) != null) {
                                                            y2.o oVar6 = (y2.o) f0Var2;
                                                            b4.j.a((b4.j) oVar6.f8985c, (u3.d) oVar6.b);
                                                            break;
                                                        }
                                                        break;
                                                    case 2:
                                                        c2 c2Var3 = d2Var.f93a;
                                                        if (c2Var3 != null) {
                                                            g0 g0Var4 = (g0) ((w3.e) c2Var3).b;
                                                            i1 i1Var2 = g0Var4.f111m;
                                                            if (i1Var2 != null) {
                                                                ArrayList arrayList = i1Var2.f126a;
                                                                arrayList.clear();
                                                                i1Var2.b = -1;
                                                                i1Var2.f132i = null;
                                                                n4.a aVar = i1Var2.f131h;
                                                                aVar.f7161q = false;
                                                                aVar.f7162r = false;
                                                                aVar.f7160p = false;
                                                                Size sizeX = g.d.C().x();
                                                                float width = sizeX.getWidth();
                                                                float height = sizeX.getHeight();
                                                                float f2 = width / 2.0f;
                                                                float f7 = height / 2.0f;
                                                                Context context = i1Var2.getContext();
                                                                float f8 = 0.13f * height;
                                                                float f9 = (0.182f * height) + f7;
                                                                float f10 = 0.042f * height;
                                                                z1 z1Var = new z1(a2.b, f2 - f8, f9, f10);
                                                                z1Var.f297d = context.getString(2131820697);
                                                                arrayList.add(z1Var);
                                                                z1 z1Var2 = new z1(a2.f42c, f2, f9, f10);
                                                                z1Var2.f297d = context.getString(2131820702);
                                                                arrayList.add(z1Var2);
                                                                z1 z1Var3 = new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10);
                                                                z1Var3.f297d = context.getString(2131820703);
                                                                arrayList.add(z1Var3);
                                                                i1.c(arrayList, width, height);
                                                                i1Var2.f();
                                                                i1.a(arrayList, width, height);
                                                                i1Var2.e();
                                                                i1Var2.d();
                                                                h1 h1Var = i1Var2.f129f;
                                                                if (h1Var != null) {
                                                                    ((d0) h1Var).f76a.f113o.setEnabled(false);
                                                                }
                                                                i1Var2.invalidate();
                                                            }
                                                            f0 f0Var4 = g0Var4.f115q;
                                                            if (f0Var4 != null && (g0Var2 = (g0) ((b4.j) ((y2.o) f0Var4).f8985c).f1846c) != null) {
                                                                g0Var2.l();
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        c2 c2Var4 = d2Var.f93a;
                                                        if (c2Var4 != null && (f0Var3 = ((g0) ((w3.e) c2Var4).b).f115q) != null) {
                                                            y2.o oVar7 = (y2.o) f0Var3;
                                                            b4.j jVar7 = (b4.j) oVar7.f8985c;
                                                            g0 g0Var5 = (g0) jVar7.f1846c;
                                                            if (g0Var5 == null) {
                                                                b4.j.a(jVar7, (u3.d) oVar7.b);
                                                            } else {
                                                                List<z1> nodes = g0Var5.getNodes();
                                                                u1 u1VarN = u1.n();
                                                                final x3.d dVar4 = new x3.d(oVar7);
                                                                Handler handler = u1VarN.f247c;
                                                                if (u1VarN.f248d == null || (str = u1VarN.f249f) == null) {
                                                                    final int i14 = 1;
                                                                    handler.post(new Runnable() { // from class: a4.j1
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i14) {
                                                                                case 0:
                                                                                    dVar4.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    dVar4.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    dVar4.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else {
                                                                    v1 v1VarD = u1VarN.d(str);
                                                                    if (v1VarD == null) {
                                                                        final int i15 = 2;
                                                                        handler.post(new Runnable() { // from class: a4.j1
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i15) {
                                                                                    case 0:
                                                                                        dVar4.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        dVar4.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        dVar4.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    } else if (!v1VarD.f258c) {
                                                                        u1VarN.m(v1VarD, nodes, dVar4);
                                                                    } else {
                                                                        String str2 = u1VarN.f248d;
                                                                        String str3 = v1VarD.f257a;
                                                                        if (str2 != null) {
                                                                            u1VarN.c(u1VarN.e(v1VarD.b), new q6.c(u1VarN, str2, str3, dVar4, new ArrayList(nodes), v1VarD, 1));
                                                                        } else {
                                                                            final int i16 = 0;
                                                                            handler.post(new Runnable() { // from class: a4.j1
                                                                                @Override // java.lang.Runnable
                                                                                public final void run() {
                                                                                    switch (i16) {
                                                                                        case 0:
                                                                                            dVar4.a(v.m.p.abcdstr(31));
                                                                                            break;
                                                                                        case 1:
                                                                                            dVar4.a(v.m.p.abcdstr(72));
                                                                                            break;
                                                                                        default:
                                                                                            dVar4.a(v.m.p.abcdstr(71));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        c2 c2Var5 = d2Var.f93a;
                                                        if (c2Var5 != null) {
                                                            g0 g0Var6 = (g0) ((w3.e) c2Var5).b;
                                                            boolean z6 = g0Var6.f114p;
                                                            g0Var6.f114p = !z6;
                                                            g0Var6.f113o.setVisibility(!z6 ? 0 : 8);
                                                            g0Var6.f112n.setDPadExpanded(g0Var6.f114p);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                        d2Var.a(linearLayoutB5, iC7);
                                        LinearLayout linearLayoutB6 = d2Var.b(floatingService2, 2131230892, d2Var.getResources().getString(2131820610));
                                        final int i14 = 1;
                                        linearLayoutB6.setOnClickListener(new View.OnClickListener() { // from class: a4.b2
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                f0 f0Var;
                                                f0 f0Var2;
                                                g0 g0Var2;
                                                f0 f0Var3;
                                                String str;
                                                switch (i14) {
                                                    case 0:
                                                        c2 c2Var = d2Var.f93a;
                                                        if (c2Var != null && (f0Var = ((g0) ((w3.e) c2Var).b).f115q) != null) {
                                                            y2.o oVar4 = (y2.o) f0Var;
                                                            b4.j jVar6 = (b4.j) oVar4.f8985c;
                                                            u3.d dVar3 = (u3.d) oVar4.b;
                                                            g0 g0Var3 = (g0) jVar6.f1846c;
                                                            c0 c0Var2 = new c0(((k3.j) dVar3).b.f6559a);
                                                            c0Var2.setOnConfigChangedListener(new d0(g0Var3));
                                                            c0Var2.setOnCloseListener(new k3.g(25));
                                                            k3.t tVarE3 = k3.t.e();
                                                            EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                            y0 y0Var = new y0(new u(c0Var2, 0), new u(c0Var2, 1), new l(1, c0Var2));
                                                            k3.o oVar5 = k3.o.f6605t;
                                                            tVarE3.l(new l3.a(oVar5, enumSetOf, y0Var));
                                                            try {
                                                                k3.t.e().n(oVar5);
                                                                c0Var2.f();
                                                                c0Var2.post(new u(c0Var2, 2));
                                                            } catch (Exception e3) {
                                                                e3.printStackTrace();
                                                                return;
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    case 1:
                                                        c2 c2Var2 = d2Var.f93a;
                                                        if (c2Var2 != null && (f0Var2 = ((g0) ((w3.e) c2Var2).b).f115q) != null) {
                                                            y2.o oVar6 = (y2.o) f0Var2;
                                                            b4.j.a((b4.j) oVar6.f8985c, (u3.d) oVar6.b);
                                                            break;
                                                        }
                                                        break;
                                                    case 2:
                                                        c2 c2Var3 = d2Var.f93a;
                                                        if (c2Var3 != null) {
                                                            g0 g0Var4 = (g0) ((w3.e) c2Var3).b;
                                                            i1 i1Var2 = g0Var4.f111m;
                                                            if (i1Var2 != null) {
                                                                ArrayList arrayList = i1Var2.f126a;
                                                                arrayList.clear();
                                                                i1Var2.b = -1;
                                                                i1Var2.f132i = null;
                                                                n4.a aVar = i1Var2.f131h;
                                                                aVar.f7161q = false;
                                                                aVar.f7162r = false;
                                                                aVar.f7160p = false;
                                                                Size sizeX = g.d.C().x();
                                                                float width = sizeX.getWidth();
                                                                float height = sizeX.getHeight();
                                                                float f2 = width / 2.0f;
                                                                float f7 = height / 2.0f;
                                                                Context context = i1Var2.getContext();
                                                                float f8 = 0.13f * height;
                                                                float f9 = (0.182f * height) + f7;
                                                                float f10 = 0.042f * height;
                                                                z1 z1Var = new z1(a2.b, f2 - f8, f9, f10);
                                                                z1Var.f297d = context.getString(2131820697);
                                                                arrayList.add(z1Var);
                                                                z1 z1Var2 = new z1(a2.f42c, f2, f9, f10);
                                                                z1Var2.f297d = context.getString(2131820702);
                                                                arrayList.add(z1Var2);
                                                                z1 z1Var3 = new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10);
                                                                z1Var3.f297d = context.getString(2131820703);
                                                                arrayList.add(z1Var3);
                                                                i1.c(arrayList, width, height);
                                                                i1Var2.f();
                                                                i1.a(arrayList, width, height);
                                                                i1Var2.e();
                                                                i1Var2.d();
                                                                h1 h1Var = i1Var2.f129f;
                                                                if (h1Var != null) {
                                                                    ((d0) h1Var).f76a.f113o.setEnabled(false);
                                                                }
                                                                i1Var2.invalidate();
                                                            }
                                                            f0 f0Var4 = g0Var4.f115q;
                                                            if (f0Var4 != null && (g0Var2 = (g0) ((b4.j) ((y2.o) f0Var4).f8985c).f1846c) != null) {
                                                                g0Var2.l();
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        c2 c2Var4 = d2Var.f93a;
                                                        if (c2Var4 != null && (f0Var3 = ((g0) ((w3.e) c2Var4).b).f115q) != null) {
                                                            y2.o oVar7 = (y2.o) f0Var3;
                                                            b4.j jVar7 = (b4.j) oVar7.f8985c;
                                                            g0 g0Var5 = (g0) jVar7.f1846c;
                                                            if (g0Var5 == null) {
                                                                b4.j.a(jVar7, (u3.d) oVar7.b);
                                                            } else {
                                                                List<z1> nodes = g0Var5.getNodes();
                                                                u1 u1VarN = u1.n();
                                                                final x3.d dVar4 = new x3.d(oVar7);
                                                                Handler handler = u1VarN.f247c;
                                                                if (u1VarN.f248d == null || (str = u1VarN.f249f) == null) {
                                                                    final int i142 = 1;
                                                                    handler.post(new Runnable() { // from class: a4.j1
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i142) {
                                                                                case 0:
                                                                                    dVar4.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    dVar4.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    dVar4.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else {
                                                                    v1 v1VarD = u1VarN.d(str);
                                                                    if (v1VarD == null) {
                                                                        final int i15 = 2;
                                                                        handler.post(new Runnable() { // from class: a4.j1
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i15) {
                                                                                    case 0:
                                                                                        dVar4.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        dVar4.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        dVar4.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    } else if (!v1VarD.f258c) {
                                                                        u1VarN.m(v1VarD, nodes, dVar4);
                                                                    } else {
                                                                        String str2 = u1VarN.f248d;
                                                                        String str3 = v1VarD.f257a;
                                                                        if (str2 != null) {
                                                                            u1VarN.c(u1VarN.e(v1VarD.b), new q6.c(u1VarN, str2, str3, dVar4, new ArrayList(nodes), v1VarD, 1));
                                                                        } else {
                                                                            final int i16 = 0;
                                                                            handler.post(new Runnable() { // from class: a4.j1
                                                                                @Override // java.lang.Runnable
                                                                                public final void run() {
                                                                                    switch (i16) {
                                                                                        case 0:
                                                                                            dVar4.a(v.m.p.abcdstr(31));
                                                                                            break;
                                                                                        case 1:
                                                                                            dVar4.a(v.m.p.abcdstr(72));
                                                                                            break;
                                                                                        default:
                                                                                            dVar4.a(v.m.p.abcdstr(71));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        c2 c2Var5 = d2Var.f93a;
                                                        if (c2Var5 != null) {
                                                            g0 g0Var6 = (g0) ((w3.e) c2Var5).b;
                                                            boolean z6 = g0Var6.f114p;
                                                            g0Var6.f114p = !z6;
                                                            g0Var6.f113o.setVisibility(!z6 ? 0 : 8);
                                                            g0Var6.f112n.setDPadExpanded(g0Var6.f114p);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                        d2Var.a(linearLayoutB6, iC7);
                                        LinearLayout linearLayoutB7 = d2Var.b(floatingService2, 2131230928, d2Var.getResources().getString(2131821064));
                                        final int i15 = 2;
                                        linearLayoutB7.setOnClickListener(new View.OnClickListener() { // from class: a4.b2
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                f0 f0Var;
                                                f0 f0Var2;
                                                g0 g0Var2;
                                                f0 f0Var3;
                                                String str;
                                                switch (i15) {
                                                    case 0:
                                                        c2 c2Var = d2Var.f93a;
                                                        if (c2Var != null && (f0Var = ((g0) ((w3.e) c2Var).b).f115q) != null) {
                                                            y2.o oVar4 = (y2.o) f0Var;
                                                            b4.j jVar6 = (b4.j) oVar4.f8985c;
                                                            u3.d dVar3 = (u3.d) oVar4.b;
                                                            g0 g0Var3 = (g0) jVar6.f1846c;
                                                            c0 c0Var2 = new c0(((k3.j) dVar3).b.f6559a);
                                                            c0Var2.setOnConfigChangedListener(new d0(g0Var3));
                                                            c0Var2.setOnCloseListener(new k3.g(25));
                                                            k3.t tVarE3 = k3.t.e();
                                                            EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                            y0 y0Var = new y0(new u(c0Var2, 0), new u(c0Var2, 1), new l(1, c0Var2));
                                                            k3.o oVar5 = k3.o.f6605t;
                                                            tVarE3.l(new l3.a(oVar5, enumSetOf, y0Var));
                                                            try {
                                                                k3.t.e().n(oVar5);
                                                                c0Var2.f();
                                                                c0Var2.post(new u(c0Var2, 2));
                                                            } catch (Exception e3) {
                                                                e3.printStackTrace();
                                                                return;
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    case 1:
                                                        c2 c2Var2 = d2Var.f93a;
                                                        if (c2Var2 != null && (f0Var2 = ((g0) ((w3.e) c2Var2).b).f115q) != null) {
                                                            y2.o oVar6 = (y2.o) f0Var2;
                                                            b4.j.a((b4.j) oVar6.f8985c, (u3.d) oVar6.b);
                                                            break;
                                                        }
                                                        break;
                                                    case 2:
                                                        c2 c2Var3 = d2Var.f93a;
                                                        if (c2Var3 != null) {
                                                            g0 g0Var4 = (g0) ((w3.e) c2Var3).b;
                                                            i1 i1Var2 = g0Var4.f111m;
                                                            if (i1Var2 != null) {
                                                                ArrayList arrayList = i1Var2.f126a;
                                                                arrayList.clear();
                                                                i1Var2.b = -1;
                                                                i1Var2.f132i = null;
                                                                n4.a aVar = i1Var2.f131h;
                                                                aVar.f7161q = false;
                                                                aVar.f7162r = false;
                                                                aVar.f7160p = false;
                                                                Size sizeX = g.d.C().x();
                                                                float width = sizeX.getWidth();
                                                                float height = sizeX.getHeight();
                                                                float f2 = width / 2.0f;
                                                                float f7 = height / 2.0f;
                                                                Context context = i1Var2.getContext();
                                                                float f8 = 0.13f * height;
                                                                float f9 = (0.182f * height) + f7;
                                                                float f10 = 0.042f * height;
                                                                z1 z1Var = new z1(a2.b, f2 - f8, f9, f10);
                                                                z1Var.f297d = context.getString(2131820697);
                                                                arrayList.add(z1Var);
                                                                z1 z1Var2 = new z1(a2.f42c, f2, f9, f10);
                                                                z1Var2.f297d = context.getString(2131820702);
                                                                arrayList.add(z1Var2);
                                                                z1 z1Var3 = new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10);
                                                                z1Var3.f297d = context.getString(2131820703);
                                                                arrayList.add(z1Var3);
                                                                i1.c(arrayList, width, height);
                                                                i1Var2.f();
                                                                i1.a(arrayList, width, height);
                                                                i1Var2.e();
                                                                i1Var2.d();
                                                                h1 h1Var = i1Var2.f129f;
                                                                if (h1Var != null) {
                                                                    ((d0) h1Var).f76a.f113o.setEnabled(false);
                                                                }
                                                                i1Var2.invalidate();
                                                            }
                                                            f0 f0Var4 = g0Var4.f115q;
                                                            if (f0Var4 != null && (g0Var2 = (g0) ((b4.j) ((y2.o) f0Var4).f8985c).f1846c) != null) {
                                                                g0Var2.l();
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        c2 c2Var4 = d2Var.f93a;
                                                        if (c2Var4 != null && (f0Var3 = ((g0) ((w3.e) c2Var4).b).f115q) != null) {
                                                            y2.o oVar7 = (y2.o) f0Var3;
                                                            b4.j jVar7 = (b4.j) oVar7.f8985c;
                                                            g0 g0Var5 = (g0) jVar7.f1846c;
                                                            if (g0Var5 == null) {
                                                                b4.j.a(jVar7, (u3.d) oVar7.b);
                                                            } else {
                                                                List<z1> nodes = g0Var5.getNodes();
                                                                u1 u1VarN = u1.n();
                                                                final x3.d dVar4 = new x3.d(oVar7);
                                                                Handler handler = u1VarN.f247c;
                                                                if (u1VarN.f248d == null || (str = u1VarN.f249f) == null) {
                                                                    final int i142 = 1;
                                                                    handler.post(new Runnable() { // from class: a4.j1
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i142) {
                                                                                case 0:
                                                                                    dVar4.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    dVar4.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    dVar4.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else {
                                                                    v1 v1VarD = u1VarN.d(str);
                                                                    if (v1VarD == null) {
                                                                        final int i152 = 2;
                                                                        handler.post(new Runnable() { // from class: a4.j1
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i152) {
                                                                                    case 0:
                                                                                        dVar4.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        dVar4.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        dVar4.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    } else if (!v1VarD.f258c) {
                                                                        u1VarN.m(v1VarD, nodes, dVar4);
                                                                    } else {
                                                                        String str2 = u1VarN.f248d;
                                                                        String str3 = v1VarD.f257a;
                                                                        if (str2 != null) {
                                                                            u1VarN.c(u1VarN.e(v1VarD.b), new q6.c(u1VarN, str2, str3, dVar4, new ArrayList(nodes), v1VarD, 1));
                                                                        } else {
                                                                            final int i16 = 0;
                                                                            handler.post(new Runnable() { // from class: a4.j1
                                                                                @Override // java.lang.Runnable
                                                                                public final void run() {
                                                                                    switch (i16) {
                                                                                        case 0:
                                                                                            dVar4.a(v.m.p.abcdstr(31));
                                                                                            break;
                                                                                        case 1:
                                                                                            dVar4.a(v.m.p.abcdstr(72));
                                                                                            break;
                                                                                        default:
                                                                                            dVar4.a(v.m.p.abcdstr(71));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        c2 c2Var5 = d2Var.f93a;
                                                        if (c2Var5 != null) {
                                                            g0 g0Var6 = (g0) ((w3.e) c2Var5).b;
                                                            boolean z6 = g0Var6.f114p;
                                                            g0Var6.f114p = !z6;
                                                            g0Var6.f113o.setVisibility(!z6 ? 0 : 8);
                                                            g0Var6.f112n.setDPadExpanded(g0Var6.f114p);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                        d2Var.a(linearLayoutB7, iC7);
                                        LinearLayout linearLayoutB8 = d2Var.b(floatingService2, 2131230929, d2Var.getResources().getString(2131821114));
                                        final int i16 = 3;
                                        linearLayoutB8.setOnClickListener(new View.OnClickListener() { // from class: a4.b2
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                f0 f0Var;
                                                f0 f0Var2;
                                                g0 g0Var2;
                                                f0 f0Var3;
                                                String str;
                                                switch (i16) {
                                                    case 0:
                                                        c2 c2Var = d2Var.f93a;
                                                        if (c2Var != null && (f0Var = ((g0) ((w3.e) c2Var).b).f115q) != null) {
                                                            y2.o oVar4 = (y2.o) f0Var;
                                                            b4.j jVar6 = (b4.j) oVar4.f8985c;
                                                            u3.d dVar3 = (u3.d) oVar4.b;
                                                            g0 g0Var3 = (g0) jVar6.f1846c;
                                                            c0 c0Var2 = new c0(((k3.j) dVar3).b.f6559a);
                                                            c0Var2.setOnConfigChangedListener(new d0(g0Var3));
                                                            c0Var2.setOnCloseListener(new k3.g(25));
                                                            k3.t tVarE3 = k3.t.e();
                                                            EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                            y0 y0Var = new y0(new u(c0Var2, 0), new u(c0Var2, 1), new l(1, c0Var2));
                                                            k3.o oVar5 = k3.o.f6605t;
                                                            tVarE3.l(new l3.a(oVar5, enumSetOf, y0Var));
                                                            try {
                                                                k3.t.e().n(oVar5);
                                                                c0Var2.f();
                                                                c0Var2.post(new u(c0Var2, 2));
                                                            } catch (Exception e3) {
                                                                e3.printStackTrace();
                                                                return;
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    case 1:
                                                        c2 c2Var2 = d2Var.f93a;
                                                        if (c2Var2 != null && (f0Var2 = ((g0) ((w3.e) c2Var2).b).f115q) != null) {
                                                            y2.o oVar6 = (y2.o) f0Var2;
                                                            b4.j.a((b4.j) oVar6.f8985c, (u3.d) oVar6.b);
                                                            break;
                                                        }
                                                        break;
                                                    case 2:
                                                        c2 c2Var3 = d2Var.f93a;
                                                        if (c2Var3 != null) {
                                                            g0 g0Var4 = (g0) ((w3.e) c2Var3).b;
                                                            i1 i1Var2 = g0Var4.f111m;
                                                            if (i1Var2 != null) {
                                                                ArrayList arrayList = i1Var2.f126a;
                                                                arrayList.clear();
                                                                i1Var2.b = -1;
                                                                i1Var2.f132i = null;
                                                                n4.a aVar = i1Var2.f131h;
                                                                aVar.f7161q = false;
                                                                aVar.f7162r = false;
                                                                aVar.f7160p = false;
                                                                Size sizeX = g.d.C().x();
                                                                float width = sizeX.getWidth();
                                                                float height = sizeX.getHeight();
                                                                float f2 = width / 2.0f;
                                                                float f7 = height / 2.0f;
                                                                Context context = i1Var2.getContext();
                                                                float f8 = 0.13f * height;
                                                                float f9 = (0.182f * height) + f7;
                                                                float f10 = 0.042f * height;
                                                                z1 z1Var = new z1(a2.b, f2 - f8, f9, f10);
                                                                z1Var.f297d = context.getString(2131820697);
                                                                arrayList.add(z1Var);
                                                                z1 z1Var2 = new z1(a2.f42c, f2, f9, f10);
                                                                z1Var2.f297d = context.getString(2131820702);
                                                                arrayList.add(z1Var2);
                                                                z1 z1Var3 = new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10);
                                                                z1Var3.f297d = context.getString(2131820703);
                                                                arrayList.add(z1Var3);
                                                                i1.c(arrayList, width, height);
                                                                i1Var2.f();
                                                                i1.a(arrayList, width, height);
                                                                i1Var2.e();
                                                                i1Var2.d();
                                                                h1 h1Var = i1Var2.f129f;
                                                                if (h1Var != null) {
                                                                    ((d0) h1Var).f76a.f113o.setEnabled(false);
                                                                }
                                                                i1Var2.invalidate();
                                                            }
                                                            f0 f0Var4 = g0Var4.f115q;
                                                            if (f0Var4 != null && (g0Var2 = (g0) ((b4.j) ((y2.o) f0Var4).f8985c).f1846c) != null) {
                                                                g0Var2.l();
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        c2 c2Var4 = d2Var.f93a;
                                                        if (c2Var4 != null && (f0Var3 = ((g0) ((w3.e) c2Var4).b).f115q) != null) {
                                                            y2.o oVar7 = (y2.o) f0Var3;
                                                            b4.j jVar7 = (b4.j) oVar7.f8985c;
                                                            g0 g0Var5 = (g0) jVar7.f1846c;
                                                            if (g0Var5 == null) {
                                                                b4.j.a(jVar7, (u3.d) oVar7.b);
                                                            } else {
                                                                List<z1> nodes = g0Var5.getNodes();
                                                                u1 u1VarN = u1.n();
                                                                final x3.d dVar4 = new x3.d(oVar7);
                                                                Handler handler = u1VarN.f247c;
                                                                if (u1VarN.f248d == null || (str = u1VarN.f249f) == null) {
                                                                    final int i142 = 1;
                                                                    handler.post(new Runnable() { // from class: a4.j1
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i142) {
                                                                                case 0:
                                                                                    dVar4.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    dVar4.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    dVar4.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else {
                                                                    v1 v1VarD = u1VarN.d(str);
                                                                    if (v1VarD == null) {
                                                                        final int i152 = 2;
                                                                        handler.post(new Runnable() { // from class: a4.j1
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i152) {
                                                                                    case 0:
                                                                                        dVar4.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        dVar4.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        dVar4.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    } else if (!v1VarD.f258c) {
                                                                        u1VarN.m(v1VarD, nodes, dVar4);
                                                                    } else {
                                                                        String str2 = u1VarN.f248d;
                                                                        String str3 = v1VarD.f257a;
                                                                        if (str2 != null) {
                                                                            u1VarN.c(u1VarN.e(v1VarD.b), new q6.c(u1VarN, str2, str3, dVar4, new ArrayList(nodes), v1VarD, 1));
                                                                        } else {
                                                                            final int i162 = 0;
                                                                            handler.post(new Runnable() { // from class: a4.j1
                                                                                @Override // java.lang.Runnable
                                                                                public final void run() {
                                                                                    switch (i162) {
                                                                                        case 0:
                                                                                            dVar4.a(v.m.p.abcdstr(31));
                                                                                            break;
                                                                                        case 1:
                                                                                            dVar4.a(v.m.p.abcdstr(72));
                                                                                            break;
                                                                                        default:
                                                                                            dVar4.a(v.m.p.abcdstr(71));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        c2 c2Var5 = d2Var.f93a;
                                                        if (c2Var5 != null) {
                                                            g0 g0Var6 = (g0) ((w3.e) c2Var5).b;
                                                            boolean z6 = g0Var6.f114p;
                                                            g0Var6.f114p = !z6;
                                                            g0Var6.f113o.setVisibility(!z6 ? 0 : 8);
                                                            g0Var6.f112n.setDPadExpanded(g0Var6.f114p);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                        d2Var.a(linearLayoutB8, iC7);
                                        String string2 = d2Var.getResources().getString(2131821027);
                                        LinearLayout linearLayout4 = new LinearLayout(floatingService2);
                                        linearLayout4.setOrientation(1);
                                        linearLayout4.setClickable(true);
                                        linearLayout4.setFocusable(true);
                                        tVar = tVar7;
                                        linearLayout4.setPadding(d2Var.c(4), d2Var.c(4), d2Var.c(4), d2Var.c(4));
                                        linearLayout4.setGravity(1);
                                        int iC8 = d2Var.c(28);
                                        ImageView imageView2 = new ImageView(floatingService2);
                                        d2Var.b = imageView2;
                                        imageView2.setImageResource(2131230889);
                                        d2Var.b.setColorFilter(androidx.core.content.c.a(floatingService2, 2131099745));
                                        d2Var.b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                                        d2Var.b.setLayoutParams(new LinearLayout.LayoutParams(iC8, iC8));
                                        TextView textView3 = new TextView(floatingService2);
                                        textView3.setText(string2);
                                        textView3.setTextColor(-1);
                                        textView3.setTextSize(11.0f);
                                        textView3.setPadding(0, d2Var.c(3), 0, 0);
                                        linearLayout4.addView(d2Var.b);
                                        linearLayout4.addView(textView3, new LinearLayout.LayoutParams(-2, -2));
                                        TypedArray typedArrayObtainStyledAttributes2 = floatingService2.obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
                                        int resourceId2 = typedArrayObtainStyledAttributes2.getResourceId(0, 0);
                                        typedArrayObtainStyledAttributes2.recycle();
                                        if (resourceId2 != 0) {
                                            linearLayout4.setBackgroundResource(resourceId2);
                                        }
                                        final int i17 = 4;
                                        linearLayout4.setOnClickListener(new View.OnClickListener() { // from class: a4.b2
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                f0 f0Var;
                                                f0 f0Var2;
                                                g0 g0Var2;
                                                f0 f0Var3;
                                                String str;
                                                switch (i17) {
                                                    case 0:
                                                        c2 c2Var = d2Var.f93a;
                                                        if (c2Var != null && (f0Var = ((g0) ((w3.e) c2Var).b).f115q) != null) {
                                                            y2.o oVar4 = (y2.o) f0Var;
                                                            b4.j jVar6 = (b4.j) oVar4.f8985c;
                                                            u3.d dVar3 = (u3.d) oVar4.b;
                                                            g0 g0Var3 = (g0) jVar6.f1846c;
                                                            c0 c0Var2 = new c0(((k3.j) dVar3).b.f6559a);
                                                            c0Var2.setOnConfigChangedListener(new d0(g0Var3));
                                                            c0Var2.setOnCloseListener(new k3.g(25));
                                                            k3.t tVarE3 = k3.t.e();
                                                            EnumSet enumSetOf = EnumSet.of(k3.n.f6586a, k3.n.b);
                                                            y0 y0Var = new y0(new u(c0Var2, 0), new u(c0Var2, 1), new l(1, c0Var2));
                                                            k3.o oVar5 = k3.o.f6605t;
                                                            tVarE3.l(new l3.a(oVar5, enumSetOf, y0Var));
                                                            try {
                                                                k3.t.e().n(oVar5);
                                                                c0Var2.f();
                                                                c0Var2.post(new u(c0Var2, 2));
                                                            } catch (Exception e3) {
                                                                e3.printStackTrace();
                                                                return;
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    case 1:
                                                        c2 c2Var2 = d2Var.f93a;
                                                        if (c2Var2 != null && (f0Var2 = ((g0) ((w3.e) c2Var2).b).f115q) != null) {
                                                            y2.o oVar6 = (y2.o) f0Var2;
                                                            b4.j.a((b4.j) oVar6.f8985c, (u3.d) oVar6.b);
                                                            break;
                                                        }
                                                        break;
                                                    case 2:
                                                        c2 c2Var3 = d2Var.f93a;
                                                        if (c2Var3 != null) {
                                                            g0 g0Var4 = (g0) ((w3.e) c2Var3).b;
                                                            i1 i1Var2 = g0Var4.f111m;
                                                            if (i1Var2 != null) {
                                                                ArrayList arrayList = i1Var2.f126a;
                                                                arrayList.clear();
                                                                i1Var2.b = -1;
                                                                i1Var2.f132i = null;
                                                                n4.a aVar = i1Var2.f131h;
                                                                aVar.f7161q = false;
                                                                aVar.f7162r = false;
                                                                aVar.f7160p = false;
                                                                Size sizeX = g.d.C().x();
                                                                float width = sizeX.getWidth();
                                                                float height = sizeX.getHeight();
                                                                float f2 = width / 2.0f;
                                                                float f7 = height / 2.0f;
                                                                Context context = i1Var2.getContext();
                                                                float f8 = 0.13f * height;
                                                                float f9 = (0.182f * height) + f7;
                                                                float f10 = 0.042f * height;
                                                                z1 z1Var = new z1(a2.b, f2 - f8, f9, f10);
                                                                z1Var.f297d = context.getString(2131820697);
                                                                arrayList.add(z1Var);
                                                                z1 z1Var2 = new z1(a2.f42c, f2, f9, f10);
                                                                z1Var2.f297d = context.getString(2131820702);
                                                                arrayList.add(z1Var2);
                                                                z1 z1Var3 = new z1(a2.f43d, f2 + f8, f7 - (0.026f * height), f10);
                                                                z1Var3.f297d = context.getString(2131820703);
                                                                arrayList.add(z1Var3);
                                                                i1.c(arrayList, width, height);
                                                                i1Var2.f();
                                                                i1.a(arrayList, width, height);
                                                                i1Var2.e();
                                                                i1Var2.d();
                                                                h1 h1Var = i1Var2.f129f;
                                                                if (h1Var != null) {
                                                                    ((d0) h1Var).f76a.f113o.setEnabled(false);
                                                                }
                                                                i1Var2.invalidate();
                                                            }
                                                            f0 f0Var4 = g0Var4.f115q;
                                                            if (f0Var4 != null && (g0Var2 = (g0) ((b4.j) ((y2.o) f0Var4).f8985c).f1846c) != null) {
                                                                g0Var2.l();
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        c2 c2Var4 = d2Var.f93a;
                                                        if (c2Var4 != null && (f0Var3 = ((g0) ((w3.e) c2Var4).b).f115q) != null) {
                                                            y2.o oVar7 = (y2.o) f0Var3;
                                                            b4.j jVar7 = (b4.j) oVar7.f8985c;
                                                            g0 g0Var5 = (g0) jVar7.f1846c;
                                                            if (g0Var5 == null) {
                                                                b4.j.a(jVar7, (u3.d) oVar7.b);
                                                            } else {
                                                                List<z1> nodes = g0Var5.getNodes();
                                                                u1 u1VarN = u1.n();
                                                                final x3.d dVar4 = new x3.d(oVar7);
                                                                Handler handler = u1VarN.f247c;
                                                                if (u1VarN.f248d == null || (str = u1VarN.f249f) == null) {
                                                                    final int i142 = 1;
                                                                    handler.post(new Runnable() { // from class: a4.j1
                                                                        @Override // java.lang.Runnable
                                                                        public final void run() {
                                                                            switch (i142) {
                                                                                case 0:
                                                                                    dVar4.a(v.m.p.abcdstr(31));
                                                                                    break;
                                                                                case 1:
                                                                                    dVar4.a(v.m.p.abcdstr(72));
                                                                                    break;
                                                                                default:
                                                                                    dVar4.a(v.m.p.abcdstr(71));
                                                                                    break;
                                                                            }
                                                                        }
                                                                    });
                                                                } else {
                                                                    v1 v1VarD = u1VarN.d(str);
                                                                    if (v1VarD == null) {
                                                                        final int i152 = 2;
                                                                        handler.post(new Runnable() { // from class: a4.j1
                                                                            @Override // java.lang.Runnable
                                                                            public final void run() {
                                                                                switch (i152) {
                                                                                    case 0:
                                                                                        dVar4.a(v.m.p.abcdstr(31));
                                                                                        break;
                                                                                    case 1:
                                                                                        dVar4.a(v.m.p.abcdstr(72));
                                                                                        break;
                                                                                    default:
                                                                                        dVar4.a(v.m.p.abcdstr(71));
                                                                                        break;
                                                                                }
                                                                            }
                                                                        });
                                                                    } else if (!v1VarD.f258c) {
                                                                        u1VarN.m(v1VarD, nodes, dVar4);
                                                                    } else {
                                                                        String str2 = u1VarN.f248d;
                                                                        String str3 = v1VarD.f257a;
                                                                        if (str2 != null) {
                                                                            u1VarN.c(u1VarN.e(v1VarD.b), new q6.c(u1VarN, str2, str3, dVar4, new ArrayList(nodes), v1VarD, 1));
                                                                        } else {
                                                                            final int i162 = 0;
                                                                            handler.post(new Runnable() { // from class: a4.j1
                                                                                @Override // java.lang.Runnable
                                                                                public final void run() {
                                                                                    switch (i162) {
                                                                                        case 0:
                                                                                            dVar4.a(v.m.p.abcdstr(31));
                                                                                            break;
                                                                                        case 1:
                                                                                            dVar4.a(v.m.p.abcdstr(72));
                                                                                            break;
                                                                                        default:
                                                                                            dVar4.a(v.m.p.abcdstr(71));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    default:
                                                        c2 c2Var5 = d2Var.f93a;
                                                        if (c2Var5 != null) {
                                                            g0 g0Var6 = (g0) ((w3.e) c2Var5).b;
                                                            boolean z6 = g0Var6.f114p;
                                                            g0Var6.f114p = !z6;
                                                            g0Var6.f113o.setVisibility(!z6 ? 0 : 8);
                                                            g0Var6.f112n.setDPadExpanded(g0Var6.f114p);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                        d2Var.a(linearLayout4, 0);
                                        g0Var.f112n = d2Var;
                                        d2Var.setOnToolbarClickListener(new w3.e(3, g0Var));
                                        y1 y1Var = new y1(floatingService2);
                                        g0Var.f113o = y1Var;
                                        y1Var.setOnDirectionListener(new d0(g0Var));
                                        i1Var.setOnNodeSelectionListener(new d0(g0Var));
                                        LinearLayout linearLayout5 = new LinearLayout(floatingService2);
                                        linearLayout5.setOrientation(1);
                                        linearLayout5.setElevation(25.0f);
                                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                                        int iA4 = androidx.core.content.c.a(floatingService2, 2131099747);
                                        gradientDrawable4.setColor(Color.argb(230, Color.red(iA4), Color.green(iA4), Color.blue(iA4)));
                                        gradientDrawable4.setCornerRadius(g0Var.k(12));
                                        linearLayout5.setBackground(gradientDrawable4);
                                        d2Var.setBackground(null);
                                        linearLayout5.addView(d2Var, new LinearLayout.LayoutParams(-2, -2));
                                        LinearLayout linearLayout6 = new LinearLayout(floatingService2);
                                        linearLayout6.setOrientation(0);
                                        linearLayout6.setGravity(16);
                                        linearLayout6.setPadding(g0Var.k(10), g0Var.k(2), g0Var.k(6), g0Var.k(2));
                                        TextView textView4 = new TextView(floatingService2);
                                        textView4.setText(2131821303);
                                        textView4.setTextColor(-1);
                                        textView4.setTextSize(12.0f);
                                        textView4.setMaxLines(1);
                                        Switch r10 = new Switch(floatingService2);
                                        r10.setChecked(((SharedPreferences) y2.l.i().f8978a).getBoolean(v.m.p.abcdstr(47), false));
                                        r10.setOnCheckedChangeListener(new e0(0, g0Var));
                                        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                                        layoutParams6.rightMargin = g0Var.k(8);
                                        linearLayout6.addView(textView4, layoutParams6);
                                        linearLayout6.addView(r10, new LinearLayout.LayoutParams(-2, -2));
                                        linearLayout5.addView(linearLayout6, new LinearLayout.LayoutParams(-1, -2));
                                        j0Var2.addView(linearLayout5, new LinearLayout.LayoutParams(-2, -2));
                                        j0Var2.addView(y1Var, new LinearLayout.LayoutParams(-2, -2));
                                        FrameLayout.LayoutParams layoutParams7 = new FrameLayout.LayoutParams(-2, -2);
                                        layoutParams7.gravity = 49;
                                        frameLayout2.addView(i1Var, layoutParams5);
                                        frameLayout2.addView(j0Var2, layoutParams7);
                                        g0Var.addView(frameLayout2, new FrameLayout.LayoutParams(-1, -1));
                                        jVar.f1846c = g0Var;
                                        WindowManager.LayoutParams layoutParams8 = new WindowManager.LayoutParams(-1, -1, 2038, 808, -3);
                                        layoutParams8.layoutInDisplayCutoutMode = 1;
                                        if (Build.VERSION.SDK_INT >= 30) {
                                            g0.f.f(layoutParams8);
                                        }
                                        layoutParams8.gravity = 8388659;
                                        layoutParams8.x = 0;
                                        layoutParams8.y = 0;
                                        ((g0) jVar.f1846c).setLayoutParams(layoutParams8);
                                        ((g0) jVar.f1846c).setWindowManager(lVar2.b);
                                        ((g0) jVar.f1846c).setOnToolbarActionListener(new y2.o(jVar, 14, jVar5));
                                    } else {
                                        tVar = tVar7;
                                    }
                                    if (!((g0) jVar.f1846c).l()) {
                                        FloatingService.f6880k.a(tVar.f8245a.getString(2131820638));
                                    }
                                    k3.t tVar8 = lVar2.f6560c;
                                    k3.o oVar4 = k3.o.f6608w;
                                    if (tVar8.f(oVar4) == null) {
                                        tVar8.l(new l3.a(oVar4, EnumSet.of(k3.n.f6586a, k3.n.b), (g0) jVar.f1846c));
                                    }
                                    tVar8.n(oVar4);
                                }
                                break;
                            }
                            break;
                    }
                }
                break;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                m3.h hVar2 = (m3.h) this.b;
                m3.h hVar3 = (m3.h) this.f110c;
                m3.e eVar = hVar2.f6808a;
                if (eVar != null && hVar3 != null) {
                    hVar3.setNavigationListener(eVar);
                    ((h3.g) ((f1) hVar2.f6808a).b).l(hVar3);
                    break;
                }
                break;
            case 10:
                n3.c cVar3 = (n3.c) this.b;
                Button button = (Button) this.f110c;
                if (!cVar3.f6967k) {
                    if (cVar3.e) {
                        i3.e.b();
                    }
                    cVar3.f6967k = true;
                    button.setText(cVar3.getContext().getString(2131821165));
                    cVar3.f6966j.setText(cVar3.getContext().getString(2131821288));
                    i3.e.a(new i0(cVar3, 11, button), false);
                } else {
                    i3.e.b();
                }
                break;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                n3.x xVar2 = (n3.x) this.b;
                int iB = ((n3.w) this.f110c).b();
                if (iB != -1 && (dVar = xVar2.f7133d) != null) {
                    h3.d0 d0Var = (h3.d0) dVar.b;
                    ArrayList arrayList = d0Var.f5943c;
                    if (iB >= 0 && iB < arrayList.size()) {
                        arrayList.remove(iB);
                        d0Var.f5946g.f1566a.f(iB);
                        d0Var.f5946g.f1566a.d(iB, arrayList.size() - iB);
                        d0Var.b();
                        break;
                    }
                }
                break;
            case 12:
                n3.x0 x0Var = (n3.x0) this.b;
                String str = (String) this.f110c;
                j3.w wVar = x0Var.f7134a;
                if (wVar.s(str)) {
                    g.d dVar3 = x0Var.b;
                    if (dVar3 != null) {
                        dVar3.e(wVar);
                    }
                    x0Var.f();
                }
                break;
            case 13:
                o3.n nVar = (o3.n) this.b;
                o3.l lVar3 = (o3.l) this.f110c;
                o3.o oVar5 = nVar.f7219d;
                String str2 = lVar3.b;
                Set set = o3.o.l0;
                moe.heroman.eventtest.auth.a aVarH = moe.heroman.eventtest.auth.a.h();
                aVarH.b.execute(new a3.f(aVarH, new e4.e0(oVar5, 21, str2), new o3.g(oVar5, 0), 0));
                break;
            case 14:
                o3.h0 h0Var = (o3.h0) this.b;
                o3.f0 f0Var = (o3.f0) this.f110c;
                String str3 = f0Var.b;
                String str4 = f0Var.f7195c;
                o1.b bVar = new o1.b(h0Var.I());
                androidx.appcompat.app.c cVar4 = (androidx.appcompat.app.c) bVar.b;
                cVar4.f418d = str3;
                cVar4.f419f = str4;
                bVar.k(2131820572);
                bVar.j();
                break;
            case 15:
                o3.j0 j0Var3 = (o3.j0) this.b;
                o3.f0 f0Var2 = (o3.f0) this.f110c;
                String str5 = f0Var2.b;
                String str6 = f0Var2.f7195c;
                o1.b bVar2 = new o1.b(j0Var3.I());
                androidx.appcompat.app.c cVar5 = (androidx.appcompat.app.c) bVar2.b;
                cVar5.f418d = str5;
                cVar5.f419f = str6;
                bVar2.k(2131820572);
                bVar2.j();
                break;
            default:
                o3.m0 m0Var = (o3.m0) this.b;
                o3.f0 f0Var3 = (o3.f0) this.f110c;
                String str7 = f0Var3.b;
                String str8 = f0Var3.f7195c;
                o1.b bVar3 = new o1.b(m0Var.I());
                androidx.appcompat.app.c cVar6 = (androidx.appcompat.app.c) bVar3.b;
                cVar6.f418d = str7;
                cVar6.f419f = str8;
                bVar3.k(2131820572);
                bVar3.j();
                break;
        }
    }
}
