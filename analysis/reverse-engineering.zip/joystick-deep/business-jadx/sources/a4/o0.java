package a4;

import android.os.Handler;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.auth.RecognitionToken;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class o0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f181a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f182c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f183d;
    public final /* synthetic */ Object e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f184f;

    public /* synthetic */ o0(Object obj, String str, String str2, Object obj2, Object obj3, int i7) {
        this.f181a = i7;
        this.b = obj;
        this.f182c = str;
        this.f183d = str2;
        this.e = obj2;
        this.f184f = obj3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f181a) {
            case 0:
                d1 d1Var = (d1) this.b;
                String str = this.f182c;
                String str2 = this.f183d;
                b1 b1Var = (b1) this.e;
                z3.a aVar = (z3.a) this.f184f;
                if (str.equals(d1Var.f80d) && str2.equals(d1Var.f81f)) {
                    b1Var.f(aVar);
                    break;
                }
                break;
            case 1:
                d1 d1Var2 = (d1) this.b;
                String str3 = this.f182c;
                String str4 = this.f183d;
                z0 z0Var = (z0) this.e;
                String str5 = (String) this.f184f;
                if (str3.equals(d1Var2.f80d) && str4.equals(d1Var2.f81f)) {
                    d1Var2.q();
                }
                if (z0Var != null) {
                    z0Var.a(str5);
                }
                break;
            case 2:
                d1 d1Var3 = (d1) this.b;
                String str6 = this.f182c;
                String str7 = this.f183d;
                m mVar = (m) this.e;
                e1 e1Var = (e1) this.f184f;
                Handler handler = d1Var3.f79c;
                if (NativeAuth.L(str6, str7) == 0) {
                    handler.post(new n0(d1Var3, e1Var, str7, mVar, 2));
                } else {
                    handler.post(new a3.e(mVar, 10, d1.m(v.m.p.abcdstr(95))));
                }
                break;
            case 3:
                u1 u1Var = (u1) this.b;
                String str8 = this.f182c;
                String str9 = this.f183d;
                y yVar = (y) this.e;
                v1 v1Var = (v1) this.f184f;
                Handler handler2 = u1Var.f247c;
                if (NativeAuth.l0(str8, str9) == 0) {
                    handler2.post(new n0(u1Var, v1Var, str9, yVar, 3));
                } else {
                    handler2.post(new a3.e(yVar, 13, u1.i(v.m.p.abcdstr(95))));
                }
                break;
            case 4:
                u1 u1Var2 = (u1) this.b;
                String str10 = this.f182c;
                String str11 = this.f183d;
                s1 s1Var = (s1) this.e;
                String str12 = (String) this.f184f;
                if (str10.equals(u1Var2.f248d) && str11.equals(u1Var2.f249f)) {
                    u1Var2.k();
                }
                if (s1Var != null) {
                    s1Var.a(str12);
                }
                break;
            case 5:
                u1 u1Var3 = (u1) this.b;
                String str13 = this.f182c;
                String str14 = this.f183d;
                RecognitionToken recognitionToken = (RecognitionToken) this.e;
                s1 s1Var2 = (s1) this.f184f;
                if (str13.equals(u1Var3.f248d) && str14.equals(u1Var3.f249f)) {
                    u1Var3.k();
                    u1Var3.f250g = recognitionToken;
                } else {
                    NativeAuth.u0(recognitionToken);
                }
                if (s1Var2 != null) {
                    s1Var2.b();
                }
                break;
            case 6:
                d4.m mVar2 = (d4.m) this.b;
                String str15 = this.f182c;
                String str16 = this.f183d;
                d4.l lVar = (d4.l) this.e;
                d4.a aVar2 = (d4.a) this.f184f;
                if (str15.equals(mVar2.f5268d) && str16.equals(mVar2.f5269f)) {
                    lVar.k(aVar2);
                    break;
                }
                break;
            case dd.f4082h /* 7 */:
                d4.m mVar3 = (d4.m) this.b;
                String str17 = this.f182c;
                String str18 = this.f183d;
                d4.j jVar = (d4.j) this.e;
                String str19 = (String) this.f184f;
                if (str17.equals(mVar3.f5268d) && str18.equals(mVar3.f5269f)) {
                    mVar3.n();
                }
                if (jVar != null) {
                    jVar.a(str19);
                }
                break;
            case 8:
                d4.m mVar4 = (d4.m) this.b;
                String str20 = this.f182c;
                String str21 = this.f183d;
                e4.h hVar = (e4.h) this.e;
                e4.x xVar = (e4.x) this.f184f;
                Handler handler3 = mVar4.f5267c;
                if (NativeAuth.L(str20, str21) == 0) {
                    handler3.post(new n0(mVar4, xVar, str21, hVar, 8));
                } else {
                    handler3.post(new a3.e(hVar, 20, d4.m.k(v.m.p.abcdstr(95))));
                }
                break;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                e4.h0 h0Var = (e4.h0) this.b;
                String str22 = this.f182c;
                String str23 = this.f183d;
                d0.g gVar = (d0.g) this.e;
                e4.i0 i0Var = (e4.i0) this.f184f;
                Handler handler4 = h0Var.f5368c;
                if (NativeAuth.l0(str22, str23) == 0) {
                    handler4.post(new n0(h0Var, i0Var, str23, gVar, 10));
                } else {
                    handler4.post(new a3.e(gVar, 26, e4.h0.j(v.m.p.abcdstr(95))));
                }
                break;
            case 10:
                e4.h0 h0Var2 = (e4.h0) this.b;
                String str24 = this.f182c;
                String str25 = this.f183d;
                e4.f0 f0Var = (e4.f0) this.e;
                String str26 = (String) this.f184f;
                if (str24.equals(h0Var2.f5369d) && str25.equals(h0Var2.f5370f)) {
                    h0Var2.l();
                }
                if (f0Var != null) {
                    f0Var.a(str26);
                }
                break;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                e4.h0 h0Var3 = (e4.h0) this.b;
                String str27 = this.f182c;
                String str28 = this.f183d;
                RecognitionToken recognitionToken2 = (RecognitionToken) this.e;
                e4.f0 f0Var2 = (e4.f0) this.f184f;
                if (str27.equals(h0Var3.f5369d) && str28.equals(h0Var3.f5370f)) {
                    h0Var3.l();
                    h0Var3.f5371g = recognitionToken2;
                } else {
                    NativeAuth.u0(recognitionToken2);
                }
                if (f0Var2 != null) {
                    f0Var2.b();
                }
                break;
            default:
                h3.j1 j1Var = (h3.j1) this.b;
                String str29 = this.f182c;
                String str30 = this.f183d;
                h3.o oVar = (h3.o) this.e;
                h3.c cVar = (h3.c) this.f184f;
                Handler handler5 = j1Var.f6019c;
                if (NativeAuth.z(str29, str30) == 0) {
                    handler5.post(new n0(j1Var, cVar, str30, oVar, 14));
                } else {
                    handler5.post(new e4.e0(oVar, 6, h3.j1.i(v.m.p.abcdstr(95))));
                }
                break;
        }
    }
}
