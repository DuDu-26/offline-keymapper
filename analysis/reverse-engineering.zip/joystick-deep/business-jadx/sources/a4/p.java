package a4;

import com.umeng.commonsdk.statistics.UMErrorCode;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class p implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f186a;
    public final /* synthetic */ o b;

    public /* synthetic */ p(o oVar, int i7) {
        this.f186a = i7;
        this.b = oVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f186a) {
            case 0:
                t tVar = this.b.b;
                tVar.h(tVar.f223j);
                s sVar = tVar.f236w;
                if (sVar != null) {
                    y3.t.o(((y3.q) ((y3.r) sVar).f9124a.b).f9123a);
                }
                FloatingService.f6880k.a(tVar.getContext().getString(2131820645));
                tVar.i(tVar.f220g);
                break;
            case 1:
                this.b.a(v.m.p.abcdstr(31));
                break;
            default:
                this.b.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                break;
        }
    }
}
