package a4;

import android.view.View;
import android.view.ViewParent;
import android.widget.FrameLayout;
import moe.heroman.eventtest.App;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class d implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f75a;
    public final /* synthetic */ t b;

    public /* synthetic */ d(t tVar, int i7) {
        this.f75a = i7;
        this.b = tVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f75a) {
            case 0:
                t tVar = this.b;
                if (tVar.f230q) {
                    i3.e.b();
                    tVar.f230q = false;
                }
                FrameLayout frameLayout = tVar.f219f;
                if (frameLayout != null) {
                    ViewParent parent = frameLayout.getParent();
                    FrameLayout frameLayout2 = tVar.e;
                    if (parent == frameLayout2) {
                        frameLayout2.removeView(tVar.f219f);
                        tVar.f219f = null;
                    }
                }
                k3.t.e().q(k3.o.f6606u);
                break;
            case 1:
                t tVar2 = this.b;
                tVar2.i(tVar2.f220g);
                break;
            case 2:
                t tVar3 = this.b;
                tVar3.i(tVar3.f220g);
                break;
            case 3:
                t tVar4 = this.b;
                tVar4.i(tVar4.f220g);
                break;
            case 4:
                t tVar5 = this.b;
                tVar5.i(tVar5.f220g);
                break;
            case 5:
                t tVar6 = this.b;
                tVar6.i(tVar6.f220g);
                break;
            case 6:
                t tVar7 = this.b;
                tVar7.i(tVar7.f231r);
                i3.e.b();
                break;
            default:
                t tVar8 = this.b;
                tVar8.n(true);
                d1 d1VarU = d1.u();
                o oVar = new o(tVar8, 1);
                d1VarU.getClass();
                d1VarU.d(d1VarU.g(App.f6858a.getString(2131820705)), oVar);
                break;
        }
    }
}
