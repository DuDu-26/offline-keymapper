package a4;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class a implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f40a;
    public final /* synthetic */ Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f41c;

    public /* synthetic */ a(Context context, String str, int i7) {
        this.f40a = i7;
        this.b = context;
        this.f41c = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f40a) {
            case 0:
                String strAbcdstr = v.m.p.abcdstr(25);
                Context context = this.b;
                ((ClipboardManager) context.getSystemService(strAbcdstr)).setPrimaryClip(ClipData.newPlainText(v.m.p.abcdstr(26), this.f41c));
                FloatingService.f6880k.a(context.getString(2131821373));
                break;
            case 1:
                String strAbcdstr2 = v.m.p.abcdstr(25);
                Context context2 = this.b;
                ((ClipboardManager) context2.getSystemService(strAbcdstr2)).setPrimaryClip(ClipData.newPlainText(v.m.p.abcdstr(26), this.f41c));
                FloatingService.f6880k.a(context2.getString(2131821373));
                break;
            case 2:
                String strAbcdstr3 = v.m.p.abcdstr(25);
                Context context3 = this.b;
                ((ClipboardManager) context3.getSystemService(strAbcdstr3)).setPrimaryClip(ClipData.newPlainText(v.m.p.abcdstr(26), this.f41c));
                e4.k.i(context3.getString(2131821373));
                break;
            case 3:
                String strAbcdstr4 = v.m.p.abcdstr(25);
                Context context4 = this.b;
                ((ClipboardManager) context4.getSystemService(strAbcdstr4)).setPrimaryClip(ClipData.newPlainText(v.m.p.abcdstr(26), this.f41c));
                e4.s.i(context4.getString(2131821373));
                break;
            default:
                String strAbcdstr5 = v.m.p.abcdstr(25);
                Context context5 = this.b;
                ((ClipboardManager) context5.getSystemService(strAbcdstr5)).setPrimaryClip(ClipData.newPlainText(v.m.p.abcdstr(26), this.f41c));
                h3.r.k(context5.getString(2131821373));
                break;
        }
    }

    public /* synthetic */ a(FrameLayout frameLayout, Context context, String str, int i7) {
        this.f40a = i7;
        this.b = context;
        this.f41c = str;
    }
}
