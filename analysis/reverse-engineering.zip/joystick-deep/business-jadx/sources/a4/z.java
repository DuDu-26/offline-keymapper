package a4;

import com.umeng.commonsdk.statistics.UMErrorCode;
import moe.heroman.eventtest.floatingservice.FloatingService;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class z implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f294a;
    public final /* synthetic */ y b;

    public /* synthetic */ z(y yVar, int i7) {
        this.f294a = i7;
        this.b = yVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f294a) {
            case 0:
                c0 c0Var = this.b.b;
                c0Var.g(c0Var.f60j);
                FloatingService.f6880k.a(c0Var.getContext().getString(2131820645));
                c0Var.h(c0Var.f57g);
                break;
            case 1:
                this.b.a(v.m.p.abcdstr(31));
                break;
            default:
                this.b.a(v.m.p.abcdstr(UMErrorCode.E_UM_BE_DEFLATE_FAILED));
                break;
        }
    }
}
