package a4;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Process;
import android.util.Log;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import java.nio.MappedByteBuffer;
import moe.heroman.eventtest.adbhelper.AdbMessage;
import moe.heroman.eventtest.common.IpcRing;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class n implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f174a;
    public final /* synthetic */ Object b;

    public /* synthetic */ n(int i7, Object obj) {
        this.f174a = i7;
        this.b = obj;
    }

    private final void a() {
        b4.r0 r0Var = (b4.r0) this.b;
        if (!r0Var.f1931a || p3.a0.i().f7383m) {
            return;
        }
        l lVar = r0Var.f1935g;
        if (lVar == null || lVar.getAsBoolean()) {
            synchronized (r0Var) {
                try {
                    d4.p pVar = r0Var.b;
                    d4.p pVar2 = r0Var.f1932c;
                    if (pVar != null && pVar2 != null) {
                        while (true) {
                            d4.p pVar3 = (d4.p) pVar2.f5289c;
                            if (pVar3 == null || pVar3.f5288a >= r0Var.f1933d) {
                                break;
                            } else {
                                pVar2 = (d4.p) pVar2.f5289c;
                            }
                        }
                        r0Var.f1932c = pVar2;
                        double d3 = pVar2.b;
                        double d7 = (0.02d * d3) + r0Var.e;
                        r0Var.e = d7;
                        b4.c0 c0Var = r0Var.f1936h;
                        if (c0Var != null) {
                            float f2 = (float) d3;
                            b4.d1 d1Var = c0Var.f1799a.f1911j;
                            if (d1Var != null) {
                                d1Var.setRecoilValue(f2);
                            }
                        }
                        if (d7 >= 1.0d) {
                            int i7 = (int) d7;
                            p3.j.h().f(0, i7);
                            r0Var.e -= (double) i7;
                            long jCurrentTimeMillis = System.currentTimeMillis();
                            if (jCurrentTimeMillis - r0Var.f1937i > 500) {
                                String.format(v.m.p.abcdstr(90), Double.valueOf(d3));
                                r0Var.f1937i = jCurrentTimeMillis;
                            }
                        }
                        r0Var.f1933d += 20;
                    }
                } finally {
                }
            }
        }
    }

    private final void b() {
        IpcRing ipcRing;
        k4.e eVar = (k4.e) this.b;
        Process.setThreadPriority(-20);
        byte[] bArr = new byte[10];
        g4.f fVarA = g4.f.a();
        synchronized (fVarA) {
            ipcRing = fVarA.e;
        }
        if (ipcRing == null) {
            Log.e(v.m.p.abcdstr(91), v.m.p.abcdstr(92));
            return;
        }
        boolean z6 = true;
        try {
            try {
                j4.c cVarE = j4.c.e();
                synchronized (cVarE) {
                    cVarE.a(true);
                }
                while (!eVar.b && !Thread.currentThread().isInterrupted()) {
                    ipcRing.t(10, bArr);
                    if (eVar.b) {
                        break;
                    }
                    com.google.android.material.internal.o oVar = new com.google.android.material.internal.o();
                    oVar.f3335a = n.e.e(3)[bArr[0]];
                    oVar.b = bArr[1];
                    oVar.f3336c = ((bArr[3] & 255) << 16) | ((bArr[2] & 255) << 24) | ((bArr[4] & 255) << 8) | (bArr[5] & 255);
                    oVar.f3337d = ((bArr[6] & 255) << 24) | ((bArr[7] & 255) << 16) | ((bArr[8] & 255) << 8) | (bArr[9] & 255);
                    j4.c.e().b(oVar);
                }
                j4.c.e().d();
                z6 = false;
            } catch (Exception e) {
                if (eVar.b) {
                    z6 = false;
                } else {
                    e.printStackTrace();
                }
                j4.c.e().d();
            }
            if (z6) {
                System.exit(0);
            }
        } catch (Throwable th) {
            j4.c.e().d();
            throw th;
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f174a) {
            case 0:
                t tVar = (t) ((w3.b) this.b).f8545c;
                t.m(tVar.f233t, false);
                tVar.f233t = null;
                tVar.o();
                return;
            case 1:
                ((o) this.b).b.n(false);
                return;
            case 2:
                c0 c0Var = (c0) ((y2.o) this.b).f8985c;
                c0.l(c0Var.f67q, false);
                c0Var.f67q = null;
                c0Var.n();
                return;
            case 3:
                ((y) this.b).b.m(false);
                return;
            case 4:
                ((b1) this.b).c();
                return;
            case 5:
                ((w3.e) this.b).a(v.m.p.abcdstr(31));
                return;
            case 6:
                ((w3.e) this.b).a(v.m.p.abcdstr(31));
                return;
            case dd.f4082h /* 7 */:
                ((t1) this.b).a(v.m.p.abcdstr(31));
                return;
            case 8:
                ((androidx.appcompat.app.k) this.b).invalidateOptionsMenu();
                return;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                androidx.activity.l lVar = (androidx.activity.l) this.b;
                Runnable runnable = lVar.b;
                if (runnable != null) {
                    runnable.run();
                    lVar.b = null;
                    return;
                }
                return;
            case 10:
                androidx.appcompat.app.h.b((androidx.appcompat.app.h) this.b);
                return;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                androidx.emoji2.text.p pVar = (androidx.emoji2.text.p) this.b;
                String strAbcdstr = v.m.p.abcdstr(94);
                synchronized (pVar.f1134d) {
                    try {
                        if (pVar.f1137h == null) {
                            return;
                        }
                        try {
                            c0.i iVarC = pVar.c();
                            int i7 = iVarC.e;
                            if (i7 == 2) {
                                synchronized (pVar.f1134d) {
                                }
                            }
                            if (i7 != 0) {
                                throw new RuntimeException(strAbcdstr + i7 + ")");
                            }
                            try {
                                int i8 = b0.h.f1784a;
                                b0.g.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                                y1.e eVar = pVar.f1133c;
                                Context context = pVar.f1132a;
                                eVar.getClass();
                                Typeface typefaceN = x.g.f8677a.n(context, new c0.i[]{iVarC}, 0);
                                MappedByteBuffer mappedByteBufferI = v1.e.I(pVar.f1132a, iVarC.f2115a);
                                if (mappedByteBufferI == null || typefaceN == null) {
                                    throw new RuntimeException("Unable to open file.");
                                }
                                try {
                                    b0.g.a("EmojiCompat.MetadataRepo.create");
                                    y0 y0Var = new y0(typefaceN, a5.h.Z(mappedByteBufferI));
                                    b0.g.b();
                                    b0.g.b();
                                    synchronized (pVar.f1134d) {
                                        try {
                                            a5.h hVar = pVar.f1137h;
                                            if (hVar != null) {
                                                hVar.T(y0Var);
                                            }
                                        } finally {
                                        }
                                        break;
                                    }
                                    pVar.b();
                                    return;
                                } finally {
                                    int i9 = b0.h.f1784a;
                                    b0.g.b();
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        } catch (Throwable th2) {
                            synchronized (pVar.f1134d) {
                                try {
                                    a5.h hVar2 = pVar.f1137h;
                                    if (hVar2 != null) {
                                        hVar2.Q(th2);
                                    }
                                    pVar.b();
                                    return;
                                } finally {
                                }
                            }
                        }
                    } finally {
                    }
                }
            case 12:
                androidx.lifecycle.c0 c0Var2 = (androidx.lifecycle.c0) this.b;
                androidx.lifecycle.t tVar2 = c0Var2.f1343f;
                if (c0Var2.b == 0) {
                    c0Var2.f1341c = true;
                    tVar2.d(androidx.lifecycle.l.ON_PAUSE);
                }
                if (c0Var2.f1340a == 0 && c0Var2.f1341c) {
                    tVar2.d(androidx.lifecycle.l.ON_STOP);
                    c0Var2.f1342d = true;
                    return;
                }
                return;
            case 13:
                a();
                return;
            case 14:
                b4.w0 w0Var = (b4.w0) this.b;
                w0Var.E1 = true;
                w0Var.invalidate();
                return;
            case 15:
                b4.d1 d1Var = (b4.d1) this.b;
                d1Var.f1805p = d1Var.getContext().getString(2131821052);
                d1Var.f1806q = d1Var.getContext().getString(2131821080);
                d1Var.f1807r = false;
                d1Var.f1808s = null;
                d1Var.f1809t = "";
                d1Var.f1810u = 0.0f;
                d1Var.f1811v = false;
                d1Var.f1812w = false;
                d1Var.f1813x = false;
                d1Var.requestLayout();
                d1Var.invalidate();
                return;
            case 16:
                ((com.google.android.material.textfield.c) this.b).s(true);
                return;
            case 17:
                com.google.android.material.textfield.j jVar = (com.google.android.material.textfield.j) this.b;
                boolean zIsPopupShowing = jVar.f3501h.isPopupShowing();
                jVar.s(zIsPopupShowing);
                jVar.f3506m = zIsPopupShowing;
                return;
            case 18:
                ((com.google.android.material.timepicker.e) this.b).m();
                return;
            case 19:
                ((d4.l) this.b).c();
                return;
            case 20:
                ((w3.e) this.b).a(v.m.p.abcdstr(31));
                return;
            case 21:
                ((w3.e) this.b).a(v.m.p.abcdstr(31));
                return;
            case 22:
                ((e4.g0) this.b).a(v.m.p.abcdstr(31));
                return;
            case 23:
                ((f3.d) this.b).a(v.m.p.abcdstr(93));
                return;
            case AdbMessage.HEADER_LENGTH /* 24 */:
                b();
                return;
            case 25:
                h3.m0 m0Var = (h3.m0) this.b;
                int width = m0Var.getWidth();
                int height = m0Var.getHeight();
                if (width > 0 && height > 0) {
                    e4.r0.t(m0Var.f6042a, width, height);
                }
                m0Var.invalidate();
                return;
            case 26:
                ((g.d) this.b).a(v.m.p.abcdstr(31));
                return;
            case 27:
                ((y0) this.b).a(v.m.p.abcdstr(31));
                return;
            case 28:
                ((k3.k) this.b).a(v.m.p.abcdstr(31));
                return;
            default:
                ((h3.i1) this.b).a(v.m.p.abcdstr(31));
                return;
        }
    }
}
