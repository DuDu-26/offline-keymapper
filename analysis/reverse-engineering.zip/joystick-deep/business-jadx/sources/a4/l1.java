package a4;

import android.os.Handler;
import java.util.ArrayList;
import moe.heroman.eventtest.auth.NativeAuth;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class l1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f161a;
    public final /* synthetic */ ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f162c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f163d;
    public final /* synthetic */ String e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ boolean f164f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ long f165g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f166h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f167i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f168j;

    public /* synthetic */ l1(Object obj, ArrayList arrayList, String str, String str2, String str3, boolean z6, long j7, int i7, Object obj2, int i8) {
        this.f161a = i8;
        this.f167i = obj;
        this.b = arrayList;
        this.f162c = str;
        this.f163d = str2;
        this.e = str3;
        this.f164f = z6;
        this.f165g = j7;
        this.f166h = i7;
        this.f168j = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f161a) {
            case 0:
                u1 u1Var = (u1) this.f167i;
                s1 s1Var = (s1) this.f168j;
                Handler handler = u1Var.f247c;
                long jCurrentTimeMillis = System.currentTimeMillis();
                byte[] bArrA = u1.a(this.b);
                String str = this.f162c;
                String str2 = this.f163d;
                String str3 = this.e;
                boolean z6 = this.f164f;
                long j7 = this.f165g;
                int i7 = this.f166h;
                if (NativeAuth.k0(bArrA, str, str2, str3, z6, j7, jCurrentTimeMillis, jCurrentTimeMillis, i7) == 0) {
                    handler.post(new q0(u1Var, str3, str, i7, s1Var, 1));
                } else {
                    handler.post(new n1(s1Var, u1.i(v.m.p.abcdstr(78)), 1));
                }
                break;
            default:
                e4.h0 h0Var = (e4.h0) this.f167i;
                e4.f0 f0Var = (e4.f0) this.f168j;
                Handler handler2 = h0Var.f5368c;
                long jCurrentTimeMillis2 = System.currentTimeMillis();
                byte[] bArrA2 = e4.h0.a(this.b);
                String str4 = this.f162c;
                String str5 = this.f163d;
                String str6 = this.e;
                boolean z7 = this.f164f;
                long j8 = this.f165g;
                int i8 = this.f166h;
                if (NativeAuth.k0(bArrA2, str4, str5, str6, z7, j8, jCurrentTimeMillis2, jCurrentTimeMillis2, i8) == 0) {
                    handler2.post(new q0(h0Var, str6, str4, i8, f0Var, 3));
                } else {
                    handler2.post(new e4.d0(f0Var, e4.h0.j(v.m.p.abcdstr(78)), 1));
                }
                break;
        }
    }
}
