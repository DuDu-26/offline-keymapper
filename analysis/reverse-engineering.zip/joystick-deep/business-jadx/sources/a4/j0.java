package a4;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j0 extends LinearLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f144a;
    public float b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f145c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f146d;
    public int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f147f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f148g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f149h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j0(Context context, int i7) {
        super(context);
        this.f144a = i7;
        switch (i7) {
            case 1:
                super(context);
                this.f147f = false;
                this.f148g = false;
                this.f149h = ViewConfiguration.get(context).getScaledTouchSlop();
                setOrientation(1);
                setGravity(1);
                break;
            default:
                this.f147f = false;
                this.f148g = false;
                this.f149h = ViewConfiguration.get(context).getScaledTouchSlop();
                setOrientation(1);
                setGravity(1);
                break;
        }
    }

    public final void a() {
        switch (this.f144a) {
            case 0:
                if (!this.f148g) {
                    ViewGroup.LayoutParams layoutParams = getLayoutParams();
                    if (layoutParams instanceof FrameLayout.LayoutParams) {
                        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
                        int[] iArr = new int[2];
                        getLocationOnScreen(iArr);
                        if (getParent() instanceof ViewGroup) {
                            int[] iArr2 = new int[2];
                            ((ViewGroup) getParent()).getLocationOnScreen(iArr2);
                            layoutParams2.leftMargin = iArr[0] - iArr2[0];
                            layoutParams2.topMargin = iArr[1] - iArr2[1];
                        }
                        layoutParams2.gravity = 0;
                        setLayoutParams(layoutParams2);
                        this.f148g = true;
                        break;
                    }
                }
                break;
            default:
                if (!this.f148g) {
                    ViewGroup.LayoutParams layoutParams3 = getLayoutParams();
                    if (layoutParams3 instanceof FrameLayout.LayoutParams) {
                        FrameLayout.LayoutParams layoutParams4 = (FrameLayout.LayoutParams) layoutParams3;
                        int[] iArr3 = new int[2];
                        getLocationOnScreen(iArr3);
                        if (getParent() instanceof ViewGroup) {
                            int[] iArr4 = new int[2];
                            ((ViewGroup) getParent()).getLocationOnScreen(iArr4);
                            layoutParams4.leftMargin = iArr3[0] - iArr4[0];
                            layoutParams4.topMargin = iArr3[1] - iArr4[1];
                        }
                        layoutParams4.gravity = 0;
                        setLayoutParams(layoutParams4);
                        this.f148g = true;
                        break;
                    }
                }
                break;
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        switch (this.f144a) {
            case 0:
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                if (layoutParams instanceof FrameLayout.LayoutParams) {
                    FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
                    if (motionEvent.getActionMasked() == 0) {
                        this.b = motionEvent.getRawX();
                        this.f145c = motionEvent.getRawY();
                        this.f146d = layoutParams2.leftMargin;
                        this.e = layoutParams2.topMargin;
                        this.f147f = false;
                    } else if (motionEvent.getActionMasked() == 2 && !this.f147f) {
                        if (Math.hypot(motionEvent.getRawX() - this.b, motionEvent.getRawY() - this.f145c) > this.f149h) {
                            this.f147f = true;
                            a();
                            this.f146d = layoutParams2.leftMargin;
                            this.e = layoutParams2.topMargin;
                            this.b = motionEvent.getRawX();
                            this.f145c = motionEvent.getRawY();
                        }
                    }
                    break;
                }
                break;
            default:
                ViewGroup.LayoutParams layoutParams3 = getLayoutParams();
                if (layoutParams3 instanceof FrameLayout.LayoutParams) {
                    FrameLayout.LayoutParams layoutParams4 = (FrameLayout.LayoutParams) layoutParams3;
                    if (motionEvent.getActionMasked() == 0) {
                        this.b = motionEvent.getRawX();
                        this.f145c = motionEvent.getRawY();
                        this.f146d = layoutParams4.leftMargin;
                        this.e = layoutParams4.topMargin;
                        this.f147f = false;
                    } else if (motionEvent.getActionMasked() == 2 && !this.f147f) {
                        if (Math.hypot(motionEvent.getRawX() - this.b, motionEvent.getRawY() - this.f145c) > this.f149h) {
                            this.f147f = true;
                            a();
                            this.f146d = layoutParams4.leftMargin;
                            this.e = layoutParams4.topMargin;
                            this.b = motionEvent.getRawX();
                            this.f145c = motionEvent.getRawY();
                        }
                    }
                    break;
                }
                break;
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0023, code lost:
    
        if (r1 != 3) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00d8, code lost:
    
        if (r1 != 3) goto L42;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
            Method dump skipped, instruction units count: 374
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.j0.onTouchEvent(android.view.MotionEvent):boolean");
    }
}
