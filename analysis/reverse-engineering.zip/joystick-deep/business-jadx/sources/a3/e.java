package a3;

import a4.a1;
import a4.b0;
import a4.c0;
import a4.d0;
import a4.d1;
import a4.e1;
import a4.g0;
import a4.i1;
import a4.o;
import a4.r;
import a4.s1;
import a4.t;
import a4.t1;
import a4.u1;
import a4.v1;
import a4.y;
import a4.z0;
import a4.z1;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.i0;
import com.efs.sdk.base.Constants;
import com.google.android.material.datepicker.h0;
import com.google.android.material.textfield.TextInputLayout;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import e4.f0;
import e4.l0;
import e4.s;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import k3.m;
import moe.heroman.eventtest.adbhelper.AdbMessage;
import moe.heroman.eventtest.floatingservice.FloatingService;
import p3.x;
import v.m.p;
import y3.q;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class e implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f15a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f16c;

    public /* synthetic */ e(Object obj, int i7, Object obj2) {
        this.f15a = i7;
        this.b = obj;
        this.f16c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        g0 g0Var;
        switch (this.f15a) {
            case 0:
                ((b) this.b).b((a) this.f16c);
                return;
            case 1:
                ArrayList arrayList = (ArrayList) this.b;
                String str = (String) this.f16c;
                int size = arrayList.size();
                int i7 = 0;
                while (i7 < size) {
                    Object obj = arrayList.get(i7);
                    i7++;
                    ((b) obj).a(str);
                }
                return;
            case 2:
                ArrayList arrayList2 = (ArrayList) this.b;
                a aVar = (a) this.f16c;
                int size2 = arrayList2.size();
                int i8 = 0;
                while (i8 < size2) {
                    Object obj2 = arrayList2.get(i8);
                    i8++;
                    ((b) obj2).b(aVar);
                }
                return;
            case 3:
                t tVar = (t) this.b;
                EditText editText = (EditText) this.f16c;
                editText.requestFocus();
                InputMethodManager inputMethodManager = (InputMethodManager) tVar.getContext().getSystemService(p.abcdstr(9));
                if (inputMethodManager != null) {
                    inputMethodManager.showSoftInput(editText, 1);
                    return;
                }
                return;
            case 4:
                w3.b bVar = (w3.b) this.b;
                e1 e1Var = (e1) this.f16c;
                t tVar2 = (t) bVar.f8545c;
                tVar2.f233t = null;
                tVar2.f232s = e1Var;
                tVar2.h(tVar2.f223j);
                r rVar = tVar2.f235v;
                if (rVar != null) {
                    y3.t tVar3 = ((q) ((y3.r) rVar).f9124a.b).f9123a;
                    y3.p pVar = tVar3.f9126d;
                    if (pVar != null) {
                        pVar.h();
                    }
                    y3.t.o(tVar3);
                }
                k3.t.e().c(m.f6583a);
                tVar2.f232s = e1Var;
                tVar2.o();
                return;
            case 5:
                o oVar = (o) this.b;
                e1 e1Var2 = (e1) this.f16c;
                t tVar4 = oVar.b;
                int i9 = 0;
                tVar4.n(false);
                while (true) {
                    if (i9 < tVar4.f217c.getChildCount()) {
                        View childAt = tVar4.f217c.getChildAt(i9);
                        if (childAt instanceof TextView) {
                            TextView textView = (TextView) childAt;
                            if (textView.getText().toString().equals(tVar4.getContext().getString(2131820613))) {
                                tVar4.j(textView, p.abcdstr(11));
                            }
                        }
                        i9++;
                    }
                }
                FloatingService.f6880k.a(String.format(tVar4.getContext().getString(2131820628), e1Var2.b));
                return;
            case 6:
                c0 c0Var = (c0) this.b;
                EditText editText2 = (EditText) this.f16c;
                editText2.requestFocus();
                InputMethodManager inputMethodManager2 = (InputMethodManager) c0Var.getContext().getSystemService(p.abcdstr(9));
                if (inputMethodManager2 != null) {
                    inputMethodManager2.showSoftInput(editText2, 1);
                    return;
                }
                return;
            case dd.f4082h /* 7 */:
                y2.o oVar2 = (y2.o) this.b;
                v1 v1Var = (v1) this.f16c;
                c0 c0Var2 = (c0) oVar2.f8985c;
                c0Var2.f67q = null;
                c0Var2.f66p = v1Var;
                c0Var2.g(c0Var2.f60j);
                b0 b0Var = c0Var2.f69s;
                if (b0Var != null && (g0Var = ((d0) b0Var).f76a) != null) {
                    g0Var.l();
                }
                k3.t.e().c(m.f6583a);
                x.t().p();
                c0Var2.f66p = v1Var;
                c0Var2.n();
                return;
            case 8:
                y yVar = (y) this.b;
                v1 v1Var2 = (v1) this.f16c;
                c0 c0Var3 = yVar.b;
                int i10 = 0;
                c0Var3.m(false);
                while (true) {
                    if (i10 < c0Var3.f54c.getChildCount()) {
                        View childAt2 = c0Var3.f54c.getChildAt(i10);
                        if (childAt2 instanceof TextView) {
                            TextView textView2 = (TextView) childAt2;
                            if (textView2.getText().toString().equals(c0Var3.getContext().getString(2131820613))) {
                                c0Var3.i(textView2, p.abcdstr(11));
                            }
                        }
                        i10++;
                    }
                }
                FloatingService.f6880k.a(String.format(c0Var3.getContext().getString(2131820628), v1Var2.b));
                return;
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                d1 d1Var = (d1) this.b;
                z0 z0Var = (z0) this.f16c;
                d1Var.f(new y1.e(2));
                d1Var.f80d = null;
                d1Var.e.clear();
                d1Var.f81f = null;
                d1Var.q();
                if (z0Var != null) {
                    z0Var.b();
                    return;
                }
                return;
            case 10:
                ((a4.m) this.b).a((String) this.f16c);
                return;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                ((a1) this.b).a((String) this.f16c);
                return;
            case 12:
                ((w3.e) this.b).a((String) this.f16c);
                return;
            case 13:
                ((y) this.b).a((String) this.f16c);
                return;
            case 14:
                ((w3.e) this.b).a((String) this.f16c);
                return;
            case 15:
                u1 u1Var = (u1) this.b;
                s1 s1Var = (s1) this.f16c;
                u1Var.f248d = null;
                u1Var.e.clear();
                u1Var.f249f = null;
                u1Var.k();
                if (s1Var != null) {
                    s1Var.b();
                    return;
                }
                return;
            case 16:
                w3.e eVar = (w3.e) this.b;
                ArrayList arrayList3 = (ArrayList) this.f16c;
                i1 i1Var = (i1) eVar.b;
                if (arrayList3.isEmpty()) {
                    return;
                }
                i1Var.f126a.clear();
                int size3 = arrayList3.size();
                int i11 = 0;
                while (i11 < size3) {
                    Object obj3 = arrayList3.get(i11);
                    i11++;
                    z1 z1Var = (z1) obj3;
                    z1 z1Var2 = new z1(z1Var.e, z1Var.f295a, z1Var.b, z1Var.f296c);
                    z1Var2.f297d = z1Var.f297d;
                    i1Var.f126a.add(z1Var2);
                }
                i1Var.f();
                i1Var.e();
                i1Var.d();
                i1Var.invalidate();
                return;
            case 17:
                ((t1) this.b).a((String) this.f16c);
                return;
            case 18:
                i0 i0Var = (i0) this.b;
                try {
                    ((Runnable) this.f16c).run();
                    return;
                } finally {
                    i0Var.a();
                }
            case 19:
                com.google.android.material.datepicker.h hVar = (com.google.android.material.datepicker.h) this.b;
                String str2 = (String) this.f16c;
                TextInputLayout textInputLayout = hVar.f3209a;
                SimpleDateFormat simpleDateFormat = hVar.f3210c;
                Context context = textInputLayout.getContext();
                String string = context.getString(2131820895);
                String str3 = String.format(context.getString(2131820897), str2.replace(' ', (char) 160));
                String str4 = String.format(context.getString(2131820896), simpleDateFormat.format(new Date(h0.f().getTimeInMillis())).replace(' ', (char) 160));
                StringBuilder sb = new StringBuilder();
                sb.append(string);
                String strAbcdstr = p.abcdstr(10);
                sb.append(strAbcdstr);
                sb.append(str3);
                sb.append(strAbcdstr);
                sb.append(str4);
                textInputLayout.setError(sb.toString());
                hVar.a();
                return;
            case 20:
                ((e4.h) this.b).a((String) this.f16c);
                return;
            case 21:
                d4.m mVar = (d4.m) this.b;
                d4.j jVar = (d4.j) this.f16c;
                mVar.e(new y1.e(14));
                mVar.f5268d = null;
                mVar.e.clear();
                mVar.f5269f = null;
                mVar.n();
                if (jVar != null) {
                    jVar.b();
                    return;
                }
                return;
            case 22:
                ((d4.k) this.b).a((String) this.f16c);
                return;
            case 23:
                ((w3.e) this.b).a((String) this.f16c);
                return;
            case AdbMessage.HEADER_LENGTH /* 24 */:
                e4.k kVar = (e4.k) this.b;
                EditText editText3 = (EditText) this.f16c;
                editText3.requestFocus();
                InputMethodManager inputMethodManager3 = (InputMethodManager) kVar.getContext().getSystemService(p.abcdstr(9));
                if (inputMethodManager3 != null) {
                    inputMethodManager3.showSoftInput(editText3, 1);
                    return;
                }
                return;
            case 25:
                s sVar = (s) this.b;
                EditText editText4 = (EditText) this.f16c;
                editText4.requestFocus();
                InputMethodManager inputMethodManager4 = (InputMethodManager) sVar.getContext().getSystemService(p.abcdstr(9));
                if (inputMethodManager4 != null) {
                    inputMethodManager4.showSoftInput(editText4, 1);
                    return;
                }
                return;
            case 26:
                ((d0.g) this.b).a((String) this.f16c);
                return;
            case 27:
                ((w3.e) this.b).a((String) this.f16c);
                return;
            case 28:
                e4.h0 h0Var = (e4.h0) this.b;
                f0 f0Var = (f0) this.f16c;
                h0Var.f5369d = null;
                h0Var.e.clear();
                h0Var.f5370f = null;
                h0Var.l();
                if (f0Var != null) {
                    f0Var.b();
                    return;
                }
                return;
            default:
                w3.e eVar2 = (w3.e) this.b;
                ArrayList arrayList4 = (ArrayList) this.f16c;
                if (arrayList4.isEmpty()) {
                    return;
                }
                ((l0) eVar2.b).setNodes(arrayList4);
                return;
        }
    }
}
