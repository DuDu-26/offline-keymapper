package a3;

import java.io.ByteArrayOutputStream;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f33a;
    public final ByteArrayOutputStream b = new ByteArrayOutputStream(64);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f34c = 0;

    public k(boolean z6) {
        this.f33a = z6;
    }
}
