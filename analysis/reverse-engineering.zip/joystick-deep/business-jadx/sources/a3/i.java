package a3;

import androidx.appcompat.widget.ActionBarContextView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import f0.y0;
import h3.h1;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import v.m.p;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class i implements y0, h1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f25a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f26c;

    public i(byte[] bArr) {
        this.b = 0;
        this.f25a = true;
        this.f26c = bArr;
    }

    @Override // h3.h1
    public void a(String str) {
        androidx.activity.g.w(p.abcdstr(17), str, p.abcdstr(16));
    }

    @Override // h3.h1
    public void b() {
        k3.l lVar = (k3.l) this.f26c;
        String str = lVar.f6563g;
        if (k3.l.b(lVar, this.b) || this.f25a || !lVar.f6564h) {
            return;
        }
        lVar.n();
    }

    @Override // f0.y0
    public void c() {
        if (this.f25a) {
            return;
        }
        ActionBarContextView actionBarContextView = (ActionBarContextView) this.f26c;
        actionBarContextView.f598f = null;
        ActionBarContextView.b(actionBarContextView, this.b);
    }

    @Override // f0.y0
    public void d() {
        this.f25a = true;
    }

    @Override // f0.y0
    public void e() {
        ActionBarContextView.a((ActionBarContextView) this.f26c);
        this.f25a = false;
    }

    public String f() {
        long jH = h();
        if (this.f25a && jH >= 0) {
            int i7 = this.b;
            long j7 = ((long) i7) + jH;
            byte[] bArr = (byte[]) this.f26c;
            if (j7 <= bArr.length) {
                int i8 = (int) jH;
                String str = new String(bArr, i7, i8, StandardCharsets.UTF_8);
                this.b += i8;
                return str;
            }
        }
        this.f25a = false;
        return "";
    }

    public j g(int i7) {
        int i8;
        int i9;
        double dLongBitsToDouble;
        if (i7 > 64) {
            this.f25a = false;
            return null;
        }
        int i10 = this.b;
        byte[] bArr = (byte[]) this.f26c;
        if (i10 >= bArr.length) {
            this.f25a = false;
            i8 = 0;
        } else {
            this.b = i10 + 1;
            i8 = bArr[i10] & 255;
        }
        if (this.f25a) {
            long j7 = 0;
            switch (i8) {
                case 0:
                    return new j(0);
                case 1:
                    j jVar = new j(1);
                    int i11 = this.b;
                    if (i11 >= bArr.length) {
                        this.f25a = false;
                        i9 = 0;
                    } else {
                        this.b = i11 + 1;
                        i9 = bArr[i11] & 255;
                    }
                    jVar.f29d = i9 != 0;
                    if (this.f25a) {
                        return jVar;
                    }
                    break;
                case 2:
                    j jVar2 = new j(2);
                    long jH = h();
                    jVar2.b = (-(jH & 1)) ^ (jH >>> 1);
                    if (this.f25a) {
                        return jVar2;
                    }
                    break;
                case 3:
                    j jVar3 = new j(3);
                    if (this.b + 8 > bArr.length) {
                        this.f25a = false;
                        dLongBitsToDouble = 0.0d;
                    } else {
                        for (int i12 = 0; i12 < 8; i12++) {
                            int i13 = this.b;
                            this.b = i13 + 1;
                            j7 = (j7 << 8) | ((long) (bArr[i13] & 255));
                        }
                        dLongBitsToDouble = Double.longBitsToDouble(j7);
                    }
                    jVar3.f28c = dLongBitsToDouble;
                    if (this.f25a) {
                        return jVar3;
                    }
                    break;
                case 4:
                    j jVar4 = new j(4);
                    jVar4.e = f();
                    if (this.f25a) {
                        return jVar4;
                    }
                    break;
                case 5:
                    long jH2 = h();
                    if (!this.f25a || jH2 < 0) {
                        this.f25a = false;
                        return null;
                    }
                    j jVar5 = new j(5);
                    jVar5.f30f = new HashMap();
                    jVar5.f31g = new LinkedHashMap();
                    for (long j8 = 0; j8 < jH2; j8++) {
                        long jH3 = h();
                        if (this.f25a) {
                            if (jH3 > 0) {
                                j jVarG = g(i7 + 1);
                                if (this.f25a) {
                                    jVar5.f30f.put(Integer.valueOf((int) jH3), jVarG);
                                }
                            } else {
                                String strF = f();
                                if (this.f25a) {
                                    j jVarG2 = g(i7 + 1);
                                    if (this.f25a) {
                                        jVar5.f31g.put(strF, jVarG2);
                                    }
                                }
                            }
                        }
                        break;
                    }
                    return jVar5;
                case 6:
                    long jH4 = h();
                    if (!this.f25a || jH4 < 0) {
                        this.f25a = false;
                        return null;
                    }
                    j jVar6 = new j(6);
                    jVar6.f32h = new ArrayList((int) Math.min(jH4, 1024L));
                    while (j7 < jH4) {
                        j jVarG3 = g(i7 + 1);
                        if (this.f25a) {
                            jVar6.f32h.add(jVarG3);
                            j7++;
                        }
                        break;
                    }
                    return jVar6;
                default:
                    this.f25a = false;
                    return null;
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0026, code lost:
    
        r9.f25a = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0028, code lost:
    
        return 0;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public long h() {
        /*
            r9 = this;
            r0 = 0
            r2 = 0
            r4 = r0
            r3 = r2
        L5:
            int r6 = r9.b
            java.lang.Object r7 = r9.f26c
            byte[] r7 = (byte[]) r7
            int r8 = r7.length
            if (r6 >= r8) goto L26
            r8 = 63
            if (r3 <= r8) goto L13
            goto L26
        L13:
            int r8 = r6 + 1
            r9.b = r8
            r6 = r7[r6]
            r7 = r6 & 127(0x7f, float:1.78E-43)
            long r7 = (long) r7
            long r7 = r7 << r3
            long r4 = r4 | r7
            r6 = r6 & 128(0x80, float:1.794E-43)
            if (r6 != 0) goto L23
            return r4
        L23:
            int r3 = r3 + 7
            goto L5
        L26:
            r9.f25a = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a3.i.h():long");
    }

    public i(FloatingActionButton floatingActionButton) {
        this.f25a = false;
        this.b = 0;
        this.f26c = floatingActionButton;
    }

    public i(ActionBarContextView actionBarContextView) {
        this.f26c = actionBarContextView;
        this.f25a = false;
    }

    public i(k3.l lVar, int i7, boolean z6) {
        this.f26c = lVar;
        this.b = i7;
        this.f25a = z6;
    }
}
