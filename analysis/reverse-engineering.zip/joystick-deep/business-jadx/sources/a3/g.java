package a3;

import android.content.Context;
import android.widget.Toast;
import b4.b1;
import e4.r0;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLProtocolException;
import moe.heroman.eventtest.adbhelper.AdbClient;
import moe.heroman.eventtest.adbhelper.AdbKey;
import moe.heroman.eventtest.adbhelper.AdbPairingService;
import o3.k0;
import o3.m0;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class g implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f20a;
    public final /* synthetic */ int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f21c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f22d;

    public /* synthetic */ g(int i7, androidx.emoji2.text.l lVar, a aVar, String str) {
        this.f20a = 0;
        this.b = i7;
        this.f21c = lVar;
        this.f22d = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f20a) {
            case 0:
                Context context = ((androidx.emoji2.text.l) this.f21c).f1124a;
                String strValueOf = (String) this.f22d;
                int i7 = this.b;
                if (i7 == 0) {
                    Toast.makeText(context, 2131820780, 0).show();
                    return;
                }
                if (strValueOf == null || strValueOf.isEmpty()) {
                    strValueOf = String.valueOf(i7);
                }
                Toast.makeText(context, context.getString(2131820778, strValueOf), 0).show();
                return;
            case 1:
                l4.k kVar = (l4.k) this.f21c;
                k0 k0Var = (k0) this.f22d;
                kVar.getClass();
                int iB = r0.B();
                if (iB <= 0) {
                    iB = this.b;
                }
                int i8 = 3;
                if (iB > 0) {
                    try {
                        try {
                            AdbClient adbClient = new AdbClient("127.0.0.1", iB, new AdbKey());
                            try {
                                adbClient.connect();
                                adbClient.close();
                                i8 = 1;
                            } catch (Throwable th) {
                                try {
                                    adbClient.close();
                                    break;
                                } catch (Throwable th2) {
                                    th.addSuppressed(th2);
                                }
                                throw th;
                            }
                        } catch (SSLProtocolException unused) {
                            i8 = 2;
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    } catch (Exception unused2) {
                    }
                }
                m0 m0Var = k0Var.f7208a;
                if (m0Var.g() == null || !m0Var.o()) {
                    return;
                }
                m0Var.g().runOnUiThread(new b1(m0Var, i8, 5));
                return;
            case 2:
                AdbPairingService.a((AdbPairingService) this.f21c, this.b, (String) this.f22d);
                return;
            case 3:
                List list = (List) this.f21c;
                q3.b bVar = (q3.b) this.f22d;
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    try {
                        ((Future) it.next()).get(2L, TimeUnit.SECONDS);
                    } catch (InterruptedException unused3) {
                        Thread.currentThread().interrupt();
                    } catch (Throwable unused4) {
                    }
                }
                bVar.a(this.b);
                return;
            default:
                s0.a aVar = (s0.a) this.f21c;
                aVar.b.l(this.b, this.f22d);
                return;
        }
    }

    public /* synthetic */ g(Object obj, int i7, Object obj2, int i8) {
        this.f20a = i8;
        this.f21c = obj;
        this.b = i7;
        this.f22d = obj2;
    }

    public /* synthetic */ g(Object obj, Object obj2, int i7, int i8) {
        this.f20a = i8;
        this.f21c = obj;
        this.f22d = obj2;
        this.b = i7;
    }
}
