package a3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f27a;
    public long b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public double f28c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f29d;
    public String e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public HashMap f30f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public LinkedHashMap f31g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList f32h;

    public j(int i7) {
        this.f27a = i7;
    }

    public final List a(int i7) {
        j jVarL = l(i7);
        return (jVarL == null || jVarL.f27a != 6) ? Collections.EMPTY_LIST : jVarL.f32h;
    }

    public final double b(double d3) {
        int i7 = this.f27a;
        return i7 == 3 ? this.f28c : i7 == 2 ? this.b : d3;
    }

    public final long c(long j7) {
        int i7 = this.f27a;
        return i7 == 2 ? this.b : i7 == 3 ? (long) this.f28c : j7;
    }

    public final List d() {
        ArrayList arrayList = this.f32h;
        return arrayList != null ? arrayList : Collections.EMPTY_LIST;
    }

    public final boolean e(int i7) {
        HashMap map = this.f30f;
        return map != null && map.containsKey(Integer.valueOf(i7));
    }

    public final j f(String str) {
        LinkedHashMap linkedHashMap = this.f31g;
        if (linkedHashMap != null) {
            return (j) linkedHashMap.get(str);
        }
        return null;
    }

    public final j g(int i7) {
        j jVarL = l(i7);
        if (jVarL == null || jVarL.f27a != 5) {
            return null;
        }
        return jVarL;
    }

    public final boolean h(int i7, boolean z6) {
        j jVarL = l(i7);
        return (jVarL == null || jVarL.f27a != 1) ? z6 : jVarL.f29d;
    }

    public final double i(int i7) {
        j jVarL = l(i7);
        if (jVarL != null) {
            return jVarL.b(0.0d);
        }
        return 0.0d;
    }

    public final int j(int i7, int i8) {
        j jVarL = l(i7);
        return jVarL != null ? (int) jVarL.c(i8) : i8;
    }

    public final String k(int i7, String str) {
        j jVarL = l(i7);
        return (jVarL == null || jVarL.f27a != 4) ? str : jVarL.e;
    }

    public final j l(int i7) {
        HashMap map = this.f30f;
        if (map != null) {
            return (j) map.get(Integer.valueOf(i7));
        }
        return null;
    }
}
