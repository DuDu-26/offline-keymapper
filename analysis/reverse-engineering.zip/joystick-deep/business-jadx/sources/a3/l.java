package a3;

import android.util.Size;
import java.util.Random;
import moe.heroman.eventtest.common.INativeBinderInterface;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static volatile boolean f35a;
    public static volatile int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static volatile int f36c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static volatile int f37d;
    public static volatile int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static volatile int f38f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final Random f39g = new Random();

    public static void a() {
        int[] touchDeviceMax;
        int i7;
        boolean zE = y2.l.i().e();
        f35a = zE;
        if (zE) {
            if (b <= 0 || f36c <= 0) {
                try {
                    INativeBinderInterface iNativeBinderInterface = y2.b.b().b;
                    if (iNativeBinderInterface != null && (touchDeviceMax = iNativeBinderInterface.getTouchDeviceMax()) != null && touchDeviceMax.length >= 2 && (i7 = touchDeviceMax[0]) > 0 && touchDeviceMax[1] > 0) {
                        b = i7;
                        f36c = touchDeviceMax[1];
                    }
                } catch (Exception unused) {
                }
            }
            g.d dVarC = g.d.C();
            Size sizeT = dVarC.t();
            e = sizeT.getWidth();
            f38f = sizeT.getHeight();
            f37d = dVarC.y();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x005b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static long b(int r14, int r15) {
        /*
            boolean r0 = a3.l.f35a
            r1 = 4294967295(0xffffffff, double:2.1219957905E-314)
            r3 = 32
            if (r0 != 0) goto L12
        Lb:
            long r4 = (long) r14
            long r3 = r4 << r3
            long r14 = (long) r15
            long r14 = r14 & r1
            long r14 = r14 | r3
            return r14
        L12:
            int r0 = a3.l.b
            int r4 = a3.l.f36c
            int r5 = a3.l.e
            int r6 = a3.l.f38f
            if (r5 <= 0) goto Lb
            if (r6 <= 0) goto Lb
            if (r0 <= 0) goto Lb
            if (r4 > 0) goto L23
            goto Lb
        L23:
            int r7 = a3.l.f37d
            r8 = 1
            if (r7 == r8) goto L3a
            r8 = 2
            if (r7 == r8) goto L35
            r8 = 3
            if (r7 == r8) goto L2f
            goto L3d
        L2f:
            int r14 = r5 - r14
        L31:
            r13 = r15
            r15 = r14
            r14 = r13
            goto L3d
        L35:
            int r14 = r6 - r14
            int r15 = r5 - r15
            goto L3d
        L3a:
            int r15 = r6 - r15
            goto L31
        L3d:
            long r7 = (long) r14
            long r9 = (long) r0
            long r7 = r7 * r9
            long r11 = (long) r6
            long r7 = r7 / r11
            long r14 = (long) r15
            long r11 = (long) r4
            long r14 = r14 * r11
            long r4 = (long) r5
            long r14 = r14 / r4
            r4 = 0
            int r0 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r0 >= 0) goto L4f
            r9 = r4
            goto L55
        L4f:
            int r0 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r0 <= 0) goto L54
            goto L55
        L54:
            r9 = r7
        L55:
            int r0 = (r14 > r4 ? 1 : (r14 == r4 ? 0 : -1))
            if (r0 >= 0) goto L5b
            r11 = r4
            goto L61
        L5b:
            int r0 = (r14 > r11 ? 1 : (r14 == r11 ? 0 : -1))
            if (r0 <= 0) goto L60
            goto L61
        L60:
            r11 = r14
        L61:
            int r14 = (int) r9
            int r15 = (int) r11
            goto Lb
        */
        throw new UnsupportedOperationException("Method not decompiled: a3.l.b(int, int):long");
    }
}
