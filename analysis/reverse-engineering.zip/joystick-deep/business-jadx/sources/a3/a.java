package a3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f10a;
    public long b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f11c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public h[] f12d;
    public long e;
}
