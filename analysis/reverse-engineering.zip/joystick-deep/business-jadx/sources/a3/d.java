package a3;

import java.util.concurrent.ThreadFactory;
import v.m.p;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class d implements ThreadFactory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f14a;

    public /* synthetic */ d(int i7) {
        this.f14a = i7;
    }

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        switch (this.f14a) {
            case 0:
                Thread thread = new Thread(runnable, p.abcdstr(8));
                thread.setDaemon(true);
                return thread;
            case 1:
                Thread thread2 = new Thread(runnable, p.abcdstr(7));
                thread2.setDaemon(true);
                return thread2;
            case 2:
                Thread thread3 = new Thread(runnable, p.abcdstr(6));
                thread3.setDaemon(true);
                return thread3;
            case 3:
                Thread thread4 = new Thread(runnable, p.abcdstr(5));
                thread4.setDaemon(true);
                return thread4;
            case 4:
                Thread thread5 = new Thread(runnable, p.abcdstr(4));
                thread5.setDaemon(true);
                return thread5;
            case 5:
                Thread thread6 = new Thread(runnable, p.abcdstr(3));
                thread6.setDaemon(true);
                return thread6;
            case 6:
                Thread thread7 = new Thread(runnable, p.abcdstr(2));
                thread7.setDaemon(true);
                return thread7;
            default:
                Thread thread8 = new Thread(runnable, p.abcdstr(1));
                thread8.setDaemon(true);
                return thread8;
        }
    }
}
