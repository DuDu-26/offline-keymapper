package a3;

import a4.d1;
import a4.e1;
import a4.i0;
import a4.m;
import a4.m0;
import a4.n0;
import a4.n1;
import a4.o;
import a4.s1;
import a4.t;
import a4.u1;
import a4.v1;
import a4.y;
import a4.z0;
import android.os.Handler;
import android.util.Log;
import androidx.emoji2.text.q;
import com.efs.sdk.base.Constants;
import com.umeng.analytics.pro.dd;
import com.umeng.commonsdk.statistics.common.ReportPolicy;
import e4.d0;
import e4.e0;
import e4.f0;
import e4.h0;
import e4.x;
import h3.h1;
import h3.j1;
import h3.y0;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.ThreadPoolExecutor;
import moe.heroman.eventtest.adbhelper.AdbMessage;
import moe.heroman.eventtest.auth.NativeAuth;
import moe.heroman.eventtest.floatingservice.FloatingService;
import v.m.p;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final /* synthetic */ class f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f17a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f18c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f19d;

    public /* synthetic */ f(j1 j1Var, NativeAuth.ConfigSummary[] configSummaryArr, String str, g.d dVar) {
        this.f17a = 27;
        this.b = j1Var;
        this.f18c = configSummaryArr;
        this.f19d = dVar;
    }

    /* JADX WARN: Type inference failed for: r4v15, types: [java.io.Serializable, moe.heroman.eventtest.auth.NativeAuth$ConfigSummary[]] */
    /* JADX WARN: Type inference failed for: r4v17, types: [java.io.Serializable, moe.heroman.eventtest.auth.NativeAuth$ConfigSummary[]] */
    /* JADX WARN: Type inference failed for: r4v3, types: [java.io.Serializable, moe.heroman.eventtest.auth.NativeAuth$ConfigSummary[]] */
    /* JADX WARN: Type inference failed for: r4v30, types: [java.io.Serializable, moe.heroman.eventtest.auth.NativeAuth$ConfigSummary[]] */
    /* JADX WARN: Type inference failed for: r4v40, types: [java.io.Serializable, moe.heroman.eventtest.auth.NativeAuth$ConfigSummary[]] */
    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f17a) {
            case 0:
                moe.heroman.eventtest.auth.a aVar = (moe.heroman.eventtest.auth.a) this.b;
                Runnable runnable = (Runnable) this.f18c;
                Runnable runnable2 = (Runnable) this.f19d;
                Handler handler = aVar.f6870a;
                int iR0 = NativeAuth.r0();
                aVar.b(moe.heroman.eventtest.auth.a.c());
                if (iR0 == 0) {
                    handler.post(runnable);
                    return;
                } else {
                    if (runnable2 != null) {
                        handler.post(runnable2);
                        return;
                    }
                    return;
                }
            case 1:
                moe.heroman.eventtest.auth.a aVar2 = (moe.heroman.eventtest.auth.a) this.b;
                String str = (String) this.f18c;
                androidx.emoji2.text.l lVar = (androidx.emoji2.text.l) this.f19d;
                int iA = NativeAuth.a(str);
                String strR = iA == 0 ? null : NativeAuth.r();
                a aVarC = moe.heroman.eventtest.auth.a.c();
                aVar2.b(aVarC);
                aVar2.f6870a.post(new g(iA, lVar, aVarC, strR));
                return;
            case 2:
                m mVar = (m) this.b;
                i0.I().q((String) this.f18c, (String) this.f19d);
                t tVar = mVar.f170c;
                tVar.h(tVar.f223j);
                FloatingService.f6880k.a(tVar.getContext().getString(2131820634));
                return;
            case 3:
                d1 d1Var = (d1) this.b;
                String str2 = (String) this.f18c;
                String str3 = (String) this.f19d;
                k3.l lVar2 = d1Var.f87l.f6553a;
                lVar2.l(lVar2.f6559a.getString(2131820624, str2, str3));
                return;
            case 4:
                d1 d1Var2 = (d1) this.b;
                String str4 = (String) this.f18c;
                z0 z0Var = (z0) this.f19d;
                Handler handler2 = d1Var2.f79c;
                ?? W = NativeAuth.W(str4);
                if (W == 0) {
                    handler2.post(new m0(z0Var, d1.m(p.abcdstr(12)), 0));
                    return;
                } else {
                    handler2.post(new n0(d1Var2, str4, (Serializable) W, z0Var, 0));
                    return;
                }
            case 5:
                e1 e1Var = (e1) this.b;
                String str5 = (String) this.f18c;
                o oVar = (o) this.f19d;
                e1Var.b = str5;
                System.currentTimeMillis();
                oVar.b();
                return;
            case 6:
                d1 d1Var3 = (d1) this.b;
                String str6 = (String) this.f18c;
                w3.e eVar = (w3.e) this.f19d;
                Handler handler3 = d1Var3.f79c;
                NativeAuth.ConfigSummary[] configSummaryArrW = NativeAuth.W(str6);
                if (configSummaryArrW == null) {
                    handler3.post(new e(eVar, 12, d1.m(p.abcdstr(15))));
                    return;
                } else {
                    handler3.post(new f(d1Var3, configSummaryArrW, eVar, 7));
                    return;
                }
            case dd.f4082h /* 7 */:
                d1 d1Var4 = (d1) this.b;
                NativeAuth.ConfigSummary[] configSummaryArr = (NativeAuth.ConfigSummary[]) this.f18c;
                w3.e eVar2 = (w3.e) this.f19d;
                ArrayList arrayList = d1Var4.e;
                arrayList.clear();
                d1Var4.q();
                for (NativeAuth.ConfigSummary configSummary : configSummaryArr) {
                    arrayList.add(d1.v(configSummary));
                }
                eVar2.b();
                return;
            case 8:
                u1 u1Var = (u1) this.b;
                String str7 = (String) this.f18c;
                w3.e eVar3 = (w3.e) this.f19d;
                Handler handler4 = u1Var.f247c;
                NativeAuth.ConfigSummary[] configSummaryArrN0 = NativeAuth.n0(str7);
                if (configSummaryArrN0 == null) {
                    handler4.post(new e(eVar3, 14, u1.i(p.abcdstr(15))));
                    return;
                } else {
                    handler4.post(new f(u1Var, configSummaryArrN0, eVar3, 11));
                    return;
                }
            case Constants.CALLBACK_LOG_GENERATOR /* 9 */:
                v1 v1Var = (v1) this.b;
                String str8 = (String) this.f18c;
                y yVar = (y) this.f19d;
                v1Var.b = str8;
                System.currentTimeMillis();
                yVar.b();
                return;
            case 10:
                u1 u1Var2 = (u1) this.b;
                String str9 = (String) this.f18c;
                String str10 = (String) this.f19d;
                k3.l lVar3 = u1Var2.f253j.f6553a;
                lVar3.l(lVar3.f6559a.getString(2131820624, str9, str10));
                return;
            case ReportPolicy.QUASI_REALTIME_POLICY /* 11 */:
                u1 u1Var3 = (u1) this.b;
                NativeAuth.ConfigSummary[] configSummaryArr2 = (NativeAuth.ConfigSummary[]) this.f18c;
                w3.e eVar4 = (w3.e) this.f19d;
                ArrayList arrayList2 = u1Var3.e;
                arrayList2.clear();
                u1Var3.k();
                for (NativeAuth.ConfigSummary configSummary2 : configSummaryArr2) {
                    arrayList2.add(u1.o(configSummary2));
                }
                eVar4.b();
                return;
            case 12:
                u1 u1Var4 = (u1) this.b;
                String str11 = (String) this.f18c;
                s1 s1Var = (s1) this.f19d;
                Handler handler5 = u1Var4.f247c;
                ?? N0 = NativeAuth.n0(str11);
                if (N0 == 0) {
                    handler5.post(new n1(s1Var, u1.i(p.abcdstr(12)), 0));
                    return;
                } else {
                    handler5.post(new n0(u1Var4, str11, (Serializable) N0, s1Var, 4));
                    return;
                }
            case 13:
                androidx.emoji2.text.l lVar4 = (androidx.emoji2.text.l) this.b;
                a5.h hVar = (a5.h) this.f18c;
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) this.f19d;
                try {
                    q qVarQ = a5.h.q(lVar4.f1124a);
                    if (qVarQ == null) {
                        throw new RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    androidx.emoji2.text.p pVar = (androidx.emoji2.text.p) ((androidx.emoji2.text.i) qVarQ.b);
                    synchronized (pVar.f1134d) {
                        pVar.f1135f = threadPoolExecutor;
                        break;
                    }
                    ((androidx.emoji2.text.i) qVarQ.b).a(new androidx.emoji2.text.k(hVar, threadPoolExecutor));
                    return;
                } catch (Throwable th) {
                    hVar.Q(th);
                    threadPoolExecutor.shutdown();
                    return;
                }
            case 14:
                d4.m mVar2 = (d4.m) this.b;
                String str12 = (String) this.f18c;
                d4.j jVar = (d4.j) this.f19d;
                Handler handler6 = mVar2.f5267c;
                ?? W2 = NativeAuth.W(str12);
                if (W2 == 0) {
                    handler6.post(new d4.c(jVar, d4.m.k(p.abcdstr(12)), 0));
                    return;
                } else {
                    handler6.post(new n0(mVar2, str12, (Serializable) W2, jVar, 7));
                    return;
                }
            case 15:
                x xVar = (x) this.b;
                String str13 = (String) this.f18c;
                e4.h hVar2 = (e4.h) this.f19d;
                xVar.b = str13;
                System.currentTimeMillis();
                hVar2.b();
                return;
            case 16:
                d4.m mVar3 = (d4.m) this.b;
                String str14 = (String) this.f18c;
                String str15 = (String) this.f19d;
                k3.l lVar5 = mVar3.f5275l.f6553a;
                lVar5.l(lVar5.f6559a.getString(2131820624, str14, str15));
                return;
            case 17:
                d4.m mVar4 = (d4.m) this.b;
                String str16 = (String) this.f18c;
                w3.e eVar5 = (w3.e) this.f19d;
                Handler handler7 = mVar4.f5267c;
                NativeAuth.ConfigSummary[] configSummaryArrW2 = NativeAuth.W(str16);
                if (configSummaryArrW2 == null) {
                    handler7.post(new e(eVar5, 23, d4.m.k(p.abcdstr(15))));
                    return;
                } else {
                    handler7.post(new f(mVar4, configSummaryArrW2, eVar5, 18));
                    return;
                }
            case 18:
                d4.m mVar5 = (d4.m) this.b;
                NativeAuth.ConfigSummary[] configSummaryArr3 = (NativeAuth.ConfigSummary[]) this.f18c;
                w3.e eVar6 = (w3.e) this.f19d;
                ArrayList arrayList3 = mVar5.e;
                arrayList3.clear();
                for (NativeAuth.ConfigSummary configSummary3 : configSummaryArr3) {
                    arrayList3.add(d4.m.u(configSummary3));
                }
                eVar6.b();
                return;
            case 19:
                h0 h0Var = (h0) this.b;
                String str17 = (String) this.f18c;
                w3.e eVar7 = (w3.e) this.f19d;
                Handler handler8 = h0Var.f5368c;
                NativeAuth.ConfigSummary[] configSummaryArrN02 = NativeAuth.n0(str17);
                if (configSummaryArrN02 == null) {
                    handler8.post(new e(eVar7, 27, h0.j(p.abcdstr(15))));
                    return;
                } else {
                    handler8.post(new f(h0Var, configSummaryArrN02, eVar7, 21));
                    return;
                }
            case 20:
                e4.i0 i0Var = (e4.i0) this.b;
                String str18 = (String) this.f18c;
                e4.p pVar2 = (e4.p) this.f19d;
                i0Var.b = str18;
                System.currentTimeMillis();
                pVar2.b();
                return;
            case 21:
                h0 h0Var2 = (h0) this.b;
                NativeAuth.ConfigSummary[] configSummaryArr4 = (NativeAuth.ConfigSummary[]) this.f18c;
                w3.e eVar8 = (w3.e) this.f19d;
                ArrayList arrayList4 = h0Var2.e;
                arrayList4.clear();
                h0Var2.l();
                for (NativeAuth.ConfigSummary configSummary4 : configSummaryArr4) {
                    arrayList4.add(h0.p(configSummary4));
                }
                eVar8.b();
                return;
            case 22:
                h0 h0Var3 = (h0) this.b;
                String str19 = (String) this.f18c;
                String str20 = (String) this.f19d;
                k3.l lVar6 = h0Var3.f5374j.f6553a;
                lVar6.l(lVar6.f6559a.getString(2131820624, str19, str20));
                return;
            case 23:
                h0 h0Var4 = (h0) this.b;
                String str21 = (String) this.f18c;
                f0 f0Var = (f0) this.f19d;
                Handler handler9 = h0Var4.f5368c;
                ?? N02 = NativeAuth.n0(str21);
                if (N02 == 0) {
                    handler9.post(new d0(f0Var, h0.j(p.abcdstr(12)), 0));
                    return;
                } else {
                    handler9.post(new n0(h0Var4, str21, (Serializable) N02, f0Var, 11));
                    return;
                }
            case AdbMessage.HEADER_LENGTH /* 24 */:
                f3.e eVar9 = (f3.e) this.b;
                final y2.e eVar10 = (y2.e) this.f18c;
                String str22 = (String) this.f19d;
                Handler handler10 = eVar9.b;
                if (NativeAuth.v()) {
                    NativeAuth.ShareImportResult shareImportResultV0 = NativeAuth.v0();
                    if (shareImportResultV0 != null) {
                        eVar9.d(shareImportResultV0, eVar10);
                        return;
                    }
                    final String strR2 = NativeAuth.r();
                    final int i7 = 0;
                    handler10.post(new Runnable() { // from class: f3.b
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i7) {
                                case 0:
                                    eVar10.a(strR2);
                                    break;
                                default:
                                    eVar10.a(strR2);
                                    break;
                            }
                        }
                    });
                    return;
                }
                NativeAuth.ShareImportResult shareImportResultA0 = NativeAuth.A0(str22);
                if (shareImportResultA0 != null) {
                    eVar9.d(shareImportResultA0, eVar10);
                    return;
                }
                final String strR3 = NativeAuth.r();
                final int i8 = 1;
                handler10.post(new Runnable() { // from class: f3.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i8) {
                            case 0:
                                eVar10.a(strR3);
                                break;
                            default:
                                eVar10.a(strR3);
                                break;
                        }
                    }
                });
                return;
            case 25:
                j1 j1Var = (j1) this.b;
                String str23 = (String) this.f18c;
                g.d dVar = (g.d) this.f19d;
                Handler handler11 = j1Var.f6019c;
                NativeAuth.ConfigSummary[] configSummaryArrB = NativeAuth.B(str23);
                if (configSummaryArrB == null) {
                    handler11.post(new e0(dVar, 7, j1.i(p.abcdstr(15))));
                    return;
                } else {
                    handler11.post(new f(j1Var, configSummaryArrB, str23, dVar));
                    return;
                }
            case 26:
                j1 j1Var2 = (j1) this.b;
                String str24 = (String) this.f18c;
                String str25 = (String) this.f19d;
                k3.l lVar7 = j1Var2.f6026k.f6553a;
                lVar7.l(lVar7.f6559a.getString(2131820624, str24, str25));
                return;
            case 27:
                j1 j1Var3 = (j1) this.b;
                NativeAuth.ConfigSummary[] configSummaryArr5 = (NativeAuth.ConfigSummary[]) this.f18c;
                g.d dVar2 = (g.d) this.f19d;
                ArrayList arrayList5 = j1Var3.e;
                arrayList5.clear();
                for (NativeAuth.ConfigSummary configSummary5 : configSummaryArr5) {
                    arrayList5.add(j1.n(configSummary5));
                }
                arrayList5.size();
                dVar2.b();
                return;
            case 28:
                j1 j1Var4 = (j1) this.b;
                String str26 = (String) this.f18c;
                h1 h1Var = (h1) this.f19d;
                Handler handler12 = j1Var4.f6019c;
                ?? B = NativeAuth.B(str26);
                if (B != 0) {
                    handler12.post(new n0(j1Var4, str26, (Serializable) B, h1Var, 15));
                    return;
                }
                String strI = j1.i(p.abcdstr(12));
                Log.e(p.abcdstr(13), p.abcdstr(14).concat(strI));
                handler12.post(new y0(h1Var, strI, 0));
                return;
            default:
                h3.c cVar = (h3.c) this.b;
                String str27 = (String) this.f18c;
                h3.o oVar2 = (h3.o) this.f19d;
                cVar.b = str27;
                System.currentTimeMillis();
                oVar2.b();
                return;
        }
    }

    public /* synthetic */ f(Object obj, Object obj2, Object obj3, int i7) {
        this.f17a = i7;
        this.b = obj;
        this.f18c = obj2;
        this.f19d = obj3;
    }
}
