package android.support.v4.os;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements IResultReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IBinder f323a;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f323a;
    }

    @Override // android.support.v4.os.IResultReceiver
    public final void send(int i7, Bundle bundle) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(IResultReceiver.DESCRIPTOR);
            parcelObtain.writeInt(i7);
            if (bundle != null) {
                parcelObtain.writeInt(1);
                bundle.writeToParcel(parcelObtain, 0);
            } else {
                parcelObtain.writeInt(0);
            }
            this.f323a.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
