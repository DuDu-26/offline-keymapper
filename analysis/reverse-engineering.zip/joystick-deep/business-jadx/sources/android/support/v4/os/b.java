package android.support.v4.os;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.os.IResultReceiver;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import androidx.versionedparcelable.ParcelImpl;
import com.google.android.material.badge.BadgeState$State;
import com.google.android.material.internal.ParcelableSparseBooleanArray;
import com.google.android.material.internal.ParcelableSparseIntArray;
import com.umeng.analytics.pro.dd;
import java.util.Locale;
import moe.heroman.eventtest.common.RingChannel;
import moe.shizuku.api.BinderContainer;
import moe.shizuku.server.IRemoteProcess;
import rikka.shizuku.ShizukuRemoteProcess;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class b implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f324a;

    public /* synthetic */ b(int i7) {
        this.f324a = i7;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f324a) {
            case 0:
                ResultReceiver resultReceiver = new ResultReceiver();
                resultReceiver.f322a = IResultReceiver.Stub.asInterface(parcel.readStrongBinder());
                return resultReceiver;
            case 1:
                return new ActivityResult(parcel);
            case 2:
                parcel.getClass();
                Parcelable parcelable = parcel.readParcelable(IntentSender.class.getClassLoader());
                parcelable.getClass();
                return new IntentSenderRequest((IntentSender) parcelable, (Intent) parcel.readParcelable(Intent.class.getClassLoader()), parcel.readInt(), parcel.readInt());
            case 3:
                int i7 = parcel.readInt();
                ParcelableSparseBooleanArray parcelableSparseBooleanArray = new ParcelableSparseBooleanArray(i7);
                int[] iArr = new int[i7];
                boolean[] zArr = new boolean[i7];
                parcel.readIntArray(iArr);
                parcel.readBooleanArray(zArr);
                for (int i8 = 0; i8 < i7; i8++) {
                    parcelableSparseBooleanArray.put(iArr[i8], zArr[i8]);
                }
                return parcelableSparseBooleanArray;
            case 4:
                int i9 = parcel.readInt();
                ParcelableSparseIntArray parcelableSparseIntArray = new ParcelableSparseIntArray(i9);
                int[] iArr2 = new int[i9];
                int[] iArr3 = new int[i9];
                parcel.readIntArray(iArr2);
                parcel.readIntArray(iArr3);
                for (int i10 = 0; i10 < i9; i10++) {
                    parcelableSparseIntArray.put(iArr2[i10], iArr3[i10]);
                }
                return parcelableSparseIntArray;
            case 5:
                BadgeState$State badgeState$State = new BadgeState$State();
                badgeState$State.f3011i = 255;
                badgeState$State.f3013k = -2;
                badgeState$State.f3014l = -2;
                badgeState$State.f3015m = -2;
                badgeState$State.f3022t = Boolean.TRUE;
                badgeState$State.f3005a = parcel.readInt();
                badgeState$State.b = (Integer) parcel.readSerializable();
                badgeState$State.f3006c = (Integer) parcel.readSerializable();
                badgeState$State.f3007d = (Integer) parcel.readSerializable();
                badgeState$State.e = (Integer) parcel.readSerializable();
                badgeState$State.f3008f = (Integer) parcel.readSerializable();
                badgeState$State.f3009g = (Integer) parcel.readSerializable();
                badgeState$State.f3010h = (Integer) parcel.readSerializable();
                badgeState$State.f3011i = parcel.readInt();
                badgeState$State.f3012j = parcel.readString();
                badgeState$State.f3013k = parcel.readInt();
                badgeState$State.f3014l = parcel.readInt();
                badgeState$State.f3015m = parcel.readInt();
                badgeState$State.f3017o = parcel.readString();
                badgeState$State.f3018p = parcel.readString();
                badgeState$State.f3019q = parcel.readInt();
                badgeState$State.f3021s = (Integer) parcel.readSerializable();
                badgeState$State.f3023u = (Integer) parcel.readSerializable();
                badgeState$State.f3024v = (Integer) parcel.readSerializable();
                badgeState$State.f3025w = (Integer) parcel.readSerializable();
                badgeState$State.f3026x = (Integer) parcel.readSerializable();
                badgeState$State.f3027y = (Integer) parcel.readSerializable();
                badgeState$State.f3028z = (Integer) parcel.readSerializable();
                badgeState$State.C = (Integer) parcel.readSerializable();
                badgeState$State.A = (Integer) parcel.readSerializable();
                badgeState$State.B = (Integer) parcel.readSerializable();
                badgeState$State.f3022t = (Boolean) parcel.readSerializable();
                badgeState$State.f3016n = (Locale) parcel.readSerializable();
                badgeState$State.D = (Boolean) parcel.readSerializable();
                return badgeState$State;
            case 6:
                return new RingChannel(parcel);
            case dd.f4082h /* 7 */:
                BinderContainer binderContainer = new BinderContainer();
                binderContainer.f6891a = parcel.readStrongBinder();
                return binderContainer;
            case 8:
                ShizukuRemoteProcess shizukuRemoteProcess = new ShizukuRemoteProcess();
                shizukuRemoteProcess.f7945a = IRemoteProcess.Stub.asInterface(parcel.readStrongBinder());
                return shizukuRemoteProcess;
            default:
                return new ParcelImpl(parcel);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i7) {
        switch (this.f324a) {
            case 0:
                return new ResultReceiver[i7];
            case 1:
                return new ActivityResult[i7];
            case 2:
                return new IntentSenderRequest[i7];
            case 3:
                return new ParcelableSparseBooleanArray[i7];
            case 4:
                return new ParcelableSparseIntArray[i7];
            case 5:
                return new BadgeState$State[i7];
            case 6:
                return new RingChannel[i7];
            case dd.f4082h /* 7 */:
                return new BinderContainer[i7];
            case 8:
                return new ShizukuRemoteProcess[i7];
            default:
                return new ParcelImpl[i7];
        }
    }
}
