package android.support.v4.app;

import android.app.Notification;
import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements INotificationSideChannel {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IBinder f321a;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f321a;
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public final void cancel(String str, int i7, String str2) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(INotificationSideChannel.DESCRIPTOR);
            parcelObtain.writeString(str);
            parcelObtain.writeInt(i7);
            parcelObtain.writeString(str2);
            this.f321a.transact(2, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public final void cancelAll(String str) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(INotificationSideChannel.DESCRIPTOR);
            parcelObtain.writeString(str);
            this.f321a.transact(3, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.support.v4.app.INotificationSideChannel
    public final void notify(String str, int i7, String str2, Notification notification) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(INotificationSideChannel.DESCRIPTOR);
            parcelObtain.writeString(str);
            parcelObtain.writeInt(i7);
            parcelObtain.writeString(str2);
            if (notification != null) {
                parcelObtain.writeInt(1);
                notification.writeToParcel(parcelObtain, 0);
            } else {
                parcelObtain.writeInt(0);
            }
            this.f321a.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
