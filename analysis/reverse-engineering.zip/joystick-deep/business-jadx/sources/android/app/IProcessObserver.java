package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import v.m.p;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public interface IProcessObserver extends IInterface {

    public static abstract class Stub extends Binder implements IProcessObserver {
        public static final String DESCRIPTOR = p.abcdstr(245);
        static final int TRANSACTION_onForegroundActivitiesChanged = 1;
        static final int TRANSACTION_onForegroundServicesChanged = 2;
        static final int TRANSACTION_onProcessDied = 3;
        static final int TRANSACTION_onProcessStarted = 4;
        static final int TRANSACTION_onProcessStateChanged = 5;

        public Stub() {
            attachInterface(this, p.abcdstr(245));
        }

        public static IProcessObserver asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(p.abcdstr(245));
            if (iInterfaceQueryLocalInterface != null && (iInterfaceQueryLocalInterface instanceof IProcessObserver)) {
                return (IProcessObserver) iInterfaceQueryLocalInterface;
            }
            a aVar = new a();
            aVar.f320a = iBinder;
            return aVar;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i7, Parcel parcel, Parcel parcel2, int i8) {
            if (i7 >= 1 && i7 <= 16777215) {
                parcel.enforceInterface("android.app.IProcessObserver");
            }
            if (i7 == 1598968902) {
                parcel2.writeString("android.app.IProcessObserver");
                return true;
            }
            if (i7 == 1) {
                onForegroundActivitiesChanged(parcel.readInt(), parcel.readInt(), parcel.readInt() != 0);
            } else if (i7 == 2) {
                onForegroundServicesChanged(parcel.readInt(), parcel.readInt(), parcel.readInt());
            } else if (i7 == 3) {
                onProcessDied(parcel.readInt(), parcel.readInt());
            } else if (i7 == 4) {
                onProcessStarted(parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readString(), parcel.readString());
            } else {
                if (i7 != 5) {
                    return super.onTransact(i7, parcel, parcel2, i8);
                }
                onProcessStateChanged(parcel.readInt(), parcel.readInt(), parcel.readInt());
            }
            return true;
        }
    }

    void onForegroundActivitiesChanged(int i7, int i8, boolean z6);

    void onForegroundServicesChanged(int i7, int i8, int i9);

    void onProcessDied(int i7, int i8);

    void onProcessStarted(int i7, int i8, int i9, String str, String str2);

    void onProcessStateChanged(int i7, int i8, int i9);
}
