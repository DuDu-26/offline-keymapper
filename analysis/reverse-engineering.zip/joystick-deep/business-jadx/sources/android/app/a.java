package android.app;

import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements IProcessObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IBinder f320a;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f320a;
    }

    @Override // android.app.IProcessObserver
    public final void onForegroundActivitiesChanged(int i7, int i8, boolean z6) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("android.app.IProcessObserver");
            parcelObtain.writeInt(i7);
            parcelObtain.writeInt(i8);
            parcelObtain.writeInt(z6 ? 1 : 0);
            this.f320a.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.app.IProcessObserver
    public final void onForegroundServicesChanged(int i7, int i8, int i9) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("android.app.IProcessObserver");
            parcelObtain.writeInt(i7);
            parcelObtain.writeInt(i8);
            parcelObtain.writeInt(i9);
            this.f320a.transact(2, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.app.IProcessObserver
    public final void onProcessDied(int i7, int i8) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("android.app.IProcessObserver");
            parcelObtain.writeInt(i7);
            parcelObtain.writeInt(i8);
            this.f320a.transact(3, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.app.IProcessObserver
    public final void onProcessStarted(int i7, int i8, int i9, String str, String str2) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("android.app.IProcessObserver");
            parcelObtain.writeInt(i7);
            parcelObtain.writeInt(i8);
            parcelObtain.writeInt(i9);
            parcelObtain.writeString(str);
            parcelObtain.writeString(str2);
            this.f320a.transact(4, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    @Override // android.app.IProcessObserver
    public final void onProcessStateChanged(int i7, int i8, int i9) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("android.app.IProcessObserver");
            parcelObtain.writeInt(i7);
            parcelObtain.writeInt(i8);
            parcelObtain.writeInt(i9);
            this.f320a.transact(5, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
