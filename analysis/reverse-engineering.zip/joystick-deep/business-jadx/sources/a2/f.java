package a2;

import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityNodeInfo;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class f {
    public static f b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f9a;

    public f() {
        this.f9a = new Object();
        new Handler(Looper.getMainLooper(), new e(this));
    }

    public static f a(boolean z6, int i7, int i8, int i9, int i10) {
        return new f(AccessibilityNodeInfo.CollectionItemInfo.obtain(i7, i8, i9, i10, false, z6));
    }

    public f(AccessibilityNodeInfo.CollectionItemInfo collectionItemInfo) {
        this.f9a = collectionItemInfo;
    }
}
