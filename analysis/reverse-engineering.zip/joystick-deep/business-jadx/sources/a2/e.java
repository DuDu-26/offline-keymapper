package a2;

import android.os.Handler;
import android.os.Message;
import androidx.appcompat.widget.f3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class e implements Handler.Callback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f f8a;

    public e(f fVar) {
        this.f8a = fVar;
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        if (message.what != 0) {
            return false;
        }
        f fVar = this.f8a;
        if (message.obj != null) {
            f3.b();
            return false;
        }
        synchronized (fVar.f9a) {
            throw null;
        }
    }
}
