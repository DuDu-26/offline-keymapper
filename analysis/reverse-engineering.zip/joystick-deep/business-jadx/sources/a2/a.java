package a2;

import android.os.Handler;
import android.os.Message;
import androidx.appcompat.widget.f3;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public final class a implements Handler.Callback {
    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i7 = message.what;
        if (i7 == 0) {
            message.obj.getClass();
            f3.b();
            return false;
        }
        if (i7 != 1) {
            return false;
        }
        message.obj.getClass();
        f3.b();
        return false;
    }
}
