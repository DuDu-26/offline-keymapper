package a2;

import android.os.Handler;
import android.os.Looper;
import android.view.animation.LinearInterpolator;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f7a = 0;

    static {
        LinearInterpolator linearInterpolator = f1.a.f5601a;
        new Handler(Looper.getMainLooper(), new a());
    }
}
