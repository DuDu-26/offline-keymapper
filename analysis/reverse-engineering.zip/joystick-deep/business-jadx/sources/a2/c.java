package a2;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.material.internal.l;
import f0.b0;
import f0.f0;
import f0.h0;
import f0.s0;
import java.util.WeakHashMap;
import y1.g;
import y1.k;

/* JADX INFO: loaded from: /Users/USER/Desktop/project/映射软件/research/joystick-deep/runtime/external-01/457095c52c1055aa7df539284a34975718a667ad7c812b3cc1e4938c60435fcf.dex */
public abstract class c extends FrameLayout {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final b f0i = new b();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f1a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f2c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f3d;
    public final int e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f4f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f5g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f6h;

    public c(Context context, AttributeSet attributeSet) {
        Drawable drawable;
        super(d2.a.a(context, attributeSet, 0, 0), attributeSet);
        Context context2 = getContext();
        TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, e1.a.C);
        if (typedArrayObtainStyledAttributes.hasValue(6)) {
            float dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(6, 0);
            WeakHashMap weakHashMap = s0.f5582a;
            h0.s(this, dimensionPixelSize);
        }
        this.b = typedArrayObtainStyledAttributes.getInt(2, 0);
        if (typedArrayObtainStyledAttributes.hasValue(8) || typedArrayObtainStyledAttributes.hasValue(9)) {
            this.f1a = k.b(context2, attributeSet, 0, 0).a();
        }
        this.f2c = typedArrayObtainStyledAttributes.getFloat(3, 1.0f);
        setBackgroundTintList(m4.f.n(context2, typedArrayObtainStyledAttributes, 4));
        setBackgroundTintMode(l.i(typedArrayObtainStyledAttributes.getInt(5, -1), PorterDuff.Mode.SRC_IN));
        this.f3d = typedArrayObtainStyledAttributes.getFloat(1, 1.0f);
        this.e = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1);
        this.f4f = typedArrayObtainStyledAttributes.getDimensionPixelSize(7, -1);
        typedArrayObtainStyledAttributes.recycle();
        setOnTouchListener(f0i);
        setFocusable(true);
        if (getBackground() == null) {
            int iA = m4.f.A(m4.f.m(this, 2130968864), getBackgroundOverlayColorAlpha(), m4.f.m(this, 2130968842));
            k kVar = this.f1a;
            if (kVar != null) {
                int i7 = d.f7a;
                g gVar = new g(kVar);
                gVar.k(ColorStateList.valueOf(iA));
                drawable = gVar;
            } else {
                Resources resources = getResources();
                int i8 = d.f7a;
                float dimension = resources.getDimension(2131165929);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setShape(0);
                gradientDrawable.setCornerRadius(dimension);
                gradientDrawable.setColor(iA);
                drawable = gradientDrawable;
            }
            ColorStateList colorStateList = this.f5g;
            if (colorStateList != null) {
                y.b.h(drawable, colorStateList);
            }
            WeakHashMap weakHashMap2 = s0.f5582a;
            b0.q(this, drawable);
        }
    }

    private void setBaseTransientBottomBar(d dVar) {
    }

    public float getActionTextColorAlpha() {
        return this.f3d;
    }

    public int getAnimationMode() {
        return this.b;
    }

    public float getBackgroundOverlayColorAlpha() {
        return this.f2c;
    }

    public int getMaxInlineActionWidth() {
        return this.f4f;
    }

    public int getMaxWidth() {
        return this.e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        WeakHashMap weakHashMap = s0.f5582a;
        f0.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i7, int i8, int i9, int i10) {
        super.onLayout(z6, i7, i8, i9, i10);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i7, int i8) {
        super.onMeasure(i7, i8);
        int i9 = this.e;
        if (i9 <= 0 || getMeasuredWidth() <= i9) {
            return;
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(i9, 1073741824), i8);
    }

    public void setAnimationMode(int i7) {
        this.b = i7;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable != null && this.f5g != null) {
            drawable = drawable.mutate();
            y.b.h(drawable, this.f5g);
            y.b.i(drawable, this.f6h);
        }
        super.setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        this.f5g = colorStateList;
        if (getBackground() != null) {
            Drawable drawableMutate = getBackground().mutate();
            y.b.h(drawableMutate, colorStateList);
            y.b.i(drawableMutate, this.f6h);
            if (drawableMutate != getBackground()) {
                super.setBackgroundDrawable(drawableMutate);
            }
        }
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        this.f6h = mode;
        if (getBackground() != null) {
            Drawable drawableMutate = getBackground().mutate();
            y.b.i(drawableMutate, mode);
            if (drawableMutate != getBackground()) {
                super.setBackgroundDrawable(drawableMutate);
            }
        }
    }

    @Override // android.view.View
    public void setLayoutParams(ViewGroup.LayoutParams layoutParams) {
        super.setLayoutParams(layoutParams);
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            new Rect(marginLayoutParams.leftMargin, marginLayoutParams.topMargin, marginLayoutParams.rightMargin, marginLayoutParams.bottomMargin);
        }
    }

    @Override // android.view.View
    public void setOnClickListener(View.OnClickListener onClickListener) {
        setOnTouchListener(onClickListener != null ? null : f0i);
        super.setOnClickListener(onClickListener);
    }
}
