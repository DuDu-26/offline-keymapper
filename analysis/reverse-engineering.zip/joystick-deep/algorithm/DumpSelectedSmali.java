import java.nio.file.*;
import java.io.*;
import java.util.*;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.baksmali.BaksmaliOptions;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

/** Offline parser only. It never loads or executes target DEX classes. */
public class DumpSelectedSmali {
    public static void main(String[] args) throws Exception {
        DexBackedDexFile dex = new DexBackedDexFile(Files.readAllBytes(Path.of(args[0])), 0);
        Set<String> wanted = new HashSet<>(Arrays.asList("Lr3/a;", "Lr3/d;", "Lr3/e;", "Landroidx/activity/g;", "Landroidx/activity/h;", "Ln/e;"));
        BaksmaliOptions options = new BaksmaliOptions();
        options.debugInfo = false; options.localsDirective = true; options.sequentialLabels = false;
        Files.createDirectories(Path.of(args[1]));
        for (int i = 0; i < dex.classCount; i++) {
            ClassDef definition = (ClassDef) dex.classSection.get(i);
            if (!wanted.contains(definition.getType())) continue;
            Path file = Path.of(args[1], definition.getType().substring(1, definition.getType().length()-1).replace('/', '.') + ".smali");
            try (Writer output = Files.newBufferedWriter(file)) {
                new ClassDefinition(options, definition).writeTo(new BaksmaliWriter(output));
            }
            System.out.println(file);
        }
    }
}
