.class public final Landroidx/activity/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:I

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/graphics/Point;Landroid/graphics/Point;I)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, Landroidx/activity/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    new-instance p1, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    iget p2, p2, Landroid/graphics/Point;->y:I

    invoke-direct {p1, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    iput-object p1, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    iput p3, p0, Landroidx/activity/h;->b:I

    return-void
.end method

.method public constructor <init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Landroidx/activity/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    iput p3, p0, Landroidx/activity/h;->b:I

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/activity/i;ILjava/lang/Object;I)V
    .locals 0

    iput p4, p0, Landroidx/activity/h;->a:I

    iput-object p1, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    iput p2, p0, Landroidx/activity/h;->b:I

    iput-object p3, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Landroid/view/View;I)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, Landroidx/activity/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    iput p3, p0, Landroidx/activity/h;->b:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Landroidx/activity/h;->a:I

    packed-switch v0, :pswitch_data_b2

    iget-object v0, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v0, Landroid/graphics/Point;

    monitor-enter v0

    :try_start_a
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v1

    if-eqz v1, :cond_18

    monitor-exit v0

    goto :goto_32

    :catchall_16
    move-exception v1

    goto :goto_33

    :cond_18
    iget-object v1, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/Point;

    iget-object v2, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    check-cast v2, Landroid/graphics/Point;

    iget v3, v2, Landroid/graphics/Point;->x:I

    iput v3, v1, Landroid/graphics/Point;->x:I

    iget v3, v2, Landroid/graphics/Point;->y:I

    iput v3, v1, Landroid/graphics/Point;->y:I

    iget v1, p0, Landroidx/activity/h;->b:I

    iget v3, v2, Landroid/graphics/Point;->x:I

    iget v2, v2, Landroid/graphics/Point;->y:I

    invoke-static {v1, v3, v2}, Lmoe/heroman/eventtest/auth/NativeAuth;->E0(III)V

    monitor-exit v0

    :goto_32
    return-void

    :goto_33
    monitor-exit v0
    :try_end_34
    .catchall {:try_start_a .. :try_end_34} :catchall_16

    throw v1

    :pswitch_35
    iget-object v0, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget-object v1, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v1, Landroid/view/View;

    iget v2, p0, Landroidx/activity/h;->b:I

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E(Landroid/view/View;IZ)V

    return-void

    :pswitch_44
    iget-object v0, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/Typeface;

    iget v2, p0, Landroidx/activity/h;->b:I

    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    return-void

    :pswitch_52
    iget-object v0, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/i;

    iget v1, p0, Landroidx/activity/h;->b:I

    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    const-string v3, "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const-string v3, "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION"

    iget-object v4, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v4, Landroid/content/IntentSender$SendIntentException;

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Landroidx/activity/result/f;->a(IILandroid/content/Intent;)Z

    return-void

    :pswitch_72
    iget-object v0, p0, Landroidx/activity/h;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/i;

    iget v1, p0, Landroidx/activity/h;->b:I

    iget-object v2, p0, Landroidx/activity/h;->d:Ljava/lang/Object;

    check-cast v2, Lw3/e;

    iget-object v2, v2, Lw3/e;->b:Ljava/lang/Object;

    check-cast v2, Ljava/io/Serializable;

    iget-object v3, v0, Landroidx/activity/result/f;->a:Ljava/util/HashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_8f

    goto :goto_b1

    :cond_8f
    iget-object v3, v0, Landroidx/activity/result/f;->e:Ljava/util/HashMap;

    invoke-virtual {v3, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/activity/result/d;

    if-eqz v3, :cond_a7

    iget-object v3, v3, Landroidx/activity/result/d;->a:Landroidx/activity/result/a;

    iget-object v0, v0, Landroidx/activity/result/f;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b1

    invoke-interface {v3, v2}, Landroidx/activity/result/a;->c(Ljava/lang/Object;)V

    goto :goto_b1

    :cond_a7
    iget-object v3, v0, Landroidx/activity/result/f;->g:Landroid/os/Bundle;

    invoke-virtual {v3, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    iget-object v0, v0, Landroidx/activity/result/f;->f:Ljava/util/HashMap;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b1
    :goto_b1
    return-void

    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_72
        :pswitch_52
        :pswitch_44
        :pswitch_35
    .end packed-switch
.end method
