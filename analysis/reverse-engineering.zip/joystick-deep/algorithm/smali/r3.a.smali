.class public final Lr3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr3/b;


# static fields
.field public static final a:F


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    div-double/2addr v2, v0

    double-to-float v0, v2

    sput v0, Lr3/a;->a:F

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Point;Landroid/graphics/Point;FII)Ljava/lang/Runnable;
    .locals 2

    invoke-static {p4}, Ln/e;->d(I)I

    move-result p4

    sget v0, Lr3/a;->a:F

    packed-switch p4, :pswitch_data_82

    new-instance p3, Landroid/graphics/Point;

    iget p4, p2, Landroid/graphics/Point;->x:I

    iget p2, p2, Landroid/graphics/Point;->y:I

    invoke-direct {p3, p4, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_7c

    :pswitch_13
    new-instance p4, Landroid/graphics/Point;

    iget v1, p2, Landroid/graphics/Point;->x:I

    mul-float/2addr p3, v0

    float-to-int p3, p3

    sub-int/2addr v1, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    sub-int/2addr p2, p3

    invoke-direct {p4, v1, p2}, Landroid/graphics/Point;-><init>(II)V

    :goto_20
    move-object p3, p4

    goto :goto_7c

    :pswitch_22
    new-instance p4, Landroid/graphics/Point;

    iget v1, p2, Landroid/graphics/Point;->x:I

    mul-float/2addr p3, v0

    float-to-int p3, p3

    sub-int/2addr v1, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    add-int/2addr p2, p3

    invoke-direct {p4, v1, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_30
    new-instance p4, Landroid/graphics/Point;

    iget v1, p2, Landroid/graphics/Point;->x:I

    mul-float/2addr p3, v0

    float-to-int p3, p3

    add-int/2addr v1, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    add-int/2addr p2, p3

    invoke-direct {p4, v1, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_3e
    new-instance p4, Landroid/graphics/Point;

    iget v1, p2, Landroid/graphics/Point;->x:I

    mul-float/2addr p3, v0

    float-to-int p3, p3

    add-int/2addr v1, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    sub-int/2addr p2, p3

    invoke-direct {p4, v1, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_4c
    new-instance p4, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    float-to-int p3, p3

    sub-int/2addr v0, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    invoke-direct {p4, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_58
    new-instance p4, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    float-to-int p3, p3

    add-int/2addr v0, p3

    iget p2, p2, Landroid/graphics/Point;->y:I

    invoke-direct {p4, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_64
    new-instance p4, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    iget p2, p2, Landroid/graphics/Point;->y:I

    float-to-int p3, p3

    add-int/2addr p2, p3

    invoke-direct {p4, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :pswitch_70
    new-instance p4, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    iget p2, p2, Landroid/graphics/Point;->y:I

    float-to-int p3, p3

    sub-int/2addr p2, p3

    invoke-direct {p4, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_20

    :goto_7c
    new-instance p2, Landroidx/activity/h;

    invoke-direct {p2, p1, p3, p5}, Landroidx/activity/h;-><init>(Landroid/graphics/Point;Landroid/graphics/Point;I)V

    return-object p2

    :pswitch_data_82
    .packed-switch 0x0
        :pswitch_70
        :pswitch_64
        :pswitch_58
        :pswitch_4c
        :pswitch_3e
        :pswitch_30
        :pswitch_22
        :pswitch_13
    .end packed-switch
.end method

.method public final b(Landroid/graphics/Point;Landroid/graphics/Point;)I
    .locals 2

    iget v0, p1, Landroid/graphics/Point;->x:I

    iget v1, p1, Landroid/graphics/Point;->y:I

    invoke-static {v0, v1}, Lmoe/heroman/eventtest/auth/NativeAuth;->B0(II)I

    move-result v0

    iget v1, p1, Landroid/graphics/Point;->x:I

    iput v1, p2, Landroid/graphics/Point;->x:I

    iget p1, p1, Landroid/graphics/Point;->y:I

    iput p1, p2, Landroid/graphics/Point;->y:I

    return v0
.end method
