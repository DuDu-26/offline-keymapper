.class public final Lr3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr3/b;


# instance fields
.field public final a:Ljava/util/Random;

.field public final b:I

.field public final c:I

.field public final d:D

.field public final e:D

.field public final f:Z

.field public final g:Z


# direct methods
.method public constructor <init>(IZ)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    iput-object v0, p0, Lr3/d;->a:Ljava/util/Random;

    iput-boolean p2, p0, Lr3/d;->g:Z

    const/4 p2, 0x1

    if-eq p1, p2, :cond_41

    const/4 p2, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eq p1, p2, :cond_2b

    iput v1, p0, Lr3/d;->b:I

    const/16 p1, 0xc

    iput p1, p0, Lr3/d;->c:I

    const-wide p1, 0x3ffccccccccccccdL    # 1.8

    iput-wide p1, p0, Lr3/d;->d:D

    const-wide p1, 0x3fd6666666666666L    # 0.35

    iput-wide p1, p0, Lr3/d;->e:D

    iput-boolean v0, p0, Lr3/d;->f:Z

    return-void

    :cond_2b
    const/4 p1, 0x3

    iput p1, p0, Lr3/d;->b:I

    iput v1, p0, Lr3/d;->c:I

    const-wide p1, 0x3ff6666666666666L    # 1.4

    iput-wide p1, p0, Lr3/d;->d:D

    const-wide p1, 0x3fc70a3d70a3d70aL    # 0.18

    iput-wide p1, p0, Lr3/d;->e:D

    iput-boolean v0, p0, Lr3/d;->f:Z

    return-void

    :cond_41
    const/16 p1, 0xa

    iput p1, p0, Lr3/d;->b:I

    const/16 p1, 0xf

    iput p1, p0, Lr3/d;->c:I

    const-wide v0, 0x400199999999999aL    # 2.2

    iput-wide v0, p0, Lr3/d;->d:D

    const-wide v0, 0x3fe3333333333333L    # 0.6

    iput-wide v0, p0, Lr3/d;->e:D

    iput-boolean p2, p0, Lr3/d;->f:Z

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Point;Landroid/graphics/Point;FII)Ljava/lang/Runnable;
    .locals 30

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    invoke-static/range {p4 .. p4}, Ln/e;->d(I)I

    move-result v3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v3, :cond_45

    if-eq v3, v5, :cond_3f

    const/4 v6, 0x3

    if-eq v3, v6, :cond_39

    if-eq v3, v4, :cond_33

    const/4 v6, 0x5

    if-eq v3, v6, :cond_2d

    const/4 v6, 0x6

    if-eq v3, v6, :cond_27

    const/4 v6, 0x7

    if-eq v3, v6, :cond_21

    const-wide/16 v6, 0x0

    goto :goto_4a

    :cond_21
    const-wide v6, 0x4002d97c7f3321d2L    # 2.356194490192345

    goto :goto_4a

    :cond_27
    const-wide v6, -0x3ffd268380ccde2eL    # -2.356194490192345

    goto :goto_4a

    :cond_2d
    const-wide v6, -0x4016de04abbbd2e8L    # -0.7853981633974483

    goto :goto_4a

    :cond_33
    const-wide v6, 0x3fe921fb54442d18L    # 0.7853981633974483

    goto :goto_4a

    :cond_39
    const-wide v6, 0x400921fb54442d18L    # Math.PI

    goto :goto_4a

    :cond_3f
    const-wide v6, -0x4006de04abbbd2e8L    # -1.5707963267948966

    goto :goto_4a

    :cond_45
    const-wide v6, 0x3ff921fb54442d18L    # 1.5707963267948966

    :goto_4a
    iget v3, v0, Lr3/d;->c:I

    mul-int/lit8 v8, v3, 0x2

    add-int/2addr v8, v5

    iget-object v5, v0, Lr3/d;->a:Ljava/util/Random;

    invoke-virtual {v5, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v8

    sub-int/2addr v8, v3

    int-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v8

    add-double/2addr v8, v6

    invoke-virtual {v5}, Ljava/util/Random;->nextDouble()D

    move-result-wide v10

    iget-wide v12, v0, Lr3/d;->d:D

    const-wide/high16 v14, 0x3ff0000000000000L    # 1.0

    sub-double/2addr v12, v14

    mul-double/2addr v12, v10

    add-double/2addr v12, v14

    float-to-double v10, v2

    mul-double v16, v10, v12

    iget v3, v1, Landroid/graphics/Point;->x:I

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v18

    move-wide/from16 v20, v14

    mul-double v14, v18, v16

    double-to-int v14, v14

    add-int/2addr v3, v14

    iget v14, v1, Landroid/graphics/Point;->y:I

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    mul-double v8, v8, v16

    double-to-int v8, v8

    sub-int/2addr v14, v8

    iget v8, v0, Lr3/d;->b:I

    mul-int/lit8 v9, v8, 0x2

    invoke-virtual {v5, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v15

    sub-int/2addr v15, v8

    invoke-virtual {v5, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v9

    sub-int/2addr v9, v8

    new-instance v8, Landroid/graphics/Point;

    add-int/2addr v3, v15

    add-int/2addr v14, v9

    invoke-direct {v8, v3, v14}, Landroid/graphics/Point;-><init>(II)V

    iget-wide v14, v0, Lr3/d;->e:D

    mul-double/2addr v14, v10

    sub-double v12, v12, v20

    mul-double/2addr v12, v10

    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->max(DD)D

    move-result-wide v12

    double-to-float v3, v12

    iget-boolean v9, v0, Lr3/d;->g:Z

    if-nez v9, :cond_ba

    new-instance v22, Lr3/e;

    const/16 v27, 0x0

    const/16 v28, 0x0

    iget-boolean v1, v0, Lr3/d;->f:Z

    move-object/from16 v23, p1

    move/from16 v25, p5

    move/from16 v29, v1

    move/from16 v26, v3

    move-object/from16 v24, v8

    invoke-direct/range {v22 .. v29}, Lr3/e;-><init>(Landroid/graphics/Point;Landroid/graphics/Point;IFLandroid/graphics/Point;FZ)V

    return-object v22

    :cond_ba
    move/from16 v26, v3

    move-object/from16 v24, v8

    const/16 v3, 0x9

    invoke-virtual {v5, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    sub-int/2addr v3, v4

    int-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v3

    add-double/2addr v3, v6

    invoke-virtual {v5}, Ljava/util/Random;->nextDouble()D

    move-result-wide v6

    const-wide v8, 0x3fb1eb851eb851ecL    # 0.07

    mul-double/2addr v6, v8

    const-wide v8, 0x3fee666666666666L    # 0.95

    add-double/2addr v6, v8

    mul-double/2addr v6, v10

    iget v8, v1, Landroid/graphics/Point;->x:I

    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    move-result-wide v9

    mul-double/2addr v9, v6

    double-to-int v9, v9

    add-int/2addr v8, v9

    iget v1, v1, Landroid/graphics/Point;->y:I

    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    mul-double/2addr v3, v6

    double-to-int v3, v3

    sub-int/2addr v1, v3

    new-instance v3, Landroid/graphics/Point;

    invoke-direct {v3, v8, v1}, Landroid/graphics/Point;-><init>(II)V

    const v1, 0x3e19999a    # 0.15f

    invoke-static {v5, v1, v1, v2}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v28

    new-instance v22, Lr3/e;

    iget-boolean v1, v0, Lr3/d;->f:Z

    move-object/from16 v23, p1

    move/from16 v25, p5

    move/from16 v29, v1

    move-object/from16 v27, v3

    invoke-direct/range {v22 .. v29}, Lr3/e;-><init>(Landroid/graphics/Point;Landroid/graphics/Point;IFLandroid/graphics/Point;FZ)V

    return-object v22
.end method

.method public final b(Landroid/graphics/Point;Landroid/graphics/Point;)I
    .locals 2

    iget v0, p1, Landroid/graphics/Point;->x:I

    iget p1, p1, Landroid/graphics/Point;->y:I

    const/16 v1, 0x1e

    invoke-static {v0, p1, v1, v1}, Lmoe/heroman/eventtest/auth/NativeAuth;->D0(IIII)[I

    move-result-object p1

    const/4 v0, 0x1

    aget v0, p1, v0

    const/4 v1, 0x2

    aget v1, p1, v1

    invoke-virtual {p2, v0, v1}, Landroid/graphics/Point;->set(II)V

    const/4 p2, 0x0

    aget p1, p1, p2

    return p1
.end method
