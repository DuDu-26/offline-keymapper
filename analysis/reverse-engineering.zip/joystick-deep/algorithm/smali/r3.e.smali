.class public final Lr3/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final a:Landroid/graphics/Point;

.field public final b:Landroid/graphics/Point;

.field public final c:I

.field public final d:Ljava/util/Random;

.field public final e:I

.field public final f:I

.field public final g:F

.field public final h:Landroid/graphics/Point;

.field public final i:F

.field public final j:Z

.field public final k:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/graphics/Point;Landroid/graphics/Point;IFLandroid/graphics/Point;FZ)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lr3/e;->a:Landroid/graphics/Point;

    new-instance p1, Landroid/graphics/Point;

    iget v0, p2, Landroid/graphics/Point;->x:I

    iget p2, p2, Landroid/graphics/Point;->y:I

    invoke-direct {p1, v0, p2}, Landroid/graphics/Point;-><init>(II)V

    iput-object p1, p0, Lr3/e;->b:Landroid/graphics/Point;

    iput p3, p0, Lr3/e;->c:I

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    iput-object p1, p0, Lr3/e;->d:Ljava/util/Random;

    const/16 p2, 0xd

    invoke-virtual {p1, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p2

    add-int/lit8 p2, p2, 0x21

    iput p2, p0, Lr3/e;->e:I

    const/16 p2, 0x10

    invoke-virtual {p1, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/lit8 p1, p1, 0xf

    iput p1, p0, Lr3/e;->f:I

    iput p4, p0, Lr3/e;->g:F

    if-eqz p5, :cond_3b

    new-instance p1, Landroid/graphics/Point;

    iget p2, p5, Landroid/graphics/Point;->x:I

    iget p3, p5, Landroid/graphics/Point;->y:I

    invoke-direct {p1, p2, p3}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_3c

    :cond_3b
    const/4 p1, 0x0

    :goto_3c
    iput-object p1, p0, Lr3/e;->h:Landroid/graphics/Point;

    iput p6, p0, Lr3/e;->i:F

    iput-boolean p7, p0, Lr3/e;->j:Z

    invoke-static {}, Lg/d;->C()Lg/d;

    move-result-object p1

    invoke-virtual {p1}, Lg/d;->t()Landroid/util/Size;

    move-result-object p1

    new-instance p2, Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result p3

    const/16 p4, 0xa

    sub-int/2addr p3, p4

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result p1

    sub-int/2addr p1, p4

    invoke-direct {p2, p4, p4, p3, p1}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object p2, p0, Lr3/e;->k:Landroid/graphics/Rect;

    return-void
.end method

.method public static a(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;
    .locals 7

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float/2addr v0, p0

    mul-float v1, p0, p0

    mul-float v2, v0, v0

    mul-float v3, v2, v0

    mul-float v4, v1, p0

    iget v5, p1, Landroid/graphics/PointF;->x:F

    mul-float/2addr v5, v3

    const/high16 v6, 0x40400000    # 3.0f

    mul-float/2addr v2, v6

    mul-float/2addr v2, p0

    iget p0, p2, Landroid/graphics/PointF;->x:F

    mul-float/2addr p0, v2

    add-float/2addr p0, v5

    mul-float/2addr v0, v6

    mul-float/2addr v0, v1

    iget v1, p3, Landroid/graphics/PointF;->x:F

    mul-float/2addr v1, v0

    add-float/2addr v1, p0

    iget p0, p4, Landroid/graphics/PointF;->x:F

    mul-float/2addr p0, v4

    add-float/2addr p0, v1

    iget p1, p1, Landroid/graphics/PointF;->y:F

    mul-float/2addr v3, p1

    iget p1, p2, Landroid/graphics/PointF;->y:F

    mul-float/2addr v2, p1

    add-float/2addr v2, v3

    iget p1, p3, Landroid/graphics/PointF;->y:F

    mul-float/2addr v0, p1

    add-float/2addr v0, v2

    iget p1, p4, Landroid/graphics/PointF;->y:F

    mul-float/2addr v4, p1

    add-float/2addr v4, v0

    new-instance p1, Landroid/graphics/PointF;

    invoke-direct {p1, p0, v4}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p1
.end method

.method public static b(II)[I
    .locals 8

    new-array v0, p1, [I

    div-int v1, p0, p1

    rem-int/2addr p0, p1

    const/4 v2, 0x0

    if-nez p0, :cond_f

    :goto_8
    if-ge v2, p1, :cond_3f

    aput v1, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_f
    int-to-float v3, p1

    int-to-float v4, p0

    div-float/2addr v3, v4

    const/4 v4, 0x0

    move v5, v4

    move v4, v2

    :goto_15
    if-ge v2, p1, :cond_2f

    aput v1, v0, v2

    const/high16 v6, 0x3f800000    # 1.0f

    div-float v7, v6, v3

    add-float/2addr v7, v5

    cmpl-float v5, v7, v6

    if-ltz v5, :cond_2b

    if-ge v4, p0, :cond_2b

    add-int/lit8 v5, v1, 0x1

    aput v5, v0, v2

    sub-float/2addr v7, v6

    add-int/lit8 v4, v4, 0x1

    :cond_2b
    move v5, v7

    add-int/lit8 v2, v2, 0x1

    goto :goto_15

    :cond_2f
    :goto_2f
    if-ge v4, p0, :cond_3f

    add-int/lit8 v1, p1, -0x1

    sub-int v2, p0, v4

    sub-int/2addr v1, v2

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    add-int/lit8 v4, v4, 0x1

    goto :goto_2f

    :cond_3f
    return-object v0
.end method

.method public static c(F)F
    .locals 2

    const/high16 v0, 0x3f000000    # 0.5f

    cmpg-float v0, p0, v0

    if-gez v0, :cond_c

    const/high16 v0, 0x40800000    # 4.0f

    mul-float/2addr v0, p0

    mul-float/2addr v0, p0

    mul-float/2addr v0, p0

    return v0

    :cond_c
    const/high16 v0, 0x40000000    # 2.0f

    mul-float/2addr p0, v0

    sub-float/2addr p0, v0

    mul-float v1, p0, p0

    mul-float/2addr v1, p0

    div-float/2addr v1, v0

    const/high16 p0, 0x3f800000    # 1.0f

    add-float/2addr v1, p0

    return v1
.end method

.method public static d(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;
    .locals 9

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float/2addr v0, p0

    mul-float v1, p0, p0

    mul-float v2, v0, v0

    mul-float v3, v2, v0

    mul-float v4, v1, p0

    mul-float v5, v3, v0

    mul-float v6, v4, p0

    iget v7, p1, Landroid/graphics/PointF;->x:F

    mul-float/2addr v7, v5

    const/high16 v8, 0x40800000    # 4.0f

    mul-float/2addr v3, v8

    mul-float/2addr v3, p0

    iget p0, p2, Landroid/graphics/PointF;->x:F

    mul-float/2addr p0, v3

    add-float/2addr p0, v7

    const/high16 v7, 0x40c00000    # 6.0f

    mul-float/2addr v2, v7

    mul-float/2addr v2, v1

    iget v1, p3, Landroid/graphics/PointF;->x:F

    mul-float/2addr v1, v2

    add-float/2addr v1, p0

    mul-float/2addr v0, v8

    mul-float/2addr v0, v4

    iget p0, p4, Landroid/graphics/PointF;->x:F

    mul-float/2addr p0, v0

    add-float/2addr p0, v1

    iget v1, p5, Landroid/graphics/PointF;->x:F

    mul-float/2addr v1, v6

    add-float/2addr v1, p0

    iget p0, p1, Landroid/graphics/PointF;->y:F

    mul-float/2addr v5, p0

    iget p0, p2, Landroid/graphics/PointF;->y:F

    mul-float/2addr v3, p0

    add-float/2addr v3, v5

    iget p0, p3, Landroid/graphics/PointF;->y:F

    mul-float/2addr v2, p0

    add-float/2addr v2, v3

    iget p0, p4, Landroid/graphics/PointF;->y:F

    mul-float/2addr v0, p0

    add-float/2addr v0, v2

    iget p0, p5, Landroid/graphics/PointF;->y:F

    mul-float/2addr v6, p0

    add-float/2addr v6, v0

    new-instance p0, Landroid/graphics/PointF;

    invoke-direct {p0, v1, v6}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p0
.end method


# virtual methods
.method public final e(II)Z
    .locals 2

    iget-object v0, p0, Lr3/e;->a:Landroid/graphics/Point;

    monitor-enter v0

    :try_start_3
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v1

    if-eqz v1, :cond_12

    const/4 p1, 0x0

    monitor-exit v0

    return p1

    :catchall_10
    move-exception p1

    goto :goto_20

    :cond_12
    iget-object v1, p0, Lr3/e;->a:Landroid/graphics/Point;

    iput p1, v1, Landroid/graphics/Point;->x:I

    iput p2, v1, Landroid/graphics/Point;->y:I

    iget v1, p0, Lr3/e;->c:I

    invoke-static {v1, p1, p2}, Lmoe/heroman/eventtest/auth/NativeAuth;->E0(III)V

    const/4 p1, 0x1

    monitor-exit v0

    return p1

    :goto_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_3 .. :try_end_21} :catchall_10

    throw p1
.end method

.method public final run()V
    .locals 42

    move-object/from16 v1, p0

    iget v0, v1, Lr3/e;->f:I

    iget-object v2, v1, Lr3/e;->k:Landroid/graphics/Rect;

    iget-object v3, v1, Lr3/e;->d:Ljava/util/Random;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Landroid/graphics/PointF;

    iget-object v5, v1, Lr3/e;->a:Landroid/graphics/Point;

    iget v7, v5, Landroid/graphics/Point;->x:I

    int-to-float v7, v7

    iget v5, v5, Landroid/graphics/Point;->y:I

    int-to-float v5, v5

    invoke-direct {v6, v7, v5}, Landroid/graphics/PointF;-><init>(FF)V

    new-instance v10, Landroid/graphics/PointF;

    iget-object v5, v1, Lr3/e;->b:Landroid/graphics/Point;

    iget v7, v5, Landroid/graphics/Point;->x:I

    int-to-float v7, v7

    iget v5, v5, Landroid/graphics/Point;->y:I

    int-to-float v5, v5

    invoke-direct {v10, v7, v5}, Landroid/graphics/PointF;-><init>(FF)V

    iget v5, v10, Landroid/graphics/PointF;->x:F

    iget v7, v6, Landroid/graphics/PointF;->x:F

    sub-float/2addr v5, v7

    iget v7, v10, Landroid/graphics/PointF;->y:F

    iget v8, v6, Landroid/graphics/PointF;->y:F

    sub-float/2addr v7, v8

    mul-float v8, v5, v5

    mul-float v9, v7, v7

    add-float/2addr v9, v8

    float-to-double v8, v9

    invoke-static {v8, v9}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v8

    double-to-float v8, v8

    iget-boolean v9, v1, Lr3/e;->j:Z

    iget v11, v1, Lr3/e;->g:F

    const v12, 0x3f666666    # 0.9f

    const v13, 0x3f4ccccd    # 0.8f

    const v14, 0x3ecccccd    # 0.4f

    const v15, 0x3f19999a    # 0.6f

    if-eqz v9, :cond_55

    invoke-static {v3, v15, v12, v11}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v16

    :goto_52
    move/from16 v17, v15

    goto :goto_5a

    :cond_55
    invoke-static {v3, v14, v13, v11}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v16

    goto :goto_52

    :goto_5a
    const/high16 v15, 0x40000000    # 2.0f

    mul-float v18, v11, v15

    cmpg-float v19, v8, v18

    move/from16 v20, v15

    const/high16 v15, 0x3f000000    # 0.5f

    if-gez v19, :cond_6e

    div-float v12, v8, v18

    invoke-static {v15, v12}, Ljava/lang/Math;->max(FF)F

    move-result v12

    mul-float v16, v16, v12

    :cond_6e
    move/from16 v12, v16

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v16

    const v22, 0x3e19999a    # 0.15f

    if-eqz v9, :cond_7d

    const v23, 0x3e99999a    # 0.3f

    goto :goto_7f

    :cond_7d
    move/from16 v23, v22

    :goto_7f
    cmpg-float v23, v16, v23

    const v24, 0x3e99999a    # 0.3f

    const/high16 v27, 0x3e800000    # 0.25f

    const/16 v29, 0x0

    const v31, -0x4036f025

    const v34, 0x3f333333    # 0.7f

    const v35, 0x3fc90fdb

    if-gez v23, :cond_1dc

    cmpl-float v18, v8, v18

    if-lez v18, :cond_1dc

    invoke-virtual {v3}, Ljava/util/Random;->nextBoolean()Z

    move-result v5

    if-eqz v9, :cond_aa

    const v7, 0x3fe66666    # 1.8f

    mul-float/2addr v12, v7

    const v7, 0x3f59999a    # 0.85f

    mul-float/2addr v8, v7

    invoke-static {v12, v8}, Ljava/lang/Math;->min(FF)F

    move-result v7

    goto :goto_b3

    :cond_aa
    const/high16 v7, 0x3fc00000    # 1.5f

    mul-float/2addr v12, v7

    mul-float v8, v8, v34

    invoke-static {v12, v8}, Ljava/lang/Math;->min(FF)F

    move-result v7

    :goto_b3
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    new-instance v8, Landroid/graphics/PointF;

    iget v12, v6, Landroid/graphics/PointF;->x:F

    iget v13, v10, Landroid/graphics/PointF;->x:F

    add-float/2addr v12, v13

    div-float v12, v12, v20

    iget v13, v6, Landroid/graphics/PointF;->y:F

    iget v14, v10, Landroid/graphics/PointF;->y:F

    add-float/2addr v13, v14

    div-float v13, v13, v20

    invoke-direct {v8, v12, v13}, Landroid/graphics/PointF;-><init>(FF)V

    iget v12, v10, Landroid/graphics/PointF;->y:F

    iget v13, v6, Landroid/graphics/PointF;->y:F

    sub-float/2addr v12, v13

    float-to-double v12, v12

    iget v14, v10, Landroid/graphics/PointF;->x:F

    iget v15, v6, Landroid/graphics/PointF;->x:F

    sub-float/2addr v14, v15

    float-to-double v14, v14

    invoke-static {v12, v13, v14, v15}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v12

    double-to-float v12, v12

    if-eqz v9, :cond_ec

    const v13, 0x40490fdb    # (float)Math.PI

    const v14, 0x3f99999a    # 1.2f

    const v15, 0x3f4ccccd    # 0.8f

    invoke-static {v3, v15, v14, v13}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    goto :goto_f7

    :cond_ec
    const v13, 0x40490fdb    # (float)Math.PI

    const/high16 v14, 0x3f800000    # 1.0f

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-static {v3, v15, v14, v13}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    :goto_f7
    move/from16 v14, v29

    :goto_f9
    const/4 v15, 0x5

    if-ge v14, v15, :cond_157

    int-to-float v15, v14

    move/from16 v16, v5

    move-object/from16 v23, v6

    const/4 v5, 0x4

    int-to-float v6, v5

    div-float/2addr v15, v6

    sub-float v5, v12, v35

    if-eqz v16, :cond_10b

    neg-float v6, v13

    mul-float/2addr v6, v15

    goto :goto_10d

    :cond_10b
    mul-float v6, v13, v15

    :goto_10d
    add-float/2addr v5, v6

    if-eqz v9, :cond_11b

    const v6, 0x3ecccccd    # 0.4f

    const v15, 0x3f4ccccd    # 0.8f

    invoke-static {v3, v6, v15, v7}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v37

    goto :goto_125

    :cond_11b
    const v6, 0x3f666666    # 0.9f

    const v15, 0x3e4ccccd    # 0.2f

    invoke-static {v3, v15, v6, v7}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v37

    :goto_125
    new-instance v6, Landroid/graphics/PointF;

    iget v15, v8, Landroid/graphics/PointF;->x:F

    move/from16 v39, v9

    move-object/from16 v38, v10

    float-to-double v9, v5

    move-wide/from16 v40, v9

    invoke-static/range {v40 .. v41}, Ljava/lang/Math;->cos(D)D

    move-result-wide v9

    double-to-float v5, v9

    mul-float v5, v5, v37

    add-float/2addr v5, v15

    iget v9, v8, Landroid/graphics/PointF;->y:F

    move v10, v7

    move-object v15, v8

    invoke-static/range {v40 .. v41}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float v7, v7, v37

    add-float/2addr v7, v9

    invoke-direct {v6, v5, v7}, Landroid/graphics/PointF;-><init>(FF)V

    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v14, v14, 0x1

    move v7, v10

    move-object v8, v15

    move/from16 v5, v16

    move-object/from16 v6, v23

    move-object/from16 v10, v38

    move/from16 v9, v39

    goto :goto_f9

    :cond_157
    const/4 v3, 0x1

    :goto_158
    move-object/from16 v23, v6

    move-object/from16 v38, v10

    if-gt v3, v0, :cond_1d8

    int-to-float v5, v3

    int-to-float v6, v0

    div-float/2addr v5, v6

    invoke-static {v5}, Lr3/e;->c(F)F

    move-result v5

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v15, 0x5

    if-lt v6, v15, :cond_18c

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    check-cast v7, Landroid/graphics/PointF;

    const/4 v13, 0x2

    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v8, v6

    check-cast v8, Landroid/graphics/PointF;

    const/4 v6, 0x3

    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/graphics/PointF;

    move-object/from16 v6, v23

    move-object/from16 v10, v38

    invoke-static/range {v5 .. v10}, Lr3/e;->d(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v5

    goto :goto_1a7

    :cond_18c
    move-object/from16 v6, v23

    move-object/from16 v10, v38

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/PointF;

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v8

    sub-int/2addr v8, v13

    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/graphics/PointF;

    invoke-static {v5, v6, v7, v8, v10}, Lr3/e;->a(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v5

    :goto_1a7
    iget v7, v5, Landroid/graphics/PointF;->x:F

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    iget v5, v5, Landroid/graphics/PointF;->y:F

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    if-eqz v2, :cond_1cd

    iget v8, v2, Landroid/graphics/Rect;->left:I

    iget v9, v2, Landroid/graphics/Rect;->right:I

    invoke-static {v9, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget v8, v2, Landroid/graphics/Rect;->top:I

    iget v9, v2, Landroid/graphics/Rect;->bottom:I

    invoke-static {v9, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    :cond_1cd
    new-instance v8, Landroid/graphics/Point;

    invoke-direct {v8, v7, v5}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_158

    :cond_1d8
    const/16 v32, 0x5

    goto/16 :goto_625

    :cond_1dc
    move/from16 v39, v9

    if-eqz v39, :cond_1e3

    const/high16 v9, 0x3f000000    # 0.5f

    goto :goto_1e5

    :cond_1e3
    move/from16 v9, v27

    :goto_1e5
    cmpg-float v9, v16, v9

    const v13, 0x3fa66666    # 1.3f

    if-gez v9, :cond_324

    cmpl-float v9, v8, v11

    if-lez v9, :cond_324

    if-eqz v39, :cond_1fa

    mul-float/2addr v12, v13

    mul-float v8, v8, v17

    invoke-static {v12, v8}, Ljava/lang/Math;->min(FF)F

    move-result v5

    goto :goto_202

    :cond_1fa
    const/high16 v28, 0x3f000000    # 0.5f

    mul-float v8, v8, v28

    invoke-static {v12, v8}, Ljava/lang/Math;->min(FF)F

    move-result v5

    :goto_202
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v8

    const v21, 0x3ecccccd    # 0.4f

    mul-float v8, v8, v21

    add-float v8, v8, v24

    new-instance v9, Landroid/graphics/PointF;

    iget v11, v6, Landroid/graphics/PointF;->x:F

    const/high16 v37, 0x3f800000    # 1.0f

    sub-float v13, v37, v8

    mul-float/2addr v11, v13

    iget v12, v10, Landroid/graphics/PointF;->x:F

    mul-float/2addr v12, v8

    add-float/2addr v12, v11

    iget v11, v6, Landroid/graphics/PointF;->y:F

    mul-float/2addr v11, v13

    iget v13, v10, Landroid/graphics/PointF;->y:F

    mul-float/2addr v13, v8

    add-float/2addr v13, v11

    invoke-direct {v9, v12, v13}, Landroid/graphics/PointF;-><init>(FF)V

    const/4 v8, 0x4

    if-eqz v39, :cond_235

    invoke-virtual {v3, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v8

    const/16 v32, 0x5

    add-int/lit8 v8, v8, 0x5

    goto :goto_23d

    :cond_235
    const/4 v11, 0x3

    const/16 v32, 0x5

    invoke-virtual {v3, v11}, Ljava/util/Random;->nextInt(I)I

    move-result v11

    add-int/2addr v8, v11

    :goto_23d
    if-eqz v39, :cond_24b

    const/high16 v11, 0x40400000    # 3.0f

    move/from16 v12, v20

    const v13, 0x40490fdb    # (float)Math.PI

    invoke-static {v3, v12, v11, v13}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v11

    goto :goto_256

    :cond_24b
    move/from16 v12, v20

    const v13, 0x40490fdb    # (float)Math.PI

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v11

    add-float/2addr v11, v12

    mul-float/2addr v11, v13

    :goto_256
    move/from16 v12, v29

    :goto_258
    if-ge v12, v8, :cond_296

    int-to-float v13, v12

    add-int/lit8 v14, v8, -0x1

    int-to-float v14, v14

    div-float/2addr v13, v14

    mul-float v14, v11, v13

    const/high16 v37, 0x3f800000    # 1.0f

    sub-float v13, v37, v13

    mul-float/2addr v13, v5

    new-instance v15, Landroid/graphics/PointF;

    move/from16 v16, v5

    iget v5, v9, Landroid/graphics/PointF;->x:F

    move-object/from16 v23, v10

    move/from16 v19, v11

    float-to-double v10, v14

    move-wide/from16 v25, v10

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    double-to-float v10, v10

    mul-float/2addr v10, v13

    add-float/2addr v10, v5

    iget v5, v9, Landroid/graphics/PointF;->y:F

    move v14, v8

    move-object v11, v9

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v13

    add-float/2addr v8, v5

    invoke-direct {v15, v10, v8}, Landroid/graphics/PointF;-><init>(FF)V

    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    move-object v9, v11

    move v8, v14

    move/from16 v5, v16

    move/from16 v11, v19

    move-object/from16 v10, v23

    goto :goto_258

    :cond_296
    move-object/from16 v23, v10

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/lit8 v8, v5, -0x1

    div-int/2addr v0, v8

    move/from16 v9, v29

    :goto_2a1
    if-ge v9, v8, :cond_625

    if-nez v9, :cond_2a9

    move-object v10, v6

    :goto_2a6
    const/16 v30, 0x2

    goto :goto_2b0

    :cond_2a9
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/graphics/PointF;

    goto :goto_2a6

    :goto_2b0
    add-int/lit8 v11, v5, -0x2

    if-ne v9, v11, :cond_2b7

    move-object/from16 v11, v23

    goto :goto_2bf

    :cond_2b7
    add-int/lit8 v11, v9, 0x1

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/graphics/PointF;

    :goto_2bf
    const/4 v12, 0x1

    :goto_2c0
    if-gt v12, v0, :cond_31e

    int-to-float v13, v12

    int-to-float v14, v0

    div-float/2addr v13, v14

    iget v14, v10, Landroid/graphics/PointF;->x:F

    iget v15, v11, Landroid/graphics/PointF;->x:F

    sub-float/2addr v15, v14

    mul-float/2addr v15, v13

    add-float/2addr v15, v14

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v14

    const/high16 v28, 0x3f000000    # 0.5f

    sub-float v14, v14, v28

    const/high16 v20, 0x40000000    # 2.0f

    mul-float v14, v14, v20

    add-float/2addr v14, v15

    iget v15, v10, Landroid/graphics/PointF;->y:F

    move/from16 v16, v0

    iget v0, v11, Landroid/graphics/PointF;->y:F

    sub-float/2addr v0, v15

    mul-float/2addr v0, v13

    add-float/2addr v0, v15

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v13

    sub-float v13, v13, v28

    mul-float v13, v13, v20

    add-float/2addr v13, v0

    if-eqz v2, :cond_309

    iget v0, v2, Landroid/graphics/Rect;->left:I

    int-to-float v0, v0

    iget v15, v2, Landroid/graphics/Rect;->right:I

    int-to-float v15, v15

    invoke-static {v15, v14}, Ljava/lang/Math;->min(FF)F

    move-result v14

    invoke-static {v0, v14}, Ljava/lang/Math;->max(FF)F

    move-result v14

    iget v0, v2, Landroid/graphics/Rect;->top:I

    int-to-float v0, v0

    iget v15, v2, Landroid/graphics/Rect;->bottom:I

    int-to-float v15, v15

    invoke-static {v15, v13}, Ljava/lang/Math;->min(FF)F

    move-result v13

    invoke-static {v0, v13}, Ljava/lang/Math;->max(FF)F

    move-result v13

    :cond_309
    new-instance v0, Landroid/graphics/Point;

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-direct {v0, v14, v13}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    move/from16 v0, v16

    goto :goto_2c0

    :cond_31e
    move/from16 v16, v0

    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_2a1

    :cond_324
    move-object/from16 v23, v10

    const/16 v32, 0x5

    if-eqz v39, :cond_32d

    const/high16 v8, 0x3f400000    # 0.75f

    goto :goto_330

    :cond_32d
    const v8, 0x3ee66666    # 0.45f

    :goto_330
    cmpg-float v8, v16, v8

    if-gez v8, :cond_424

    float-to-double v8, v7

    float-to-double v10, v5

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v8

    double-to-float v8, v8

    invoke-virtual {v3}, Ljava/util/Random;->nextBoolean()Z

    move-result v9

    if-eqz v9, :cond_344

    move/from16 v9, v35

    goto :goto_346

    :cond_344
    move/from16 v9, v31

    :goto_346
    add-float/2addr v8, v9

    if-eqz v39, :cond_353

    const v9, 0x3fb33333    # 1.4f

    move/from16 v10, v34

    invoke-static {v3, v10, v9, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v9

    goto :goto_35b

    :cond_353
    const/high16 v14, 0x3f800000    # 1.0f

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-static {v3, v15, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v9

    :goto_35b
    if-eqz v39, :cond_368

    move/from16 v10, v17

    const v14, 0x3f99999a    # 1.2f

    invoke-static {v3, v10, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v3

    :goto_366
    move v10, v7

    goto :goto_373

    :cond_368
    const v10, 0x3ecccccd    # 0.4f

    const v15, 0x3f4ccccd    # 0.8f

    invoke-static {v3, v10, v15, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v3

    goto :goto_366

    :goto_373
    new-instance v7, Landroid/graphics/PointF;

    iget v11, v6, Landroid/graphics/PointF;->x:F

    const v36, 0x3e4ccccd    # 0.2f

    mul-float v13, v5, v36

    add-float/2addr v13, v11

    float-to-double v11, v8

    invoke-static {v11, v12}, Ljava/lang/Math;->cos(D)D

    move-result-wide v14

    double-to-float v8, v14

    mul-float/2addr v8, v9

    add-float/2addr v8, v13

    iget v13, v6, Landroid/graphics/PointF;->y:F

    mul-float v14, v10, v36

    add-float/2addr v14, v13

    move-wide v15, v11

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v11, v11

    mul-float/2addr v11, v9

    add-float/2addr v11, v14

    invoke-direct {v7, v8, v11}, Landroid/graphics/PointF;-><init>(FF)V

    new-instance v8, Landroid/graphics/PointF;

    iget v11, v6, Landroid/graphics/PointF;->x:F

    const/high16 v28, 0x3f000000    # 0.5f

    mul-float v12, v5, v28

    add-float/2addr v12, v11

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->cos(D)D

    move-result-wide v13

    double-to-float v11, v13

    mul-float/2addr v11, v3

    sub-float/2addr v12, v11

    iget v11, v6, Landroid/graphics/PointF;->y:F

    mul-float v13, v10, v28

    add-float/2addr v13, v11

    move v11, v13

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->sin(D)D

    move-result-wide v13

    double-to-float v13, v13

    mul-float/2addr v13, v3

    sub-float v13, v11, v13

    invoke-direct {v8, v12, v13}, Landroid/graphics/PointF;-><init>(FF)V

    move v3, v9

    new-instance v9, Landroid/graphics/PointF;

    iget v11, v6, Landroid/graphics/PointF;->x:F

    const v33, 0x3f4ccccd    # 0.8f

    mul-float v5, v5, v33

    add-float/2addr v5, v11

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->cos(D)D

    move-result-wide v11

    double-to-float v11, v11

    mul-float/2addr v11, v3

    const v34, 0x3f333333    # 0.7f

    mul-float v11, v11, v34

    add-float/2addr v11, v5

    iget v5, v6, Landroid/graphics/PointF;->y:F

    mul-float v10, v10, v33

    add-float/2addr v10, v5

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    double-to-float v5, v12

    mul-float/2addr v5, v3

    mul-float v5, v5, v34

    add-float/2addr v5, v10

    invoke-direct {v9, v11, v5}, Landroid/graphics/PointF;-><init>(FF)V

    const/4 v12, 0x1

    :goto_3df
    if-gt v12, v0, :cond_625

    int-to-float v3, v12

    int-to-float v5, v0

    div-float/2addr v3, v5

    invoke-static {v3}, Lr3/e;->c(F)F

    move-result v5

    move-object/from16 v10, v23

    invoke-static/range {v5 .. v10}, Lr3/e;->d(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v3

    move-object v5, v7

    move-object v7, v10

    iget v10, v3, Landroid/graphics/PointF;->x:F

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    iget v3, v3, Landroid/graphics/PointF;->y:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    if-eqz v2, :cond_416

    iget v11, v2, Landroid/graphics/Rect;->left:I

    iget v13, v2, Landroid/graphics/Rect;->right:I

    invoke-static {v13, v10}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v11, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    iget v11, v2, Landroid/graphics/Rect;->top:I

    iget v13, v2, Landroid/graphics/Rect;->bottom:I

    invoke-static {v13, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    :cond_416
    new-instance v11, Landroid/graphics/Point;

    invoke-direct {v11, v10, v3}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v23, v7

    move-object v7, v5

    goto :goto_3df

    :cond_424
    move v10, v7

    move-object/from16 v7, v23

    if-eqz v39, :cond_42d

    const v8, 0x3f666666    # 0.9f

    goto :goto_430

    :cond_42d
    const v8, 0x3f266666    # 0.65f

    :goto_430
    cmpg-float v8, v16, v8

    if-gez v8, :cond_502

    float-to-double v8, v10

    float-to-double v14, v5

    invoke-static {v8, v9, v14, v15}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v8

    double-to-float v8, v8

    add-float v9, v8, v35

    sub-float v8, v8, v35

    if-eqz v39, :cond_44b

    const v11, 0x3f333333    # 0.7f

    invoke-static {v3, v11, v13, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    const/high16 v15, 0x3f000000    # 0.5f

    goto :goto_453

    :cond_44b
    const/high16 v14, 0x3f800000    # 1.0f

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-static {v3, v15, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    :goto_453
    if-eqz v39, :cond_460

    const v11, 0x3f8ccccd    # 1.1f

    const v14, 0x3f19999a    # 0.6f

    invoke-static {v3, v14, v11, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v11

    goto :goto_46b

    :cond_460
    const v11, 0x3f4ccccd    # 0.8f

    const v14, 0x3f19999a    # 0.6f

    invoke-static {v3, v15, v11, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v12

    move v11, v12

    :goto_46b
    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v12

    const v36, 0x3e4ccccd    # 0.2f

    mul-float v12, v12, v36

    add-float v12, v12, v36

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v3

    mul-float v3, v3, v36

    add-float/2addr v3, v14

    new-instance v14, Landroid/graphics/PointF;

    iget v15, v6, Landroid/graphics/PointF;->x:F

    mul-float v16, v5, v12

    add-float v16, v16, v15

    move v15, v11

    move/from16 v19, v12

    float-to-double v11, v9

    move-wide/from16 v25, v11

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->cos(D)D

    move-result-wide v11

    double-to-float v9, v11

    mul-float/2addr v9, v13

    add-float v9, v9, v16

    iget v11, v6, Landroid/graphics/PointF;->y:F

    mul-float v12, v10, v19

    add-float/2addr v12, v11

    move/from16 v16, v12

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v11, v11

    mul-float/2addr v11, v13

    add-float v11, v11, v16

    invoke-direct {v14, v9, v11}, Landroid/graphics/PointF;-><init>(FF)V

    new-instance v9, Landroid/graphics/PointF;

    iget v11, v6, Landroid/graphics/PointF;->x:F

    mul-float/2addr v5, v3

    add-float/2addr v5, v11

    float-to-double v11, v8

    move-wide/from16 v25, v11

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->cos(D)D

    move-result-wide v11

    double-to-float v8, v11

    mul-float/2addr v8, v15

    add-float/2addr v8, v5

    iget v5, v6, Landroid/graphics/PointF;->y:F

    mul-float/2addr v3, v10

    add-float/2addr v3, v5

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v5, v10

    mul-float/2addr v5, v15

    add-float/2addr v5, v3

    invoke-direct {v9, v8, v5}, Landroid/graphics/PointF;-><init>(FF)V

    const/4 v12, 0x1

    :goto_4c4
    if-gt v12, v0, :cond_625

    int-to-float v3, v12

    int-to-float v5, v0

    div-float/2addr v3, v5

    invoke-static {v3}, Lr3/e;->c(F)F

    move-result v3

    invoke-static {v3, v6, v14, v9, v7}, Lr3/e;->a(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v3

    iget v5, v3, Landroid/graphics/PointF;->x:F

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget v3, v3, Landroid/graphics/PointF;->y:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    if-eqz v2, :cond_4f7

    iget v8, v2, Landroid/graphics/Rect;->left:I

    iget v10, v2, Landroid/graphics/Rect;->right:I

    invoke-static {v10, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iget v8, v2, Landroid/graphics/Rect;->top:I

    iget v10, v2, Landroid/graphics/Rect;->bottom:I

    invoke-static {v10, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v8, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    :cond_4f7
    new-instance v8, Landroid/graphics/Point;

    invoke-direct {v8, v5, v3}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    goto :goto_4c4

    :cond_502
    float-to-double v8, v10

    float-to-double v13, v5

    invoke-static {v8, v9, v13, v14}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v8

    double-to-float v8, v8

    invoke-virtual {v3}, Ljava/util/Random;->nextBoolean()Z

    move-result v9

    if-eqz v9, :cond_54e

    invoke-virtual {v3}, Ljava/util/Random;->nextBoolean()Z

    move-result v9

    if-eqz v9, :cond_518

    move/from16 v9, v35

    goto :goto_51a

    :cond_518
    move/from16 v9, v31

    :goto_51a
    add-float/2addr v8, v9

    if-eqz v39, :cond_52e

    const v9, 0x3f19999a    # 0.6f

    const v14, 0x3f99999a    # 1.2f

    invoke-static {v3, v9, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v11

    move v13, v11

    const v11, 0x3ecccccd    # 0.4f

    const/high16 v14, 0x3f800000    # 1.0f

    goto :goto_53a

    :cond_52e
    const v9, 0x3f19999a    # 0.6f

    const v11, 0x3ecccccd    # 0.4f

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-static {v3, v11, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    :goto_53a
    if-eqz v39, :cond_541

    invoke-static {v3, v9, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v11

    goto :goto_548

    :cond_541
    const v9, 0x3f666666    # 0.9f

    invoke-static {v3, v11, v9, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v11

    :goto_548
    move v12, v11

    const v9, 0x3f19999a    # 0.6f

    move v11, v8

    goto :goto_593

    :cond_54e
    invoke-virtual {v3}, Ljava/util/Random;->nextBoolean()Z

    move-result v9

    if-eqz v9, :cond_557

    move/from16 v11, v35

    goto :goto_559

    :cond_557
    move/from16 v11, v31

    :goto_559
    add-float/2addr v11, v8

    if-eqz v9, :cond_55f

    move/from16 v9, v31

    goto :goto_561

    :cond_55f
    move/from16 v9, v35

    :goto_561
    add-float/2addr v8, v9

    if-eqz v39, :cond_575

    const v9, 0x3f19999a    # 0.6f

    const v14, 0x3f99999a    # 1.2f

    invoke-static {v3, v9, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    move v15, v13

    const v13, 0x3ecccccd    # 0.4f

    const/high16 v14, 0x3f800000    # 1.0f

    goto :goto_581

    :cond_575
    const v9, 0x3f19999a    # 0.6f

    const v13, 0x3ecccccd    # 0.4f

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-static {v3, v13, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v15

    :goto_581
    if-eqz v39, :cond_588

    invoke-static {v3, v9, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v12

    goto :goto_58f

    :cond_588
    const v14, 0x3f4ccccd    # 0.8f

    invoke-static {v3, v13, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v12

    :goto_58f
    move v13, v11

    move v11, v8

    move v8, v13

    move v13, v15

    :goto_593
    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v14

    mul-float v14, v14, v22

    add-float v14, v14, v27

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v3

    mul-float v3, v3, v22

    add-float/2addr v3, v9

    new-instance v9, Landroid/graphics/PointF;

    iget v15, v6, Landroid/graphics/PointF;->x:F

    mul-float v16, v5, v14

    add-float v16, v16, v15

    move v15, v12

    move/from16 v19, v13

    float-to-double v12, v8

    move-wide/from16 v25, v12

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    double-to-float v8, v12

    mul-float v8, v8, v19

    add-float v8, v8, v16

    iget v12, v6, Landroid/graphics/PointF;->y:F

    mul-float v13, v10, v14

    add-float/2addr v13, v12

    move v14, v13

    invoke-static/range {v25 .. v26}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    double-to-float v12, v12

    mul-float v12, v12, v19

    add-float/2addr v12, v14

    invoke-direct {v9, v8, v12}, Landroid/graphics/PointF;-><init>(FF)V

    new-instance v8, Landroid/graphics/PointF;

    iget v12, v6, Landroid/graphics/PointF;->x:F

    mul-float/2addr v5, v3

    add-float/2addr v5, v12

    float-to-double v11, v11

    invoke-static {v11, v12}, Ljava/lang/Math;->cos(D)D

    move-result-wide v13

    double-to-float v13, v13

    mul-float/2addr v13, v15

    add-float/2addr v13, v5

    iget v5, v6, Landroid/graphics/PointF;->y:F

    mul-float/2addr v3, v10

    add-float/2addr v3, v5

    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v5, v10

    mul-float/2addr v5, v15

    add-float/2addr v5, v3

    invoke-direct {v8, v13, v5}, Landroid/graphics/PointF;-><init>(FF)V

    const/4 v12, 0x1

    :goto_5e7
    if-gt v12, v0, :cond_625

    int-to-float v3, v12

    int-to-float v5, v0

    div-float/2addr v3, v5

    invoke-static {v3}, Lr3/e;->c(F)F

    move-result v3

    invoke-static {v3, v6, v9, v8, v7}, Lr3/e;->a(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v3

    iget v5, v3, Landroid/graphics/PointF;->x:F

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget v3, v3, Landroid/graphics/PointF;->y:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    if-eqz v2, :cond_61a

    iget v10, v2, Landroid/graphics/Rect;->left:I

    iget v11, v2, Landroid/graphics/Rect;->right:I

    invoke-static {v11, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v10, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iget v10, v2, Landroid/graphics/Rect;->top:I

    iget v11, v2, Landroid/graphics/Rect;->bottom:I

    invoke-static {v11, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    :cond_61a
    new-instance v10, Landroid/graphics/Point;

    invoke-direct {v10, v5, v3}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    goto :goto_5e7

    :cond_625
    :goto_625
    iget v0, v1, Lr3/e;->e:I

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-static {v0, v2}, Lr3/e;->b(II)[I

    move-result-object v0

    move/from16 v2, v29

    :goto_631
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_652

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Point;

    :try_start_63d
    aget v5, v0, v2

    int-to-long v5, v5

    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_643
    .catch Ljava/lang/InterruptedException; {:try_start_63d .. :try_end_643} :catch_86e

    iget v5, v3, Landroid/graphics/Point;->x:I

    iget v3, v3, Landroid/graphics/Point;->y:I

    invoke-virtual {v1, v5, v3}, Lr3/e;->e(II)Z

    move-result v3

    if-nez v3, :cond_64f

    goto/16 :goto_86e

    :cond_64f
    add-int/lit8 v2, v2, 0x1

    goto :goto_631

    :cond_652
    new-instance v0, Landroid/graphics/Point;

    iget-object v2, v1, Lr3/e;->b:Landroid/graphics/Point;

    iget v3, v2, Landroid/graphics/Point;->x:I

    iget v2, v2, Landroid/graphics/Point;->y:I

    invoke-direct {v0, v3, v2}, Landroid/graphics/Point;-><init>(II)V

    iget-object v2, v1, Lr3/e;->h:Landroid/graphics/Point;

    if-eqz v2, :cond_7ff

    :try_start_661
    iget-object v0, v1, Lr3/e;->d:Ljava/util/Random;

    const/16 v2, 0x2e

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x19

    int-to-long v2, v0

    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_66f
    .catch Ljava/lang/InterruptedException; {:try_start_661 .. :try_end_66f} :catch_86e

    iget-object v2, v1, Lr3/e;->a:Landroid/graphics/Point;

    monitor-enter v2

    :try_start_672
    new-instance v0, Landroid/graphics/PointF;

    iget-object v3, v1, Lr3/e;->a:Landroid/graphics/Point;

    iget v4, v3, Landroid/graphics/Point;->x:I

    int-to-float v4, v4

    iget v3, v3, Landroid/graphics/Point;->y:I

    int-to-float v3, v3

    invoke-direct {v0, v4, v3}, Landroid/graphics/PointF;-><init>(FF)V

    monitor-exit v2
    :try_end_680
    .catchall {:try_start_672 .. :try_end_680} :catchall_7fc

    new-instance v2, Landroid/graphics/PointF;

    iget-object v3, v1, Lr3/e;->h:Landroid/graphics/Point;

    iget v4, v3, Landroid/graphics/Point;->x:I

    int-to-float v4, v4

    iget v3, v3, Landroid/graphics/Point;->y:I

    int-to-float v3, v3

    invoke-direct {v2, v4, v3}, Landroid/graphics/PointF;-><init>(FF)V

    iget-object v3, v1, Lr3/e;->d:Ljava/util/Random;

    const/4 v4, 0x7

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    add-int/lit8 v3, v3, 0x8

    iget-object v4, v1, Lr3/e;->d:Ljava/util/Random;

    const/16 v5, 0x24

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/lit8 v4, v4, 0x2d

    iget-object v5, v1, Lr3/e;->k:Landroid/graphics/Rect;

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iget v7, v2, Landroid/graphics/PointF;->x:F

    iget v8, v0, Landroid/graphics/PointF;->x:F

    sub-float/2addr v7, v8

    iget v8, v2, Landroid/graphics/PointF;->y:F

    iget v9, v0, Landroid/graphics/PointF;->y:F

    sub-float/2addr v8, v9

    mul-float v9, v7, v7

    mul-float v10, v8, v8

    add-float/2addr v10, v9

    float-to-double v9, v10

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v9, v9

    iget v10, v1, Lr3/e;->i:F

    iget-object v11, v1, Lr3/e;->d:Ljava/util/Random;

    const v14, 0x3f19999a    # 0.6f

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-static {v11, v15, v14, v10}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v12

    const/high16 v20, 0x40000000    # 2.0f

    mul-float v15, v10, v20

    cmpg-float v13, v9, v15

    if-gez v13, :cond_6de

    const/4 v13, 0x0

    cmpl-float v10, v10, v13

    if-lez v10, :cond_6de

    div-float/2addr v9, v15

    move/from16 v10, v24

    invoke-static {v10, v9}, Ljava/lang/Math;->max(FF)F

    move-result v9

    mul-float/2addr v12, v9

    :cond_6de
    float-to-double v9, v8

    float-to-double v13, v7

    invoke-static {v9, v10, v13, v14}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v9

    double-to-float v9, v9

    invoke-virtual {v11}, Ljava/util/Random;->nextBoolean()Z

    move-result v10

    if-eqz v10, :cond_709

    invoke-virtual {v11}, Ljava/util/Random;->nextBoolean()Z

    move-result v10

    if-eqz v10, :cond_6f3

    move/from16 v31, v35

    :cond_6f3
    add-float v9, v9, v31

    const v10, 0x3e99999a    # 0.3f

    const v15, 0x3f4ccccd    # 0.8f

    invoke-static {v11, v10, v15, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    const v14, 0x3f19999a    # 0.6f

    invoke-static {v11, v10, v14, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v10

    move v12, v10

    move v10, v9

    goto :goto_72f

    :cond_709
    const v10, 0x3e99999a    # 0.3f

    invoke-virtual {v11}, Ljava/util/Random;->nextBoolean()Z

    move-result v13

    if-eqz v13, :cond_715

    move/from16 v14, v35

    goto :goto_717

    :cond_715
    move/from16 v14, v31

    :goto_717
    add-float/2addr v14, v9

    if-eqz v13, :cond_71b

    goto :goto_71d

    :cond_71b
    move/from16 v31, v35

    :goto_71d
    add-float v9, v9, v31

    const v13, 0x3f333333    # 0.7f

    invoke-static {v11, v10, v13, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v13

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-static {v11, v10, v15, v12}, Landroidx/activity/g;->g(Ljava/util/Random;FFF)F

    move-result v10

    move v12, v10

    move v10, v9

    move v9, v14

    :goto_72f
    invoke-virtual {v11}, Ljava/util/Random;->nextFloat()F

    move-result v14

    mul-float v14, v14, v22

    add-float v14, v14, v27

    invoke-virtual {v11}, Ljava/util/Random;->nextFloat()F

    move-result v11

    mul-float v11, v11, v22

    const v17, 0x3f19999a    # 0.6f

    add-float v11, v11, v17

    new-instance v15, Landroid/graphics/PointF;

    move/from16 v16, v7

    iget v7, v0, Landroid/graphics/PointF;->x:F

    mul-float v17, v16, v14

    add-float v17, v17, v7

    move/from16 v19, v8

    float-to-double v7, v9

    move-wide/from16 v20, v7

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float/2addr v7, v13

    add-float v7, v7, v17

    iget v8, v0, Landroid/graphics/PointF;->y:F

    mul-float v9, v19, v14

    add-float/2addr v9, v8

    move v14, v9

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v13

    add-float/2addr v8, v14

    invoke-direct {v15, v7, v8}, Landroid/graphics/PointF;-><init>(FF)V

    new-instance v7, Landroid/graphics/PointF;

    iget v8, v0, Landroid/graphics/PointF;->x:F

    mul-float v9, v16, v11

    add-float/2addr v9, v8

    float-to-double v13, v10

    move v10, v9

    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v12

    add-float/2addr v8, v10

    iget v9, v0, Landroid/graphics/PointF;->y:F

    mul-float v10, v19, v11

    add-float/2addr v10, v9

    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v13

    double-to-float v9, v13

    mul-float/2addr v9, v12

    add-float/2addr v9, v10

    invoke-direct {v7, v8, v9}, Landroid/graphics/PointF;-><init>(FF)V

    const/4 v12, 0x1

    :goto_789
    if-gt v12, v3, :cond_7c5

    int-to-float v8, v12

    int-to-float v9, v3

    div-float/2addr v8, v9

    invoke-static {v8}, Lr3/e;->c(F)F

    move-result v8

    invoke-static {v8, v0, v15, v7, v2}, Lr3/e;->a(FLandroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/graphics/PointF;

    move-result-object v8

    iget v9, v8, Landroid/graphics/PointF;->x:F

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    iget v8, v8, Landroid/graphics/PointF;->y:F

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    iget v10, v5, Landroid/graphics/Rect;->left:I

    iget v11, v5, Landroid/graphics/Rect;->right:I

    invoke-static {v11, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v10, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    iget v10, v5, Landroid/graphics/Rect;->top:I

    iget v11, v5, Landroid/graphics/Rect;->bottom:I

    invoke-static {v11, v8}, Ljava/lang/Math;->min(II)I

    move-result v8

    invoke-static {v10, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    new-instance v10, Landroid/graphics/Point;

    invoke-direct {v10, v9, v8}, Landroid/graphics/Point;-><init>(II)V

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    goto :goto_789

    :cond_7c5
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-static {v4, v0}, Lr3/e;->b(II)[I

    move-result-object v0

    move/from16 v2, v29

    :goto_7cf
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_7f0

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Point;

    :try_start_7db
    aget v4, v0, v2

    int-to-long v4, v4

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7e1
    .catch Ljava/lang/InterruptedException; {:try_start_7db .. :try_end_7e1} :catch_86e

    iget v4, v3, Landroid/graphics/Point;->x:I

    iget v3, v3, Landroid/graphics/Point;->y:I

    invoke-virtual {v1, v4, v3}, Lr3/e;->e(II)Z

    move-result v3

    if-nez v3, :cond_7ed

    goto/16 :goto_86e

    :cond_7ed
    add-int/lit8 v2, v2, 0x1

    goto :goto_7cf

    :cond_7f0
    new-instance v0, Landroid/graphics/Point;

    iget-object v2, v1, Lr3/e;->h:Landroid/graphics/Point;

    iget v3, v2, Landroid/graphics/Point;->x:I

    iget v2, v2, Landroid/graphics/Point;->y:I

    invoke-direct {v0, v3, v2}, Landroid/graphics/Point;-><init>(II)V

    goto :goto_7ff

    :catchall_7fc
    move-exception v0

    :try_start_7fd
    monitor-exit v2
    :try_end_7fe
    .catchall {:try_start_7fd .. :try_end_7fe} :catchall_7fc

    throw v0

    :cond_7ff
    :goto_7ff
    iget-boolean v2, v1, Lr3/e;->j:Z

    if-eqz v2, :cond_806

    const/16 v3, 0x78

    goto :goto_808

    :cond_806
    const/16 v3, 0x96

    :goto_808
    if-eqz v2, :cond_80d

    const/16 v4, 0x104

    goto :goto_80f

    :cond_80d
    const/16 v4, 0x12c

    :goto_80f
    if-eqz v2, :cond_814

    const/16 v15, 0xc

    goto :goto_816

    :cond_814
    move/from16 v15, v32

    :cond_816
    :goto_816
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v2

    if-nez v2, :cond_86e

    iget-object v2, v1, Lr3/e;->d:Ljava/util/Random;

    sub-int v5, v4, v3

    const/16 v18, 0x1

    add-int/lit8 v5, v5, 0x1

    invoke-virtual {v2, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v2, v3

    int-to-long v5, v2

    :try_start_82e
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_831
    .catch Ljava/lang/InterruptedException; {:try_start_82e .. :try_end_831} :catch_86e

    iget-object v2, v1, Lr3/e;->d:Ljava/util/Random;

    mul-int/lit8 v5, v15, 0x2

    add-int/lit8 v5, v5, 0x1

    invoke-virtual {v2, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    sub-int/2addr v2, v15

    iget-object v6, v1, Lr3/e;->d:Ljava/util/Random;

    invoke-virtual {v6, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v5

    sub-int/2addr v5, v15

    iget v6, v0, Landroid/graphics/Point;->x:I

    add-int/2addr v6, v2

    iget v2, v0, Landroid/graphics/Point;->y:I

    add-int/2addr v2, v5

    iget-object v5, v1, Lr3/e;->k:Landroid/graphics/Rect;

    if-eqz v5, :cond_867

    iget v7, v5, Landroid/graphics/Rect;->left:I

    iget v5, v5, Landroid/graphics/Rect;->right:I

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v6

    iget-object v5, v1, Lr3/e;->k:Landroid/graphics/Rect;

    iget v7, v5, Landroid/graphics/Rect;->top:I

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    invoke-static {v5, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    :cond_867
    invoke-virtual {v1, v6, v2}, Lr3/e;->e(II)Z

    move-result v2

    if-nez v2, :cond_816

    nop

    :catch_86e
    :cond_86e
    :goto_86e
    return-void
.end method
