# 酷凡 26.1.17：WASD 摇杆轨迹专项只读研究

日期：2026-10-14。结论：确实找到了未加密 DEX 的随机逻辑，但它随机的是 Android 触点大小字段 `size`，不是摇杆的 X/Y、角度或半径。补充调用链确认：X/Y由应用侧提供的IPC环通道传入，服务侧读取10字节记录后直接注入；坐标生成器的应用侧业务实现尚未恢复。现有可读代码没有恢复“普通 / 半摇感随机 / 全摇感随机”三种摇杆轨迹的生成算法，也没有恢复原角度范围、半径噪声、插值曲线和更新周期。用户说随机只是猜想，本报告不再建议预设随机角度或用通用算法替代原算法；只有恢复真实参数之后才能据此实现对应自定义功能。

用户最新范围：复杂宏、压枪和图像识别已排除。“手搓”指ManualTouch模式；键鼠模式中的摇杆模拟人手轨迹仍属于本次键鼠研究，不能因为包含“人手轨迹”就归入ManualTouch或跳过。当前报告研究的是这个键鼠摇杆坐标生成边界，未恢复其算子，不提供冒称原软件的角度或曲线参数。

## 原包和研究方法

- APK SHA-256：`aebaa741983299577da0e72f5cea90484a750e528048164c6b39c4c714e9d3bc`。
- 使用项目范围内的 REA 6.4.0 CLI、JDK17、固定 JADX 0.7.1 JAR；不更改 Codex 配置。
- 本轮实际调用 REA 搜索 APK 和未加密 shellproc 研究封装中的 joystick/trajectory 类；检查 TouchStateManager、PointersState 类成员；反编译 update、getPointerIndex、performTouch、Pointer.setPos；追踪 update 的静态引用。
- 补充读取原 APK 两份 DEX 的声明字符串表、方法引用表、类定义表和 PointersState 静态 encoded values；读取 libinput.so ELF64 动态符号和可见 ASCII 字符串。脚本 `scan_dex_and_native.py` 可重新运行，无目标执行。
- 未解壳、解密、破解激活或运行原 APK。未使用 KeySync 算法作为酷凡证据。

REA 指令沿用项目已核对的 [官方 Android 分析说明](https://github.com/morluto/rea/blob/main/docs/android-analysis.md)。JADX Java 输出是派生表示，不等同原始源码；REA 没有提供原 DEX 指令偏移或原源码行号。

## 一、直接代码证据：随机只作用于触点 size

REA `pointers-state-class.json` 确认 `random` 字段属于：

`moe.heroman.eventtest.shellprocess.touchcontroller.PointersState`

REA `pointers-update-method.json` 返回完整 Java 表示、无 smali 回退，其关键原样文本为：

```java
Pointer pointer = this.active[i];
props[i].id = pointer.getLocalId();
coords[i].x = pointer.getX();
coords[i].y = pointer.getY();
coords[i].size = (this.random.nextFloat() * 0.030000001f) + MIN_TOUCH_SIZE;
```

读取 shellproc DEX 的该类静态 encoded values 得到以下原常量，证据在 `dex-native-inventory.json`；这部分是字节表解析，不是 REA 字段值推测：

| 字段 | 原单精度值 | 原编码 |
|---|---|---|
| MIN_TOUCH_SIZE | `0.02f`，解码为0.019999999552965164 | encoded value `70 0a d7 a3 3c`；float bits `0x3ca3d70a` |
| MAX_TOUCH_SIZE | `0.05f`，解码为0.05000000074505806 | encoded value `70 cd cc 4c 3d`；float bits `0x3d4ccccd` |
| MAX_POINTERS | 10 | encoded value `04 0a` |
| SLOT_NONE | -1 | encoded value `04 ff` |

因此观察到的运算是大致 `size = 0.02 + U×0.03`，U为 `Random.nextFloat()`，名义范围约0.02～0.05。这个 size 是注入事件的触点大小字段，没有据此恢复几何面积或物理单位；它不是摇杆半径。单精度舍入可影响端点，不能把数学上的连续区间当成运行时逐值精确边界。

同一方法直接采用 pointer 的 X/Y，没有任何 `sin`、`cos`、`atan2`、角度噪声或半径噪声计算。它对当前所有活跃触点赋 size，不按摇杆模式区分。该事实不能证明更高层没有轨迹随机，只能证明这个可读随机源的用途。

## 二、直接代码证据：此层接收坐标，不生成 WASD 路径

`perform-touch-method.json` 显示 `TouchStateManager.performTouch(TouchInfo)`：

1. 系统触摸模式直接将 `touchInfo.type.ordinal()`、fingerIndex、x、y交给SystemTouchInjector。
2. 框架触摸路径调用 `pointer.setPos(touchInfo.x, touchInfo.y)`，再调用PointersState.update填充事件。
3. 事件时间使用 `SystemClock.uptimeMillis()`，随后注入MotionEvent。

该方法的JADX输出包含“Code duplicated”警告和不完整的Java控制流重排，不能仅靠这段派生表示断言所有动作分支语义；坐标赋值与参数传递是明确可见的局部观察。

进一步用REA核查 `Pointer.setPos(int,int)`，`pointer-setpos-method.json` 的完整结果为：

```java
public void setPos(int x, int y) {
    this.x = x;
    this.y = y;
}
```

`pointers-update-references.json` 显示 update 只有两条该引擎识别的静态入站引用：performTouch和cancelFrameworkTouches。说明这里是通用触摸事件装配链路，不能从这两条引用推出它是三种摇杆轨迹生成器。

时间边界：可以确认size在该update每次被调用时重新取随机值，框架事件使用当前uptime。没有在这些方法中找到WASD摇杆的定时调度常量，因此不能将输入读取poll周期、通用注入时间戳或独立版tick频率当成原轨迹更新周期。

### 补充直接调用链：坐标来自应用侧 IPC，生成业务仍未恢复

REA `perform-touch-references.json` 确认performTouch只有一条引擎识别的静态入站引用：NativeEventMux的startMonitor lambda。`native-event-mux-reader-method.json` 的完整Java表示直接读取：

```java
IpcRing incoming = NativeBridgeHelper.sharedInstance().getIncomingRing();
incoming.readFully(data, 0, 10);
touchInfo.type = TouchInfoType.values()[data[0]];
touchInfo.fingerIndex = data[1];
touchInfo.x = ((data[2] & 255) << 24) | ((data[3] & 255) << 16)
        | ((data[4] & 255) << 8) | (data[5] & 255);
touchInfo.y = ((data[6] & 255) << 24) | ((data[7] & 255) << 16)
        | ((data[8] & 255) << 8) | (data[9] & 255);
TouchStateManager.sharedInstance().performTouch(touchInfo);
```

真实已恢复的传输参数是：固定记录10字节；类型索引1字节、手指索引1字节，X/Y各为大端32位整数。此循环等待incoming数据后处理，没有在其中恢复摇杆周期或插值。

继续仅追这个必要入口，`native-bridge-setincoming-method.json` 显示setIncomingChannel将传入RingChannel用 `IpcRing.open(channel,false)` 打开、清理旧数据和shutdown标志；引用追踪 `native-bridge-setincoming-references.json` 只有TouchService.exchangeRingChannels。

`touch-service-exchange-method.json` 的完整结果确认incoming是以下调用的返回值：

```java
incoming = NativeBridgeHelper.sharedInstance()
        .getAppBinder().exchangeRingChannel(outgoing);
NativeBridgeHelper.sharedInstance().setIncomingChannel(incoming);
NativeEventMux.sharedInstance().startMonitor();
```

`native-bridge-setapp-method.json` 显示appBinder通过 `IAppBinderInterface.Stub.asInterface(appBinder)` 接入。可确定服务消费的incoming通道由应用侧Binder接口提供；应用侧实际写入坐标的业务实现及WASD到坐标的算子未在这条可见链中恢复。这里不是“原软件没有特殊轨迹”的证明，也不能用未恢复的写端补猜公式。

NativeBinderImpl的REA成员检查 `native-binder-class.json` 没有发现X/Y轨迹生成或坐标发送方法；可见成员是输入抓取、polling、截图、系统触摸模式等控制接口。不能把这个控制Binder当作已恢复的摇杆生成器。

已恢复链路为：应用侧提供RingChannel → 服务打开incoming IpcRing → 每条10字节记录解出X/Y → Pointer.setPos原样保存 → 触点大小size扰动/事件组装 → 框架或系统触摸注入。坐标产生的应用业务层仍未知，本轮到此停止，不扩大到解壳。

## 三、声明 DEX 表和原生库检查

| 观察对象 | 可确认结果 | 不能推出的结论 |
|---|---|---|
| 原 `classes.dex` | 764条字符串、194条方法引用、5条class_def；候选random仅RandomAccessFile | RandomAccessFile是文件I/O，不是随机轨迹 |
| `lib/arm64-v8a/libshellproc.so` | 实际是80356字节DEX039；1210条字符串、525条方法引用、67条class_def；存在Random、nextFloat | 文件名.so不代表这份内容是原生ELF；Random存在不代表角度随机 |
| REA整个APK类搜索 | 55个可显示类，joystick搜索无匹配 | 55不是原主DEX的class_def数；REA显示类型和DEX物理类定义口径不同 |
| REA shellproc封装类搜索 | 49个可显示类；joystick、trajectory都无匹配 | 包括inner/synthetic的67个原class_def不等于REA的49个可显示类 |
| libinput.so | 790条动态符号；JNI导出为设备识别、grab、绝对轴值、系统触摸打开/注入/关闭/重置等 | JNI名字只定位接口，不证明函数内算法 |
| libinput动态符号精确筛选 | 无rand/srand/random/srandom/drand48/sin/cos/atan2/hypot及相应float变体匹配 | 缺少符号不排除内联、剥离、保护或不同实现方式 |

字串筛选中“demangle”会包含“angle”子串，已明确排除C++符号解码器噪声。不能把这些字符串误当摇杆角度代码。

## 四、界面字符串证据：三种模式和半径切换存在

原REA中文资源派生证据 `resource-joystick-zh.json` 保留原APK SHA-256和来源Evidence ID。

| 资源键 | 中文原值 | 证据等级 |
|---|---|---|
| settings_joystick_trajectory_agile | 普通摇杆 | 界面字符串 |
| settings_joystick_trajectory_standard | 半摇感随机 | 界面字符串 |
| settings_joystick_trajectory_steady | 全摇感随机 | 界面字符串 |
| settings_joystick_radius | 半径大小 | 界面字符串 |
| settings_joystick_radius_switch_* | 半径切换、切换键、切换百分比、不切换、长按切换、按下切换 | 界面字符串 |
| settings_joystick_mode_* | WSAD、上下左右、自定义 | 操作方式字符串；不证明自定义角度范围 |

模式说明字符串称普通模式采用直接触控轨迹、半摇感随机会改变触控轨迹。这是软件的界面说明，未通过可读代码或运行观测验证其路径形状。不能从“半随机/全随机”的label推断角度分布、半径分布、曲线或更新频率；触点大小size扰动不能归为摇杆轨迹算法。原资源中的风险提示也不证明任何模式可规避游戏检测。

## 五、推断和未知，供独立实现决策使用

**代码确定的边界：** 可读shellprocess层消费应用侧提供的IPC环通道记录并搬运x/y；已经定位到应用侧Binder交换入口，尚未恢复该侧写入者或坐标生成实现。**仍属推断：** 三种模式的路径生成很可能位于当前不可读的应用业务层，不能将此定位推断写成已找到具体隐藏类或完整调用链。

**明确未知：**

- 半摇感、全摇感分别在按下、持续按住、转向或抬起哪个阶段引入随机。
- 随机分布、种子来源、角度扰动上下限、方向扇区、轴向/斜向默认角度。
- 半径随机幅度、中心漂移幅度、边缘约束和半径切换百分比默认值。
- 线性、Bezier、缓动或其他插值；轨迹点数、时间步长、按键组合转向算法。
- 原配置字段名和可公开给用户调节的原角度范围。

本报告没有恢复可用来复刻酷凡摇杆的角度常量、曲线或噪声参数，因而不建议新增随机角度或以通用joystick算法补猜。自定义功能应以原软件真实恢复的参数为依据；当前直接恢复的0.02～0.05只属于通用触点大小字段，不是WASD轨迹参数。KeySync中的随机或平滑实现不在本结论的证据链内。主线目前的固定方向基础摇杆也不能因此称为已经复现酷凡特殊轨迹。

## 证据索引与复现

本目录主要证据：`classes-joystick.json`、`shellproc-classes-joystick.json`、`shellproc-classes-trajectory.json`、`touch-state-class.json`、`pointers-state-class.json`、`pointers-update-method.json`、`pointers-slot-method.json`、`perform-touch-method.json`、`pointer-setpos-method.json`、`pointers-update-references.json`、`dex-native-inventory.json`、`resource-joystick-zh.json`。

追加坐标来源证据：`perform-touch-references.json`、`native-binder-class.json`、`native-event-mux-class.json`、`native-event-mux-reader-method.json`、`native-event-mux-start-method.json`、`native-bridge-helper-class.json`、`native-bridge-setincoming-method.json`、`native-bridge-setapp-method.json`、`native-bridge-setincoming-references.json`、`touch-service-exchange-method.json`。

`evidence-index.json`提供上述文件哈希及大小。原shellproc研究封装的来源关联见上层目录既有`shellproc-probe-provenance.json`，其解码类不代表可安装原软件或完整业务代码。

```sh
export JAVA_HOME=/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home
export REA_JADX_MCP_JAR="$PWD/tools/rea/engines/jadx-headless-mcp-0.7.1-all.jar"
REA_CLI="$PWD/tools/rea/runtime/node_modules/.bin/rea"
"$REA_CLI" inspect-android-method "$PWD/research/target.apk" moe.heroman.eventtest.shellprocess.touchcontroller.PointersState update --format json
"$REA_CLI" inspect-android-method "$PWD/research/target.apk" moe.heroman.eventtest.shellprocess.touchcontroller.Pointer setPos --format json
python3 research/joystick/scan_dex_and_native.py
```
