"""Read-only static evidence: declared DEX string/method tables plus ELF symbol clues."""
from pathlib import Path
import hashlib, json, re, struct, zipfile

ROOT = Path(__file__).resolve().parents[2]
APK = ROOT / "酷凡游戏厅26.1.17.apk.1"
OUT = Path(__file__).resolve().parent
KEYWORDS = re.compile(r"joystick|trajectory|random|interpolat|bezier|angle|radius|noise|nextDouble|nextFloat|nextGaussian|atan2|hypot|sin\b|cos\b", re.I)

def dex_inventory(data, entry):
    def u32(offset): return struct.unpack_from("<I", data, offset)[0]
    def leb(pos):
        value, shift = 0, 0
        for _ in range(5):
            byte = data[pos]; pos += 1; value |= (byte & 127) << shift
            if byte < 128: return value, pos
            shift += 7
        raise ValueError("invalid ULEB128")
    strings = []
    string_count, string_offset = u32(0x38), u32(0x3c)
    for index in range(string_count):
        pos = u32(string_offset + index * 4)
        for _ in range(5):
            byte = data[pos]; pos += 1
            if byte < 128: break
        end = data.index(b"\0", pos)
        strings.append(data[pos:end].decode("utf-8", "replace"))
    types = [strings[u32(u32(0x44) + i * 4)] for i in range(u32(0x40))]
    methods = []
    for i in range(u32(0x58)):
        class_id, proto_id, name_id = struct.unpack_from("<HHI", data, u32(0x5c) + i * 8)
        methods.append({"declaring_type": types[class_id], "name": strings[name_id], "method_id_index": i, "proto_id": proto_id})
    classes = [types[u32(u32(0x64) + i * 32)] for i in range(u32(0x60))]
    constants = []
    for i in range(u32(0x60)):
        class_def = u32(0x64) + i * 32
        if types[u32(class_def)] != "Lmoe/heroman/eventtest/shellprocess/touchcontroller/PointersState;": continue
        pos = u32(class_def + 24)
        counts = []
        for _ in range(4):
            count, pos = leb(pos); counts.append(count)
        field_ids, field_index = [], 0
        for _ in range(counts[0]):
            delta, pos = leb(pos); access, pos = leb(pos); field_index += delta; field_ids.append(field_index)
        values = u32(class_def + 28)
        if not values: continue
        count, pos = leb(values)
        for field_id in field_ids[:count]:
            header = data[pos]; pos += 1; kind, arg = header & 31, header >> 5
            size = arg + 1; raw = data[pos:pos + size]; pos += size
            if kind == 0x10:
                bits = int.from_bytes(raw, "little") << ((4 - size) * 8)
                value = struct.unpack("<f", struct.pack("<I", bits))[0]
            elif kind == 0x04: value = int.from_bytes(raw, "little", signed=True)
            else: raise ValueError("Unexpected PointersState static value type")
            class_id, type_id, name_id = struct.unpack_from("<HHI", data, u32(0x54) + field_id * 8)
            constants.append({"field": strings[name_id], "type": types[type_id], "value": value, "encoded_value_hex": bytes([header]).hex() + raw.hex()})
    return {"entry": entry, "bytes": len(data), "declared_dex_file_size": u32(0x20), "sha256": hashlib.sha256(data).hexdigest(),
            "declared_string_count": len(strings), "declared_method_count": len(methods), "declared_class_def_count": len(classes),
            "defined_classes": classes, "matching_strings": [s for s in strings if KEYWORDS.search(s)],
            "matching_method_references": [m for m in methods if KEYWORDS.search(m["declaring_type"] + m["name"])],
            "pointers_state_static_constants": constants,
            "limitations": ["Referenced methods are table entries, not proof of invocation or joystick logic.", "Only declared DEX tables parsed; protected/appended contents are not decoded."]}

def elf_symbols(data):
    # ELF64 little-endian section headers; return defined/exported dynamic symbols only.
    if data[:6] != b"\x7fELF\x02\x01": return []
    section_offset = struct.unpack_from("<Q", data, 0x28)[0]
    entry_size, count = struct.unpack_from("<HH", data, 0x3a)
    sections = [struct.unpack_from("<IIQQQQIIQQ", data, section_offset + entry_size * i) for i in range(count)]
    symbols = []
    for section in sections:
        if section[1] != 11: continue  # SHT_DYNSYM
        strings_section = sections[section[6]]
        strings = data[strings_section[4]:strings_section[4] + strings_section[5]]
        for pos in range(section[4], section[4] + section[5], section[9] or 24):
            name, info, other, shndx, value, size = struct.unpack_from("<IBBHQQ", data, pos)
            if name == 0: continue
            end = strings.find(b"\0", name)
            text = strings[name:end].decode("utf-8", "replace")
            symbols.append({"name": text, "defined": shndx != 0, "binding": info >> 4, "type": info & 15})
    return symbols

with zipfile.ZipFile(APK) as archive:
    result = {"operation": "read_only_declared_dex_tables_and_elf_symbols", "source_apk": str(APK), "apk_sha256": hashlib.sha256(APK.read_bytes()).hexdigest(),
              "dex": [dex_inventory(archive.read(name), name) for name in ["classes.dex", "lib/arm64-v8a/libshellproc.so"]]}
    data = archive.read("lib/arm64-v8a/libinput.so")
    strings = [b.decode("ascii") for b in re.findall(rb"[ -~]{5,}", data)]
    symbols = elf_symbols(data)
    result["libinput"] = {"entry": "lib/arm64-v8a/libinput.so", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                          "dynamic_symbols": symbols, "selected_ascii_strings": sorted(set(s for s in strings if (KEYWORDS.search(s) and "demangle" not in s) or s.startswith("Java_moe_heroman") or "/dev/input" in s)),
                          "prng_and_math_symbol_matches": [s for s in symbols if re.fullmatch(r"(rand|srand|random|srandom|drand48|sin|sinf|cos|cosf|atan2|atan2f|hypot|hypotf)", s["name"])],
                          "limitations": ["No ELF disassembly or runtime capture. Absent keywords do not prove absence of a hidden or stripped algorithm."]}
    result["coverage"] = "complete for declared DEX table rows and ELF64 dynamic-symbol sections; limited ASCII keyword projection"
    (OUT / "dex-native-inventory.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps({"dex": [{k: v for k, v in d.items() if k not in ["defined_classes", "limitations"]} for d in result["dex"]],
                      "libinput": {"dynamic_symbol_count": len(symbols), "selected_ascii_strings": result["libinput"]["selected_ascii_strings"]}}, ensure_ascii=False, indent=2))
