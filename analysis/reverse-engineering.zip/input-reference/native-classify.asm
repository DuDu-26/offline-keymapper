
research/target-resources/lib/arm64-v8a/libinput.so:	file format elf64-littleaarch64

Disassembly of section .text:

000000000002a5d8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative>:
   2a5d8:      	sub	sp, sp, #0xb0
   2a5dc:      	stp	x29, x30, [sp, #0x70]
   2a5e0:      	stp	x24, x23, [sp, #0x80]
   2a5e4:      	stp	x22, x21, [sp, #0x90]
   2a5e8:      	stp	x20, x19, [sp, #0xa0]
   2a5ec:      	add	x29, sp, #0x70
   2a5f0:      	mrs	x23, TPIDR_EL0
   2a5f4:      	movi	v0.2d, #0000000000000000
   2a5f8:      	mov	x20, x1
   2a5fc:      	ldr	x8, [x23, #0x28]
   2a600:      	mov	x19, x0
   2a604:      	stur	x8, [x29, #-0x8]
   2a608:      	ldr	x8, [x0]
   2a60c:      	stur	xzr, [x29, #-0x10]
   2a610:      	stp	q0, q0, [sp]
   2a614:      	ldr	x8, [x8, #0xf8]
   2a618:      	stp	q0, q0, [sp, #0x20]
   2a61c:      	stp	q0, q0, [sp, #0x40]
   2a620:      	blr	x8
   2a624:      	cbz	x0, 0x2a744 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x16c>
   2a628:      	ldr	x8, [x19]
   2a62c:      	mov	x1, x0
   2a630:      	adrp	x2, 0x1a000
   2a634:      	add	x2, x2, #0x8e7
   2a638:      	adrp	x3, 0x1a000
   2a63c:      	add	x3, x3, #0x110
   2a640:      	ldr	x8, [x8, #0x2f0]
   2a644:      	mov	x0, x19
   2a648:      	blr	x8
   2a64c:      	cbz	x0, 0x2a744 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x16c>
   2a650:      	ldr	x8, [x19]
   2a654:      	mov	x2, x0
   2a658:      	mov	x0, x19
   2a65c:      	mov	x1, x20
   2a660:      	ldr	x8, [x8, #0x2f8]
   2a664:      	blr	x8
   2a668:      	cbz	x0, 0x2a744 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x16c>
   2a66c:      	ldr	x8, [x19]
   2a670:      	mov	x20, x0
   2a674:      	mov	x0, x19
   2a678:      	mov	x1, x20
   2a67c:      	mov	x2, xzr
   2a680:      	ldr	x8, [x8, #0x548]
   2a684:      	blr	x8
   2a688:      	cbz	x0, 0x2a744 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x16c>
   2a68c:      	mov	w1, wzr
   2a690:      	mov	x21, x0
   2a694:      	bl	0x5a6d0 <__open_2@plt>
   2a698:      	cmn	w0, #0x1
   2a69c:      	b.eq	0x2a740 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x168>
   2a6a0:      	mov	w1, #0x4520             // =17696
   2a6a4:      	sub	x2, x29, #0x10
   2a6a8:      	mov	w22, w0
   2a6ac:      	movk	w1, #0x8008, lsl #16
   2a6b0:      	bl	0x5a6e0 <ioctl@plt>
   2a6b4:      	tbnz	w0, #0x1f, 0x2a714 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x13c>
   2a6b8:      	ldurb	w8, [x29, #-0x10]
   2a6bc:      	tbz	w8, #0x1, 0x2a714 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x13c>
   2a6c0:      	mov	w1, #0x4521             // =17697
   2a6c4:      	mov	x2, sp
   2a6c8:      	mov	w0, w22
   2a6cc:      	movk	w1, #0x8060, lsl #16
   2a6d0:      	mov	x24, sp
   2a6d4:      	bl	0x5a6e0 <ioctl@plt>
   2a6d8:      	tbnz	w0, #0x1f, 0x2a714 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x13c>
   2a6dc:      	mov	x8, xzr
   2a6e0:      	nop
   2a6e4:      	adr	x9, 0x1c0e0
   2a6e8:      	ldrsw	x10, [x9, x8]
   2a6ec:      	lsr	x11, x10, #3
   2a6f0:      	and	x11, x11, #0x1ffffffffffffff8
   2a6f4:      	ldr	x11, [x24, x11]
   2a6f8:      	lsr	x10, x11, x10
   2a6fc:      	tbz	w10, #0x0, 0x2a714 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x13c>
   2a700:      	add	x8, x8, #0x4
   2a704:      	cmp	x8, #0x50
   2a708:      	b.ne	0x2a6e8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x110>
   2a70c:      	mov	w24, #0x1               // =1
   2a710:      	b	0x2a718 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x140>
   2a714:      	mov	w24, wzr
   2a718:      	mov	w0, w22
   2a71c:      	bl	0x5a6f0 <close@plt>
   2a720:      	ldr	x8, [x19]
   2a724:      	mov	x0, x19
   2a728:      	mov	x1, x20
   2a72c:      	mov	x2, x21
   2a730:      	ldr	x8, [x8, #0x550]
   2a734:      	blr	x8
   2a738:      	mov	w0, w24
   2a73c:      	b	0x2a744 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x16c>
   2a740:      	mov	w0, wzr
   2a744:      	ldr	x8, [x23, #0x28]
   2a748:      	ldur	x9, [x29, #-0x8]
   2a74c:      	cmp	x8, x9
   2a750:      	b.ne	0x2a76c <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsKeyboardDeviceNative+0x194>
   2a754:      	ldp	x20, x19, [sp, #0xa0]
   2a758:      	ldp	x22, x21, [sp, #0x90]
   2a75c:      	ldp	x24, x23, [sp, #0x80]
   2a760:      	ldp	x29, x30, [sp, #0x70]
   2a764:      	add	sp, sp, #0xb0
   2a768:      	ret
   2a76c:      	bl	0x5a700 <__stack_chk_fail@plt>

000000000002a770 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative>:
   2a770:      	sub	sp, sp, #0xc0
   2a774:      	stp	x29, x30, [sp, #0x80]
   2a778:      	stp	x24, x23, [sp, #0x90]
   2a77c:      	stp	x22, x21, [sp, #0xa0]
   2a780:      	stp	x20, x19, [sp, #0xb0]
   2a784:      	add	x29, sp, #0x80
   2a788:      	mrs	x23, TPIDR_EL0
   2a78c:      	movi	v0.2d, #0000000000000000
   2a790:      	mov	x20, x1
   2a794:      	ldr	x8, [x23, #0x28]
   2a798:      	mov	x19, x0
   2a79c:      	stur	x8, [x29, #-0x8]
   2a7a0:      	ldr	x8, [x0]
   2a7a4:      	stp	xzr, xzr, [x29, #-0x18]
   2a7a8:      	stp	q0, q0, [sp]
   2a7ac:      	ldr	x8, [x8, #0xf8]
   2a7b0:      	stp	q0, q0, [sp, #0x20]
   2a7b4:      	stp	q0, q0, [sp, #0x40]
   2a7b8:      	blr	x8
   2a7bc:      	cbz	x0, 0x2a8dc <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x16c>
   2a7c0:      	ldr	x8, [x19]
   2a7c4:      	mov	x1, x0
   2a7c8:      	adrp	x2, 0x1a000
   2a7cc:      	add	x2, x2, #0x8e7
   2a7d0:      	adrp	x3, 0x1a000
   2a7d4:      	add	x3, x3, #0x110
   2a7d8:      	ldr	x8, [x8, #0x2f0]
   2a7dc:      	mov	x0, x19
   2a7e0:      	blr	x8
   2a7e4:      	cbz	x0, 0x2a8dc <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x16c>
   2a7e8:      	ldr	x8, [x19]
   2a7ec:      	mov	x2, x0
   2a7f0:      	mov	x0, x19
   2a7f4:      	mov	x1, x20
   2a7f8:      	ldr	x8, [x8, #0x2f8]
   2a7fc:      	blr	x8
   2a800:      	cbz	x0, 0x2a8dc <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x16c>
   2a804:      	ldr	x8, [x19]
   2a808:      	mov	x20, x0
   2a80c:      	mov	x0, x19
   2a810:      	mov	x1, x20
   2a814:      	mov	x2, xzr
   2a818:      	ldr	x8, [x8, #0x548]
   2a81c:      	blr	x8
   2a820:      	cbz	x0, 0x2a8dc <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x16c>
   2a824:      	mov	w1, wzr
   2a828:      	mov	x21, x0
   2a82c:      	bl	0x5a6d0 <__open_2@plt>
   2a830:      	cmn	w0, #0x1
   2a834:      	b.eq	0x2a8d8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x168>
   2a838:      	mov	w1, #0x4520             // =17696
   2a83c:      	mov	w24, #0x4520            // =17696
   2a840:      	sub	x2, x29, #0x10
   2a844:      	movk	w1, #0x8008, lsl #16
   2a848:      	mov	w22, w0
   2a84c:      	movk	w24, #0x8008, lsl #16
   2a850:      	bl	0x5a6e0 <ioctl@plt>
   2a854:      	tbnz	w0, #0x1f, 0x2a8ac <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x13c>
   2a858:      	ldur	w8, [x29, #-0x10]
   2a85c:      	mvn	w8, w8
   2a860:      	tst	x8, #0x6
   2a864:      	b.ne	0x2a8ac <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x13c>
   2a868:      	add	w1, w24, #0x2
   2a86c:      	sub	x2, x29, #0x18
   2a870:      	mov	w0, w22
   2a874:      	bl	0x5a6e0 <ioctl@plt>
   2a878:      	tbnz	w0, #0x1f, 0x2a8ac <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x13c>
   2a87c:      	mov	w1, #0x4521             // =17697
   2a880:      	mov	x2, sp
   2a884:      	mov	w0, w22
   2a888:      	movk	w1, #0x8060, lsl #16
   2a88c:      	bl	0x5a6e0 <ioctl@plt>
   2a890:      	tbnz	w0, #0x1f, 0x2a8ac <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x13c>
   2a894:      	ldur	w8, [x29, #-0x18]
   2a898:      	mvn	w8, w8
   2a89c:      	tst	x8, #0x3
   2a8a0:      	b.ne	0x2a8ac <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x13c>
   2a8a4:      	ldr	x8, [sp, #0x20]
   2a8a8:      	tbnz	w8, #0x10, 0x2a904 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x194>
   2a8ac:      	mov	w24, wzr
   2a8b0:      	mov	w0, w22
   2a8b4:      	bl	0x5a6f0 <close@plt>
   2a8b8:      	ldr	x8, [x19]
   2a8bc:      	mov	x0, x19
   2a8c0:      	mov	x1, x20
   2a8c4:      	mov	x2, x21
   2a8c8:      	ldr	x8, [x8, #0x550]
   2a8cc:      	blr	x8
   2a8d0:      	mov	w0, w24
   2a8d4:      	b	0x2a8dc <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x16c>
   2a8d8:      	mov	w0, wzr
   2a8dc:      	ldr	x8, [x23, #0x28]
   2a8e0:      	ldur	x9, [x29, #-0x8]
   2a8e4:      	cmp	x8, x9
   2a8e8:      	b.ne	0x2a90c <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x19c>
   2a8ec:      	ldp	x20, x19, [sp, #0xb0]
   2a8f0:      	ldp	x22, x21, [sp, #0xa0]
   2a8f4:      	ldp	x24, x23, [sp, #0x90]
   2a8f8:      	ldp	x29, x30, [sp, #0x80]
   2a8fc:      	add	sp, sp, #0xc0
   2a900:      	ret
   2a904:      	ubfx	w24, w8, #17, #1
   2a908:      	b	0x2a8b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_checkIsMouseDeviceNative+0x140>
   2a90c:      	bl	0x5a700 <__stack_chk_fail@plt>
