
research/target-resources/lib/arm64-v8a/libinput.so:	file format elf64-littleaarch64

Disassembly of section .text:

000000000002ae24 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative>:
   2b658:      	sub	sp, sp, #0x80
   2b65c:      	stp	x29, x30, [sp, #0x30]
   2b660:      	str	x25, [sp, #0x40]
   2b664:      	stp	x24, x23, [sp, #0x50]
   2b668:      	stp	x22, x21, [sp, #0x60]
   2b66c:      	stp	x20, x19, [sp, #0x70]
   2b670:      	add	x29, sp, #0x30
   2b674:      	mrs	x25, TPIDR_EL0
   2b678:      	mov	x20, x1
   2b67c:      	mov	x22, x0
   2b680:      	ldr	x8, [x25, #0x28]
   2b684:      	add	x0, x0, #0x18
   2b688:      	mov	x1, x2
   2b68c:      	mov	w24, w4
   2b690:      	mov	x23, x3
   2b694:      	mov	x19, x2
   2b698:      	stur	x8, [x29, #-0x8]
   2b69c:      	bl	0x2bf0c <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x10e8>
   2b6a0:      	add	x8, x22, #0x20
   2b6a4:      	cmp	x8, x0
   2b6a8:      	b.ne	0x2b800 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x9dc>
   2b6ac:      	ldrb	w8, [x19]
   2b6b0:      	ldr	x9, [x19, #0x10]
   2b6b4:      	mov	w1, wzr
   2b6b8:      	tst	w8, #0x1
   2b6bc:      	csinc	x0, x9, x19, ne
   2b6c0:      	bl	0x5a6d0 <__open_2@plt>
   2b6c4:      	cmn	w0, #0x1
   2b6c8:      	b.eq	0x2b800 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x9dc>
   2b6cc:      	mov	w1, #0x4590             // =17808
   2b6d0:      	mov	w2, #0x1                // =1
   2b6d4:      	mov	w21, w0
   2b6d8:      	movk	w1, #0x4004, lsl #16
   2b6dc:      	bl	0x5a6e0 <ioctl@plt>
   2b6e0:      	cmn	w0, #0x1
   2b6e4:      	b.eq	0x2b7c4 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x9a0>
   2b6e8:      	ldr	x8, [x20]
   2b6ec:      	ldr	x8, [x8, #0x2f8]
   2b6f0:      	tbz	w24, #0x0, 0x2b764 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x940>
   2b6f4:      	ldr	x2, [x22, #0x58]
   2b6f8:      	mov	x0, x20
   2b6fc:      	mov	x1, x23
   2b700:      	blr	x8
   2b704:      	cbz	x0, 0x2b7b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x98c>
   2b708:      	ldr	x8, [x20]
   2b70c:      	mov	x1, x0
   2b710:      	mov	x0, x20
   2b714:      	ldr	x8, [x8, #0xa8]
   2b718:      	blr	x8
   2b71c:      	cbz	x0, 0x2b7b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x98c>
   2b720:      	mov	w1, #0x4523             // =17699
   2b724:      	mov	x24, x0
   2b728:      	add	x2, sp, #0x18
   2b72c:      	mov	w0, w21
   2b730:      	movk	w1, #0x8008, lsl #16
   2b734:      	str	xzr, [sp, #0x18]
   2b738:      	bl	0x5a6e0 <ioctl@plt>
   2b73c:      	tbnz	w0, #0x1f, 0x2b748 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x924>
   2b740:      	ldrb	w8, [sp, #0x1d]
   2b744:      	tbnz	w8, #0x7, 0x2b82c <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0xa08>
   2b748:      	mov	w0, #0x6b8              // =1720
   2b74c:      	bl	0x5a720 <_Znwm@plt>
   2b750:      	ldp	x2, x3, [x22, #0x40]
   2b754:      	mov	x23, x0
   2b758:      	mov	x1, x24
   2b75c:      	bl	0x2d2b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x248c>
   2b760:      	b	0x2b844 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0xa20>
   2b764:      	ldr	x2, [x22, #0x50]
   2b768:      	mov	x0, x20
   2b76c:      	mov	x1, x23
   2b770:      	blr	x8
   2b774:      	cbz	x0, 0x2b7b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x98c>
   2b778:      	ldr	x8, [x20]
   2b77c:      	mov	x1, x0
   2b780:      	mov	x0, x20
   2b784:      	ldr	x8, [x8, #0xa8]
   2b788:      	blr	x8
   2b78c:      	cbz	x0, 0x2b7b0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x98c>
   2b790:      	mov	x24, x0
   2b794:      	mov	w0, #0x528              // =1320
   2b798:      	bl	0x5a720 <_Znwm@plt>
   2b79c:      	ldp	x2, x3, [x22, #0x30]
   2b7a0:      	mov	x23, x0
   2b7a4:      	mov	x1, x24
   2b7a8:      	bl	0x2c834 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x1a10>
   2b7ac:      	b	0x2b844 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0xa20>
   2b7b0:      	mov	w1, #0x4590             // =17808
   2b7b4:      	mov	w0, w21
   2b7b8:      	mov	w2, wzr
   2b7bc:      	movk	w1, #0x4004, lsl #16
   2b7c0:      	bl	0x5a6e0 <ioctl@plt>
   2b7c4:      	mov	w0, w21
   2b7c8:      	bl	0x5a6f0 <close@plt>
   2b7cc:      	adrp	x4, 0x1a000
   2b7d0:      	add	x4, x4, #0x3e5
   2b7d4:      	ldrb	w8, [x19]
   2b7d8:      	ldr	x9, [x19, #0x10]
   2b7dc:      	add	x10, x19, #0x1
   2b7e0:      	nop
   2b7e4:      	adr	x1, 0x1a700
   2b7e8:      	adrp	x2, 0x1b000
   2b7ec:      	add	x2, x2, #0xc91
   2b7f0:      	tst	w8, #0x1
   2b7f4:      	mov	w0, #0x3                // =3
   2b7f8:      	csel	x3, x10, x9, eq
   2b7fc:      	bl	0x5a6c0 <__android_log_print@plt>
   2b800:      	ldr	x8, [x25, #0x28]
   2b804:      	ldur	x9, [x29, #-0x8]
   2b808:      	cmp	x8, x9
   2b80c:      	b.ne	0x2b938 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0xb14>
   2b810:      	ldp	x20, x19, [sp, #0x70]
   2b814:      	ldr	x25, [sp, #0x40]
   2b818:      	ldp	x22, x21, [sp, #0x60]
   2b81c:      	ldp	x24, x23, [sp, #0x50]
   2b820:      	ldp	x29, x30, [sp, #0x30]
   2b824:      	add	sp, sp, #0x80
   2b828:      	ret
   2b82c:      	mov	w0, #0x5e0              // =1504
   2b830:      	bl	0x5a720 <_Znwm@plt>
   2b834:      	ldp	x2, x3, [x22, #0x40]
   2b838:      	mov	x23, x0
   2b83c:      	mov	x1, x24
   2b840:      	bl	0x2ca94 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x1c70>
