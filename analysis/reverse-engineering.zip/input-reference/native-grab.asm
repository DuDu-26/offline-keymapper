
research/target-resources/lib/arm64-v8a/libinput.so:	file format elf64-littleaarch64

Disassembly of section .text:

000000000002aab0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative>:
   2aab0:      	sub	sp, sp, #0x80
   2aab4:      	stp	x29, x30, [sp, #0x20]
   2aab8:      	stp	x28, x27, [sp, #0x30]
   2aabc:      	stp	x26, x25, [sp, #0x40]
   2aac0:      	stp	x24, x23, [sp, #0x50]
   2aac4:      	stp	x22, x21, [sp, #0x60]
   2aac8:      	stp	x20, x19, [sp, #0x70]
   2aacc:      	add	x29, sp, #0x20
   2aad0:      	mrs	x28, TPIDR_EL0
   2aad4:      	mov	w24, w3
   2aad8:      	mov	w25, w2
   2aadc:      	ldr	x8, [x28, #0x28]
   2aae0:      	mov	x19, x0
   2aae4:      	mov	x23, x1
   2aae8:      	stur	x8, [x29, #-0x8]
   2aaec:      	ldr	x8, [x0]
   2aaf0:      	ldr	x8, [x8, #0xf8]
   2aaf4:      	blr	x8
   2aaf8:      	cbz	x0, 0x2ad00 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x250>
   2aafc:      	ldr	x8, [x19]
   2ab00:      	mov	x20, x0
   2ab04:      	adrp	x2, 0x1a000
   2ab08:      	add	x2, x2, #0x8e7
   2ab0c:      	adrp	x3, 0x1a000
   2ab10:      	add	x3, x3, #0x110
   2ab14:      	ldr	x8, [x8, #0x2f0]
   2ab18:      	mov	x0, x19
   2ab1c:      	mov	x1, x20
   2ab20:      	blr	x8
   2ab24:      	cbz	x0, 0x2acec <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x23c>
   2ab28:      	ldr	x8, [x19]
   2ab2c:      	mov	x2, x0
   2ab30:      	mov	x0, x19
   2ab34:      	mov	x1, x23
   2ab38:      	ldr	x8, [x8, #0x2f8]
   2ab3c:      	blr	x8
   2ab40:      	cbz	x0, 0x2acec <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x23c>
   2ab44:      	ldr	x8, [x19]
   2ab48:      	mov	x21, x0
   2ab4c:      	mov	x0, x19
   2ab50:      	mov	x1, x21
   2ab54:      	mov	x2, xzr
   2ab58:      	ldr	x8, [x8, #0x548]
   2ab5c:      	blr	x8
   2ab60:      	cbz	x0, 0x2acd8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x228>
   2ab64:      	nop
   2ab68:      	adr	x8, 0x67e28
   2ab6c:      	mov	x22, x0
   2ab70:      	ldarb	w8, [x8]
   2ab74:      	tst	w25, #0xff
   2ab78:      	b.eq	0x2abb4 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x104>
   2ab7c:      	tbz	w8, #0x0, 0x2ad48 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x298>
   2ab80:      	mov	x0, x22
   2ab84:      	bl	0x5a710 <strlen@plt>
   2ab88:      	cmn	x0, #0x8
   2ab8c:      	b.hs	0x2ad30 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x280>
   2ab90:      	mov	x25, x0
   2ab94:      	cmp	x0, #0x17
   2ab98:      	b.hs	0x2abec <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x13c>
   2ab9c:      	lsl	w8, w25, #1
   2aba0:      	mov	x9, sp
   2aba4:      	orr	x26, x9, #0x1
   2aba8:      	strb	w8, [sp]
   2abac:      	cbnz	x25, 0x2ac1c <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x16c>
   2abb0:      	b	0x2ac2c <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x17c>
   2abb4:      	tbz	w8, #0x0, 0x2ad90 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x2e0>
   2abb8:      	mov	x0, x22
   2abbc:      	bl	0x5a710 <strlen@plt>
   2abc0:      	cmn	x0, #0x8
   2abc4:      	b.hs	0x2ad30 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x280>
   2abc8:      	mov	x23, x0
   2abcc:      	cmp	x0, #0x17
   2abd0:      	b.hs	0x2ac58 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x1a8>
   2abd4:      	lsl	w8, w23, #1
   2abd8:      	mov	x9, sp
   2abdc:      	orr	x24, x9, #0x1
   2abe0:      	strb	w8, [sp]
   2abe4:      	cbnz	x23, 0x2ac88 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x1d8>
   2abe8:      	b	0x2ac98 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x1e8>
   2abec:      	and	x8, x25, #0xfffffffffffffff8
   2abf0:      	orr	x9, x25, #0x7
   2abf4:      	add	x8, x8, #0x8
   2abf8:      	cmp	x9, #0x17
   2abfc:      	csel	x8, x8, x9, eq
   2ac00:      	add	x27, x8, #0x1
   2ac04:      	mov	x0, x27
   2ac08:      	bl	0x5a720 <_Znwm@plt>
   2ac0c:      	orr	x8, x27, #0x1
   2ac10:      	mov	x26, x0
   2ac14:      	stp	x25, x0, [sp, #0x8]
   2ac18:      	str	x8, [sp]
   2ac1c:      	mov	x0, x26
   2ac20:      	mov	x1, x22
   2ac24:      	mov	x2, x25
   2ac28:      	bl	0x5a730 <memmove@plt>
   2ac2c:      	and	w8, w24, #0xff
   2ac30:      	strb	wzr, [x26, x25]
   2ac34:      	cmp	w8, #0x1
   2ac38:      	cset	w4, eq
   2ac3c:      	nop
   2ac40:      	adr	x0, 0x67dc8
   2ac44:      	mov	x2, sp
   2ac48:      	mov	x1, x19
   2ac4c:      	mov	x3, x23
   2ac50:      	bl	0x2b658 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x834>
   2ac54:      	b	0x2acb0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x200>
   2ac58:      	and	x8, x23, #0xfffffffffffffff8
   2ac5c:      	orr	x9, x23, #0x7
   2ac60:      	add	x8, x8, #0x8
   2ac64:      	cmp	x9, #0x17
   2ac68:      	csel	x8, x8, x9, eq
   2ac6c:      	add	x25, x8, #0x1
   2ac70:      	mov	x0, x25
   2ac74:      	bl	0x5a720 <_Znwm@plt>
   2ac78:      	orr	x8, x25, #0x1
   2ac7c:      	mov	x24, x0
   2ac80:      	stp	x23, x0, [sp, #0x8]
   2ac84:      	str	x8, [sp]
   2ac88:      	mov	x0, x24
   2ac8c:      	mov	x1, x22
   2ac90:      	mov	x2, x23
   2ac94:      	bl	0x5a730 <memmove@plt>
   2ac98:      	strb	wzr, [x24, x23]
   2ac9c:      	nop
   2aca0:      	adr	x0, 0x67dc8
   2aca4:      	mov	x2, sp
   2aca8:      	mov	x1, x19
   2acac:      	bl	0x2b93c <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0xb18>
   2acb0:      	ldrb	w8, [sp]
   2acb4:      	tbz	w8, #0x0, 0x2acc0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x210>
   2acb8:      	ldr	x0, [sp, #0x10]
   2acbc:      	bl	0x5a740 <_ZdlPv@plt>
   2acc0:      	ldr	x8, [x19]
   2acc4:      	mov	x0, x19
   2acc8:      	mov	x1, x21
   2accc:      	mov	x2, x22
   2acd0:      	ldr	x8, [x8, #0x550]
   2acd4:      	blr	x8
   2acd8:      	ldr	x8, [x19]
   2acdc:      	mov	x0, x19
   2ace0:      	mov	x1, x21
   2ace4:      	ldr	x8, [x8, #0xb8]
   2ace8:      	blr	x8
   2acec:      	ldr	x8, [x19]
   2acf0:      	mov	x0, x19
   2acf4:      	mov	x1, x20
   2acf8:      	ldr	x8, [x8, #0xb8]
   2acfc:      	blr	x8
   2ad00:      	ldr	x8, [x28, #0x28]
   2ad04:      	ldur	x9, [x29, #-0x8]
   2ad08:      	cmp	x8, x9
   2ad0c:      	b.ne	0x2ae20 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x370>
   2ad10:      	ldp	x20, x19, [sp, #0x70]
   2ad14:      	ldp	x22, x21, [sp, #0x60]
   2ad18:      	ldp	x24, x23, [sp, #0x50]
   2ad1c:      	ldp	x26, x25, [sp, #0x40]
   2ad20:      	ldp	x28, x27, [sp, #0x30]
   2ad24:      	ldp	x29, x30, [sp, #0x20]
   2ad28:      	add	sp, sp, #0x80
   2ad2c:      	ret
   2ad30:      	ldr	x8, [x28, #0x28]
   2ad34:      	ldur	x9, [x29, #-0x8]
   2ad38:      	cmp	x8, x9
   2ad3c:      	b.ne	0x2ae20 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x370>
   2ad40:      	mov	x0, sp
   2ad44:      	bl	0x2afe0 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x1bc>
   2ad48:      	nop
   2ad4c:      	adr	x0, 0x67e28
   2ad50:      	bl	0x5a750 <__cxa_guard_acquire@plt>
   2ad54:      	cbz	w0, 0x2ab80 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0xd0>
   2ad58:      	nop
   2ad5c:      	adr	x0, 0x67dc8
   2ad60:      	bl	0x2b320 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x4fc>
   2ad64:      	adrp	x0, 0x63000 <_ZTISt10bad_typeid+0x28c0>
   2ad68:      	nop
   2ad6c:      	adr	x1, 0x67dc8
   2ad70:      	ldr	x0, [x0, #0x448]
   2ad74:      	nop
   2ad78:      	adr	x2, 0x5f380
   2ad7c:      	bl	0x5a6a0 <__cxa_atexit@plt>
   2ad80:      	nop
   2ad84:      	adr	x0, 0x67e28
   2ad88:      	bl	0x5a760 <__cxa_guard_release@plt>
   2ad8c:      	b	0x2ab80 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0xd0>
   2ad90:      	nop
   2ad94:      	adr	x0, 0x67e28
   2ad98:      	bl	0x5a750 <__cxa_guard_acquire@plt>
   2ad9c:      	cbz	w0, 0x2abb8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x108>
   2ada0:      	nop
   2ada4:      	adr	x0, 0x67dc8
   2ada8:      	bl	0x2b320 <Java_moe_heroman_eventtest_shellprocess_InputDevice_getAbsMaxValueNative+0x4fc>
   2adac:      	adrp	x0, 0x63000 <_ZTISt10bad_typeid+0x28c0>
   2adb0:      	nop
   2adb4:      	adr	x1, 0x67dc8
   2adb8:      	ldr	x0, [x0, #0x448]
   2adbc:      	nop
   2adc0:      	adr	x2, 0x5f380
   2adc4:      	bl	0x5a6a0 <__cxa_atexit@plt>
   2adc8:      	nop
   2adcc:      	adr	x0, 0x67e28
   2add0:      	bl	0x5a760 <__cxa_guard_release@plt>
   2add4:      	b	0x2abb8 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x108>
   2add8:      	b	0x2addc <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x32c>
   2addc:      	mov	x19, x0
   2ade0:      	nop
   2ade4:      	adr	x0, 0x67e28
   2ade8:      	bl	0x5a770 <__cxa_guard_abort@plt>
   2adec:      	b	0x2ae08 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x358>
   2adf0:      	b	0x2adf4 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x344>
   2adf4:      	ldrb	w8, [sp]
   2adf8:      	mov	x19, x0
   2adfc:      	tbz	w8, #0x0, 0x2ae08 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x358>
   2ae00:      	ldr	x0, [sp, #0x10]
   2ae04:      	bl	0x5a740 <_ZdlPv@plt>
   2ae08:      	ldr	x8, [x28, #0x28]
   2ae0c:      	ldur	x9, [x29, #-0x8]
   2ae10:      	cmp	x8, x9
   2ae14:      	b.ne	0x2ae20 <Java_moe_heroman_eventtest_shellprocess_InputDevice_setGrabbingEventNative+0x370>
   2ae18:      	mov	x0, x19
   2ae1c:      	bl	0x567dc <__emutls_get_address+0x9ec>
   2ae20:      	bl	0x5a700 <__stack_chk_fail@plt>
