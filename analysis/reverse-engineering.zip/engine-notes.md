# Root 键鼠引擎实现与核验

KeySync 本地 clone 位于 `research/keysync`，许可为 Apache 2.0。其输入来源为可聚焦浮窗的 Android KeyEvent 与 captured-pointer MotionEvent，再通过 Shizuku InputManager Binder 注入。没有 evdev 抓取或 EVIOCGRAB，不能把服务改为 su 启动即获得 root 输入独占。其 EventManager 同时使用 downTime 作为 eventTime，不宜直接复用。当前实现独立编写，没有复制它的界面、动画、随机或反检测代码。

当前链路：应用 RootBridge → su app_process RootDaemon → JNI evdev → MappingEngine → InputManager。只使用 USB/蓝牙 bus 且具备字母键盘或相对鼠标能力的节点；排除触屏、内部 power-only 与虚拟输入节点。全功能外接键盘上的音量/电源键转发正常系统按键。不会改动 SELinux、系统权限或设置。

触点统一共享手势 downTime，eventTime 使用 uptime。最多同时10触点，binding ID 1..20、摇杆30、视角31，抬起事件在删除触点前发出。hold/tap/toggle/repeat/swipe、方向摇杆、视角鼠标均实现。100%坐标限制在屏幕内。F8、pause、设备拔出、SYN_DROPPED、连接关闭会取消触点并释放全部grab。退出进程自动关闭输入fd；断开物理输入后需用户重新开始。

F1 默认切换视角锁定。视角启用且解锁时全部鼠标按钮走普通指针；锁定时已绑定按钮走触控。视角关闭时已绑定按钮走触控，其他按钮走系统鼠标。普通指针包含 HOVER_MOVE、DOWN、BUTTON_PRESS/RELEASE、UP 和 SCROLL，并向应用发送限流游标位置。视角闲时释放保留锁定，idleMs=0关闭闲时释放；超出视角区域时抬起回中，允许持续移动。

Socket 使用随机抽象名称。只接受指定应用UID或root，5秒内以随机token认证；20秒未成功连接自动退出；NDJSON最大128KiB。配置失败会阻止start，直至一次成功配置。进程仅在start独占，pause保留服务但释放键鼠。

2026-10-13 本地构建：Android NDK 27.2.12479018 编译 arm64-v8a、armeabi-v7a、x86_64，启用 -Wall -Wextra -Werror，均通过。`EngineSelfTest` 在 Android33 arm64 模拟器中通过多指action/index、稳定ID与时间、摇杆斜向、连点停止、滑动释放、tap定时、视角闲时与idle0、F8和断连取消、双键盘按键归属、屏幕边界、高灵敏度半径、鼠标动作序列测试。

Android33 模拟器 root peer 通过临时uinput USB探针验证 daemon认证、输入节点过滤、EVIOCGRAB、真实键事件、F8释放、拔出安全暂停与socket断开后进程退出。该测试使用模拟器root shell，不等同于真实手机的su管理器授权、USB/蓝牙兼容性与游戏内验收。最终真实触控接收结果另存 `outputs/root-engine-test.json`。

参考原理：[Android InputManagerGlobal](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/hardware/input/InputManagerGlobal.java)、[Linux输入事件与SYN_DROPPED](https://cdn.kernel.org/doc/html/latest/input/event-codes.html)、[Linux EVIOCGRAB定义](https://github.com/torvalds/linux/blob/master/include/uapi/linux/input.h)。
